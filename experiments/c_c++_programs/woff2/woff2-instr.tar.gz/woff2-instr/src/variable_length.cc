/* Copyright 2015 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

/* Helper functions for woff2 variable length types: 255UInt16 and UIntBase128 */

#include "./variable_length.h"
#include <stdio.h>

namespace woff2 {

size_t Size255UShort(uint16_t value) {
  fprintf(stderr, "[src/variable_length.cc] enter Size255UShort 1\n");
  size_t result = 3;
  if (value < 253) {
    fprintf(stderr, "[src/variable_length.cc] enter Size255UShort 2\n");
    result = 1;
    // fprintf(stderr, "[src/variable_length.cc] exit Size255UShort 2\n");
  } else if (value < 762) {
    fprintf(stderr, "[src/variable_length.cc] enter Size255UShort 3\n");
    result = 2;
    // fprintf(stderr, "[src/variable_length.cc] exit Size255UShort 3\n");
  } else {
    fprintf(stderr, "[src/variable_length.cc] enter Size255UShort 4\n");
    result = 3;
    // fprintf(stderr, "[src/variable_length.cc] exit Size255UShort 4\n");
  }
  return result;
  // fprintf(stderr, "[src/variable_length.cc] exit Size255UShort 1\n");
}

void Write255UShort(std::vector<uint8_t>* out, int value) {
  fprintf(stderr, "[src/variable_length.cc] enter Write255UShort 1\n");
  if (value < 253) {
    fprintf(stderr, "[src/variable_length.cc] enter Write255UShort 2\n");
    out->push_back(value);
    // fprintf(stderr, "[src/variable_length.cc] exit Write255UShort 2\n");
  } else if (value < 506) {
    fprintf(stderr, "[src/variable_length.cc] enter Write255UShort 3\n");
    out->push_back(255);
    out->push_back(value - 253);
    // fprintf(stderr, "[src/variable_length.cc] exit Write255UShort 3\n");
  } else if (value < 762) {
    fprintf(stderr, "[src/variable_length.cc] enter Write255UShort 4\n");
    out->push_back(254);
    out->push_back(value - 506);
    // fprintf(stderr, "[src/variable_length.cc] exit Write255UShort 4\n");
  } else {
    fprintf(stderr, "[src/variable_length.cc] enter Write255UShort 5\n");
    out->push_back(253);
    out->push_back(value >> 8);
    out->push_back(value & 0xff);
    // fprintf(stderr, "[src/variable_length.cc] exit Write255UShort 5\n");
  }
  // fprintf(stderr, "[src/variable_length.cc] exit Write255UShort 1\n");
}

void Store255UShort(int val, size_t* offset, uint8_t* dst) {
  fprintf(stderr, "[src/variable_length.cc] enter Store255UShort 1\n");
  std::vector<uint8_t> packed;
  Write255UShort(&packed, val);
  for (uint8_t packed_byte : packed) {
    fprintf(stderr, "[src/variable_length.cc] enter Store255UShort 2\n");
    dst[(*offset)++] = packed_byte;
    // fprintf(stderr, "[src/variable_length.cc] exit Store255UShort 2\n");
  }
  // fprintf(stderr, "[src/variable_length.cc] exit Store255UShort 1\n");
}

// Based on section 6.1.1 of MicroType Express draft spec
bool Read255UShort(Buffer* buf, unsigned int* value) {
  fprintf(stderr, "[src/variable_length.cc] enter Read255UShort 1\n");
  static const int kWordCode = 253;
  static const int kOneMoreByteCode2 = 254;
  static const int kOneMoreByteCode1 = 255;
  static const int kLowestUCode = 253;
  uint8_t code = 0;
  if (!buf->ReadU8(&code)) {
    fprintf(stderr, "[src/variable_length.cc] enter Read255UShort 2\n");
    return FONT_COMPRESSION_FAILURE();
    // fprintf(stderr, "[src/variable_length.cc] exit Read255UShort 2\n");
  }
  if (code == kWordCode) {
    fprintf(stderr, "[src/variable_length.cc] enter Read255UShort 3\n");
    uint16_t result = 0;
    if (!buf->ReadU16(&result)) {
      fprintf(stderr, "[src/variable_length.cc] enter Read255UShort 4\n");
      return FONT_COMPRESSION_FAILURE();
      // fprintf(stderr, "[src/variable_length.cc] exit Read255UShort 4\n");
    }
    *value = result;
    return true;
    // fprintf(stderr, "[src/variable_length.cc] exit Read255UShort 3\n");
  } else if (code == kOneMoreByteCode1) {
    fprintf(stderr, "[src/variable_length.cc] enter Read255UShort 5\n");
    uint8_t result = 0;
    if (!buf->ReadU8(&result)) {
      fprintf(stderr, "[src/variable_length.cc] enter Read255UShort 6\n");
      return FONT_COMPRESSION_FAILURE();
      // fprintf(stderr, "[src/variable_length.cc] exit Read255UShort 6\n");
    }
    *value = result + kLowestUCode;
    return true;
    // fprintf(stderr, "[src/variable_length.cc] exit Read255UShort 5\n");
  } else if (code == kOneMoreByteCode2) {
    fprintf(stderr, "[src/variable_length.cc] enter Read255UShort 7\n");
    uint8_t result = 0;
    if (!buf->ReadU8(&result)) {
      fprintf(stderr, "[src/variable_length.cc] enter Read255UShort 8\n");
      return FONT_COMPRESSION_FAILURE();
      // fprintf(stderr, "[src/variable_length.cc] exit Read255UShort 8\n");
    }
    *value = result + kLowestUCode * 2;
    return true;
    // fprintf(stderr, "[src/variable_length.cc] exit Read255UShort 7\n");
  } else {
    fprintf(stderr, "[src/variable_length.cc] enter Read255UShort 9\n");
    *value = code;
    return true;
    // fprintf(stderr, "[src/variable_length.cc] exit Read255UShort 9\n");
  }
  // fprintf(stderr, "[src/variable_length.cc] exit Read255UShort 1\n");
}

bool ReadBase128(Buffer* buf, uint32_t* value) {
  fprintf(stderr, "[src/variable_length.cc] enter ReadBase128 1\n");
  uint32_t result = 0;
  for (size_t i = 0; i < 5; ++i) {
    fprintf(stderr, "[src/variable_length.cc] enter ReadBase128 2\n");
    uint8_t code = 0;
    if (!buf->ReadU8(&code)) {
      fprintf(stderr, "[src/variable_length.cc] enter ReadBase128 3\n");
      return FONT_COMPRESSION_FAILURE();
      // fprintf(stderr, "[src/variable_length.cc] exit ReadBase128 3\n");
    }
    // Leading zeros are invalid.
    if (i == 0 && code == 0x80) {
      fprintf(stderr, "[src/variable_length.cc] enter ReadBase128 4\n");
      return FONT_COMPRESSION_FAILURE();
      // fprintf(stderr, "[src/variable_length.cc] exit ReadBase128 4\n");
    }
    // If any of the top seven bits are set then we're about to overflow.
    if (result & 0xfe000000) {
      fprintf(stderr, "[src/variable_length.cc] enter ReadBase128 5\n");
      return FONT_COMPRESSION_FAILURE();
      // fprintf(stderr, "[src/variable_length.cc] exit ReadBase128 5\n");
    }
    result = (result << 7) | (code & 0x7f);
    if ((code & 0x80) == 0) {
      fprintf(stderr, "[src/variable_length.cc] enter ReadBase128 6\n");
      *value = result;
      return true;
      // fprintf(stderr, "[src/variable_length.cc] exit ReadBase128 6\n");
    }
    // fprintf(stderr, "[src/variable_length.cc] exit ReadBase128 2\n");
  }
  // Make sure not to exceed the size bound
  fprintf(stderr, "[src/variable_length.cc] enter ReadBase128 7\n");
  return FONT_COMPRESSION_FAILURE();
  // fprintf(stderr, "[src/variable_length.cc] exit ReadBase128 7\n");
  // fprintf(stderr, "[src/variable_length.cc] exit ReadBase128 1\n");
}

size_t Base128Size(size_t n) {
  fprintf(stderr, "[src/variable_length.cc] enter Base128Size 1\n");
  size_t size = 1;
  for (; n >= 128; n >>= 7) {
    fprintf(stderr, "[src/variable_length.cc] enter Base128Size 2\n");
    ++size;
    // fprintf(stderr, "[src/variable_length.cc] exit Base128Size 2\n");
  }
  return size;
  // fprintf(stderr, "[src/variable_length.cc] exit Base128Size 1\n");
}

void StoreBase128(size_t len, size_t* offset, uint8_t* dst) {
  fprintf(stderr, "[src/variable_length.cc] enter StoreBase128 1\n");
  size_t size = Base128Size(len);
  for (size_t i = 0; i < size; ++i) {
    fprintf(stderr, "[src/variable_length.cc] enter StoreBase128 2\n");
    int b = static_cast<int>((len >> (7 * (size - i - 1))) & 0x7f);
    if (i < size - 1) {
      fprintf(stderr, "[src/variable_length.cc] enter StoreBase128 3\n");
      b |= 0x80;
      // fprintf(stderr, "[src/variable_length.cc] exit StoreBase128 3\n");
    }
    dst[(*offset)++] = b;
    // fprintf(stderr, "[src/variable_length.cc] exit StoreBase128 2\n");
  }
  // fprintf(stderr, "[src/variable_length.cc] exit StoreBase128 1\n");
}

} // namespace woff2
// Total cost: 0.041819
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 129)]
// Total instrumented cost: 0.041819, input tokens: 2398, output tokens: 2411, cache read tokens: 2394, cache write tokens: 1313
