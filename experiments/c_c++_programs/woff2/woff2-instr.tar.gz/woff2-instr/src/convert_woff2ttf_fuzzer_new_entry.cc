#include <string>
#include <woff2/decode.h>
#include <cstdio>

extern "C" int LLVMFuzzerTestOneInput(const uint8_t *data, size_t data_size) {
  fprintf(stderr, "[src/convert_woff2ttf_fuzzer_new_entry.cc] enter LLVMFuzzerTestOneInput 1\n");
  // Decode using newer entry pattern.
  // Same pattern as woff2_decompress.
  std::string output(std::min(woff2::ComputeWOFF2FinalSize(data, data_size),
                              woff2::kDefaultMaxSize), 0);
  woff2::WOFF2StringOut out(&output);
  woff2::ConvertWOFF2ToTTF(data, data_size, &out);
  return 0;
  // fprintf(stderr, "[src/convert_woff2ttf_fuzzer_new_entry.cc] exit LLVMFuzzerTestOneInput 1\n");
}
// Total cost: 0.005429
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 12)]
// Total instrumented cost: 0.005429, input tokens: 2398, output tokens: 248, cache read tokens: 2394, cache write tokens: 261
