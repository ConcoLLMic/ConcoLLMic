/* Copyright 2013 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

/* Helper for rounding */

#ifndef WOFF2_ROUND_H_
#define WOFF2_ROUND_H_

#include <limits>
#include <cstdio>

namespace woff2 {

// Round a value up to the nearest multiple of 4. Don't round the value in the
// case that rounding up overflows.
template<typename T> T Round4(T value) {
  fprintf(stderr, "[src/round.h] enter Round4 1\n");
  if (std::numeric_limits<T>::max() - value < 3) {
    fprintf(stderr, "[src/round.h] enter Round4 2\n");
    return value;
    // fprintf(stderr, "[src/round.h] exit Round4 2\n");
  }
  fprintf(stderr, "[src/round.h] enter Round4 3\n");
  return (value + 3) & ~3;
  // fprintf(stderr, "[src/round.h] exit Round4 3\n");
  // fprintf(stderr, "[src/round.h] exit Round4 1\n");
}

} // namespace woff2

#endif  // WOFF2_ROUND_H_
// Total cost: 0.006614
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 27)]
// Total instrumented cost: 0.006614, input tokens: 2398, output tokens: 323, cache read tokens: 2394, cache write tokens: 277
