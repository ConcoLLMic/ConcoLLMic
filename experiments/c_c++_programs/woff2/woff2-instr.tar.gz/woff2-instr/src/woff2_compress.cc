/* Copyright 2013 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

/* A commandline tool for compressing ttf format files to woff2. */

#include <string>
#include <stdio.h>

#include "file.h"
#include <woff2/encode.h>


int main(int argc, char **argv) {
  fprintf(stderr, "[src/woff2_compress.cc] enter main 1\n");
  if (argc != 2) {
    fprintf(stderr, "[src/woff2_compress.cc] enter main 2\n");
    fprintf(stderr, "One argument, the input filename, must be provided.\n");
    return 1;
    // fprintf(stderr, "[src/woff2_compress.cc] exit main 2\n");
  }

  std::string filename(argv[1]);
  std::string outfilename = filename.substr(0, filename.find_last_of(".")) + ".woff2";
  fprintf(stdout, "Processing %s => %s\n",
    filename.c_str(), outfilename.c_str());
  std::string input = woff2::GetFileContent(filename);

  const uint8_t* input_data = reinterpret_cast<const uint8_t*>(input.data());
  size_t output_size = woff2::MaxWOFF2CompressedSize(input_data, input.size());
  std::string output(output_size, 0);
  uint8_t* output_data = reinterpret_cast<uint8_t*>(&output[0]);

  woff2::WOFF2Params params;
  if (!woff2::ConvertTTFToWOFF2(input_data, input.size(),
                                output_data, &output_size, params)) {
    fprintf(stderr, "[src/woff2_compress.cc] enter main 3\n");
    fprintf(stderr, "Compression failed.\n");
    return 1;
    // fprintf(stderr, "[src/woff2_compress.cc] exit main 3\n");
  }
  
  fprintf(stderr, "[src/woff2_compress.cc] enter main 4\n");
  output.resize(output_size);

  woff2::SetFileContents(outfilename, output.begin(), output.end());

  return 0;
  // fprintf(stderr, "[src/woff2_compress.cc] exit main 4\n");
  // fprintf(stderr, "[src/woff2_compress.cc] exit main 1\n");
}
// Total cost: 0.011714
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 43)]
// Total instrumented cost: 0.011714, input tokens: 2398, output tokens: 599, cache read tokens: 2394, cache write tokens: 533
