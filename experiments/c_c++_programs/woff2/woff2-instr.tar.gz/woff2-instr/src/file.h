/* Copyright 2013 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

/* File IO helpers. */

#ifndef WOFF2_FILE_H_
#define WOFF2_FILE_H_

#include <fstream>
#include <iterator>
#include <stdio.h>

namespace woff2 {

inline std::string GetFileContent(std::string filename) {
  fprintf(stderr, "[src/file.h] enter GetFileContent 1\n");
  std::ifstream ifs(filename.c_str(), std::ios::binary);
  return std::string(std::istreambuf_iterator<char>(ifs.rdbuf()),
                     std::istreambuf_iterator<char>());
  // fprintf(stderr, "[src/file.h] exit GetFileContent 1\n");
}

inline void SetFileContents(std::string filename, std::string::iterator start,
                            std::string::iterator end) {
  fprintf(stderr, "[src/file.h] enter SetFileContents 1\n");
  std::ofstream ofs(filename.c_str(), std::ios::binary);
  std::copy(start, end, std::ostream_iterator<char>(ofs));
  // fprintf(stderr, "[src/file.h] exit SetFileContents 1\n");
}

} // namespace woff2
#endif  // WOFF2_FILE_H_
// Total cost: 0.007518
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 30)]
// Total instrumented cost: 0.007518, input tokens: 2398, output tokens: 366, cache read tokens: 2394, cache write tokens: 346
