#include <stddef.h>
#include <stdint.h>
#include <stdio.h>

#include <woff2/decode.h>

// Entry point for LibFuzzer.
extern "C" int LLVMFuzzerTestOneInput(const uint8_t* data, size_t size) {
  fprintf(stderr, "[src/convert_woff2ttf_fuzzer.cc] enter LLVMFuzzerTestOneInput 1\n");
  std::string buf;
  woff2::WOFF2StringOut out(&buf);
  out.SetMaxSize(30 * 1024 * 1024);
  woff2::ConvertWOFF2ToTTF(data, size, &out);
  return 0;
  // fprintf(stderr, "[src/convert_woff2ttf_fuzzer.cc] exit LLVMFuzzerTestOneInput 1\n");
}
// Total cost: 0.004930
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 13)]
// Total instrumented cost: 0.004930, input tokens: 2398, output tokens: 222, cache read tokens: 2394, cache write tokens: 232
