/* Copyright 2013 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

/* Helper function for bit twiddling and macros for branch prediction. */

#ifndef WOFF2_PORT_H_
#define WOFF2_PORT_H_

#include <assert.h>
#include <stdio.h>

namespace woff2 {

typedef unsigned int       uint32;

inline int Log2Floor(uint32 n) {
#if defined(__GNUC__)
  fprintf(stderr, "[src/port.h] enter Log2Floor 1\n");
  return n == 0 ? -1 : 31 ^ __builtin_clz(n);
  // fprintf(stderr, "[src/port.h] exit Log2Floor 1\n");
#else
  fprintf(stderr, "[src/port.h] enter Log2Floor 2\n");
  if (n == 0)
    return -1;
  // fprintf(stderr, "[src/port.h] exit Log2Floor 2\n");
  
  fprintf(stderr, "[src/port.h] enter Log2Floor 3\n");
  int log = 0;
  uint32 value = n;
  for (int i = 4; i >= 0; --i) {
    fprintf(stderr, "[src/port.h] enter Log2Floor 4\n");
    int shift = (1 << i);
    uint32 x = value >> shift;
    if (x != 0) {
      fprintf(stderr, "[src/port.h] enter Log2Floor 5\n");
      value = x;
      log += shift;
      // fprintf(stderr, "[src/port.h] exit Log2Floor 5\n");
    }
    // fprintf(stderr, "[src/port.h] exit Log2Floor 4\n");
  }
  assert(value == 1);
  return log;
  // fprintf(stderr, "[src/port.h] exit Log2Floor 3\n");
#endif
}

} // namespace woff2

/* Compatibility with non-clang compilers. */
#ifndef __has_builtin
#define __has_builtin(x) 0
#endif

#if (__GNUC__ > 2) || (__GNUC__ == 2 && __GNUC_MINOR__ > 95) || \
    (defined(__llvm__) && __has_builtin(__builtin_expect))
#define PREDICT_FALSE(x) (__builtin_expect(x, 0))
#define PREDICT_TRUE(x) (__builtin_expect(!!(x), 1))
#else
#define PREDICT_FALSE(x) (x)
#define PREDICT_TRUE(x) (x)
#endif

#if (defined(__ARM_ARCH) && (__ARM_ARCH == 7)) || \
    (defined(M_ARM) && (M_ARM == 7)) || \
    defined(__aarch64__) || defined(__ARM64_ARCH_8__) || defined(__i386) || \
    defined(_M_IX86) || defined(__x86_64__) || defined(_M_X64)
#if defined(__BYTE_ORDER__) && (__BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__)
#define WOFF_LITTLE_ENDIAN
#elif defined(__BYTE_ORDER__) && (__BYTE_ORDER__ == __ORDER_BIG_ENDIAN__)
#define WOFF_BIG_ENDIAN
#endif  /* endianness */
#endif  /* CPU whitelist */

#endif  // WOFF2_PORT_H_
// Total cost: 0.016634
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 66)]
// Total instrumented cost: 0.016634, input tokens: 2398, output tokens: 872, cache read tokens: 2394, cache write tokens: 753
