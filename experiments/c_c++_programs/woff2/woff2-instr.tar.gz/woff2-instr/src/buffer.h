/* Copyright 2013 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

/* The parts of ots.h & opentype-sanitiser.h that we need, taken from the
   https://code.google.com/p/ots/ project. */

#ifndef WOFF2_BUFFER_H_
#define WOFF2_BUFFER_H_

#if defined(_WIN32)
#include <stdlib.h>
typedef signed char int8_t;
typedef unsigned char uint8_t;
typedef short int16_t;
typedef unsigned short uint16_t;
typedef int int32_t;
typedef unsigned int uint32_t;
typedef __int64 int64_t;
typedef unsigned __int64 uint64_t;
#define ntohl(x) _byteswap_ulong (x)
#define ntohs(x) _byteswap_ushort (x)
#define htonl(x) _byteswap_ulong (x)
#define htons(x) _byteswap_ushort (x)
#else
#include <arpa/inet.h>
#include <stdint.h>
#endif

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <limits>

namespace woff2 {

#if defined(_MSC_VER) || !defined(FONT_COMPRESSION_DEBUG)
#define FONT_COMPRESSION_FAILURE() false
#else
#define FONT_COMPRESSION_FAILURE() \
  woff2::Failure(__FILE__, __LINE__, __PRETTY_FUNCTION__)
inline bool Failure(const char *f, int l, const char *fn) {
  fprintf(stderr, "[src/buffer.h] enter Failure 1\n");
  fprintf(stderr, "ERROR at %s:%d (%s)\n", f, l, fn);
  fflush(stderr);
  return false;
  // fprintf(stderr, "[src/buffer.h] exit Failure 1\n");
}
#endif

// -----------------------------------------------------------------------------
// Buffer helper class
//
// This class perform some trival buffer operations while checking for
// out-of-bounds errors. As a family they return false if anything is amiss,
// updating the current offset otherwise.
// -----------------------------------------------------------------------------
class Buffer {
 public:
  Buffer(const uint8_t *data, size_t len)
      : buffer_(data),
        length_(len),
        offset_(0) { }

  bool Skip(size_t n_bytes) {
    fprintf(stderr, "[src/buffer.h] enter Buffer::Skip 1\n");
    bool result = Read(NULL, n_bytes);
    // fprintf(stderr, "[src/buffer.h] exit Buffer::Skip 1\n");
    return result;
  }

  bool Read(uint8_t *data, size_t n_bytes) {
    fprintf(stderr, "[src/buffer.h] enter Buffer::Read 1\n");
    if (n_bytes > 1024 * 1024 * 1024) {
      fprintf(stderr, "[src/buffer.h] enter Buffer::Read 2\n");
      return FONT_COMPRESSION_FAILURE();
      // fprintf(stderr, "[src/buffer.h] exit Buffer::Read 2\n");
    }
    if ((offset_ + n_bytes > length_) ||
        (offset_ > length_ - n_bytes)) {
      fprintf(stderr, "[src/buffer.h] enter Buffer::Read 3\n");
      return FONT_COMPRESSION_FAILURE();
      // fprintf(stderr, "[src/buffer.h] exit Buffer::Read 3\n");
    }
    if (data) {
      fprintf(stderr, "[src/buffer.h] enter Buffer::Read 4\n");
      std::memcpy(data, buffer_ + offset_, n_bytes);
      // fprintf(stderr, "[src/buffer.h] exit Buffer::Read 4\n");
    }
    fprintf(stderr, "[src/buffer.h] enter Buffer::Read 5\n");
    offset_ += n_bytes;
    return true;
    // fprintf(stderr, "[src/buffer.h] exit Buffer::Read 5\n");
    // fprintf(stderr, "[src/buffer.h] exit Buffer::Read 1\n");
  }

  inline bool ReadU8(uint8_t *value) {
    fprintf(stderr, "[src/buffer.h] enter Buffer::ReadU8 1\n");
    if (offset_ + 1 > length_) {
      fprintf(stderr, "[src/buffer.h] enter Buffer::ReadU8 2\n");
      return FONT_COMPRESSION_FAILURE();
      // fprintf(stderr, "[src/buffer.h] exit Buffer::ReadU8 2\n");
    }
    fprintf(stderr, "[src/buffer.h] enter Buffer::ReadU8 3\n");
    *value = buffer_[offset_];
    ++offset_;
    return true;
    // fprintf(stderr, "[src/buffer.h] exit Buffer::ReadU8 3\n");
    // fprintf(stderr, "[src/buffer.h] exit Buffer::ReadU8 1\n");
  }

  bool ReadU16(uint16_t *value) {
    fprintf(stderr, "[src/buffer.h] enter Buffer::ReadU16 1\n");
    if (offset_ + 2 > length_) {
      fprintf(stderr, "[src/buffer.h] enter Buffer::ReadU16 2\n");
      return FONT_COMPRESSION_FAILURE();
      // fprintf(stderr, "[src/buffer.h] exit Buffer::ReadU16 2\n");
    }
    fprintf(stderr, "[src/buffer.h] enter Buffer::ReadU16 3\n");
    std::memcpy(value, buffer_ + offset_, sizeof(uint16_t));
    *value = ntohs(*value);
    offset_ += 2;
    return true;
    // fprintf(stderr, "[src/buffer.h] exit Buffer::ReadU16 3\n");
    // fprintf(stderr, "[src/buffer.h] exit Buffer::ReadU16 1\n");
  }

  bool ReadS16(int16_t *value) {
    fprintf(stderr, "[src/buffer.h] enter Buffer::ReadS16 1\n");
    bool result = ReadU16(reinterpret_cast<uint16_t*>(value));
    // fprintf(stderr, "[src/buffer.h] exit Buffer::ReadS16 1\n");
    return result;
  }

  bool ReadU24(uint32_t *value) {
    fprintf(stderr, "[src/buffer.h] enter Buffer::ReadU24 1\n");
    if (offset_ + 3 > length_) {
      fprintf(stderr, "[src/buffer.h] enter Buffer::ReadU24 2\n");
      return FONT_COMPRESSION_FAILURE();
      // fprintf(stderr, "[src/buffer.h] exit Buffer::ReadU24 2\n");
    }
    fprintf(stderr, "[src/buffer.h] enter Buffer::ReadU24 3\n");
    *value = static_cast<uint32_t>(buffer_[offset_]) << 16 |
        static_cast<uint32_t>(buffer_[offset_ + 1]) << 8 |
        static_cast<uint32_t>(buffer_[offset_ + 2]);
    offset_ += 3;
    return true;
    // fprintf(stderr, "[src/buffer.h] exit Buffer::ReadU24 3\n");
    // fprintf(stderr, "[src/buffer.h] exit Buffer::ReadU24 1\n");
  }

  bool ReadU32(uint32_t *value) {
    fprintf(stderr, "[src/buffer.h] enter Buffer::ReadU32 1\n");
    if (offset_ + 4 > length_) {
      fprintf(stderr, "[src/buffer.h] enter Buffer::ReadU32 2\n");
      return FONT_COMPRESSION_FAILURE();
      // fprintf(stderr, "[src/buffer.h] exit Buffer::ReadU32 2\n");
    }
    fprintf(stderr, "[src/buffer.h] enter Buffer::ReadU32 3\n");
    std::memcpy(value, buffer_ + offset_, sizeof(uint32_t));
    *value = ntohl(*value);
    offset_ += 4;
    return true;
    // fprintf(stderr, "[src/buffer.h] exit Buffer::ReadU32 3\n");
    // fprintf(stderr, "[src/buffer.h] exit Buffer::ReadU32 1\n");
  }

  bool ReadS32(int32_t *value) {
    fprintf(stderr, "[src/buffer.h] enter Buffer::ReadS32 1\n");
    bool result = ReadU32(reinterpret_cast<uint32_t*>(value));
    // fprintf(stderr, "[src/buffer.h] exit Buffer::ReadS32 1\n");
    return result;
  }

  bool ReadTag(uint32_t *value) {
    fprintf(stderr, "[src/buffer.h] enter Buffer::ReadTag 1\n");
    if (offset_ + 4 > length_) {
      fprintf(stderr, "[src/buffer.h] enter Buffer::ReadTag 2\n");
      return FONT_COMPRESSION_FAILURE();
      // fprintf(stderr, "[src/buffer.h] exit Buffer::ReadTag 2\n");
    }
    fprintf(stderr, "[src/buffer.h] enter Buffer::ReadTag 3\n");
    std::memcpy(value, buffer_ + offset_, sizeof(uint32_t));
    offset_ += 4;
    return true;
    // fprintf(stderr, "[src/buffer.h] exit Buffer::ReadTag 3\n");
    // fprintf(stderr, "[src/buffer.h] exit Buffer::ReadTag 1\n");
  }

  bool ReadR64(uint64_t *value) {
    fprintf(stderr, "[src/buffer.h] enter Buffer::ReadR64 1\n");
    if (offset_ + 8 > length_) {
      fprintf(stderr, "[src/buffer.h] enter Buffer::ReadR64 2\n");
      return FONT_COMPRESSION_FAILURE();
      // fprintf(stderr, "[src/buffer.h] exit Buffer::ReadR64 2\n");
    }
    fprintf(stderr, "[src/buffer.h] enter Buffer::ReadR64 3\n");
    std::memcpy(value, buffer_ + offset_, sizeof(uint64_t));
    offset_ += 8;
    return true;
    // fprintf(stderr, "[src/buffer.h] exit Buffer::ReadR64 3\n");
    // fprintf(stderr, "[src/buffer.h] exit Buffer::ReadR64 1\n");
  }

  const uint8_t *buffer() const { return buffer_; }
  size_t offset() const { return offset_; }
  size_t length() const { return length_; }

  void set_offset(size_t newoffset) { offset_ = newoffset; }

 private:
  const uint8_t * const buffer_;
  const size_t length_;
  size_t offset_;
};

} // namespace woff2

#endif  // WOFF2_BUFFER_H_
// Total cost: 0.145535
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 164)]
// Total instrumented cost: 0.145535, input tokens: 12908, output tokens: 7730, cache read tokens: 12896, cache write tokens: 6848
