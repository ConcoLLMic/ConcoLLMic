/* Copyright 2013 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

/* Glyph manipulation */

#include "./glyph.h"

#include <stdlib.h>
#include <limits>
#include <stdio.h>
#include "./buffer.h"
#include "./store_bytes.h"

namespace woff2 {

static const int32_t kFLAG_ONCURVE = 1;
static const int32_t kFLAG_XSHORT = 1 << 1;
static const int32_t kFLAG_YSHORT = 1 << 2;
static const int32_t kFLAG_REPEAT = 1 << 3;
static const int32_t kFLAG_XREPEATSIGN = 1 << 4;
static const int32_t kFLAG_YREPEATSIGN = 1 << 5;
static const int32_t kFLAG_OVERLAP_SIMPLE = 1 << 6;
static const int32_t kFLAG_ARG_1_AND_2_ARE_WORDS = 1 << 0;
static const int32_t kFLAG_WE_HAVE_A_SCALE = 1 << 3;
static const int32_t kFLAG_MORE_COMPONENTS = 1 << 5;
static const int32_t kFLAG_WE_HAVE_AN_X_AND_Y_SCALE = 1 << 6;
static const int32_t kFLAG_WE_HAVE_A_TWO_BY_TWO = 1 << 7;
static const int32_t kFLAG_WE_HAVE_INSTRUCTIONS = 1 << 8;

bool ReadCompositeGlyphData(Buffer* buffer, Glyph* glyph) {
  fprintf(stderr, "[src/glyph.cc] enter ReadCompositeGlyphData 1\n");
  glyph->have_instructions = false;
  glyph->composite_data = buffer->buffer() + buffer->offset();
  size_t start_offset = buffer->offset();
  uint16_t flags = kFLAG_MORE_COMPONENTS;
  // fprintf(stderr, "[src/glyph.cc] exit ReadCompositeGlyphData 1\n");
  
  while (flags & kFLAG_MORE_COMPONENTS) {
    fprintf(stderr, "[src/glyph.cc] enter ReadCompositeGlyphData 2\n");
    if (!buffer->ReadU16(&flags)) {
      return FONT_COMPRESSION_FAILURE();
    }
    glyph->have_instructions |= (flags & kFLAG_WE_HAVE_INSTRUCTIONS) != 0;
    size_t arg_size = 2;  // glyph index
    // fprintf(stderr, "[src/glyph.cc] exit ReadCompositeGlyphData 2\n");
    
    if (flags & kFLAG_ARG_1_AND_2_ARE_WORDS) {
      fprintf(stderr, "[src/glyph.cc] enter ReadCompositeGlyphData 3\n");
      arg_size += 4;
      // fprintf(stderr, "[src/glyph.cc] exit ReadCompositeGlyphData 3\n");
    } else {
      fprintf(stderr, "[src/glyph.cc] enter ReadCompositeGlyphData 4\n");
      arg_size += 2;
      // fprintf(stderr, "[src/glyph.cc] exit ReadCompositeGlyphData 4\n");
    }
    
    if (flags & kFLAG_WE_HAVE_A_SCALE) {
      fprintf(stderr, "[src/glyph.cc] enter ReadCompositeGlyphData 5\n");
      arg_size += 2;
      // fprintf(stderr, "[src/glyph.cc] exit ReadCompositeGlyphData 5\n");
    } else if (flags & kFLAG_WE_HAVE_AN_X_AND_Y_SCALE) {
      fprintf(stderr, "[src/glyph.cc] enter ReadCompositeGlyphData 6\n");
      arg_size += 4;
      // fprintf(stderr, "[src/glyph.cc] exit ReadCompositeGlyphData 6\n");
    } else if (flags & kFLAG_WE_HAVE_A_TWO_BY_TWO) {
      fprintf(stderr, "[src/glyph.cc] enter ReadCompositeGlyphData 7\n");
      arg_size += 8;
      // fprintf(stderr, "[src/glyph.cc] exit ReadCompositeGlyphData 7\n");
    }
    
    fprintf(stderr, "[src/glyph.cc] enter ReadCompositeGlyphData 8\n");
    if (!buffer->Skip(arg_size)) {
      return FONT_COMPRESSION_FAILURE();
    }
    // fprintf(stderr, "[src/glyph.cc] exit ReadCompositeGlyphData 8\n");
  }
  
  fprintf(stderr, "[src/glyph.cc] enter ReadCompositeGlyphData 9\n");
  if (buffer->offset() - start_offset > std::numeric_limits<uint32_t>::max()) {
    return FONT_COMPRESSION_FAILURE();
  }
  glyph->composite_data_size = buffer->offset() - start_offset;
  return true;
  // fprintf(stderr, "[src/glyph.cc] exit ReadCompositeGlyphData 9\n");
}

bool ReadGlyph(const uint8_t* data, size_t len, Glyph* glyph) {
  fprintf(stderr, "[src/glyph.cc] enter ReadGlyph 1\n");
  Buffer buffer(data, len);

  int16_t num_contours;
  if (!buffer.ReadS16(&num_contours)) {
    return FONT_COMPRESSION_FAILURE();
  }

  // Read the bounding box.
  if (!buffer.ReadS16(&glyph->x_min) ||
      !buffer.ReadS16(&glyph->y_min) ||
      !buffer.ReadS16(&glyph->x_max) ||
      !buffer.ReadS16(&glyph->y_max)) {
    return FONT_COMPRESSION_FAILURE();
  }
  // fprintf(stderr, "[src/glyph.cc] exit ReadGlyph 1\n");

  if (num_contours == 0) {
    fprintf(stderr, "[src/glyph.cc] enter ReadGlyph 2\n");
    // Empty glyph.
    return true;
    // fprintf(stderr, "[src/glyph.cc] exit ReadGlyph 2\n");
  }

  if (num_contours > 0) {
    fprintf(stderr, "[src/glyph.cc] enter ReadGlyph 3\n");
    // Simple glyph.
    glyph->contours.resize(num_contours);

    // Read the number of points per contour.
    uint16_t last_point_index = 0;
    // fprintf(stderr, "[src/glyph.cc] exit ReadGlyph 3\n");
    
    for (int i = 0; i < num_contours; ++i) {
      fprintf(stderr, "[src/glyph.cc] enter ReadGlyph 4\n");
      uint16_t point_index;
      if (!buffer.ReadU16(&point_index)) {
        return FONT_COMPRESSION_FAILURE();
      }
      uint16_t num_points = point_index - last_point_index + (i == 0 ? 1 : 0);
      glyph->contours[i].resize(num_points);
      last_point_index = point_index;
      // fprintf(stderr, "[src/glyph.cc] exit ReadGlyph 4\n");
    }

    fprintf(stderr, "[src/glyph.cc] enter ReadGlyph 5\n");
    // Read the instructions.
    if (!buffer.ReadU16(&glyph->instructions_size)) {
      return FONT_COMPRESSION_FAILURE();
    }
    glyph->instructions_data = data + buffer.offset();
    if (!buffer.Skip(glyph->instructions_size)) {
      return FONT_COMPRESSION_FAILURE();
    }
    // fprintf(stderr, "[src/glyph.cc] exit ReadGlyph 5\n");

    fprintf(stderr, "[src/glyph.cc] enter ReadGlyph 6\n");
    // Read the run-length coded flags.
    std::vector<std::vector<uint8_t> > flags(num_contours);
    // fprintf(stderr, "[src/glyph.cc] exit ReadGlyph 6\n");
    
    {
      fprintf(stderr, "[src/glyph.cc] enter ReadGlyph 7\n");
      uint8_t flag = 0;
      uint8_t flag_repeat = 0;
      // fprintf(stderr, "[src/glyph.cc] exit ReadGlyph 7\n");
      
      for (int i = 0; i < num_contours; ++i) {
        fprintf(stderr, "[src/glyph.cc] enter ReadGlyph 8\n");
        flags[i].resize(glyph->contours[i].size());
        // fprintf(stderr, "[src/glyph.cc] exit ReadGlyph 8\n");
        
        for (size_t j = 0; j < glyph->contours[i].size(); ++j) {
          fprintf(stderr, "\n");
          if (flag_repeat == 0) {
            fprintf(stderr, "[src/glyph.cc] enter ReadGlyph 10\n");
            if (!buffer.ReadU8(&flag)) {
              return FONT_COMPRESSION_FAILURE();
            }
            // fprintf(stderr, "[src/glyph.cc] exit ReadGlyph 10\n");
            
            if (flag & kFLAG_REPEAT) {
              fprintf(stderr, "[src/glyph.cc] enter ReadGlyph 11\n");
              if (!buffer.ReadU8(&flag_repeat)) {
                return FONT_COMPRESSION_FAILURE();
              }
              // fprintf(stderr, "[src/glyph.cc] exit ReadGlyph 11\n");
            }
          } else {
            fprintf(stderr, "[src/glyph.cc] enter ReadGlyph 12\n");
            flag_repeat--;
            // fprintf(stderr, "[src/glyph.cc] exit ReadGlyph 12\n");
          }
          
          fprintf(stderr, "[src/glyph.cc] enter ReadGlyph 13\n");
          flags[i][j] = flag;
          glyph->contours[i][j].on_curve = flag & kFLAG_ONCURVE;
          // fprintf(stderr, "[src/glyph.cc] exit ReadGlyph 13\n");
        }
      }
    }

    fprintf(stderr, "[src/glyph.cc] enter ReadGlyph 14\n");
    if (!flags.empty() && !flags[0].empty()) {
      glyph->overlap_simple_flag_set = (flags[0][0] & kFLAG_OVERLAP_SIMPLE);
    }
    // fprintf(stderr, "[src/glyph.cc] exit ReadGlyph 14\n");

    fprintf(stderr, "[src/glyph.cc] enter ReadGlyph 15\n");
    // Read the x coordinates.
    int prev_x = 0;
    // fprintf(stderr, "[src/glyph.cc] exit ReadGlyph 15\n");
    
    for (int i = 0; i < num_contours; ++i) {
      fprintf(stderr, "\n");
      // fprintf(stderr, "\n");
      
      for (size_t j = 0; j < glyph->contours[i].size(); ++j) {
        fprintf(stderr, "[src/glyph.cc] enter ReadGlyph 17\n");
        uint8_t flag = flags[i][j];
        // fprintf(stderr, "[src/glyph.cc] exit ReadGlyph 17\n");
        
        if (flag & kFLAG_XSHORT) {
          fprintf(stderr, "[src/glyph.cc] enter ReadGlyph 18\n");
          // single byte x-delta coord value
          uint8_t x_delta;
          if (!buffer.ReadU8(&x_delta)) {
            return FONT_COMPRESSION_FAILURE();
          }
          int sign = (flag & kFLAG_XREPEATSIGN) ? 1 : -1;
          glyph->contours[i][j].x = prev_x + sign * x_delta;
          // fprintf(stderr, "[src/glyph.cc] exit ReadGlyph 18\n");
        } else {
          fprintf(stderr, "[src/glyph.cc] enter ReadGlyph 19\n");
          // double byte x-delta coord value
          int16_t x_delta = 0;
          // fprintf(stderr, "[src/glyph.cc] exit ReadGlyph 19\n");
          
          if (!(flag & kFLAG_XREPEATSIGN)) {
            fprintf(stderr, "[src/glyph.cc] enter ReadGlyph 20\n");
            if (!buffer.ReadS16(&x_delta)) {
              return FONT_COMPRESSION_FAILURE();
            }
            // fprintf(stderr, "[src/glyph.cc] exit ReadGlyph 20\n");
          }
          
          fprintf(stderr, "[src/glyph.cc] enter ReadGlyph 21\n");
          glyph->contours[i][j].x = prev_x + x_delta;
          // fprintf(stderr, "[src/glyph.cc] exit ReadGlyph 21\n");
        }
        
        fprintf(stderr, "[src/glyph.cc] enter ReadGlyph 22\n");
        prev_x = glyph->contours[i][j].x;
        // fprintf(stderr, "[src/glyph.cc] exit ReadGlyph 22\n");
      }
    }

    fprintf(stderr, "[src/glyph.cc] enter ReadGlyph 23\n");
    // Read the y coordinates.
    int prev_y = 0;
    // fprintf(stderr, "[src/glyph.cc] exit ReadGlyph 23\n");
    
    for (int i = 0; i < num_contours; ++i) {
      fprintf(stderr, "\n");
      // fprintf(stderr, "\n");
      
      for (size_t j = 0; j < glyph->contours[i].size(); ++j) {
        fprintf(stderr, "[src/glyph.cc] enter ReadGlyph 25\n");
        uint8_t flag = flags[i][j];
        // fprintf(stderr, "[src/glyph.cc] exit ReadGlyph 25\n");
        
        if (flag & kFLAG_YSHORT) {
          fprintf(stderr, "[src/glyph.cc] enter ReadGlyph 26\n");
          // single byte y-delta coord value
          uint8_t y_delta;
          if (!buffer.ReadU8(&y_delta)) {
            return FONT_COMPRESSION_FAILURE();
          }
          int sign = (flag & kFLAG_YREPEATSIGN) ? 1 : -1;
          glyph->contours[i][j].y = prev_y + sign * y_delta;
          // fprintf(stderr, "[src/glyph.cc] exit ReadGlyph 26\n");
        } else {
          fprintf(stderr, "[src/glyph.cc] enter ReadGlyph 27\n");
          // double byte y-delta coord value
          int16_t y_delta = 0;
          // fprintf(stderr, "[src/glyph.cc] exit ReadGlyph 27\n");
          
          if (!(flag & kFLAG_YREPEATSIGN)) {
            fprintf(stderr, "[src/glyph.cc] enter ReadGlyph 28\n");
            if (!buffer.ReadS16(&y_delta)) {
              return FONT_COMPRESSION_FAILURE();
            }
            // fprintf(stderr, "[src/glyph.cc] exit ReadGlyph 28\n");
          }
          
          fprintf(stderr, "[src/glyph.cc] enter ReadGlyph 29\n");
          glyph->contours[i][j].y = prev_y + y_delta;
          // fprintf(stderr, "[src/glyph.cc] exit ReadGlyph 29\n");
        }
        
        fprintf(stderr, "[src/glyph.cc] enter ReadGlyph 30\n");
        prev_y = glyph->contours[i][j].y;
        // fprintf(stderr, "[src/glyph.cc] exit ReadGlyph 30\n");
      }
    }
  } else if (num_contours == -1) {
    fprintf(stderr, "[src/glyph.cc] enter ReadGlyph 31\n");
    // Composite glyph.
    if (!ReadCompositeGlyphData(&buffer, glyph)) {
      return FONT_COMPRESSION_FAILURE();
    }
    // fprintf(stderr, "[src/glyph.cc] exit ReadGlyph 31\n");
    
    fprintf(stderr, "[src/glyph.cc] enter ReadGlyph 32\n");
    // Read the instructions.
    // fprintf(stderr, "[src/glyph.cc] exit ReadGlyph 32\n");
    
    if (glyph->have_instructions) {
      fprintf(stderr, "[src/glyph.cc] enter ReadGlyph 33\n");
      if (!buffer.ReadU16(&glyph->instructions_size)) {
        return FONT_COMPRESSION_FAILURE();
      }
      glyph->instructions_data = data + buffer.offset();
      if (!buffer.Skip(glyph->instructions_size)) {
        return FONT_COMPRESSION_FAILURE();
      }
      // fprintf(stderr, "[src/glyph.cc] exit ReadGlyph 33\n");
    } else {
      fprintf(stderr, "[src/glyph.cc] enter ReadGlyph 34\n");
      glyph->instructions_size = 0;
      // fprintf(stderr, "[src/glyph.cc] exit ReadGlyph 34\n");
    }
  } else {
    fprintf(stderr, "[src/glyph.cc] enter ReadGlyph 35\n");
    return FONT_COMPRESSION_FAILURE();
    // fprintf(stderr, "[src/glyph.cc] exit ReadGlyph 35\n");
  }
  
  fprintf(stderr, "[src/glyph.cc] enter ReadGlyph 36\n");
  return true;
  // fprintf(stderr, "[src/glyph.cc] exit ReadGlyph 36\n");
}

namespace {

void StoreBbox(const Glyph& glyph, size_t* offset, uint8_t* dst) {
  fprintf(stderr, "[src/glyph.cc] enter StoreBbox 1\n");
  Store16(glyph.x_min, offset, dst);
  Store16(glyph.y_min, offset, dst);
  Store16(glyph.x_max, offset, dst);
  Store16(glyph.y_max, offset, dst);
  // fprintf(stderr, "[src/glyph.cc] exit StoreBbox 1\n");
}

void StoreInstructions(const Glyph& glyph, size_t* offset, uint8_t* dst) {
  fprintf(stderr, "[src/glyph.cc] enter StoreInstructions 1\n");
  Store16(glyph.instructions_size, offset, dst);
  StoreBytes(glyph.instructions_data, glyph.instructions_size, offset, dst);
  // fprintf(stderr, "[src/glyph.cc] exit StoreInstructions 1\n");
}

bool StoreEndPtsOfContours(const Glyph& glyph, size_t* offset, uint8_t* dst) {
  fprintf(stderr, "[src/glyph.cc] enter StoreEndPtsOfContours 1\n");
  int end_point = -1;
  // fprintf(stderr, "[src/glyph.cc] exit StoreEndPtsOfContours 1\n");
  
  for (const auto& contour : glyph.contours) {
    fprintf(stderr, "[src/glyph.cc] enter StoreEndPtsOfContours 2\n");
    end_point += contour.size();
    if (contour.size() > std::numeric_limits<uint16_t>::max() ||
        end_point > std::numeric_limits<uint16_t>::max()) {
      return FONT_COMPRESSION_FAILURE();
    }
    Store16(end_point, offset, dst);
    // fprintf(stderr, "[src/glyph.cc] exit StoreEndPtsOfContours 2\n");
  }
  
  fprintf(stderr, "[src/glyph.cc] enter StoreEndPtsOfContours 3\n");
  return true;
  // fprintf(stderr, "[src/glyph.cc] exit StoreEndPtsOfContours 3\n");
}

bool StorePoints(const Glyph& glyph, size_t* offset,
                 uint8_t* dst, size_t dst_size) {
  fprintf(stderr, "[src/glyph.cc] enter StorePoints 1\n");
  int previous_flag = -1;
  int repeat_count = 0;
  int last_x = 0;
  int last_y = 0;
  size_t x_bytes = 0;
  size_t y_bytes = 0;
  // fprintf(stderr, "[src/glyph.cc] exit StorePoints 1\n");

  fprintf(stderr, "[src/glyph.cc] enter StorePoints 2\n");
  // Store the flags and calculate the total size of the x and y coordinates.
  // fprintf(stderr, "[src/glyph.cc] exit StorePoints 2\n");
  
  for (const auto& contour : glyph.contours) {
    fprintf(stderr, "\n");
    // fprintf(stderr, "\n");
    
    for (const auto& point : contour) {
      fprintf(stderr, "[src/glyph.cc] enter StorePoints 4\n");
      int flag = point.on_curve ? kFLAG_ONCURVE : 0;
      // fprintf(stderr, "[src/glyph.cc] exit StorePoints 4\n");
      
      if (previous_flag == -1 && glyph.overlap_simple_flag_set) {
        fprintf(stderr, "[src/glyph.cc] enter StorePoints 5\n");
        // First flag needs to have overlap simple bit set.
        flag = flag | kFLAG_OVERLAP_SIMPLE;
        // fprintf(stderr, "[src/glyph.cc] exit StorePoints 5\n");
      }
      
      fprintf(stderr, "[src/glyph.cc] enter StorePoints 6\n");
      int dx = point.x - last_x;
      int dy = point.y - last_y;
      // fprintf(stderr, "[src/glyph.cc] exit StorePoints 6\n");
      
      if (dx == 0) {
        fprintf(stderr, "[src/glyph.cc] enter StorePoints 7\n");
        flag |= kFLAG_XREPEATSIGN;
        // fprintf(stderr, "[src/glyph.cc] exit StorePoints 7\n");
      } else if (dx > -256 && dx < 256) {
        fprintf(stderr, "[src/glyph.cc] enter StorePoints 8\n");
        flag |= kFLAG_XSHORT | (dx > 0 ? kFLAG_XREPEATSIGN : 0);
        x_bytes += 1;
        // fprintf(stderr, "[src/glyph.cc] exit StorePoints 8\n");
      } else {
        fprintf(stderr, "[src/glyph.cc] enter StorePoints 9\n");
        x_bytes += 2;
        // fprintf(stderr, "[src/glyph.cc] exit StorePoints 9\n");
      }
      
      if (dy == 0) {
        fprintf(stderr, "[src/glyph.cc] enter StorePoints 10\n");
        flag |= kFLAG_YREPEATSIGN;
        // fprintf(stderr, "[src/glyph.cc] exit StorePoints 10\n");
      } else if (dy > -256 && dy < 256) {
        fprintf(stderr, "[src/glyph.cc] enter StorePoints 11\n");
        flag |= kFLAG_YSHORT | (dy > 0 ? kFLAG_YREPEATSIGN : 0);
        y_bytes += 1;
        // fprintf(stderr, "[src/glyph.cc] exit StorePoints 11\n");
      } else {
        fprintf(stderr, "[src/glyph.cc] enter StorePoints 12\n");
        y_bytes += 2;
        // fprintf(stderr, "[src/glyph.cc] exit StorePoints 12\n");
      }
      
      if (flag == previous_flag && repeat_count != 255) {
        fprintf(stderr, "[src/glyph.cc] enter StorePoints 13\n");
        dst[*offset - 1] |= kFLAG_REPEAT;
        repeat_count++;
        // fprintf(stderr, "[src/glyph.cc] exit StorePoints 13\n");
      } else {
        fprintf(stderr, "\n");
        // fprintf(stderr, "\n");
        
        if (repeat_count != 0) {
          fprintf(stderr, "[src/glyph.cc] enter StorePoints 15\n");
          if (*offset >= dst_size) {
            return FONT_COMPRESSION_FAILURE();
          }
          dst[(*offset)++] = repeat_count;
          // fprintf(stderr, "[src/glyph.cc] exit StorePoints 15\n");
        }
        
        fprintf(stderr, "[src/glyph.cc] enter StorePoints 16\n");
        if (*offset >= dst_size) {
          return FONT_COMPRESSION_FAILURE();
        }
        dst[(*offset)++] = flag;
        repeat_count = 0;
        // fprintf(stderr, "[src/glyph.cc] exit StorePoints 16\n");
      }
      
      fprintf(stderr, "[src/glyph.cc] enter StorePoints 17\n");
      last_x = point.x;
      last_y = point.y;
      previous_flag = flag;
      // fprintf(stderr, "[src/glyph.cc] exit StorePoints 17\n");
    }
  }
  
  if (repeat_count != 0) {
    fprintf(stderr, "[src/glyph.cc] enter StorePoints 18\n");
    if (*offset >= dst_size) {
      return FONT_COMPRESSION_FAILURE();
    }
    dst[(*offset)++] = repeat_count;
    // fprintf(stderr, "[src/glyph.cc] exit StorePoints 18\n");
  }

  fprintf(stderr, "[src/glyph.cc] enter StorePoints 19\n");
  if (*offset + x_bytes + y_bytes > dst_size) {
    return FONT_COMPRESSION_FAILURE();
  }
  // fprintf(stderr, "[src/glyph.cc] exit StorePoints 19\n");

  fprintf(stderr, "[src/glyph.cc] enter StorePoints 20\n");
  // Store the x and y coordinates.
  size_t x_offset = *offset;
  size_t y_offset = *offset + x_bytes;
  last_x = 0;
  last_y = 0;
  // fprintf(stderr, "[src/glyph.cc] exit StorePoints 20\n");
  
  for (const auto& contour : glyph.contours) {
    fprintf(stderr, "\n");
    // fprintf(stderr, "\n");
    
    for (const auto& point : contour) {
      fprintf(stderr, "[src/glyph.cc] enter StorePoints 22\n");
      int dx = point.x - last_x;
      int dy = point.y - last_y;
      // fprintf(stderr, "[src/glyph.cc] exit StorePoints 22\n");
      
      if (dx == 0) {
        fprintf(stderr, "[src/glyph.cc] enter StorePoints 23\n");
        // pass
        // fprintf(stderr, "[src/glyph.cc] exit StorePoints 23\n");
      } else if (dx > -256 && dx < 256) {
        fprintf(stderr, "[src/glyph.cc] enter StorePoints 24\n");
        dst[x_offset++] = std::abs(dx);
        // fprintf(stderr, "[src/glyph.cc] exit StorePoints 24\n");
      } else {
        fprintf(stderr, "[src/glyph.cc] enter StorePoints 25\n");
        Store16(dx, &x_offset, dst);
        // fprintf(stderr, "[src/glyph.cc] exit StorePoints 25\n");
      }
      
      if (dy == 0) {
        fprintf(stderr, "[src/glyph.cc] enter StorePoints 26\n");
        // pass
        // fprintf(stderr, "[src/glyph.cc] exit StorePoints 26\n");
      } else if (dy > -256 && dy < 256) {
        fprintf(stderr, "[src/glyph.cc] enter StorePoints 27\n");
        dst[y_offset++] = std::abs(dy);
        // fprintf(stderr, "[src/glyph.cc] exit StorePoints 27\n");
      } else {
        fprintf(stderr, "[src/glyph.cc] enter StorePoints 28\n");
        Store16(dy, &y_offset, dst);
        // fprintf(stderr, "[src/glyph.cc] exit StorePoints 28\n");
      }
      
      fprintf(stderr, "[src/glyph.cc] enter StorePoints 29\n");
      last_x += dx;
      last_y += dy;
      // fprintf(stderr, "[src/glyph.cc] exit StorePoints 29\n");
    }
  }
  
  fprintf(stderr, "[src/glyph.cc] enter StorePoints 30\n");
  *offset = y_offset;
  return true;
  // fprintf(stderr, "[src/glyph.cc] exit StorePoints 30\n");
}

}  // namespace

bool StoreGlyph(const Glyph& glyph, uint8_t* dst, size_t* dst_size) {
  fprintf(stderr, "[src/glyph.cc] enter StoreGlyph 1\n");
  size_t offset = 0;
  // fprintf(stderr, "[src/glyph.cc] exit StoreGlyph 1\n");
  
  if (glyph.composite_data_size > 0) {
    fprintf(stderr, "[src/glyph.cc] enter StoreGlyph 2\n");
    // Composite glyph.
    if (*dst_size < ((10ULL + glyph.composite_data_size) +
                     ((glyph.have_instructions ? 2ULL : 0) +
                      glyph.instructions_size))) {
      return FONT_COMPRESSION_FAILURE();
    }
    Store16(-1, &offset, dst);
    StoreBbox(glyph, &offset, dst);
    StoreBytes(glyph.composite_data, glyph.composite_data_size, &offset, dst);
    // fprintf(stderr, "[src/glyph.cc] exit StoreGlyph 2\n");
    
    if (glyph.have_instructions) {
      fprintf(stderr, "[src/glyph.cc] enter StoreGlyph 3\n");
      StoreInstructions(glyph, &offset, dst);
      // fprintf(stderr, "[src/glyph.cc] exit StoreGlyph 3\n");
    }
  } else if (glyph.contours.size() > 0) {
    fprintf(stderr, "[src/glyph.cc] enter StoreGlyph 4\n");
    // Simple glyph.
    if (glyph.contours.size() > std::numeric_limits<int16_t>::max()) {
      return FONT_COMPRESSION_FAILURE();
    }
    if (*dst_size < ((12ULL + 2 * glyph.contours.size()) +
                     glyph.instructions_size)) {
      return FONT_COMPRESSION_FAILURE();
    }
    Store16(glyph.contours.size(), &offset, dst);
    StoreBbox(glyph, &offset, dst);
    if (!StoreEndPtsOfContours(glyph, &offset, dst)) {
      return FONT_COMPRESSION_FAILURE();
    }
    StoreInstructions(glyph, &offset, dst);
    if (!StorePoints(glyph, &offset, dst, *dst_size)) {
      return FONT_COMPRESSION_FAILURE();
    }
    // fprintf(stderr, "[src/glyph.cc] exit StoreGlyph 4\n");
  }
  
  fprintf(stderr, "[src/glyph.cc] enter StoreGlyph 5\n");
  *dst_size = offset;
  return true;
  // fprintf(stderr, "[src/glyph.cc] exit StoreGlyph 5\n");
}

} // namespace woff2
// Total cost: 0.132959
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 383)]
// Total instrumented cost: 0.132959, input tokens: 2398, output tokens: 7662, cache read tokens: 2394, cache write tokens: 4613
