/* Copyright 2014 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

/* Common definition for WOFF2 encoding/decoding */

#ifndef WOFF2_WOFF2_COMMON_H_
#define WOFF2_WOFF2_COMMON_H_

#include <stddef.h>
#include <inttypes.h>
#include <stdio.h>

#include <string>

namespace woff2 {

static const uint32_t kWoff2Signature = 0x774f4632;  // "wOF2"

// Leave the first byte open to store flag_byte
const unsigned int kWoff2FlagsTransform = 1 << 8;

// TrueType Collection ID string: 'ttcf'
static const uint32_t kTtcFontFlavor = 0x74746366;

static const size_t kSfntHeaderSize = 12;
static const size_t kSfntEntrySize = 16;

struct Point {
  int x;
  int y;
  bool on_curve;
};

struct Table {
  uint32_t tag;
  uint32_t flags;
  uint32_t src_offset;
  uint32_t src_length;

  uint32_t transform_length;

  uint32_t dst_offset;
  uint32_t dst_length;
  const uint8_t* dst_data;

  bool operator<(const Table& other) const {
    fprintf(stderr, "[src/woff2_common.h] enter Table::operator< 1\n");
    return tag < other.tag;
    // fprintf(stderr, "[src/woff2_common.h] exit Table::operator< 1\n");
  }
};


// Size of the collection header. 0 if version indicates this isn't a
// collection. Ref http://www.microsoft.com/typography/otspec/otff.htm,
// True Type Collections
size_t CollectionHeaderSize(uint32_t header_version, uint32_t num_fonts);

// Compute checksum over size bytes of buf
uint32_t ComputeULongSum(const uint8_t* buf, size_t size);

} // namespace woff2

#endif  // WOFF2_WOFF2_COMMON_H_
// Total cost: 0.011931
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 64)]
// Total instrumented cost: 0.011931, input tokens: 2398, output tokens: 594, cache read tokens: 2394, cache write tokens: 611
