/* Copyright 2013 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

/* Helper functions for storing integer values into byte streams.
   No bounds checking is performed, that is the responsibility of the caller. */

#ifndef WOFF2_STORE_BYTES_H_
#define WOFF2_STORE_BYTES_H_

#include <inttypes.h>
#include <stddef.h>
#include <string.h>
#include <stdio.h>

#include "./port.h"

namespace woff2 {

inline size_t StoreU32(uint8_t* dst, size_t offset, uint32_t x) {
  fprintf(stderr, "[src/store_bytes.h] enter StoreU32 1\n");
  dst[offset] = x >> 24;
  dst[offset + 1] = x >> 16;
  dst[offset + 2] = x >> 8;
  dst[offset + 3] = x;
  return offset + 4;
  // fprintf(stderr, "[src/store_bytes.h] exit StoreU32 1\n");
}

inline size_t Store16(uint8_t* dst, size_t offset, int x) {
  fprintf(stderr, "[src/store_bytes.h] enter Store16 1\n");
  dst[offset] = x >> 8;
  dst[offset + 1] = x;
  return offset + 2;
  // fprintf(stderr, "[src/store_bytes.h] exit Store16 1\n");
}

inline void StoreU32(uint32_t val, size_t* offset, uint8_t* dst) {
  fprintf(stderr, "[src/store_bytes.h] enter StoreU32 2\n");
  dst[(*offset)++] = val >> 24;
  dst[(*offset)++] = val >> 16;
  dst[(*offset)++] = val >> 8;
  dst[(*offset)++] = val;
  // fprintf(stderr, "[src/store_bytes.h] exit StoreU32 2\n");
}

inline void Store16(int val, size_t* offset, uint8_t* dst) {
  fprintf(stderr, "[src/store_bytes.h] enter Store16 2\n");
  dst[(*offset)++] = val >> 8;
  dst[(*offset)++] = val;
  // fprintf(stderr, "[src/store_bytes.h] exit Store16 2\n");
}

inline void StoreBytes(const uint8_t* data, size_t len,
                       size_t* offset, uint8_t* dst) {
  fprintf(stderr, "[src/store_bytes.h] enter StoreBytes 1\n");
  memcpy(&dst[*offset], data, len);
  *offset += len;
  // fprintf(stderr, "[src/store_bytes.h] exit StoreBytes 1\n");
}

} // namespace woff2

#endif  // WOFF2_STORE_BYTES_H_
// Total cost: 0.013724
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 55)]
// Total instrumented cost: 0.013724, input tokens: 2398, output tokens: 716, cache read tokens: 2394, cache write tokens: 601
