package org.brotli.wrapper.enc;

import static org.junit.Assert.assertEquals;

import org.brotli.integration.BrotliJniTestBase;
import org.brotli.integration.BundleHelper;
import org.brotli.wrapper.dec.BrotliInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.WritableByteChannel;
import java.util.List;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import org.junit.runner.RunWith;
import org.junit.runners.AllTests;

/** Tests for {@link org.brotli.wrapper.enc.BrotliEncoderChannel}. */
@RunWith(AllTests.class)
public class BrotliEncoderChannelTest extends BrotliJniTestBase {

  private enum TestMode {
    WRITE_ALL,
    WRITE_CHUNKS
  }

  private static final int CHUNK_SIZE = 256;

  static InputStream getBundle() throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannelTest.java] enter getBundle 1");
    return new FileInputStream(System.getProperty("TEST_BUNDLE"));
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannelTest.java] exit getBundle 1");
  }

  /** Creates a test suite. */
  public static TestSuite suite() throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannelTest.java] enter suite 1");
    TestSuite suite = new TestSuite();
    InputStream bundle = getBundle();
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannelTest.java] exit suite 1");
    try {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannelTest.java] enter suite 2");
      List<String> entries = BundleHelper.listEntries(bundle);
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannelTest.java] exit suite 2");
      for (String entry : entries) {
        System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannelTest.java] enter suite 3");
        suite.addTest(new ChannleTestCase(entry, TestMode.WRITE_ALL));
        suite.addTest(new ChannleTestCase(entry, TestMode.WRITE_CHUNKS));
        // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannelTest.java] exit suite 3");
      }
    } finally {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannelTest.java] enter suite 4");
      bundle.close();
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannelTest.java] exit suite 4");
    }
    System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannelTest.java] enter suite 5");
    return suite;
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannelTest.java] exit suite 5");
  }

  /** Test case with a unique name. */
  static class ChannleTestCase extends TestCase {
    final String entryName;
    final TestMode mode;
    ChannleTestCase(String entryName, TestMode mode) {
      super("BrotliEncoderChannelTest." + entryName + "." + mode.name());
      System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannelTest.java] enter ChannleTestCase 1");
      this.entryName = entryName;
      this.mode = mode;
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannelTest.java] exit ChannleTestCase 1");
    }

    @Override
    protected void runTest() throws Throwable {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannelTest.java] enter runTest 1");
      BrotliEncoderChannelTest.run(entryName, mode);
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannelTest.java] exit runTest 1");
    }
  }

  private static void run(String entryName, TestMode mode) throws Throwable {
    System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannelTest.java] enter run 1");
    InputStream bundle = getBundle();
    byte[] original;
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannelTest.java] exit run 1");
    try {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannelTest.java] enter run 2");
      original = BundleHelper.readEntry(bundle, entryName);
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannelTest.java] exit run 2");
    } finally {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannelTest.java] enter run 3");
      bundle.close();
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannelTest.java] exit run 3");
    }
    if (original == null) {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannelTest.java] enter run 4");
      throw new RuntimeException("Can't read bundle entry: " + entryName);
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannelTest.java] exit run 4");
    }

    if ((mode == TestMode.WRITE_CHUNKS) && (original.length <= CHUNK_SIZE)) {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannelTest.java] enter run 5");
      return;
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannelTest.java] exit run 5");
    }

    System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannelTest.java] enter run 6");
    ByteArrayOutputStream dst = new ByteArrayOutputStream();
    WritableByteChannel encoder = new BrotliEncoderChannel(Channels.newChannel(dst));
    ByteBuffer src = ByteBuffer.wrap(original);
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannelTest.java] exit run 6");
    try {
      switch (mode) {
        case WRITE_ALL:
          System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannelTest.java] enter run 7");
          encoder.write(src);
          break;
          // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannelTest.java] exit run 7");

        case WRITE_CHUNKS:
          System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannelTest.java] enter run 8");
          while (src.hasRemaining()) {
            System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannelTest.java] enter run 9");
            int limit = Math.min(CHUNK_SIZE, src.remaining());
            ByteBuffer slice = src.slice();
            slice.limit(limit);
            src.position(src.position() + limit);
            encoder.write(slice);
            // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannelTest.java] exit run 9");
          }
          break;
          // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannelTest.java] exit run 8");
      }
    } finally {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannelTest.java] enter run 10");
      encoder.close();
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannelTest.java] exit run 10");
    }

    System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannelTest.java] enter run 11");
    InputStream decoder = new BrotliInputStream(new ByteArrayInputStream(dst.toByteArray()));
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannelTest.java] exit run 11");
    try {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannelTest.java] enter run 12");
      long originalCrc = BundleHelper.fingerprintStream(new ByteArrayInputStream(original));
      long crc = BundleHelper.fingerprintStream(decoder);
      assertEquals(originalCrc, crc);
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannelTest.java] exit run 12");
    } finally {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannelTest.java] enter run 13");
      decoder.close();
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannelTest.java] exit run 13");
    }
  }
}
// Total cost: 0.029883
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 117)]
// Total instrumented cost: 0.029883, input tokens: 2398, output tokens: 1655, cache read tokens: 2394, cache write tokens: 1154
