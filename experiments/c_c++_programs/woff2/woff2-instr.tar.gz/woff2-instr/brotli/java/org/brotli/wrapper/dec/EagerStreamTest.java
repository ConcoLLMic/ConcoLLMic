/* Copyright 2017 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

package org.brotli.wrapper.dec;

import static org.junit.Assert.assertEquals;

import org.brotli.integration.BrotliJniTestBase;
import java.io.IOException;
import java.io.InputStream;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

/** Tests for {@link org.brotli.wrapper.dec.BrotliInputStream}. */
@RunWith(JUnit4.class)
public class EagerStreamTest extends BrotliJniTestBase {

  @Test
  public void testEagerReading() throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/dec/EagerStreamTest.java] enter testEagerReading 1");
    final StringBuilder log = new StringBuilder();
    final byte[] data = {0, 0, 16, 42, 3};
    InputStream source = new InputStream() {
      int index;

      @Override
      public int read() {
        System.err.println("[brotli/java/org/brotli/wrapper/dec/EagerStreamTest.java] enter read 1");
        if (index < data.length) {
          System.err.println("[brotli/java/org/brotli/wrapper/dec/EagerStreamTest.java] enter read 2");
          log.append("<").append(index);
          return data[index++];
          // System.err.println("[brotli/java/org/brotli/wrapper/dec/EagerStreamTest.java] exit read 2");
        } else {
          System.err.println("[brotli/java/org/brotli/wrapper/dec/EagerStreamTest.java] enter read 3");
          log.append("<#");
          return -1;
          // System.err.println("[brotli/java/org/brotli/wrapper/dec/EagerStreamTest.java] exit read 3");
        }
        // System.err.println("[brotli/java/org/brotli/wrapper/dec/EagerStreamTest.java] exit read 1");
      }

      @Override
      public int read(byte[] b) throws IOException {
        System.err.println("[brotli/java/org/brotli/wrapper/dec/EagerStreamTest.java] enter read(byte[]) 1");
        return read(b, 0, b.length);
        // System.err.println("[brotli/java/org/brotli/wrapper/dec/EagerStreamTest.java] exit read(byte[]) 1");
      }

      @Override
      public int read(byte[] b, int off, int len) throws IOException {
        System.err.println("[brotli/java/org/brotli/wrapper/dec/EagerStreamTest.java] enter read(byte[],int,int) 1");
        if (len < 1) {
          System.err.println("[brotli/java/org/brotli/wrapper/dec/EagerStreamTest.java] enter read(byte[],int,int) 2");
          return 0;
          // System.err.println("[brotli/java/org/brotli/wrapper/dec/EagerStreamTest.java] exit read(byte[],int,int) 2");
        }
        int d = read();
        if (d == -1) {
          System.err.println("[brotli/java/org/brotli/wrapper/dec/EagerStreamTest.java] enter read(byte[],int,int) 3");
          return 0;
          // System.err.println("[brotli/java/org/brotli/wrapper/dec/EagerStreamTest.java] exit read(byte[],int,int) 3");
        }
        System.err.println("[brotli/java/org/brotli/wrapper/dec/EagerStreamTest.java] enter read(byte[],int,int) 4");
        b[off] = (byte) d;
        return 1;
        // System.err.println("[brotli/java/org/brotli/wrapper/dec/EagerStreamTest.java] exit read(byte[],int,int) 4");
        // System.err.println("[brotli/java/org/brotli/wrapper/dec/EagerStreamTest.java] exit read(byte[],int,int) 1");
      }
    };
    BrotliInputStream reader = new BrotliInputStream(source);
    reader.setEager(true);
    int count = 0;
    while (true) {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/EagerStreamTest.java] enter testEagerReading 2");
      log.append("^").append(count);
      int b = reader.read();
      if (b == -1) {
        System.err.println("[brotli/java/org/brotli/wrapper/dec/EagerStreamTest.java] enter testEagerReading 3");
        log.append(">#");
        break;
        // System.err.println("[brotli/java/org/brotli/wrapper/dec/EagerStreamTest.java] exit testEagerReading 3");
      } else {
        System.err.println("[brotli/java/org/brotli/wrapper/dec/EagerStreamTest.java] enter testEagerReading 4");
        log.append(">").append(count++);
        // System.err.println("[brotli/java/org/brotli/wrapper/dec/EagerStreamTest.java] exit testEagerReading 4");
      }
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/EagerStreamTest.java] exit testEagerReading 2");
    }
    // Lazy log:  ^0<0<1<2<3<4>0^1>#
    System.err.println("[brotli/java/org/brotli/wrapper/dec/EagerStreamTest.java] enter testEagerReading 5");
    assertEquals("^0<0<1<2<3>0^1<4>#", log.toString());
    // System.err.println("[brotli/java/org/brotli/wrapper/dec/EagerStreamTest.java] exit testEagerReading 5");
    // System.err.println("[brotli/java/org/brotli/wrapper/dec/EagerStreamTest.java] exit testEagerReading 1");
  }

}
// Total cost: 0.019630
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 75)]
// Total instrumented cost: 0.019630, input tokens: 2398, output tokens: 1086, cache read tokens: 2394, cache write tokens: 696
