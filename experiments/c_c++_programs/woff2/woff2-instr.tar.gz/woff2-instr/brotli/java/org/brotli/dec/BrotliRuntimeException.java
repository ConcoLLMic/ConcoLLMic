/* Copyright 2015 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

package org.brotli.dec;

/**
 * Unchecked exception used internally.
 */
class BrotliRuntimeException extends RuntimeException {

  BrotliRuntimeException(String message) {
    System.err.println("[brotli/java/org/brotli/dec/BrotliRuntimeException.java] enter BrotliRuntimeException 1");
    super(message);
    // System.err.println("[brotli/java/org/brotli/dec/BrotliRuntimeException.java] exit BrotliRuntimeException 1");
  }

  BrotliRuntimeException(String message, Throwable cause) {
    System.err.println("[brotli/java/org/brotli/dec/BrotliRuntimeException.java] enter BrotliRuntimeException 2");
    super(message, cause);
    // System.err.println("[brotli/java/org/brotli/dec/BrotliRuntimeException.java] exit BrotliRuntimeException 2");
  }
}
// Total cost: 0.005020
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 21)]
// Total instrumented cost: 0.005020, input tokens: 2398, output tokens: 229, cache read tokens: 2394, cache write tokens: 228
