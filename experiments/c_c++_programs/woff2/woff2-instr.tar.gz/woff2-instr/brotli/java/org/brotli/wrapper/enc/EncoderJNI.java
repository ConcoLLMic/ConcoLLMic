/* Copyright 2017 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

package org.brotli.wrapper.enc;

import java.io.IOException;
import java.nio.ByteBuffer;

/**
 * JNI wrapper for brotli encoder.
 */
class EncoderJNI {
  private static native ByteBuffer nativeCreate(long[] context);
  private static native void nativePush(long[] context, int length);
  private static native ByteBuffer nativePull(long[] context);
  private static native void nativeDestroy(long[] context);

  enum Operation {
    PROCESS,
    FLUSH,
    FINISH
  }

  static class Wrapper {
    protected final long[] context = new long[5];
    private final ByteBuffer inputBuffer;

    Wrapper(int inputBufferSize, int quality, int lgwin)
        throws IOException {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/EncoderJNI.java] enter Wrapper 1");
      this.context[1] = inputBufferSize;
      this.context[2] = quality;
      this.context[3] = lgwin;
      this.inputBuffer = nativeCreate(this.context);
      if (this.context[0] == 0) {
        throw new IOException("failed to initialize native brotli encoder");
      }
      this.context[1] = 1;
      this.context[2] = 0;
      this.context[3] = 0;
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/EncoderJNI.java] exit Wrapper 1");
    }

    void push(Operation op, int length) {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/EncoderJNI.java] enter push 1");
      if (length < 0) {
        throw new IllegalArgumentException("negative block length");
      }
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/EncoderJNI.java] exit push 1");
      
      System.err.println("[brotli/java/org/brotli/wrapper/enc/EncoderJNI.java] enter push 2");
      if (context[0] == 0) {
        throw new IllegalStateException("brotli encoder is already destroyed");
      }
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/EncoderJNI.java] exit push 2");
      
      System.err.println("[brotli/java/org/brotli/wrapper/enc/EncoderJNI.java] enter push 3");
      if (!isSuccess() || hasMoreOutput()) {
        throw new IllegalStateException("pushing input to encoder in unexpected state");
      }
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/EncoderJNI.java] exit push 3");
      
      System.err.println("[brotli/java/org/brotli/wrapper/enc/EncoderJNI.java] enter push 4");
      if (hasRemainingInput() && length != 0) {
        throw new IllegalStateException("pushing input to encoder over previous input");
      }
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/EncoderJNI.java] exit push 4");
      
      System.err.println("[brotli/java/org/brotli/wrapper/enc/EncoderJNI.java] enter push 5");
      context[1] = op.ordinal();
      nativePush(context, length);
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/EncoderJNI.java] exit push 5");
    }

    boolean isSuccess() {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/EncoderJNI.java] enter isSuccess 1");
      return context[1] != 0;
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/EncoderJNI.java] exit isSuccess 1");
    }

    boolean hasMoreOutput() {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/EncoderJNI.java] enter hasMoreOutput 1");
      return context[2] != 0;
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/EncoderJNI.java] exit hasMoreOutput 1");
    }

    boolean hasRemainingInput() {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/EncoderJNI.java] enter hasRemainingInput 1");
      return context[3] != 0;
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/EncoderJNI.java] exit hasRemainingInput 1");
    }

    boolean isFinished() {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/EncoderJNI.java] enter isFinished 1");
      return context[4] != 0;
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/EncoderJNI.java] exit isFinished 1");
    }

    ByteBuffer getInputBuffer() {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/EncoderJNI.java] enter getInputBuffer 1");
      return inputBuffer;
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/EncoderJNI.java] exit getInputBuffer 1");
    }

    ByteBuffer pull() {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/EncoderJNI.java] enter pull 1");
      if (context[0] == 0) {
        throw new IllegalStateException("brotli encoder is already destroyed");
      }
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/EncoderJNI.java] exit pull 1");
      
      System.err.println("[brotli/java/org/brotli/wrapper/enc/EncoderJNI.java] enter pull 2");
      if (!isSuccess() || !hasMoreOutput()) {
        throw new IllegalStateException("pulling while data is not ready");
      }
      return nativePull(context);
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/EncoderJNI.java] exit pull 2");
    }

    /**
     * Releases native resources.
     */
    void destroy() {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/EncoderJNI.java] enter destroy 1");
      if (context[0] == 0) {
        throw new IllegalStateException("brotli encoder is already destroyed");
      }
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/EncoderJNI.java] exit destroy 1");
      
      System.err.println("[brotli/java/org/brotli/wrapper/enc/EncoderJNI.java] enter destroy 2");
      nativeDestroy(context);
      context[0] = 0;
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/EncoderJNI.java] exit destroy 2");
    }

    @Override
    protected void finalize() throws Throwable {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/EncoderJNI.java] enter finalize 1");
      if (context[0] != 0) {
        /* TODO: log resource leak? */
        destroy();
      }
      super.finalize();
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/EncoderJNI.java] exit finalize 1");
    }
  }
}
// Total cost: 0.024505
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 112)]
// Total instrumented cost: 0.024505, input tokens: 2398, output tokens: 1347, cache read tokens: 2394, cache write tokens: 952
