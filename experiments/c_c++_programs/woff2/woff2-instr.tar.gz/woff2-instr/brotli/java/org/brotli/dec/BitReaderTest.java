/* Copyright 2015 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

package org.brotli.dec;

import static org.junit.Assert.fail;

import java.io.ByteArrayInputStream;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

/**
 * Tests for {@link BitReader}.
 */
@RunWith(JUnit4.class)
public class BitReaderTest {

  @Test
  public void testReadAfterEos() {
    System.err.println("[brotli/java/org/brotli/dec/BitReaderTest.java] enter testReadAfterEos 1");
    State reader = new State();
    Decode.initState(reader, new ByteArrayInputStream(new byte[1]));
    BitReader.readBits(reader, 9);
    // System.err.println("[brotli/java/org/brotli/dec/BitReaderTest.java] exit testReadAfterEos 1");
    try {
      System.err.println("[brotli/java/org/brotli/dec/BitReaderTest.java] enter testReadAfterEos 2");
      BitReader.checkHealth(reader, 0);
      // System.err.println("[brotli/java/org/brotli/dec/BitReaderTest.java] exit testReadAfterEos 2");
    } catch (BrotliRuntimeException ex) {
      System.err.println("[brotli/java/org/brotli/dec/BitReaderTest.java] enter testReadAfterEos 3");
      // This exception is expected.
      return;
      // System.err.println("[brotli/java/org/brotli/dec/BitReaderTest.java] exit testReadAfterEos 3");
    }
    System.err.println("[brotli/java/org/brotli/dec/BitReaderTest.java] enter testReadAfterEos 4");
    fail("BrotliRuntimeException should have been thrown by BitReader.checkHealth");
    // System.err.println("[brotli/java/org/brotli/dec/BitReaderTest.java] exit testReadAfterEos 4");
  }
}
// Total cost: 0.008710
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 35)]
// Total instrumented cost: 0.008710, input tokens: 2398, output tokens: 441, cache read tokens: 2394, cache write tokens: 364
