/* Copyright 2015 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

package org.brotli.dec;

import java.nio.ByteBuffer;
import java.io.PrintStream;

/**
 * Collection of static dictionary words.
 *
 * <p>Dictionary content is loaded from binary resource when {@link #getData()} is executed for the
 * first time. Consequently, it saves memory and CPU in case dictionary is not required.
 *
 * <p>One possible drawback is that multiple threads that need dictionary data may be blocked (only
 * once in each classworld). To avoid this, it is enough to call {@link #getData()} proactively.
 */
public final class Dictionary {
  private static volatile ByteBuffer data;

  private static class DataLoader {
    static final boolean OK;

    static {
      System.err.println("[brotli/java/org/brotli/dec/Dictionary.java] enter DataLoader.static 1");
      boolean ok = true;
      try {
        Class.forName(Dictionary.class.getPackage().getName() + ".DictionaryData");
      } catch (Throwable ex) {
        System.err.println("[brotli/java/org/brotli/dec/Dictionary.java] enter DataLoader.static 2");
        ok = false;
        // System.err.println("[brotli/java/org/brotli/dec/Dictionary.java] exit DataLoader.static 2");
      }
      OK = ok;
      // System.err.println("[brotli/java/org/brotli/dec/Dictionary.java] exit DataLoader.static 1");
    }
  }

  public static void setData(ByteBuffer data) {
    System.err.println("[brotli/java/org/brotli/dec/Dictionary.java] enter Dictionary.setData 1");
    if (!data.isDirect() || !data.isReadOnly()) {
      System.err.println("[brotli/java/org/brotli/dec/Dictionary.java] enter Dictionary.setData 2");
      throw new BrotliRuntimeException("data must be a direct read-only byte buffer");
      // System.err.println("[brotli/java/org/brotli/dec/Dictionary.java] exit Dictionary.setData 2");
    }
    Dictionary.data = data;
    // System.err.println("[brotli/java/org/brotli/dec/Dictionary.java] exit Dictionary.setData 1");
  }

  public static ByteBuffer getData() {
    System.err.println("[brotli/java/org/brotli/dec/Dictionary.java] enter Dictionary.getData 1");
    if (data != null) {
      System.err.println("[brotli/java/org/brotli/dec/Dictionary.java] enter Dictionary.getData 2");
      return data;
      // System.err.println("[brotli/java/org/brotli/dec/Dictionary.java] exit Dictionary.getData 2");
    }
    if (!DataLoader.OK) {
      System.err.println("[brotli/java/org/brotli/dec/Dictionary.java] enter Dictionary.getData 3");
      throw new BrotliRuntimeException("brotli dictionary is not set");
      // System.err.println("[brotli/java/org/brotli/dec/Dictionary.java] exit Dictionary.getData 3");
    }
    /* Might have been set when {@link DictionaryData} was loaded.*/
    return data;
    // System.err.println("[brotli/java/org/brotli/dec/Dictionary.java] exit Dictionary.getData 1");
  }
}
// Total cost: 0.013101
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 54)]
// Total instrumented cost: 0.013101, input tokens: 2398, output tokens: 693, cache read tokens: 2394, cache write tokens: 527
