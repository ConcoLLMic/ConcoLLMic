/* Copyright 2017 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

#include <jni.h>
#include <stdio.h>

#include "../common/dictionary.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Set data to be brotli dictionary data.
 *
 * @param buffer direct ByteBuffer
 * @returns false if dictionary data was already set; otherwise true
 */
JNIEXPORT jint JNICALL
Java_org_brotli_wrapper_common_CommonJNI_nativeSetDictionaryData(
    JNIEnv* env, jobject /*jobj*/, jobject buffer) {
  fprintf(stderr, "\n");
  jobject buffer_ref = env->NewGlobalRef(buffer);
  if (!buffer_ref) {
    fprintf(stderr, "[brotli/java/org/brotli/wrapper/common/common_jni.cc] enter Java_org_brotli_wrapper_common_CommonJNI_nativeSetDictionaryData 2\n");
    return false;
    // fprintf(stderr, "[brotli/java/org/brotli/wrapper/common/common_jni.cc] exit Java_org_brotli_wrapper_common_CommonJNI_nativeSetDictionaryData 2\n");
  }
  fprintf(stderr, "\n");
  uint8_t* data = static_cast<uint8_t*>(env->GetDirectBufferAddress(buffer));
  if (!data) {
    fprintf(stderr, "[brotli/java/org/brotli/wrapper/common/common_jni.cc] enter Java_org_brotli_wrapper_common_CommonJNI_nativeSetDictionaryData 4\n");
    env->DeleteGlobalRef(buffer_ref);
    return false;
    // fprintf(stderr, "[brotli/java/org/brotli/wrapper/common/common_jni.cc] exit Java_org_brotli_wrapper_common_CommonJNI_nativeSetDictionaryData 4\n");
  }

  fprintf(stderr, "\n");
  BrotliSetDictionaryData(data);

  const BrotliDictionary* dictionary = BrotliGetDictionary();
  if (dictionary->data != data) {
    fprintf(stderr, "[brotli/java/org/brotli/wrapper/common/common_jni.cc] enter Java_org_brotli_wrapper_common_CommonJNI_nativeSetDictionaryData 6\n");
    env->DeleteGlobalRef(buffer_ref);
    // fprintf(stderr, "[brotli/java/org/brotli/wrapper/common/common_jni.cc] exit Java_org_brotli_wrapper_common_CommonJNI_nativeSetDictionaryData 6\n");
  } else {
    fprintf(stderr, "[brotli/java/org/brotli/wrapper/common/common_jni.cc] enter Java_org_brotli_wrapper_common_CommonJNI_nativeSetDictionaryData 7\n");
    /* Don't release reference; it is an intended memory leak. */
    // fprintf(stderr, "[brotli/java/org/brotli/wrapper/common/common_jni.cc] exit Java_org_brotli_wrapper_common_CommonJNI_nativeSetDictionaryData 7\n");
  }
  fprintf(stderr, "[brotli/java/org/brotli/wrapper/common/common_jni.cc] enter Java_org_brotli_wrapper_common_CommonJNI_nativeSetDictionaryData 8\n");
  return true;
  // fprintf(stderr, "[brotli/java/org/brotli/wrapper/common/common_jni.cc] exit Java_org_brotli_wrapper_common_CommonJNI_nativeSetDictionaryData 8\n");
}

#ifdef __cplusplus
}
#endif
// Total cost: 0.015839
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 47)]
// Total instrumented cost: 0.015839, input tokens: 2398, output tokens: 890, cache read tokens: 2394, cache write tokens: 469
