/* Copyright 2017 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

package org.brotli.wrapper.dec;

import static org.junit.Assert.assertEquals;

import org.brotli.integration.BrotliJniTestBase;
import org.brotli.integration.BundleHelper;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.util.List;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import org.junit.runner.RunWith;
import org.junit.runners.AllTests;

/** Tests for {@link org.brotli.wrapper.dec.BrotliDecoderChannel}. */
@RunWith(AllTests.class)
public class BrotliDecoderChannelTest extends BrotliJniTestBase {

  static InputStream getBundle() throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannelTest.java] enter getBundle 1");
    return new FileInputStream(System.getProperty("TEST_BUNDLE"));
    // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannelTest.java] exit getBundle 1");
  }

  /** Creates a test suite. */
  public static TestSuite suite() throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannelTest.java] enter suite 1");
    TestSuite suite = new TestSuite();
    InputStream bundle = getBundle();
    // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannelTest.java] exit suite 1");
    try {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannelTest.java] enter suite 2");
      List<String> entries = BundleHelper.listEntries(bundle);
      for (String entry : entries) {
        System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannelTest.java] enter suite 3");
        suite.addTest(new ChannelTestCase(entry));
        // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannelTest.java] exit suite 3");
      }
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannelTest.java] exit suite 2");
    } finally {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannelTest.java] enter suite 4");
      bundle.close();
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannelTest.java] exit suite 4");
    }
    System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannelTest.java] enter suite 5");
    return suite;
    // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannelTest.java] exit suite 5");
  }

  /** Test case with a unique name. */
  static class ChannelTestCase extends TestCase {
    final String entryName;
    ChannelTestCase(String entryName) {
      super("BrotliDecoderChannelTest." + entryName);
      System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannelTest.java] enter ChannelTestCase.constructor 1");
      this.entryName = entryName;
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannelTest.java] exit ChannelTestCase.constructor 1");
    }

    @Override
    protected void runTest() throws Throwable {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannelTest.java] enter ChannelTestCase.runTest 1");
      BrotliDecoderChannelTest.run(entryName);
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannelTest.java] exit ChannelTestCase.runTest 1");
    }
  }

  private static void run(String entryName) throws Throwable {
    System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannelTest.java] enter run 1");
    InputStream bundle = getBundle();
    byte[] compressed;
    // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannelTest.java] exit run 1");
    try {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannelTest.java] enter run 2");
      compressed = BundleHelper.readEntry(bundle, entryName);
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannelTest.java] exit run 2");
    } finally {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannelTest.java] enter run 3");
      bundle.close();
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannelTest.java] exit run 3");
    }
    if (compressed == null) {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannelTest.java] enter run 4");
      throw new RuntimeException("Can't read bundle entry: " + entryName);
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannelTest.java] exit run 4");
    }

    System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannelTest.java] enter run 5");
    ReadableByteChannel src = Channels.newChannel(new ByteArrayInputStream(compressed));
    ReadableByteChannel decoder = new BrotliDecoderChannel(src);
    long crc;
    // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannelTest.java] exit run 5");
    try {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannelTest.java] enter run 6");
      crc = BundleHelper.fingerprintStream(Channels.newInputStream(decoder));
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannelTest.java] exit run 6");
    } finally {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannelTest.java] enter run 7");
      decoder.close();
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannelTest.java] exit run 7");
    }
    System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannelTest.java] enter run 8");
    assertEquals(BundleHelper.getExpectedFingerprint(entryName), crc);
    // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannelTest.java] exit run 8");
  }
}
// Total cost: 0.022398
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 84)]
// Total instrumented cost: 0.022398, input tokens: 2398, output tokens: 1232, cache read tokens: 2394, cache write tokens: 850
