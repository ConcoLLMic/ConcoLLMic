/* Copyright 2015 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

package org.brotli.wrapper.common;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;

import org.brotli.integration.BrotliJniTestBase;
import org.brotli.wrapper.dec.BrotliInputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

/**
 * Tests for {@link BrotliCommon}.
 */
@RunWith(JUnit4.class)
public class SetZeroDictionaryTest extends BrotliJniTestBase {

  @Test
  public void testZeroDictionary() throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/common/SetZeroDictionaryTest.java] enter testZeroDictionary 1");
    /* "leftdatadataleft" encoded with dictionary words. */
    byte[] data = {27, 15, 0, 0, 0, 0, -128, -29, -76, 13, 0, 0, 7, 91, 38, 49, 64, 2, 0, -32, 78,
        27, 65, -128, 32, 80, 16, 36, 8, 6};
    byte[] dictionary = new byte[BrotliCommon.RFC_DICTIONARY_SIZE];
    BrotliCommon.setDictionaryData(dictionary);

    BrotliInputStream decoder = new BrotliInputStream(new ByteArrayInputStream(data));
    byte[] output = new byte[17];
    int offset = 0;
    // System.err.println("[brotli/java/org/brotli/wrapper/common/SetZeroDictionaryTest.java] exit testZeroDictionary 1");
    
    try {
      System.err.println("[brotli/java/org/brotli/wrapper/common/SetZeroDictionaryTest.java] enter testZeroDictionary 2");
      int bytesRead;
      // System.err.println("[brotli/java/org/brotli/wrapper/common/SetZeroDictionaryTest.java] exit testZeroDictionary 2");
      
      while ((bytesRead = decoder.read(output, offset, 17 - offset)) != -1) {
        System.err.println("[brotli/java/org/brotli/wrapper/common/SetZeroDictionaryTest.java] enter testZeroDictionary 3");
        offset += bytesRead;
        // System.err.println("[brotli/java/org/brotli/wrapper/common/SetZeroDictionaryTest.java] exit testZeroDictionary 3");
      }
    } finally {
      System.err.println("[brotli/java/org/brotli/wrapper/common/SetZeroDictionaryTest.java] enter testZeroDictionary 4");
      decoder.close();
      // System.err.println("[brotli/java/org/brotli/wrapper/common/SetZeroDictionaryTest.java] exit testZeroDictionary 4");
    }
    
    System.err.println("[brotli/java/org/brotli/wrapper/common/SetZeroDictionaryTest.java] enter testZeroDictionary 5");
    assertEquals(16, offset);
    assertArrayEquals(new byte[17], output);
    // System.err.println("[brotli/java/org/brotli/wrapper/common/SetZeroDictionaryTest.java] exit testZeroDictionary 5");
  }
}
// Total cost: 0.013874
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 48)]
// Total instrumented cost: 0.013874, input tokens: 2398, output tokens: 724, cache read tokens: 2394, cache write tokens: 609
