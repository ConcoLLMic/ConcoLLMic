/* Copyright 2017 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

package org.brotli.wrapper.common;

import java.nio.ByteBuffer;

/**
 * JNI wrapper for brotli common.
 */
class CommonJNI {
  static native boolean nativeSetDictionaryData(ByteBuffer data);
}
// Total cost: 0.001840
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 16)]
// Total instrumented cost: 0.001840, input tokens: 2398, output tokens: 23, cache read tokens: 2394, cache write tokens: 204
