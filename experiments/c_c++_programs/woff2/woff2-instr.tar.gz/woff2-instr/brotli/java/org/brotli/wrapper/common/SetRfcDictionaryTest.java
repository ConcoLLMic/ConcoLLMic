/* Copyright 2015 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

package org.brotli.wrapper.common;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import org.brotli.integration.BrotliJniTestBase;
import org.brotli.wrapper.dec.BrotliInputStream;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

/**
 * Tests for {@link BrotliCommon}.
 */
@RunWith(JUnit4.class)
public class SetRfcDictionaryTest extends BrotliJniTestBase {

  @Test
  public void testRfcDictionaryChecksums() throws IOException, NoSuchAlgorithmException {
    System.err.println("[brotli/java/org/brotli/wrapper/common/SetRfcDictionaryTest.java] enter testRfcDictionaryChecksums 1");
    FileInputStream dictionary = new FileInputStream(System.getProperty("RFC_DICTIONARY"));
    byte[] data = new byte[BrotliCommon.RFC_DICTIONARY_SIZE + 1];
    int offset = 0;
    // System.err.println("[brotli/java/org/brotli/wrapper/common/SetRfcDictionaryTest.java] exit testRfcDictionaryChecksums 1");
    try {
      System.err.println("[brotli/java/org/brotli/wrapper/common/SetRfcDictionaryTest.java] enter testRfcDictionaryChecksums 2");
      int readBytes;
      // System.err.println("[brotli/java/org/brotli/wrapper/common/SetRfcDictionaryTest.java] exit testRfcDictionaryChecksums 2");
      while ((readBytes = dictionary.read(data, offset, data.length - offset)) != -1) {
        System.err.println("[brotli/java/org/brotli/wrapper/common/SetRfcDictionaryTest.java] enter testRfcDictionaryChecksums 3");
        offset += readBytes;
        // System.err.println("[brotli/java/org/brotli/wrapper/common/SetRfcDictionaryTest.java] exit testRfcDictionaryChecksums 3");
        if (offset > BrotliCommon.RFC_DICTIONARY_SIZE) {
          System.err.println("[brotli/java/org/brotli/wrapper/common/SetRfcDictionaryTest.java] enter testRfcDictionaryChecksums 4");
          break;
          // System.err.println("[brotli/java/org/brotli/wrapper/common/SetRfcDictionaryTest.java] exit testRfcDictionaryChecksums 4");
        }
      }
    } finally {
      System.err.println("[brotli/java/org/brotli/wrapper/common/SetRfcDictionaryTest.java] enter testRfcDictionaryChecksums 5");
      dictionary.close();
      // System.err.println("[brotli/java/org/brotli/wrapper/common/SetRfcDictionaryTest.java] exit testRfcDictionaryChecksums 5");
    }
    
    System.err.println("[brotli/java/org/brotli/wrapper/common/SetRfcDictionaryTest.java] enter testRfcDictionaryChecksums 6");
    if (offset != BrotliCommon.RFC_DICTIONARY_SIZE) {
      System.err.println("[brotli/java/org/brotli/wrapper/common/SetRfcDictionaryTest.java] enter testRfcDictionaryChecksums 7");
      fail("dictionary size mismatch");
      // System.err.println("[brotli/java/org/brotli/wrapper/common/SetRfcDictionaryTest.java] exit testRfcDictionaryChecksums 7");
    }

    MessageDigest md5 = MessageDigest.getInstance("MD5");
    md5.update(data, 0, offset);
    assertTrue(BrotliCommon.checkDictionaryDataMd5(md5.digest()));

    MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
    sha1.update(data, 0, offset);
    assertTrue(BrotliCommon.checkDictionaryDataSha1(sha1.digest()));

    MessageDigest sha256 = MessageDigest.getInstance("SHA-256");
    sha256.update(data, 0, offset);
    assertTrue(BrotliCommon.checkDictionaryDataSha256(sha256.digest()));
    // System.err.println("[brotli/java/org/brotli/wrapper/common/SetRfcDictionaryTest.java] exit testRfcDictionaryChecksums 6");
  }

  @Test
  public void testSetRfcDictionary() throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/common/SetRfcDictionaryTest.java] enter testSetRfcDictionary 1");
    /* "leftdatadataleft" encoded with dictionary words. */
    byte[] data = {27, 15, 0, 0, 0, 0, -128, -29, -76, 13, 0, 0, 7, 91, 38, 49, 64, 2, 0, -32, 78,
        27, 65, -128, 32, 80, 16, 36, 8, 6};
    FileInputStream dictionary = new FileInputStream(System.getProperty("RFC_DICTIONARY"));
    // System.err.println("[brotli/java/org/brotli/wrapper/common/SetRfcDictionaryTest.java] exit testSetRfcDictionary 1");
    try {
      System.err.println("[brotli/java/org/brotli/wrapper/common/SetRfcDictionaryTest.java] enter testSetRfcDictionary 2");
      BrotliCommon.setDictionaryData(dictionary);
      // System.err.println("[brotli/java/org/brotli/wrapper/common/SetRfcDictionaryTest.java] exit testSetRfcDictionary 2");
    } finally {
      System.err.println("[brotli/java/org/brotli/wrapper/common/SetRfcDictionaryTest.java] enter testSetRfcDictionary 3");
      dictionary.close();
      // System.err.println("[brotli/java/org/brotli/wrapper/common/SetRfcDictionaryTest.java] exit testSetRfcDictionary 3");
    }

    System.err.println("[brotli/java/org/brotli/wrapper/common/SetRfcDictionaryTest.java] enter testSetRfcDictionary 4");
    BrotliInputStream decoder = new BrotliInputStream(new ByteArrayInputStream(data));
    byte[] output = new byte[17];
    int offset = 0;
    // System.err.println("[brotli/java/org/brotli/wrapper/common/SetRfcDictionaryTest.java] exit testSetRfcDictionary 4");
    try {
      System.err.println("[brotli/java/org/brotli/wrapper/common/SetRfcDictionaryTest.java] enter testSetRfcDictionary 5");
      int bytesRead;
      // System.err.println("[brotli/java/org/brotli/wrapper/common/SetRfcDictionaryTest.java] exit testSetRfcDictionary 5");
      while ((bytesRead = decoder.read(output, offset, 17 - offset)) != -1) {
        System.err.println("[brotli/java/org/brotli/wrapper/common/SetRfcDictionaryTest.java] enter testSetRfcDictionary 6");
        offset += bytesRead;
        // System.err.println("[brotli/java/org/brotli/wrapper/common/SetRfcDictionaryTest.java] exit testSetRfcDictionary 6");
      }
    } finally {
      System.err.println("[brotli/java/org/brotli/wrapper/common/SetRfcDictionaryTest.java] enter testSetRfcDictionary 7");
      decoder.close();
      // System.err.println("[brotli/java/org/brotli/wrapper/common/SetRfcDictionaryTest.java] exit testSetRfcDictionary 7");
    }
    
    System.err.println("[brotli/java/org/brotli/wrapper/common/SetRfcDictionaryTest.java] enter testSetRfcDictionary 8");
    assertEquals(16, offset);
    byte[] expected = {
      'l', 'e', 'f', 't',
      'd', 'a', 't', 'a',
      'd', 'a', 't', 'a',
      'l', 'e', 'f', 't',
      0
    };
    assertArrayEquals(expected, output);
    // System.err.println("[brotli/java/org/brotli/wrapper/common/SetRfcDictionaryTest.java] exit testSetRfcDictionary 8");
  }
}
// Total cost: 0.030505
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 97)]
// Total instrumented cost: 0.030505, input tokens: 2398, output tokens: 1702, cache read tokens: 2394, cache write tokens: 1132
