/* Copyright 2015 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

package org.brotli.dec;

import java.nio.ByteBuffer;

/**
 * Transformations on dictionary words.
 */
final class Transform {

  static final int NUM_TRANSFORMS = 121;
  private static final int[] TRANSFORMS = new int[NUM_TRANSFORMS * 3];
  private static final byte[] PREFIX_SUFFIX = new byte[217];
  private static final int[] PREFIX_SUFFIX_HEADS = new int[51];

  // Bundle of 0-terminated strings.
  private static final String PREFIX_SUFFIX_SRC = "# #s #, #e #.# the #.com/#\u00C2\u00A0# of # and"
      + " # in # to #\"#\">#\n#]# for # a # that #. # with #'# from # by #. The # on # as # is #ing"
      + " #\n\t#:#ed #(# at #ly #=\"# of the #. This #,# not #er #al #='#ful #ive #less #est #ize #"
      + "ous #";
  private static final String TRANSFORMS_SRC = "     !! ! ,  *!  &!  \" !  ) *   * -  ! # !  #!*!  "
      + "+  ,$ !  -  %  .  / #   0  1 .  \"   2  3!*   4%  ! # /   5  6  7  8 0  1 &   $   9 +   : "
      + " ;  < '  !=  >  ?! 4  @ 4  2  &   A *# (   B  C& ) %  ) !*# *-% A +! *.  D! %'  & E *6  F "
      + " G% ! *A *%  H! D  I!+!  J!+   K +- *4! A  L!*4  M  N +6  O!*% +.! K *G  P +%(  ! G *D +D "
      + " Q +# *K!*G!+D!+# +G +A +4!+% +K!+4!*D!+K!*K";

  private static void unpackTransforms(byte[] prefixSuffix, int[] prefixSuffixHeads,
      int[] transforms, String prefixSuffixSrc, String transformsSrc) {
    System.err.println("[brotli/java/org/brotli/dec/Transform.java] enter unpackTransforms 1");
    int n = prefixSuffixSrc.length();
    int index = 1;
    for (int i = 0; i < n; ++i) {
      System.err.println("[brotli/java/org/brotli/dec/Transform.java] enter unpackTransforms 2");
      char c = prefixSuffixSrc.charAt(i);
      prefixSuffix[i] = (byte) c;
      if (c == 35) { // == #
        System.err.println("[brotli/java/org/brotli/dec/Transform.java] enter unpackTransforms 3");
        prefixSuffixHeads[index++] = i + 1;
        prefixSuffix[i] = 0;
        // System.err.println("[brotli/java/org/brotli/dec/Transform.java] exit unpackTransforms 3");
      }
      // System.err.println("[brotli/java/org/brotli/dec/Transform.java] exit unpackTransforms 2");
    }

    for (int i = 0; i < NUM_TRANSFORMS * 3; ++i) {
      System.err.println("[brotli/java/org/brotli/dec/Transform.java] enter unpackTransforms 4");
      transforms[i] = transformsSrc.charAt(i) - 32;
      // System.err.println("[brotli/java/org/brotli/dec/Transform.java] exit unpackTransforms 4");
    }
    // System.err.println("[brotli/java/org/brotli/dec/Transform.java] exit unpackTransforms 1");
  }

  static {
    System.err.println("enter Transform static 1");
    unpackTransforms(PREFIX_SUFFIX, PREFIX_SUFFIX_HEADS, TRANSFORMS, PREFIX_SUFFIX_SRC,
        TRANSFORMS_SRC);
    // System.err.println("exit Transform static 1");
  }

  static int transformDictionaryWord(byte[] dst, int dstOffset, ByteBuffer data, int wordOffset,
      int len, int transformIndex) {
    System.err.println("[brotli/java/org/brotli/dec/Transform.java] enter transformDictionaryWord 1");
    int offset = dstOffset;
    int transformOffset = 3 * transformIndex;
    int transformPrefix = PREFIX_SUFFIX_HEADS[TRANSFORMS[transformOffset]];
    int transformType = TRANSFORMS[transformOffset + 1];
    int transformSuffix = PREFIX_SUFFIX_HEADS[TRANSFORMS[transformOffset + 2]];

    // Copy prefix.
    while (PREFIX_SUFFIX[transformPrefix] != 0) {
      System.err.println("[brotli/java/org/brotli/dec/Transform.java] enter transformDictionaryWord 2");
      dst[offset++] = PREFIX_SUFFIX[transformPrefix++];
      // System.err.println("[brotli/java/org/brotli/dec/Transform.java] exit transformDictionaryWord 2");
    }

    // Copy trimmed word.
    int omitFirst = transformType >= 12 ? (transformType - 11) : 0;
    if (omitFirst > len) {
      System.err.println("[brotli/java/org/brotli/dec/Transform.java] enter transformDictionaryWord 3");
      omitFirst = len;
      // System.err.println("[brotli/java/org/brotli/dec/Transform.java] exit transformDictionaryWord 3");
    }
    wordOffset += omitFirst;
    len -= omitFirst;
    len -= transformType <= 9 ? transformType : 0;  // Omit last.
    int i = len;
    while (i > 0) {
      System.err.println("[brotli/java/org/brotli/dec/Transform.java] enter transformDictionaryWord 4");
      dst[offset++] = data.get(wordOffset++);
      i--;
      // System.err.println("[brotli/java/org/brotli/dec/Transform.java] exit transformDictionaryWord 4");
    }

    // Ferment.
    if (transformType == 11 || transformType == 10) {
      System.err.println("[brotli/java/org/brotli/dec/Transform.java] enter transformDictionaryWord 5");
      int uppercaseOffset = offset - len;
      if (transformType == 10) {
        System.err.println("[brotli/java/org/brotli/dec/Transform.java] enter transformDictionaryWord 6");
        len = 1;
        // System.err.println("[brotli/java/org/brotli/dec/Transform.java] exit transformDictionaryWord 6");
      }
      while (len > 0) {
        System.err.println("[brotli/java/org/brotli/dec/Transform.java] enter transformDictionaryWord 7");
        int tmp = dst[uppercaseOffset] & 0xFF;
        if (tmp < 0xc0) {
          System.err.println("[brotli/java/org/brotli/dec/Transform.java] enter transformDictionaryWord 8");
          if (tmp >= 97 && tmp <= 122) { // in [a..z] range
            System.err.println("[brotli/java/org/brotli/dec/Transform.java] enter transformDictionaryWord 9");
            dst[uppercaseOffset] ^= (byte) 32;
            // System.err.println("[brotli/java/org/brotli/dec/Transform.java] exit transformDictionaryWord 9");
          }
          uppercaseOffset += 1;
          len -= 1;
          // System.err.println("[brotli/java/org/brotli/dec/Transform.java] exit transformDictionaryWord 8");
        } else if (tmp < 0xe0) {
          System.err.println("[brotli/java/org/brotli/dec/Transform.java] enter transformDictionaryWord 10");
          dst[uppercaseOffset + 1] ^= (byte) 32;
          uppercaseOffset += 2;
          len -= 2;
          // System.err.println("[brotli/java/org/brotli/dec/Transform.java] exit transformDictionaryWord 10");
        } else {
          System.err.println("[brotli/java/org/brotli/dec/Transform.java] enter transformDictionaryWord 11");
          dst[uppercaseOffset + 2] ^= (byte) 5;
          uppercaseOffset += 3;
          len -= 3;
          // System.err.println("[brotli/java/org/brotli/dec/Transform.java] exit transformDictionaryWord 11");
        }
        // System.err.println("[brotli/java/org/brotli/dec/Transform.java] exit transformDictionaryWord 7");
      }
      // System.err.println("[brotli/java/org/brotli/dec/Transform.java] exit transformDictionaryWord 5");
    }

    // Copy suffix.
    while (PREFIX_SUFFIX[transformSuffix] != 0) {
      System.err.println("[brotli/java/org/brotli/dec/Transform.java] enter transformDictionaryWord 12");
      dst[offset++] = PREFIX_SUFFIX[transformSuffix++];
      // System.err.println("[brotli/java/org/brotli/dec/Transform.java] exit transformDictionaryWord 12");
    }

    return offset - dstOffset;
    // System.err.println("[brotli/java/org/brotli/dec/Transform.java] exit transformDictionaryWord 1");
  }
}
// Total cost: 0.037938
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 115)]
// Total instrumented cost: 0.037938, input tokens: 2398, output tokens: 2087, cache read tokens: 2394, cache write tokens: 1574
