/* Copyright 2017 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

package org.brotli.wrapper.enc;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.channels.Channels;

/**
 * Output stream that wraps native brotli encoder.
 */
public class BrotliOutputStream extends OutputStream {
  /** The default internal buffer size used by the encoder. */
  private static final int DEFAULT_BUFFER_SIZE = 16384;

  private final Encoder encoder;

  /**
   * Creates a BrotliOutputStream.
   *
   * @param destination underlying destination
   * @param params encoding settings
   * @param bufferSize intermediate buffer size
   */
  public BrotliOutputStream(OutputStream destination, Encoder.Parameters params, int bufferSize)
      throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStream.java] enter BrotliOutputStream 1");
    this.encoder = new Encoder(Channels.newChannel(destination), params, bufferSize);
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStream.java] exit BrotliOutputStream 1");
  }

  public BrotliOutputStream(OutputStream destination, Encoder.Parameters params)
      throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStream.java] enter BrotliOutputStream 2");
    this(destination, params, DEFAULT_BUFFER_SIZE);
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStream.java] exit BrotliOutputStream 2");
  }

  public BrotliOutputStream(OutputStream destination) throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStream.java] enter BrotliOutputStream 3");
    this(destination, new Encoder.Parameters());
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStream.java] exit BrotliOutputStream 3");
  }

  @Override
  public void close() throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStream.java] enter close 1");
    encoder.close();
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStream.java] exit close 1");
  }

  @Override
  public void flush() throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStream.java] enter flush 1");
    if (encoder.closed) {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStream.java] enter flush 2");
      throw new IOException("write after close");
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStream.java] exit flush 2");
    }
    System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStream.java] enter flush 3");
    encoder.flush();
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStream.java] exit flush 3");
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStream.java] exit flush 1");
  }

  @Override
  public void write(int b) throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStream.java] enter write 1");
    if (encoder.closed) {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStream.java] enter write 2");
      throw new IOException("write after close");
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStream.java] exit write 2");
    }
    System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStream.java] enter write 3");
    while (!encoder.encode(EncoderJNI.Operation.PROCESS)) {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStream.java] enter write 4");
      // Busy-wait loop.
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStream.java] exit write 4");
    }
    System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStream.java] enter write 5");
    encoder.inputBuffer.put((byte) b);
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStream.java] exit write 5");
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStream.java] exit write 3");
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStream.java] exit write 1");
  }

  @Override
  public void write(byte[] b) throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStream.java] enter write 6");
    this.write(b, 0, b.length);
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStream.java] exit write 6");
  }

  @Override
  public void write(byte[] b, int off, int len) throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStream.java] enter write 7");
    if (encoder.closed) {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStream.java] enter write 8");
      throw new IOException("write after close");
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStream.java] exit write 8");
    }
    System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStream.java] enter write 9");
    while (len > 0) {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStream.java] enter write 10");
      if (!encoder.encode(EncoderJNI.Operation.PROCESS)) {
        System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStream.java] enter write 11");
        continue;
        // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStream.java] exit write 11");
      }
      System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStream.java] enter write 12");
      int limit = Math.min(len, encoder.inputBuffer.remaining());
      encoder.inputBuffer.put(b, off, limit);
      off += limit;
      len -= limit;
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStream.java] exit write 12");
    }
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStream.java] exit write 10");
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStream.java] exit write 9");
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStream.java] exit write 7");
  }
}
// Total cost: 0.021513
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 87)]
// Total instrumented cost: 0.021513, input tokens: 2398, output tokens: 1200, cache read tokens: 2394, cache write tokens: 742
