package org.brotli.integration;

/**
 * Optionally loads brotli JNI wrapper native library.
 */
public class BrotliJniTestBase {
  static {
    System.err.println("enter BrotliJniTestBase static_initializer 1");
    String jniLibrary = System.getProperty("BROTLI_JNI_LIBRARY");
    // System.err.println("exit BrotliJniTestBase static_initializer 1");
    
    if (jniLibrary != null) {
      System.err.println("enter BrotliJniTestBase static_initializer 2");
      System.load(new java.io.File(jniLibrary).getAbsolutePath());
      // System.err.println("exit BrotliJniTestBase static_initializer 2");
    }
    // System.err.println("exit BrotliJniTestBase static_initializer 3");
  }
}
// Total cost: 0.005376
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 13)]
// Total instrumented cost: 0.005376, input tokens: 2398, output tokens: 257, cache read tokens: 2394, cache write tokens: 211
