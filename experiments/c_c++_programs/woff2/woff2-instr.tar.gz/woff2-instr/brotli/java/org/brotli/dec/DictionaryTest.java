/* Copyright 2015 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

package org.brotli.dec;

import static org.junit.Assert.assertEquals;

import java.nio.ByteBuffer;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import java.io.PrintStream;

/**
 * Tests for {@link Dictionary}.
 */
@RunWith(JUnit4.class)
public class DictionaryTest {

  private static long crc64(ByteBuffer data) {
    System.err.println("[brotli/java/org/brotli/dec/DictionaryTest.java] enter crc64 1");
    long crc = -1;
    // System.err.println("[brotli/java/org/brotli/dec/DictionaryTest.java] exit crc64 1");
    
    for (int i = 0; i < data.capacity(); ++i) {
      System.err.println("[brotli/java/org/brotli/dec/DictionaryTest.java] enter crc64 2");
      long c = (crc ^ (long) (data.get(i) & 0xFF)) & 0xFF;
      // System.err.println("[brotli/java/org/brotli/dec/DictionaryTest.java] exit crc64 2");
      
      for (int k = 0; k < 8; k++) {
        System.err.println("[brotli/java/org/brotli/dec/DictionaryTest.java] enter crc64 3");
        c = (c >>> 1) ^ (-(c & 1L) & -3932672073523589310L);
        // System.err.println("[brotli/java/org/brotli/dec/DictionaryTest.java] exit crc64 3");
      }
      
      System.err.println("[brotli/java/org/brotli/dec/DictionaryTest.java] enter crc64 4");
      crc = c ^ (crc >>> 8);
      // System.err.println("[brotli/java/org/brotli/dec/DictionaryTest.java] exit crc64 4");
    }
    
    System.err.println("[brotli/java/org/brotli/dec/DictionaryTest.java] enter crc64 5");
    return ~crc;
    // System.err.println("[brotli/java/org/brotli/dec/DictionaryTest.java] exit crc64 5");
  }

  @Test
  public void testGetData() {
    System.err.println("[brotli/java/org/brotli/dec/DictionaryTest.java] enter testGetData 1");
    assertEquals(37084801881332636L, crc64(Dictionary.getData()));
    // System.err.println("[brotli/java/org/brotli/dec/DictionaryTest.java] exit testGetData 1");
  }
}
// Total cost: 0.010566
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 38)]
// Total instrumented cost: 0.010566, input tokens: 2398, output tokens: 551, cache read tokens: 2394, cache write tokens: 419
