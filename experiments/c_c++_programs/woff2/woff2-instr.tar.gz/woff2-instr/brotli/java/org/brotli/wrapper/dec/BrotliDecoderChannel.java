/* Copyright 2017 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

package org.brotli.wrapper.dec;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.ClosedChannelException;
import java.nio.channels.ReadableByteChannel;

/**
 * ReadableByteChannel that wraps native brotli decoder.
 */
public class BrotliDecoderChannel extends Decoder implements ReadableByteChannel {
  /** The default internal buffer size used by the decoder. */
  private static final int DEFAULT_BUFFER_SIZE = 16384;

  private final Object mutex = new Object();

  /**
   * Creates a BrotliDecoderChannel.
   *
   * @param source underlying source
   * @param bufferSize intermediate buffer size
   * @param customDictionary initial LZ77 dictionary
   */
  public BrotliDecoderChannel(ReadableByteChannel source, int bufferSize) throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannel.java] enter BrotliDecoderChannel 1");
    super(source, bufferSize);
    // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannel.java] exit BrotliDecoderChannel 1");
  }

  public BrotliDecoderChannel(ReadableByteChannel source) throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannel.java] enter BrotliDecoderChannel 2");
    this(source, DEFAULT_BUFFER_SIZE);
    // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannel.java] exit BrotliDecoderChannel 2");
  }

  @Override
  public boolean isOpen() {
    System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannel.java] enter isOpen 1");
    synchronized (mutex) {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannel.java] enter isOpen 2");
      return !closed;
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannel.java] exit isOpen 2");
    }
    // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannel.java] exit isOpen 1");
  }

  @Override
  public void close() throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannel.java] enter close 1");
    synchronized (mutex) {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannel.java] enter close 2");
      super.close();
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannel.java] exit close 2");
    }
    // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannel.java] exit close 1");
  }

  @Override
  public int read(ByteBuffer dst) throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannel.java] enter read 1");
    synchronized (mutex) {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannel.java] enter read 2");
      if (closed) {
        System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannel.java] enter read 3");
        throw new ClosedChannelException();
        // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannel.java] exit read 3");
      }
      int result = 0;
      while (dst.hasRemaining()) {
        System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannel.java] enter read 4");
        int outputSize = decode();
        if (outputSize <= 0) {
          System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannel.java] enter read 5");
          return result == 0 ? outputSize : result;
          // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannel.java] exit read 5");
        }
        result += consume(dst);
        // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannel.java] exit read 4");
      }
      return result;
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannel.java] exit read 2");
    }
    // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliDecoderChannel.java] exit read 1");
  }
}
// Total cost: 0.015753
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 69)]
// Total instrumented cost: 0.015753, input tokens: 2398, output tokens: 851, cache read tokens: 2394, cache write tokens: 602
