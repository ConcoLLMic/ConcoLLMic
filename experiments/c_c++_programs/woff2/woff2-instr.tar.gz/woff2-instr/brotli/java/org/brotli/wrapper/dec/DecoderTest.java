/* Copyright 2017 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

package org.brotli.wrapper.dec;

import static org.junit.Assert.assertEquals;

import org.brotli.integration.BrotliJniTestBase;
import org.brotli.integration.BundleHelper;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import org.junit.runner.RunWith;
import org.junit.runners.AllTests;

/** Tests for {@link org.brotli.wrapper.dec.Decoder}. */
@RunWith(AllTests.class)
public class DecoderTest extends BrotliJniTestBase {

  static InputStream getBundle() throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderTest.java] enter getBundle 1");
    return new FileInputStream(System.getProperty("TEST_BUNDLE"));
    // System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderTest.java] exit getBundle 1");
  }

  /** Creates a test suite. */
  public static TestSuite suite() throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderTest.java] enter suite 1");
    TestSuite suite = new TestSuite();
    InputStream bundle = getBundle();
    try {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderTest.java] enter suite 2");
      List<String> entries = BundleHelper.listEntries(bundle);
      for (String entry : entries) {
        System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderTest.java] enter suite 3");
        suite.addTest(new DecoderTestCase(entry));
        // System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderTest.java] exit suite 3");
      }
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderTest.java] exit suite 2");
    } finally {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderTest.java] enter suite 4");
      bundle.close();
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderTest.java] exit suite 4");
    }
    return suite;
    // System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderTest.java] exit suite 1");
  }

  /** Test case with a unique name. */
  static class DecoderTestCase extends TestCase {
    final String entryName;
    DecoderTestCase(String entryName) {
      super("DecoderTest." + entryName);
      System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderTest.java] enter DecoderTestCase.constructor 1");
      this.entryName = entryName;
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderTest.java] exit DecoderTestCase.constructor 1");
    }

    @Override
    protected void runTest() throws Throwable {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderTest.java] enter DecoderTestCase.runTest 1");
      DecoderTest.run(entryName);
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderTest.java] exit DecoderTestCase.runTest 1");
    }
  }

  private static void run(String entryName) throws Throwable {
    System.err.println("");
    InputStream bundle = getBundle();
    byte[] compressed;
    try {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderTest.java] enter run 2");
      compressed = BundleHelper.readEntry(bundle, entryName);
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderTest.java] exit run 2");
    } finally {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderTest.java] enter run 3");
      bundle.close();
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderTest.java] exit run 3");
    }
    if (compressed == null) {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderTest.java] enter run 4");
      throw new RuntimeException("Can't read bundle entry: " + entryName);
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderTest.java] exit run 4");
    }

    System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderTest.java] enter run 5");
    byte[] decompressed = Decoder.decompress(compressed);

    long crc = BundleHelper.fingerprintStream(new ByteArrayInputStream(decompressed));
    assertEquals(BundleHelper.getExpectedFingerprint(entryName), crc);
    // System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderTest.java] exit run 5");
  }
}
// Total cost: 0.018805
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 77)]
// Total instrumented cost: 0.018805, input tokens: 2398, output tokens: 1017, cache read tokens: 2394, cache write tokens: 752
