/* Copyright 2017 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

package org.brotli.wrapper.dec;

import java.io.IOException;
import java.nio.ByteBuffer;

/**
 * JNI wrapper for brotli decoder.
 */
public class DecoderJNI {
  private static native ByteBuffer nativeCreate(long[] context);
  private static native void nativePush(long[] context, int length);
  private static native ByteBuffer nativePull(long[] context);
  private static native void nativeDestroy(long[] context);

  public enum Status {
    ERROR,
    DONE,
    NEEDS_MORE_INPUT,
    NEEDS_MORE_OUTPUT,
    OK
  };

  public static class Wrapper {
    private final long[] context = new long[3];
    private final ByteBuffer inputBuffer;
    private Status lastStatus = Status.NEEDS_MORE_INPUT;

    public Wrapper(int inputBufferSize) throws IOException {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] enter Wrapper 1");
      this.context[1] = inputBufferSize;
      this.inputBuffer = nativeCreate(this.context);
      if (this.context[0] == 0) {
        System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] enter Wrapper 2");
        throw new IOException("failed to initialize native brotli decoder");
        // System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] exit Wrapper 2");
      }
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] exit Wrapper 1");
    }

    public void push(int length) {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] enter push 1");
      if (length < 0) {
        System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] enter push 2");
        throw new IllegalArgumentException("negative block length");
        // System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] exit push 2");
      }
      if (context[0] == 0) {
        System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] enter push 3");
        throw new IllegalStateException("brotli decoder is already destroyed");
        // System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] exit push 3");
      }
      if (lastStatus != Status.NEEDS_MORE_INPUT && lastStatus != Status.OK) {
        System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] enter push 4");
        throw new IllegalStateException("pushing input to decoder in " + lastStatus + " state");
        // System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] exit push 4");
      }
      if (lastStatus == Status.OK && length != 0) {
        System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] enter push 5");
        throw new IllegalStateException("pushing input to decoder in OK state");
        // System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] exit push 5");
      }
      System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] enter push 6");
      nativePush(context, length);
      parseStatus();
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] exit push 6");
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] exit push 1");
    }

    private void parseStatus() {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] enter parseStatus 1");
      long status = context[1];
      if (status == 1) {
        System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] enter parseStatus 2");
        lastStatus = Status.DONE;
        // System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] exit parseStatus 2");
      } else if (status == 2) {
        System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] enter parseStatus 3");
        lastStatus = Status.NEEDS_MORE_INPUT;
        // System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] exit parseStatus 3");
      } else if (status == 3) {
        System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] enter parseStatus 4");
        lastStatus = Status.NEEDS_MORE_OUTPUT;
        // System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] exit parseStatus 4");
      } else if (status == 4) {
        System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] enter parseStatus 5");
        lastStatus = Status.OK;
        // System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] exit parseStatus 5");
      } else {
        System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] enter parseStatus 6");
        lastStatus = Status.ERROR;
        // System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] exit parseStatus 6");
      }
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] exit parseStatus 1");
    }

    public Status getStatus() {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] enter getStatus 1");
      return lastStatus;
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] exit getStatus 1");
    }

    public ByteBuffer getInputBuffer() {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] enter getInputBuffer 1");
      return inputBuffer;
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] exit getInputBuffer 1");
    }

    public boolean hasOutput() {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] enter hasOutput 1");
      return context[2] != 0;
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] exit hasOutput 1");
    }

    public ByteBuffer pull() {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] enter pull 1");
      if (context[0] == 0) {
        System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] enter pull 2");
        throw new IllegalStateException("brotli decoder is already destroyed");
        // System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] exit pull 2");
      }
      if (lastStatus != Status.NEEDS_MORE_OUTPUT && !hasOutput()) {
        System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] enter pull 3");
        throw new IllegalStateException("pulling output from decoder in " + lastStatus + " state");
        // System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] exit pull 3");
      }
      System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] enter pull 4");
      ByteBuffer result = nativePull(context);
      parseStatus();
      return result;
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] exit pull 4");
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] exit pull 1");
    }

    /**
     * Releases native resources.
     */
    public void destroy() {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] enter destroy 1");
      if (context[0] == 0) {
        System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] enter destroy 2");
        throw new IllegalStateException("brotli decoder is already destroyed");
        // System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] exit destroy 2");
      }
      System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] enter destroy 3");
      nativeDestroy(context);
      context[0] = 0;
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] exit destroy 3");
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] exit destroy 1");
    }

    @Override
    protected void finalize() throws Throwable {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] enter finalize 1");
      if (context[0] != 0) {
        System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] enter finalize 2");
        /* TODO: log resource leak? */
        destroy();
        // System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] exit finalize 2");
      }
      System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] enter finalize 3");
      super.finalize();
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] exit finalize 3");
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/DecoderJNI.java] exit finalize 1");
    }
  }
}
// Total cost: 0.030434
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 118)]
// Total instrumented cost: 0.030434, input tokens: 2398, output tokens: 1721, cache read tokens: 2394, cache write tokens: 1037
