/* Copyright 2016 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

package org.brotli.integration;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Utilities to work test files bundles in zip archive.
 */
public class BundleHelper {
  private BundleHelper() { }

  public static List<String> listEntries(InputStream input) throws IOException {
    System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] enter listEntries 1");
    List<String> result = new ArrayList<String>();
    ZipInputStream zis = new ZipInputStream(input);
    ZipEntry entry;
    try {
      while ((entry = zis.getNextEntry()) != null) {
        System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] enter listEntries 2");
        if (!entry.isDirectory()) {
          System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] enter listEntries 3");
          result.add(entry.getName());
          // System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] exit listEntries 3");
        }
        System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] enter listEntries 4");
        zis.closeEntry();
        // System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] exit listEntries 4");
        // System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] exit listEntries 2");
      }
    } finally {
      System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] enter listEntries 5");
      zis.close();
      // System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] exit listEntries 5");
    }
    System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] enter listEntries 6");
    return result;
    // System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] exit listEntries 6");
    // System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] exit listEntries 1");
  }

  public static byte[] readStream(InputStream input) throws IOException {
    System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] enter readStream 1");
    ByteArrayOutputStream result = new ByteArrayOutputStream();
    byte[] buffer = new byte[65536];
    int bytesRead;
    while ((bytesRead = input.read(buffer)) != -1) {
      System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] enter readStream 2");
      result.write(buffer, 0, bytesRead);
      // System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] exit readStream 2");
    }
    System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] enter readStream 3");
    return result.toByteArray();
    // System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] exit readStream 3");
    // System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] exit readStream 1");
  }

  public static byte[] readEntry(InputStream input, String entryName) throws IOException {
    System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] enter readEntry 1");
    ZipInputStream zis = new ZipInputStream(input);
    ZipEntry entry;
    try {
      while ((entry = zis.getNextEntry()) != null) {
        System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] enter readEntry 2");
        if (entry.getName().equals(entryName)) {
          System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] enter readEntry 3");
          byte[] result = readStream(zis);
          zis.closeEntry();
          return result;
          // System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] exit readEntry 3");
        }
        System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] enter readEntry 4");
        zis.closeEntry();
        // System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] exit readEntry 4");
        // System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] exit readEntry 2");
      }
    } finally {
      System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] enter readEntry 5");
      zis.close();
      // System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] exit readEntry 5");
    }
    /* entry not found */
    System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] enter readEntry 6");
    return null;
    // System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] exit readEntry 6");
    // System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] exit readEntry 1");
  }

  /** ECMA CRC64 polynomial. */
  private static final long CRC_64_POLY =
      new BigInteger("C96C5795D7870F42", 16).longValue();

  /**
   * Rolls CRC64 calculation.
   *
   * <p> {@code CRC64(data) = -1 ^ updateCrc64((... updateCrc64(-1, firstBlock), ...), lastBlock);}
   * <p> This simple and reliable checksum is chosen to make is easy to calculate the same value
   * across the variety of languages (C++, Java, Go, ...).
   */
  public static long updateCrc64(long crc, byte[] data, int offset, int length) {
    System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] enter updateCrc64 1");
    for (int i = offset; i < offset + length; ++i) {
      System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] enter updateCrc64 2");
      long c = (crc ^ (long) (data[i] & 0xFF)) & 0xFF;
      for (int k = 0; k < 8; k++) {
        System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] enter updateCrc64 3");
        c = ((c & 1) == 1) ? CRC_64_POLY ^ (c >>> 1) : c >>> 1;
        // System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] exit updateCrc64 3");
      }
      System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] enter updateCrc64 4");
      crc = c ^ (crc >>> 8);
      // System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] exit updateCrc64 4");
      // System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] exit updateCrc64 2");
    }
    System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] enter updateCrc64 5");
    return crc;
    // System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] exit updateCrc64 5");
    // System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] exit updateCrc64 1");
  }

  /**
   * Calculates CRC64 of stream contents.
   */
  public static long fingerprintStream(InputStream input) throws IOException {
    System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] enter fingerprintStream 1");
    byte[] buffer = new byte[65536];
    long crc = -1;
    while (true) {
      System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] enter fingerprintStream 2");
      int len = input.read(buffer);
      if (len <= 0) {
        System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] enter fingerprintStream 3");
        break;
        // System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] exit fingerprintStream 3");
      }
      System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] enter fingerprintStream 4");
      crc = updateCrc64(crc, buffer, 0, len);
      // System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] exit fingerprintStream 4");
      // System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] exit fingerprintStream 2");
    }
    System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] enter fingerprintStream 5");
    return ~crc;
    // System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] exit fingerprintStream 5");
    // System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] exit fingerprintStream 1");
  }

  public static long getExpectedFingerprint(String entryName) {
    System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] enter getExpectedFingerprint 1");
    int dotIndex = entryName.indexOf('.');
    String entryCrcString = (dotIndex == -1) ? entryName : entryName.substring(0, dotIndex);
    return new BigInteger(entryCrcString, 16).longValue();
    // System.err.println("[brotli/java/org/brotli/integration/BundleHelper.java] exit getExpectedFingerprint 1");
  }
}
// Total cost: 0.033531
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 113)]
// Total instrumented cost: 0.033531, input tokens: 2398, output tokens: 1898, cache read tokens: 2394, cache write tokens: 1155
