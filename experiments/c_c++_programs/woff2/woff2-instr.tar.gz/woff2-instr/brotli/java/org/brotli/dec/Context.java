/* Copyright 2015 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

package org.brotli.dec;

/**
 * Common context lookup table for all context modes.
 */
final class Context {

  static final int[] LOOKUP = new int[2048];

  private static final String UTF_MAP = "         !!  !                  \"#$##%#$&'##(#)#+++++++++"
      + "+((&*'##,---,---,-----,-----,-----&#'###.///.///./////./////./////&#'# ";
  private static final String UTF_RLE = "A/*  ':  & : $  \u0081 @";

  private static void unpackLookupTable(int[] lookup, String map, String rle) {
    System.err.println("[brotli/java/org/brotli/dec/Context.java] enter unpackLookupTable 1");
    // LSB6, MSB6, SIGNED
    for (int i = 0; i < 256; ++i) {
      System.err.println("[brotli/java/org/brotli/dec/Context.java] enter unpackLookupTable 2");
      lookup[i] = i & 0x3F;
      lookup[512 + i] = i >> 2;
      lookup[1792 + i] = 2 + (i >> 6);
      // System.err.println("[brotli/java/org/brotli/dec/Context.java] exit unpackLookupTable 2");
    }
    // UTF8
    for (int i = 0; i < 128; ++i) {
      System.err.println("[brotli/java/org/brotli/dec/Context.java] enter unpackLookupTable 3");
      lookup[1024 + i] = 4 * (map.charAt(i) - 32);
      // System.err.println("[brotli/java/org/brotli/dec/Context.java] exit unpackLookupTable 3");
    }
    for (int i = 0; i < 64; ++i) {
      System.err.println("[brotli/java/org/brotli/dec/Context.java] enter unpackLookupTable 4");
      lookup[1152 + i] = i & 1;
      lookup[1216 + i] = 2 + (i & 1);
      // System.err.println("[brotli/java/org/brotli/dec/Context.java] exit unpackLookupTable 4");
    }
    int offset = 1280;
    for (int k = 0; k < 19; ++k) {
      System.err.println("[brotli/java/org/brotli/dec/Context.java] enter unpackLookupTable 5");
      int value = k & 3;
      int rep = rle.charAt(k) - 32;
      for (int i = 0; i < rep; ++i) {
        System.err.println("[brotli/java/org/brotli/dec/Context.java] enter unpackLookupTable 6");
        lookup[offset++] = value;
        // System.err.println("[brotli/java/org/brotli/dec/Context.java] exit unpackLookupTable 6");
      }
      // System.err.println("[brotli/java/org/brotli/dec/Context.java] exit unpackLookupTable 5");
    }
    // SIGNED
    for (int i = 0; i < 16; ++i) {
      System.err.println("[brotli/java/org/brotli/dec/Context.java] enter unpackLookupTable 7");
      lookup[1792 + i] = 1;
      lookup[2032 + i] = 6;
      // System.err.println("[brotli/java/org/brotli/dec/Context.java] exit unpackLookupTable 7");
    }
    lookup[1792] = 0;
    lookup[2047] = 7;
    for (int i = 0; i < 256; ++i) {
      System.err.println("[brotli/java/org/brotli/dec/Context.java] enter unpackLookupTable 8");
      lookup[1536 + i] = lookup[1792 + i] << 3;
      // System.err.println("[brotli/java/org/brotli/dec/Context.java] exit unpackLookupTable 8");
    }
    // System.err.println("[brotli/java/org/brotli/dec/Context.java] exit unpackLookupTable 1");
  }

  static {
    System.err.println("[brotli/java/org/brotli/dec/Context.java] enter Context_static_initializer 1");
    unpackLookupTable(LOOKUP, UTF_MAP, UTF_RLE);
    // System.err.println("[brotli/java/org/brotli/dec/Context.java] exit Context_static_initializer 1");
  }
}
// Total cost: 0.018655
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 58)]
// Total instrumented cost: 0.018655, input tokens: 2398, output tokens: 1009, cache read tokens: 2394, cache write tokens: 744
