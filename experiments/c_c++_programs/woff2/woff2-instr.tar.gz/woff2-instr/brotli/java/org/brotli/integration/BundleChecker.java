/* Copyright 2016 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

package org.brotli.integration;

import org.brotli.dec.BrotliInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Decompress files and (optionally) checks their checksums.
 *
 * <p> File are read from ZIP archive passed as an array of bytes. Multiple checkers negotiate about
 * task distribution via shared AtomicInteger counter.
 * <p> All entries are expected to be valid brotli compressed streams and output CRC64 checksum
 * is expected to match the checksum hex-encoded in the first part of entry name.
 */
public class BundleChecker implements Runnable {
  private final AtomicInteger nextJob;
  private final InputStream input;
  private final boolean sanityCheck;

  /**
   * @param sanityCheck do not calculate checksum and ignore {@link IOException}.
   */
  public BundleChecker(InputStream input, AtomicInteger nextJob, boolean sanityCheck) {
    System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] enter BundleChecker 1");
    this.input = input;
    this.nextJob = nextJob;
    this.sanityCheck = sanityCheck;
    // System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] exit BundleChecker 1");
  }

  private long decompressAndCalculateCrc(ZipInputStream input) throws IOException {
    System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] enter decompressAndCalculateCrc 1");
    /* Do not allow entry readers to close the whole ZipInputStream. */
    FilterInputStream entryStream = new FilterInputStream(input) {
      @Override
      public void close() {}
    };

    BrotliInputStream decompressedStream = new BrotliInputStream(entryStream);
    long crc;
    try {
      System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] enter decompressAndCalculateCrc 2");
      crc = BundleHelper.fingerprintStream(decompressedStream);
      // System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] exit decompressAndCalculateCrc 2");
    } finally {
      System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] enter decompressAndCalculateCrc 3");
      decompressedStream.close();
      // System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] exit decompressAndCalculateCrc 3");
    }
    return crc;
    // System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] exit decompressAndCalculateCrc 1");
  }

  @Override
  public void run() {
    System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] enter run 1");
    String entryName = "";
    ZipInputStream zis = new ZipInputStream(input);
    try {
      System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] enter run 2");
      int entryIndex = 0;
      ZipEntry entry;
      int jobIndex = nextJob.getAndIncrement();
      // System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] exit run 2");
      while ((entry = zis.getNextEntry()) != null) {
        System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] enter run 3");
        if (entry.isDirectory()) {
          System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] enter run 4");
          continue;
          // System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] exit run 4");
        }
        // System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] exit run 3");
        
        System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] enter run 5");
        if (entryIndex++ != jobIndex) {
          System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] enter run 6");
          zis.closeEntry();
          continue;
          // System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] exit run 6");
        }
        // System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] exit run 5");
        
        System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] enter run 7");
        entryName = entry.getName();
        long entryCrc = BundleHelper.getExpectedFingerprint(entryName);
        try {
          System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] enter run 8");
          if (entryCrc != decompressAndCalculateCrc(zis) && !sanityCheck) {
            System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] enter run 9");
            throw new RuntimeException("CRC mismatch");
            // System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] exit run 9");
          }
          // System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] exit run 8");
        } catch (IOException iox) {
          System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] enter run 10");
          if (!sanityCheck) {
            System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] enter run 11");
            throw new RuntimeException("Decompression failed", iox);
            // System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] exit run 11");
          }
          // System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] exit run 10");
        }
        System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] enter run 12");
        zis.closeEntry();
        entryName = "";
        jobIndex = nextJob.getAndIncrement();
        // System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] exit run 12");
        // System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] exit run 7");
      }
      System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] enter run 13");
      zis.close();
      input.close();
      // System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] exit run 13");
    } catch (Throwable ex) {
      System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] enter run 14");
      throw new RuntimeException(entryName, ex);
      // System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] exit run 14");
    }
    // System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] exit run 1");
  }

  public static void main(String[] args) throws FileNotFoundException {
    System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] enter main 1");
    int argsOffset = 0;
    boolean sanityCheck = false;
    // System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] exit main 1");
    if (args.length != 0) {
      System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] enter main 2");
      if (args[0].equals("-s")) {
        System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] enter main 3");
        sanityCheck = true;
        argsOffset = 1;
        // System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] exit main 3");
      }
      // System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] exit main 2");
    }
    System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] enter main 4");
    if (args.length == argsOffset) {
      System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] enter main 5");
      throw new RuntimeException("Usage: BundleChecker [-s] <fileX.zip> ...");
      // System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] exit main 5");
    }
    // System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] exit main 4");
    
    System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] enter main 6");
    for (int i = argsOffset; i < args.length; ++i) {
      System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] enter main 7");
      new BundleChecker(new FileInputStream(args[i]), new AtomicInteger(0), sanityCheck).run();
      // System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] exit main 7");
    }
    // System.err.println("[brotli/java/org/brotli/integration/BundleChecker.java] exit main 6");
  }
}
// Total cost: 0.031878
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 112)]
// Total instrumented cost: 0.031878, input tokens: 2398, output tokens: 1793, cache read tokens: 2394, cache write tokens: 1134
