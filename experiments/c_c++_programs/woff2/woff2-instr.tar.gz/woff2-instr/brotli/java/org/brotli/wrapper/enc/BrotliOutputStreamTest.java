package org.brotli.wrapper.enc;

import static org.junit.Assert.assertEquals;

import org.brotli.integration.BrotliJniTestBase;
import org.brotli.integration.BundleHelper;
import org.brotli.wrapper.dec.BrotliInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import org.junit.runner.RunWith;
import org.junit.runners.AllTests;

/** Tests for {@link org.brotli.wrapper.enc.BrotliOutputStream}. */
@RunWith(AllTests.class)
public class BrotliOutputStreamTest extends BrotliJniTestBase {

  private enum TestMode {
    WRITE_ALL,
    WRITE_CHUNKS,
    WRITE_BYTE
  }

  private static final int CHUNK_SIZE = 256;

  static InputStream getBundle() throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] enter getBundle 1");
    return new FileInputStream(System.getProperty("TEST_BUNDLE"));
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] exit getBundle 1");
  }

  /** Creates a test suite. */
  public static TestSuite suite() throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] enter suite 1");
    TestSuite suite = new TestSuite();
    InputStream bundle = getBundle();
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] exit suite 1");
    try {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] enter suite 2");
      List<String> entries = BundleHelper.listEntries(bundle);
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] exit suite 2");
      for (String entry : entries) {
        System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] enter suite 3");
        suite.addTest(new StreamTestCase(entry, TestMode.WRITE_ALL));
        suite.addTest(new StreamTestCase(entry, TestMode.WRITE_CHUNKS));
        suite.addTest(new StreamTestCase(entry, TestMode.WRITE_BYTE));
        // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] exit suite 3");
      }
    } finally {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] enter suite 4");
      bundle.close();
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] exit suite 4");
    }
    System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] enter suite 5");
    return suite;
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] exit suite 5");
  }

  /** Test case with a unique name. */
  static class StreamTestCase extends TestCase {
    final String entryName;
    final TestMode mode;
    StreamTestCase(String entryName, TestMode mode) {
      super("BrotliOutputStreamTest." + entryName + "." + mode.name());
      System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] enter StreamTestCase.constructor 1");
      this.entryName = entryName;
      this.mode = mode;
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] exit StreamTestCase.constructor 1");
    }

    @Override
    protected void runTest() throws Throwable {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] enter StreamTestCase.runTest 1");
      BrotliOutputStreamTest.run(entryName, mode);
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] exit StreamTestCase.runTest 1");
    }
  }

  private static void run(String entryName, TestMode mode) throws Throwable {
    System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] enter run 1");
    InputStream bundle = getBundle();
    byte[] original;
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] exit run 1");
    try {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] enter run 2");
      original = BundleHelper.readEntry(bundle, entryName);
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] exit run 2");
    } finally {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] enter run 3");
      bundle.close();
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] exit run 3");
    }
    if (original == null) {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] enter run 4");
      throw new RuntimeException("Can't read bundle entry: " + entryName);
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] exit run 4");
    }

    if ((mode == TestMode.WRITE_CHUNKS) && (original.length <= CHUNK_SIZE)) {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] enter run 5");
      return;
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] exit run 5");
    }

    System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] enter run 6");
    ByteArrayOutputStream dst = new ByteArrayOutputStream();
    OutputStream encoder = new BrotliOutputStream(dst);
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] exit run 6");
    try {
      switch (mode) {
        case WRITE_ALL:
          System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] enter run 7");
          encoder.write(original);
          break;
          // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] exit run 7");

        case WRITE_CHUNKS:
          System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] enter run 8");
          for (int offset = 0; offset < original.length; offset += CHUNK_SIZE) {
            System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] enter run 9");
            encoder.write(original, offset, Math.min(CHUNK_SIZE, original.length - offset));
            // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] exit run 9");
          }
          break;
          // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] exit run 8");

        case WRITE_BYTE:
          System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] enter run 10");
          for (byte singleByte : original) {
            System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] enter run 11");
            encoder.write(singleByte);
            // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] exit run 11");
          }
          break;
          // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] exit run 10");
      }
    } finally {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] enter run 12");
      encoder.close();
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] exit run 12");
    }

    System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] enter run 13");
    InputStream decoder = new BrotliInputStream(new ByteArrayInputStream(dst.toByteArray()));
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] exit run 13");
    try {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] enter run 14");
      long originalCrc = BundleHelper.fingerprintStream(new ByteArrayInputStream(original));
      long crc = BundleHelper.fingerprintStream(decoder);
      assertEquals(originalCrc, crc);
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] exit run 14");
    } finally {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] enter run 15");
      decoder.close();
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliOutputStreamTest.java] exit run 15");
    }
  }
}
// Total cost: 0.030389
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 118)]
// Total instrumented cost: 0.030389, input tokens: 2398, output tokens: 1695, cache read tokens: 2394, cache write tokens: 1129
