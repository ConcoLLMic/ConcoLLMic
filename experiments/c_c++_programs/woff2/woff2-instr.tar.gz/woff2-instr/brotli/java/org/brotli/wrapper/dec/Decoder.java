/* Copyright 2017 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

package org.brotli.wrapper.dec;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.ReadableByteChannel;
import java.util.ArrayList;

/**
 * Base class for InputStream / Channel implementations.
 */
public class Decoder {
  private final ReadableByteChannel source;
  private final DecoderJNI.Wrapper decoder;
  ByteBuffer buffer;
  boolean closed;
  boolean eager;

  /**
   * Creates a Decoder wrapper.
   *
   * @param source underlying source
   * @param inputBufferSize read buffer size
   */
  public Decoder(ReadableByteChannel source, int inputBufferSize)
      throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] enter Decoder 1");
    if (inputBufferSize <= 0) {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] enter Decoder 2");
      throw new IllegalArgumentException("buffer size must be positive");
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] exit Decoder 2");
    }
    if (source == null) {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] enter Decoder 3");
      throw new NullPointerException("source can not be null");
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] exit Decoder 3");
    }
    this.source = source;
    this.decoder = new DecoderJNI.Wrapper(inputBufferSize);
    // System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] exit Decoder 1");
  }

  private void fail(String message) throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] enter fail 1");
    try {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] enter fail 2");
      close();
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] exit fail 2");
    } catch (IOException ex) {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] enter fail 3");
      /* Ignore */
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] exit fail 3");
    }
    throw new IOException(message);
    // System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] exit fail 1");
  }

  public void setEager(boolean eager) {
    System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] enter setEager 1");
    this.eager = eager;
    // System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] exit setEager 1");
  }

  /**
   * Continue decoding.
   *
   * @return -1 if stream is finished, or number of bytes available in read buffer (> 0)
   */
  int decode() throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] enter decode 1");
    while (true) {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] enter decode 2");
      if (buffer != null) {
        System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] enter decode 3");
        if (!buffer.hasRemaining()) {
          System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] enter decode 4");
          buffer = null;
          // System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] exit decode 4");
        } else {
          System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] enter decode 5");
          return buffer.remaining();
          // System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] exit decode 5");
        }
        // System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] exit decode 3");
      }

      switch (decoder.getStatus()) {
        case DONE:
          System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] enter decode 6");
          return -1;
          // System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] exit decode 6");

        case OK:
          System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] enter decode 7");
          decoder.push(0);
          break;
          // System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] exit decode 7");

        case NEEDS_MORE_INPUT:
          System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] enter decode 8");
          // In "eager" more pulling preempts pushing.
          if (eager && decoder.hasOutput()) {
            System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] enter decode 9");
            buffer = decoder.pull();
            break;
            // System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] exit decode 9");
          }
          ByteBuffer inputBuffer = decoder.getInputBuffer();
          inputBuffer.clear();
          int bytesRead = source.read(inputBuffer);
          if (bytesRead == -1) {
            System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] enter decode 10");
            fail("unexpected end of input");
            // System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] exit decode 10");
          }
          decoder.push(bytesRead);
          break;
          // System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] exit decode 8");

        case NEEDS_MORE_OUTPUT:
          System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] enter decode 11");
          buffer = decoder.pull();
          break;
          // System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] exit decode 11");

        default:
          System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] enter decode 12");
          fail("corrupted input");
          // System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] exit decode 12");
      }
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] exit decode 2");
    }
    // System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] exit decode 1");
  }

  void discard(int length) {
    System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] enter discard 1");
    buffer.position(buffer.position() + length);
    if (!buffer.hasRemaining()) {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] enter discard 2");
      buffer = null;
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] exit discard 2");
    }
    // System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] exit discard 1");
  }

  int consume(ByteBuffer dst) {
    System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] enter consume 1");
    ByteBuffer slice = buffer.slice();
    int limit = Math.min(slice.remaining(), dst.remaining());
    slice.limit(limit);
    dst.put(slice);
    discard(limit);
    return limit;
    // System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] exit consume 1");
  }

  void close() throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] enter close 1");
    if (closed) {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] enter close 2");
      return;
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] exit close 2");
    }
    closed = true;
    decoder.destroy();
    source.close();
    // System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] exit close 1");
  }

  /**
   * Decodes the given data buffer.
   */
  public static byte[] decompress(byte[] data) throws IOException {
    System.err.println("");
    DecoderJNI.Wrapper decoder = new DecoderJNI.Wrapper(data.length);
    ArrayList<byte[]> output = new ArrayList<byte[]>();
    int totalOutputSize = 0;
    try {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] enter decompress 2");
      decoder.getInputBuffer().put(data);
      decoder.push(data.length);
      while (decoder.getStatus() != DecoderJNI.Status.DONE) {
        System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] enter decompress 3");
        switch (decoder.getStatus()) {
          case OK:
            System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] enter decompress 4");
            decoder.push(0);
            break;
            // System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] exit decompress 4");

          case NEEDS_MORE_OUTPUT:
            System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] enter decompress 5");
            ByteBuffer buffer = decoder.pull();
            byte[] chunk = new byte[buffer.remaining()];
            buffer.get(chunk);
            output.add(chunk);
            totalOutputSize += chunk.length;
            break;
            // System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] exit decompress 5");

          default:
            System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] enter decompress 6");
            throw new IOException("corrupted input");
            // System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] exit decompress 6");
        }
        // System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] exit decompress 3");
      }
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] exit decompress 2");
    } finally {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] enter decompress 7");
      decoder.destroy();
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] exit decompress 7");
    }
    if (output.size() == 1) {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] enter decompress 8");
      return output.get(0);
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] exit decompress 8");
    }
    System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] enter decompress 9");
    byte[] result = new byte[totalOutputSize];
    int offset = 0;
    for (byte[] chunk : output) {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] enter decompress 10");
      System.arraycopy(chunk, 0, result, offset, chunk.length);
      offset += chunk.length;
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] exit decompress 10");
    }
    return result;
    // System.err.println("[brotli/java/org/brotli/wrapper/dec/Decoder.java] exit decompress 9");
  }
}
// Total cost: 0.038170
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 170)]
// Total instrumented cost: 0.038170, input tokens: 2398, output tokens: 2170, cache read tokens: 2394, cache write tokens: 1304
