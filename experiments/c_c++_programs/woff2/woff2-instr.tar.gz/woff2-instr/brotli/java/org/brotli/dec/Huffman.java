/* Copyright 2015 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

package org.brotli.dec;

/**
 * Utilities for building Huffman decoding tables.
 */
final class Huffman {

  private static final int MAX_LENGTH = 15;

  /**
   * Returns reverse(reverse(key, len) + 1, len).
   *
   * <p> reverse(key, len) is the bit-wise reversal of the len least significant bits of key.
   */
  private static int getNextKey(int key, int len) {
    System.err.println("[brotli/java/org/brotli/dec/Huffman.java] enter getNextKey 1");
    int step = 1 << (len - 1);
    // System.err.println("[brotli/java/org/brotli/dec/Huffman.java] exit getNextKey 1");
    
    while ((key & step) != 0) {
      System.err.println("[brotli/java/org/brotli/dec/Huffman.java] enter getNextKey 2");
      step >>= 1;
      // System.err.println("[brotli/java/org/brotli/dec/Huffman.java] exit getNextKey 2");
    }
    
    System.err.println("[brotli/java/org/brotli/dec/Huffman.java] enter getNextKey 3");
    return (key & (step - 1)) + step;
    // System.err.println("[brotli/java/org/brotli/dec/Huffman.java] exit getNextKey 3");
  }

  /**
   * Stores {@code item} in {@code table[0], table[step], table[2 * step] .., table[end]}.
   *
   * <p> Assumes that end is an integer multiple of step.
   */
  private static void replicateValue(int[] table, int offset, int step, int end, int item) {
    System.err.println("[brotli/java/org/brotli/dec/Huffman.java] enter replicateValue 1");
    do {
      System.err.println("[brotli/java/org/brotli/dec/Huffman.java] enter replicateValue 2");
      end -= step;
      table[offset + end] = item;
      // System.err.println("[brotli/java/org/brotli/dec/Huffman.java] exit replicateValue 2");
    } while (end > 0);
    // System.err.println("[brotli/java/org/brotli/dec/Huffman.java] exit replicateValue 1");
  }

  /**
   * @param count histogram of bit lengths for the remaining symbols,
   * @param len code length of the next processed symbol.
   * @return table width of the next 2nd level table.
   */
  private static int nextTableBitSize(int[] count, int len, int rootBits) {
    System.err.println("[brotli/java/org/brotli/dec/Huffman.java] enter nextTableBitSize 1");
    int left = 1 << (len - rootBits);
    // System.err.println("[brotli/java/org/brotli/dec/Huffman.java] exit nextTableBitSize 1");
    
    while (len < MAX_LENGTH) {
      System.err.println("[brotli/java/org/brotli/dec/Huffman.java] enter nextTableBitSize 2");
      left -= count[len];
      // System.err.println("[brotli/java/org/brotli/dec/Huffman.java] exit nextTableBitSize 2");
      
      if (left <= 0) {
        System.err.println("[brotli/java/org/brotli/dec/Huffman.java] enter nextTableBitSize 3");
        break;
        // System.err.println("[brotli/java/org/brotli/dec/Huffman.java] exit nextTableBitSize 3");
      }
      
      System.err.println("[brotli/java/org/brotli/dec/Huffman.java] enter nextTableBitSize 4");
      len++;
      left <<= 1;
      // System.err.println("[brotli/java/org/brotli/dec/Huffman.java] exit nextTableBitSize 4");
    }
    
    System.err.println("[brotli/java/org/brotli/dec/Huffman.java] enter nextTableBitSize 5");
    return len - rootBits;
    // System.err.println("[brotli/java/org/brotli/dec/Huffman.java] exit nextTableBitSize 5");
  }

  /**
   * Builds Huffman lookup table assuming code lengths are in symbol order.
   */
  static void buildHuffmanTable(int[] rootTable, int tableOffset, int rootBits, int[] codeLengths,
      int codeLengthsSize) {
    System.err.println("[brotli/java/org/brotli/dec/Huffman.java] enter buildHuffmanTable 1");
    int key; // Reversed prefix code.
    int[] sorted = new int[codeLengthsSize]; // Symbols sorted by code length.
    // TODO: fill with zeroes?
    int[] count = new int[MAX_LENGTH + 1]; // Number of codes of each length.
    int[] offset = new int[MAX_LENGTH + 1]; // Offsets in sorted table for each length.
    int symbol;

    // Build histogram of code lengths.
    for (symbol = 0; symbol < codeLengthsSize; symbol++) {
      System.err.println("[brotli/java/org/brotli/dec/Huffman.java] enter buildHuffmanTable 2");
      count[codeLengths[symbol]]++;
      // System.err.println("[brotli/java/org/brotli/dec/Huffman.java] exit buildHuffmanTable 2");
    }

    // Generate offsets into sorted symbol table by code length.
    System.err.println("[brotli/java/org/brotli/dec/Huffman.java] enter buildHuffmanTable 3");
    offset[1] = 0;
    // System.err.println("[brotli/java/org/brotli/dec/Huffman.java] exit buildHuffmanTable 3");
    
    for (int len = 1; len < MAX_LENGTH; len++) {
      System.err.println("[brotli/java/org/brotli/dec/Huffman.java] enter buildHuffmanTable 4");
      offset[len + 1] = offset[len] + count[len];
      // System.err.println("[brotli/java/org/brotli/dec/Huffman.java] exit buildHuffmanTable 4");
    }

    // Sort symbols by length, by symbol order within each length.
    for (symbol = 0; symbol < codeLengthsSize; symbol++) {
      System.err.println("[brotli/java/org/brotli/dec/Huffman.java] enter buildHuffmanTable 5");
      if (codeLengths[symbol] != 0) {
        System.err.println("[brotli/java/org/brotli/dec/Huffman.java] enter buildHuffmanTable 6");
        sorted[offset[codeLengths[symbol]]++] = symbol;
        // System.err.println("[brotli/java/org/brotli/dec/Huffman.java] exit buildHuffmanTable 6");
      }
      // System.err.println("[brotli/java/org/brotli/dec/Huffman.java] exit buildHuffmanTable 5");
    }

    System.err.println("[brotli/java/org/brotli/dec/Huffman.java] enter buildHuffmanTable 7");
    int tableBits = rootBits;
    int tableSize = 1 << tableBits;
    int totalSize = tableSize;
    // System.err.println("[brotli/java/org/brotli/dec/Huffman.java] exit buildHuffmanTable 7");

    // Special case code with only one value.
    if (offset[MAX_LENGTH] == 1) {
      System.err.println("[brotli/java/org/brotli/dec/Huffman.java] enter buildHuffmanTable 8");
      for (key = 0; key < totalSize; key++) {
        System.err.println("[brotli/java/org/brotli/dec/Huffman.java] enter buildHuffmanTable 9");
        rootTable[tableOffset + key] = sorted[0];
        // System.err.println("[brotli/java/org/brotli/dec/Huffman.java] exit buildHuffmanTable 9");
      }
      return;
      // System.err.println("[brotli/java/org/brotli/dec/Huffman.java] exit buildHuffmanTable 8");
    }

    // Fill in root table.
    System.err.println("[brotli/java/org/brotli/dec/Huffman.java] enter buildHuffmanTable 10");
    key = 0;
    symbol = 0;
    // System.err.println("[brotli/java/org/brotli/dec/Huffman.java] exit buildHuffmanTable 10");
    
    for (int len = 1, step = 2; len <= rootBits; len++, step <<= 1) {
      System.err.println("[brotli/java/org/brotli/dec/Huffman.java] enter buildHuffmanTable 11");
      for (; count[len] > 0; count[len]--) {
        System.err.println("[brotli/java/org/brotli/dec/Huffman.java] enter buildHuffmanTable 12");
        replicateValue(rootTable, tableOffset + key, step, tableSize, len << 16 | sorted[symbol++]);
        key = getNextKey(key, len);
        // System.err.println("[brotli/java/org/brotli/dec/Huffman.java] exit buildHuffmanTable 12");
      }
      // System.err.println("[brotli/java/org/brotli/dec/Huffman.java] exit buildHuffmanTable 11");
    }

    // Fill in 2nd level tables and add pointers to root table.
    System.err.println("[brotli/java/org/brotli/dec/Huffman.java] enter buildHuffmanTable 13");
    int mask = totalSize - 1;
    int low = -1;
    int currentOffset = tableOffset;
    // System.err.println("[brotli/java/org/brotli/dec/Huffman.java] exit buildHuffmanTable 13");
    
    for (int len = rootBits + 1, step = 2; len <= MAX_LENGTH; len++, step <<= 1) {
      System.err.println("[brotli/java/org/brotli/dec/Huffman.java] enter buildHuffmanTable 14");
      for (; count[len] > 0; count[len]--) {
        System.err.println("[brotli/java/org/brotli/dec/Huffman.java] enter buildHuffmanTable 15");
        if ((key & mask) != low) {
          System.err.println("[brotli/java/org/brotli/dec/Huffman.java] enter buildHuffmanTable 16");
          currentOffset += tableSize;
          tableBits = nextTableBitSize(count, len, rootBits);
          tableSize = 1 << tableBits;
          totalSize += tableSize;
          low = key & mask;
          rootTable[tableOffset + low] =
              (tableBits + rootBits) << 16 | (currentOffset - tableOffset - low);
          // System.err.println("[brotli/java/org/brotli/dec/Huffman.java] exit buildHuffmanTable 16");
        }
        
        System.err.println("[brotli/java/org/brotli/dec/Huffman.java] enter buildHuffmanTable 17");
        replicateValue(rootTable, currentOffset + (key >> rootBits), step, tableSize,
            (len - rootBits) << 16 | sorted[symbol++]);
        key = getNextKey(key, len);
        // System.err.println("[brotli/java/org/brotli/dec/Huffman.java] exit buildHuffmanTable 17");
        // System.err.println("[brotli/java/org/brotli/dec/Huffman.java] exit buildHuffmanTable 15");
      }
      // System.err.println("[brotli/java/org/brotli/dec/Huffman.java] exit buildHuffmanTable 14");
    }
    // System.err.println("[brotli/java/org/brotli/dec/Huffman.java] exit buildHuffmanTable 1");
  }
}
// Total cost: 0.088723
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 132)]
// Total instrumented cost: 0.088723, input tokens: 6233, output tokens: 4820, cache read tokens: 6225, cache write tokens: 3875
