/* Copyright 2015 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

package org.brotli.dec;

import java.io.IOException;
import java.io.InputStream;

/**
 * API for Brotli decompression.
 */
final class Decode {

  //----------------------------------------------------------------------------
  // RunningState
  //----------------------------------------------------------------------------
  private static final int UNINITIALIZED = 0;
  private static final int BLOCK_START = 1;
  private static final int COMPRESSED_BLOCK_START = 2;
  private static final int MAIN_LOOP = 3;
  private static final int READ_METADATA = 4;
  private static final int COPY_UNCOMPRESSED = 5;
  private static final int INSERT_LOOP = 6;
  private static final int COPY_LOOP = 7;
  private static final int TRANSFORM = 8;
  private static final int FINISHED = 9;
  private static final int CLOSED = 10;
  private static final int INIT_WRITE = 11;
  private static final int WRITE = 12;

  private static final int DEFAULT_CODE_LENGTH = 8;
  private static final int CODE_LENGTH_REPEAT_CODE = 16;
  private static final int NUM_LITERAL_CODES = 256;
  private static final int NUM_INSERT_AND_COPY_CODES = 704;
  private static final int NUM_BLOCK_LENGTH_CODES = 26;
  private static final int LITERAL_CONTEXT_BITS = 6;
  private static final int DISTANCE_CONTEXT_BITS = 2;

  private static final int HUFFMAN_TABLE_BITS = 8;
  private static final int HUFFMAN_TABLE_MASK = 0xFF;

  /**
   * Maximum possible Huffman table size for an alphabet size of 704, max code length 15 and root
   * table bits 8.
   */
  static final int HUFFMAN_TABLE_SIZE = 1080;

  private static final int CODE_LENGTH_CODES = 18;
  private static final int[] CODE_LENGTH_CODE_ORDER = {
      1, 2, 3, 4, 0, 5, 17, 6, 16, 7, 8, 9, 10, 11, 12, 13, 14, 15,
  };

  private static final int NUM_DISTANCE_SHORT_CODES = 16;
  private static final int[] DISTANCE_SHORT_CODE_INDEX_OFFSET = {
      3, 2, 1, 0, 3, 3, 3, 3, 3, 3, 2, 2, 2, 2, 2, 2
  };

  private static final int[] DISTANCE_SHORT_CODE_VALUE_OFFSET = {
      0, 0, 0, 0, -1, 1, -2, 2, -3, 3, -1, 1, -2, 2, -3, 3
  };

  /**
   * Static Huffman code for the code length code lengths.
   */
  private static final int[] FIXED_TABLE = {
      0x020000, 0x020004, 0x020003, 0x030002, 0x020000, 0x020004, 0x020003, 0x040001,
      0x020000, 0x020004, 0x020003, 0x030002, 0x020000, 0x020004, 0x020003, 0x040005
  };

  static final int[] DICTIONARY_OFFSETS_BY_LENGTH = {
    0, 0, 0, 0, 0, 4096, 9216, 21504, 35840, 44032, 53248, 63488, 74752, 87040, 93696, 100864,
    104704, 106752, 108928, 113536, 115968, 118528, 119872, 121280, 122016
  };

  static final int[] DICTIONARY_SIZE_BITS_BY_LENGTH = {
    0, 0, 0, 0, 10, 10, 11, 11, 10, 10, 10, 10, 10, 9, 9, 8, 7, 7, 8, 7, 7, 6, 6, 5, 5
  };

  static final int MIN_WORD_LENGTH = 4;

  static final int MAX_WORD_LENGTH = 24;

  static final int MAX_TRANSFORMED_WORD_LENGTH = 5 + MAX_WORD_LENGTH + 8;

  //----------------------------------------------------------------------------
  // Prefix code LUT.
  //----------------------------------------------------------------------------
  static final int[] BLOCK_LENGTH_OFFSET = {
      1, 5, 9, 13, 17, 25, 33, 41, 49, 65, 81, 97, 113, 145, 177, 209, 241, 305, 369, 497,
      753, 1265, 2289, 4337, 8433, 16625
  };

  static final int[] BLOCK_LENGTH_N_BITS = {
      2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 6, 6, 7, 8, 9, 10, 11, 12, 13, 24
  };

  static final int[] INSERT_LENGTH_OFFSET = {
      0, 1, 2, 3, 4, 5, 6, 8, 10, 14, 18, 26, 34, 50, 66, 98, 130, 194, 322, 578, 1090, 2114, 6210,
      22594
  };

  static final int[] INSERT_LENGTH_N_BITS = {
      0, 0, 0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 7, 8, 9, 10, 12, 14, 24
  };

  static final int[] COPY_LENGTH_OFFSET = {
      2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 14, 18, 22, 30, 38, 54, 70, 102, 134, 198, 326, 582, 1094,
      2118
  };

  static final int[] COPY_LENGTH_N_BITS = {
      0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 7, 8, 9, 10, 24
  };

  static final int[] INSERT_RANGE_LUT = {
      0, 0, 8, 8, 0, 16, 8, 16, 16
  };

  static final int[] COPY_RANGE_LUT = {
      0, 8, 0, 8, 16, 0, 16, 8, 16
  };

  private static int decodeWindowBits(State s) {
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeWindowBits 1");
    BitReader.fillBitWindow(s);
    if (BitReader.readFewBits(s, 1) == 0) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeWindowBits 2");
      return 16;
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeWindowBits 2");
    }
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeWindowBits 3");
    int n = BitReader.readFewBits(s, 3);
    if (n != 0) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeWindowBits 4");
      return 17 + n;
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeWindowBits 4");
    }
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeWindowBits 5");
    n = BitReader.readFewBits(s, 3);
    if (n != 0) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeWindowBits 6");
      return 8 + n;
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeWindowBits 6");
    }
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeWindowBits 7");
    return 17;
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeWindowBits 7");
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeWindowBits 5");
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeWindowBits 3");
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeWindowBits 1");
  }

  /**
   * Associate input with decoder state.
   *
   * @param s uninitialized state without associated input
   * @param input compressed data source
   */
  static void initState(State s, InputStream input) {
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter initState 1");
    if (s.runningState != UNINITIALIZED) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter initState 2");
      throw new IllegalStateException("State MUST be uninitialized");
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit initState 2");
    }
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter initState 3");
    s.blockTrees = new int[6 * HUFFMAN_TABLE_SIZE];
    s.input = input;
    BitReader.initBitReader(s);
    int windowBits = decodeWindowBits(s);
    if (windowBits == 9) { /* Reserved case for future expansion. */
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter initState 4");
      throw new BrotliRuntimeException("Invalid 'windowBits' code");
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit initState 4");
    }
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter initState 5");
    s.maxRingBufferSize = 1 << windowBits;
    s.maxBackwardDistance = s.maxRingBufferSize - 16;
    s.runningState = BLOCK_START;
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit initState 5");
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit initState 3");
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit initState 1");
  }

  static void close(State s) throws IOException {
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter close 1");
    if (s.runningState == UNINITIALIZED) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter close 2");
      throw new IllegalStateException("State MUST be initialized");
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit close 2");
    }
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter close 3");
    if (s.runningState == CLOSED) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter close 4");
      return;
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit close 4");
    }
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter close 5");
    s.runningState = CLOSED;
    if (s.input != null) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter close 6");
      Utils.closeInput(s.input);
      s.input = null;
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit close 6");
    }
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit close 5");
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit close 3");
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit close 1");
  }

  /**
   * Decodes a number in the range [0..255], by reading 1 - 11 bits.
   */
  private static int decodeVarLenUnsignedByte(State s) {
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeVarLenUnsignedByte 1");
    BitReader.fillBitWindow(s);
    if (BitReader.readFewBits(s, 1) != 0) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeVarLenUnsignedByte 2");
      int n = BitReader.readFewBits(s, 3);
      if (n == 0) {
        System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeVarLenUnsignedByte 3");
        return 1;
        // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeVarLenUnsignedByte 3");
      } else {
        System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeVarLenUnsignedByte 4");
        return BitReader.readFewBits(s, n) + (1 << n);
        // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeVarLenUnsignedByte 4");
      }
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeVarLenUnsignedByte 2");
    }
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeVarLenUnsignedByte 5");
    return 0;
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeVarLenUnsignedByte 5");
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeVarLenUnsignedByte 1");
  }

  private static void decodeMetaBlockLength(State s) {
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeMetaBlockLength 1");
    BitReader.fillBitWindow(s);
    s.inputEnd = BitReader.readFewBits(s, 1);
    s.metaBlockLength = 0;
    s.isUncompressed = 0;
    s.isMetadata = 0;
    if ((s.inputEnd != 0) && BitReader.readFewBits(s, 1) != 0) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeMetaBlockLength 2");
      return;
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeMetaBlockLength 2");
    }
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeMetaBlockLength 3");
    int sizeNibbles = BitReader.readFewBits(s, 2) + 4;
    if (sizeNibbles == 7) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeMetaBlockLength 4");
      s.isMetadata = 1;
      if (BitReader.readFewBits(s, 1) != 0) {
        System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeMetaBlockLength 5");
        throw new BrotliRuntimeException("Corrupted reserved bit");
        // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeMetaBlockLength 5");
      }
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeMetaBlockLength 6");
      int sizeBytes = BitReader.readFewBits(s, 2);
      if (sizeBytes == 0) {
        System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeMetaBlockLength 7");
        return;
        // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeMetaBlockLength 7");
      }
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeMetaBlockLength 8");
      for (int i = 0; i < sizeBytes; i++) {
        System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeMetaBlockLength 9");
        BitReader.fillBitWindow(s);
        int bits = BitReader.readFewBits(s, 8);
        if (bits == 0 && i + 1 == sizeBytes && sizeBytes > 1) {
          System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeMetaBlockLength 10");
          throw new BrotliRuntimeException("Exuberant nibble");
          // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeMetaBlockLength 10");
        }
        System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeMetaBlockLength 11");
        s.metaBlockLength |= bits << (i * 8);
        // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeMetaBlockLength 11");
        // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeMetaBlockLength 9");
      }
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeMetaBlockLength 8");
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeMetaBlockLength 6");
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeMetaBlockLength 4");
    } else {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeMetaBlockLength 12");
      for (int i = 0; i < sizeNibbles; i++) {
        System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeMetaBlockLength 13");
        BitReader.fillBitWindow(s);
        int bits = BitReader.readFewBits(s, 4);
        if (bits == 0 && i + 1 == sizeNibbles && sizeNibbles > 4) {
          System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeMetaBlockLength 14");
          throw new BrotliRuntimeException("Exuberant nibble");
          // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeMetaBlockLength 14");
        }
        System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeMetaBlockLength 15");
        s.metaBlockLength |= bits << (i * 4);
        // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeMetaBlockLength 15");
        // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeMetaBlockLength 13");
      }
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeMetaBlockLength 12");
    }
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeMetaBlockLength 16");
    s.metaBlockLength++;
    if (s.inputEnd == 0) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeMetaBlockLength 17");
      s.isUncompressed = BitReader.readFewBits(s, 1);
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeMetaBlockLength 17");
    }
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeMetaBlockLength 16");
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeMetaBlockLength 3");
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeMetaBlockLength 1");
  }

  /**
   * Decodes the next Huffman code from bit-stream.
   */
  private static int readSymbol(int[] table, int offset, State s) {
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readSymbol 1");
    int val = BitReader.peekBits(s);
    offset += val & HUFFMAN_TABLE_MASK;
    int bits = table[offset] >> 16;
    int sym = table[offset] & 0xFFFF;
    if (bits <= HUFFMAN_TABLE_BITS) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readSymbol 2");
      s.bitOffset += bits;
      return sym;
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readSymbol 2");
    }
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readSymbol 3");
    offset += sym;
    int mask = (1 << bits) - 1;
    offset += (val & mask) >>> HUFFMAN_TABLE_BITS;
    s.bitOffset += ((table[offset] >> 16) + HUFFMAN_TABLE_BITS);
    return table[offset] & 0xFFFF;
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readSymbol 3");
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readSymbol 1");
  }

  private static int readBlockLength(int[] table, int offset, State s) {
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readBlockLength 1");
    BitReader.fillBitWindow(s);
    int code = readSymbol(table, offset, s);
    int n = BLOCK_LENGTH_N_BITS[code];
    BitReader.fillBitWindow(s);
    return BLOCK_LENGTH_OFFSET[code] + BitReader.readBits(s, n);
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readBlockLength 1");
  }

  private static int translateShortCodes(int code, int[] ringBuffer, int index) {
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter translateShortCodes 1");
    if (code < NUM_DISTANCE_SHORT_CODES) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter translateShortCodes 2");
      index += DISTANCE_SHORT_CODE_INDEX_OFFSET[code];
      index &= 3;
      return ringBuffer[index] + DISTANCE_SHORT_CODE_VALUE_OFFSET[code];
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit translateShortCodes 2");
    }
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter translateShortCodes 3");
    return code - NUM_DISTANCE_SHORT_CODES + 1;
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit translateShortCodes 3");
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit translateShortCodes 1");
  }

  private static void moveToFront(int[] v, int index) {
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter moveToFront 1");
    int value = v[index];
    for (; index > 0; index--) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter moveToFront 2");
      v[index] = v[index - 1];
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit moveToFront 2");
    }
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter moveToFront 3");
    v[0] = value;
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit moveToFront 3");
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit moveToFront 1");
  }

  private static void inverseMoveToFrontTransform(byte[] v, int vLen) {
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter inverseMoveToFrontTransform 1");
    int[] mtf = new int[256];
    for (int i = 0; i < 256; i++) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter inverseMoveToFrontTransform 2");
      mtf[i] = i;
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit inverseMoveToFrontTransform 2");
    }
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter inverseMoveToFrontTransform 3");
    for (int i = 0; i < vLen; i++) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter inverseMoveToFrontTransform 4");
      int index = v[i] & 0xFF;
      v[i] = (byte) mtf[index];
      if (index != 0) {
        System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter inverseMoveToFrontTransform 5");
        moveToFront(mtf, index);
        // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit inverseMoveToFrontTransform 5");
      }
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit inverseMoveToFrontTransform 4");
    }
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit inverseMoveToFrontTransform 3");
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit inverseMoveToFrontTransform 1");
  }

  private static void readHuffmanCodeLengths(
      int[] codeLengthCodeLengths, int numSymbols, int[] codeLengths, State s) {
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readHuffmanCodeLengths 1");
    int symbol = 0;
    int prevCodeLen = DEFAULT_CODE_LENGTH;
    int repeat = 0;
    int repeatCodeLen = 0;
    int space = 32768;
    int[] table = new int[32];

    Huffman.buildHuffmanTable(table, 0, 5, codeLengthCodeLengths, CODE_LENGTH_CODES);

    while (symbol < numSymbols && space > 0) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readHuffmanCodeLengths 2");
      BitReader.readMoreInput(s);
      BitReader.fillBitWindow(s);
      int p = BitReader.peekBits(s) & 31;
      s.bitOffset += table[p] >> 16;
      int codeLen = table[p] & 0xFFFF;
      if (codeLen < CODE_LENGTH_REPEAT_CODE) {
        System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readHuffmanCodeLengths 3");
        repeat = 0;
        codeLengths[symbol++] = codeLen;
        if (codeLen != 0) {
          System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readHuffmanCodeLengths 4");
          prevCodeLen = codeLen;
          space -= 32768 >> codeLen;
          // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readHuffmanCodeLengths 4");
        }
        // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readHuffmanCodeLengths 3");
      } else {
        System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readHuffmanCodeLengths 5");
        int extraBits = codeLen - 14;
        int newLen = 0;
        if (codeLen == CODE_LENGTH_REPEAT_CODE) {
          System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readHuffmanCodeLengths 6");
          newLen = prevCodeLen;
          // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readHuffmanCodeLengths 6");
        }
        System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readHuffmanCodeLengths 7");
        if (repeatCodeLen != newLen) {
          System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readHuffmanCodeLengths 8");
          repeat = 0;
          repeatCodeLen = newLen;
          // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readHuffmanCodeLengths 8");
        }
        System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readHuffmanCodeLengths 9");
        int oldRepeat = repeat;
        if (repeat > 0) {
          System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readHuffmanCodeLengths 10");
          repeat -= 2;
          repeat <<= extraBits;
          // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readHuffmanCodeLengths 10");
        }
        System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readHuffmanCodeLengths 11");
        BitReader.fillBitWindow(s);
        repeat += BitReader.readFewBits(s, extraBits) + 3;
        int repeatDelta = repeat - oldRepeat;
        if (symbol + repeatDelta > numSymbols) {
          System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readHuffmanCodeLengths 12");
          throw new BrotliRuntimeException("symbol + repeatDelta > numSymbols"); // COV_NF_LINE
          // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readHuffmanCodeLengths 12");
        }
        System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readHuffmanCodeLengths 13");
        for (int i = 0; i < repeatDelta; i++) {
          System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readHuffmanCodeLengths 14");
          codeLengths[symbol++] = repeatCodeLen;
          // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readHuffmanCodeLengths 14");
        }
        System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readHuffmanCodeLengths 15");
        if (repeatCodeLen != 0) {
          System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readHuffmanCodeLengths 16");
          space -= repeatDelta << (15 - repeatCodeLen);
          // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readHuffmanCodeLengths 16");
        }
        // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readHuffmanCodeLengths 15");
        // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readHuffmanCodeLengths 13");
        // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readHuffmanCodeLengths 11");
        // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readHuffmanCodeLengths 9");
        // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readHuffmanCodeLengths 7");
        // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readHuffmanCodeLengths 5");
      }
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readHuffmanCodeLengths 2");
    }
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readHuffmanCodeLengths 17");
    if (space != 0) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readHuffmanCodeLengths 18");
      throw new BrotliRuntimeException("Unused space"); // COV_NF_LINE
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readHuffmanCodeLengths 18");
    }
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readHuffmanCodeLengths 19");
    // TODO: Pass max_symbol to Huffman table builder instead?
    Utils.fillIntsWithZeroes(codeLengths, symbol, numSymbols);
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readHuffmanCodeLengths 19");
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readHuffmanCodeLengths 17");
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readHuffmanCodeLengths 1");
  }

  static int checkDupes(int[] symbols, int length) {
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter checkDupes 1");
    for (int i = 0; i < length - 1; ++i) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter checkDupes 2");
      for (int j = i + 1; j < length; ++j) {
        System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter checkDupes 3");
        if (symbols[i] == symbols[j]) {
          System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter checkDupes 4");
          return 0;
          // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit checkDupes 4");
        }
        // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit checkDupes 3");
      }
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit checkDupes 2");
    }
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter checkDupes 5");
    return 1;
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit checkDupes 5");
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit checkDupes 1");
  }

  // TODO: Use specialized versions for smaller tables.
  static void readHuffmanCode(int alphabetSize, int[] table, int offset, State s) {
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readHuffmanCode 1");
    int ok = 1;
    int simpleCodeOrSkip;
    BitReader.readMoreInput(s);
    // TODO: Avoid allocation.
    int[] codeLengths = new int[alphabetSize];
    BitReader.fillBitWindow(s);
    simpleCodeOrSkip = BitReader.readFewBits(s, 2);
    if (simpleCodeOrSkip == 1) { // Read symbols, codes & code lengths directly.
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readHuffmanCode 2");
      int maxBitsCounter = alphabetSize - 1;
      int maxBits = 0;
      int[] symbols = new int[4];
      int numSymbols = BitReader.readFewBits(s, 2) + 1;
      while (maxBitsCounter != 0) {
        System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readHuffmanCode 3");
        maxBitsCounter >>= 1;
        maxBits++;
        // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readHuffmanCode 3");
      }
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readHuffmanCode 4");
      // TODO: uncomment when codeLengths is reused.
      // Utils.fillWithZeroes(codeLengths, 0, alphabetSize);
      for (int i = 0; i < numSymbols; i++) {
        System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readHuffmanCode 5");
        BitReader.fillBitWindow(s);
        symbols[i] = BitReader.readFewBits(s, maxBits) % alphabetSize;
        codeLengths[symbols[i]] = 2;
        // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readHuffmanCode 5");
      }
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readHuffmanCode 6");
      codeLengths[symbols[0]] = 1;
      switch (numSymbols) {
        case 2:
          System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readHuffmanCode 7");
          codeLengths[symbols[1]] = 1;
          // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readHuffmanCode 7");
          break;
        case 4:
          System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readHuffmanCode 8");
          if (BitReader.readFewBits(s, 1) == 1) {
            System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readHuffmanCode 9");
            codeLengths[symbols[2]] = 3;
            codeLengths[symbols[3]] = 3;
            // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readHuffmanCode 9");
          } else {
            System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readHuffmanCode 10");
            codeLengths[symbols[0]] = 2;
            // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readHuffmanCode 10");
          }
          // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readHuffmanCode 8");
          break;
        default:
          break;
      }
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readHuffmanCode 11");
      ok = checkDupes(symbols, numSymbols);
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readHuffmanCode 11");
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readHuffmanCode 6");
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readHuffmanCode 4");
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readHuffmanCode 2");
    } else { // Decode Huffman-coded code lengths.
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readHuffmanCode 12");
      int[] codeLengthCodeLengths = new int[CODE_LENGTH_CODES];
      int space = 32;
      int numCodes = 0;
      for (int i = simpleCodeOrSkip; i < CODE_LENGTH_CODES && space > 0; i++) {
        System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readHuffmanCode 13");
        int codeLenIdx = CODE_LENGTH_CODE_ORDER[i];
        BitReader.fillBitWindow(s);
        int p = BitReader.peekBits(s) & 15;
        // TODO: Demultiplex FIXED_TABLE.
        s.bitOffset += FIXED_TABLE[p] >> 16;
        int v = FIXED_TABLE[p] & 0xFFFF;
        codeLengthCodeLengths[codeLenIdx] = v;
        if (v != 0) {
          System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readHuffmanCode 14");
          space -= (32 >> v);
          numCodes++;
          // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readHuffmanCode 14");
        }
        // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readHuffmanCode 13");
      }
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readHuffmanCode 15");
      if (space != 0 && numCodes != 1) {
        System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readHuffmanCode 16");
        ok = 0;
        // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readHuffmanCode 16");
      }
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readHuffmanCode 17");
      readHuffmanCodeLengths(codeLengthCodeLengths, alphabetSize, codeLengths, s);
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readHuffmanCode 17");
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readHuffmanCode 15");
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readHuffmanCode 12");
    }
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readHuffmanCode 18");
    if (ok == 0) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readHuffmanCode 19");
      throw new BrotliRuntimeException("Can't readHuffmanCode"); // COV_NF_LINE
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readHuffmanCode 19");
    }
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readHuffmanCode 20");
    Huffman.buildHuffmanTable(table, offset, HUFFMAN_TABLE_BITS, codeLengths, alphabetSize);
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readHuffmanCode 20");
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readHuffmanCode 18");
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readHuffmanCode 1");
  }

  private static int decodeContextMap(int contextMapSize, byte[] contextMap, State s) {
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeContextMap 1");
    BitReader.readMoreInput(s);
    int numTrees = decodeVarLenUnsignedByte(s) + 1;

    if (numTrees == 1) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeContextMap 2");
      Utils.fillBytesWithZeroes(contextMap, 0, contextMapSize);
      return numTrees;
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeContextMap 2");
    }

    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeContextMap 3");
    BitReader.fillBitWindow(s);
    int useRleForZeros = BitReader.readFewBits(s, 1);
    int maxRunLengthPrefix = 0;
    if (useRleForZeros != 0) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeContextMap 4");
      maxRunLengthPrefix = BitReader.readFewBits(s, 4) + 1;
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeContextMap 4");
    }
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeContextMap 5");
    int[] table = new int[HUFFMAN_TABLE_SIZE];
    readHuffmanCode(numTrees + maxRunLengthPrefix, table, 0, s);
    for (int i = 0; i < contextMapSize; ) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeContextMap 6");
      BitReader.readMoreInput(s);
      BitReader.fillBitWindow(s);
      int code = readSymbol(table, 0, s);
      if (code == 0) {
        System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeContextMap 7");
        contextMap[i] = 0;
        i++;
        // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeContextMap 7");
      } else if (code <= maxRunLengthPrefix) {
        System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeContextMap 8");
        BitReader.fillBitWindow(s);
        int reps = (1 << code) + BitReader.readFewBits(s, code);
        while (reps != 0) {
          System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeContextMap 9");
          if (i >= contextMapSize) {
            System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeContextMap 10");
            throw new BrotliRuntimeException("Corrupted context map"); // COV_NF_LINE
            // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeContextMap 10");
          }
          System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeContextMap 11");
          contextMap[i] = 0;
          i++;
          reps--;
          // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeContextMap 11");
          // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeContextMap 9");
        }
        // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeContextMap 8");
      } else {
        System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeContextMap 12");
        contextMap[i] = (byte) (code - maxRunLengthPrefix);
        i++;
        // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeContextMap 12");
      }
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeContextMap 6");
    }
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeContextMap 13");
    BitReader.fillBitWindow(s);
    if (BitReader.readFewBits(s, 1) == 1) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeContextMap 14");
      inverseMoveToFrontTransform(contextMap, contextMapSize);
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeContextMap 14");
    }
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeContextMap 15");
    return numTrees;
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeContextMap 15");
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeContextMap 13");
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeContextMap 5");
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeContextMap 3");
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeContextMap 1");
  }

  private static int decodeBlockTypeAndLength(State s, int treeType, int numBlockTypes) {
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeBlockTypeAndLength 1");
    final int[] ringBuffers = s.rings;
    final int offset = 4 + treeType * 2;
    BitReader.fillBitWindow(s);
    int blockType = readSymbol(s.blockTrees, treeType * HUFFMAN_TABLE_SIZE, s);
    int result = readBlockLength(s.blockTrees, (treeType + 3) * HUFFMAN_TABLE_SIZE, s);

    if (blockType == 1) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeBlockTypeAndLength 2");
      blockType = ringBuffers[offset + 1] + 1;
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeBlockTypeAndLength 2");
    } else if (blockType == 0) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeBlockTypeAndLength 3");
      blockType = ringBuffers[offset];
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeBlockTypeAndLength 3");
    } else {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeBlockTypeAndLength 4");
      blockType -= 2;
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeBlockTypeAndLength 4");
    }
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeBlockTypeAndLength 5");
    if (blockType >= numBlockTypes) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeBlockTypeAndLength 6");
      blockType -= numBlockTypes;
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeBlockTypeAndLength 6");
    }
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeBlockTypeAndLength 7");
    ringBuffers[offset] = ringBuffers[offset + 1];
    ringBuffers[offset + 1] = blockType;
    return result;
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeBlockTypeAndLength 7");
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeBlockTypeAndLength 5");
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeBlockTypeAndLength 1");
  }

  private static void decodeLiteralBlockSwitch(State s) {
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeLiteralBlockSwitch 1");
    s.literalBlockLength = decodeBlockTypeAndLength(s, 0, s.numLiteralBlockTypes);
    int literalBlockType = s.rings[5];
    s.contextMapSlice = literalBlockType << LITERAL_CONTEXT_BITS;
    s.literalTreeIndex = s.contextMap[s.contextMapSlice] & 0xFF;
    s.literalTree = s.hGroup0[s.literalTreeIndex];
    int contextMode = s.contextModes[literalBlockType];
    s.contextLookupOffset1 = contextMode << 9;
    s.contextLookupOffset2 = s.contextLookupOffset1 + 256;
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeLiteralBlockSwitch 1");
  }

  private static void decodeCommandBlockSwitch(State s) {
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeCommandBlockSwitch 1");
    s.commandBlockLength = decodeBlockTypeAndLength(s, 1, s.numCommandBlockTypes);
    s.treeCommandOffset = s.hGroup1[s.rings[7]];
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeCommandBlockSwitch 1");
  }

  private static void decodeDistanceBlockSwitch(State s) {
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeDistanceBlockSwitch 1");
    s.distanceBlockLength = decodeBlockTypeAndLength(s, 2, s.numDistanceBlockTypes);
    s.distContextMapSlice = s.rings[9] << DISTANCE_CONTEXT_BITS;
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeDistanceBlockSwitch 1");
  }

  private static void maybeReallocateRingBuffer(State s) {
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter maybeReallocateRingBuffer 1");
    int newSize = s.maxRingBufferSize;
    if (newSize > s.expectedTotalSize) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter maybeReallocateRingBuffer 2");
      /* TODO: Handle 2GB+ cases more gracefully. */
      int minimalNewSize = s.expectedTotalSize;
      while ((newSize >> 1) > minimalNewSize) {
        System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter maybeReallocateRingBuffer 3");
        newSize >>= 1;
        // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit maybeReallocateRingBuffer 3");
      }
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter maybeReallocateRingBuffer 4");
      if ((s.inputEnd == 0) && newSize < 16384 && s.maxRingBufferSize >= 16384) {
        System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter maybeReallocateRingBuffer 5");
        newSize = 16384;
        // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit maybeReallocateRingBuffer 5");
      }
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit maybeReallocateRingBuffer 4");
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit maybeReallocateRingBuffer 2");
    }
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter maybeReallocateRingBuffer 6");
    if (newSize <= s.ringBufferSize) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter maybeReallocateRingBuffer 7");
      return;
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit maybeReallocateRingBuffer 7");
    }
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter maybeReallocateRingBuffer 8");
    int ringBufferSizeWithSlack = newSize + MAX_TRANSFORMED_WORD_LENGTH;
    byte[] newBuffer = new byte[ringBufferSizeWithSlack];
    if (s.ringBuffer.length != 0) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter maybeReallocateRingBuffer 9");
      System.arraycopy(s.ringBuffer, 0, newBuffer, 0, s.ringBufferSize);
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit maybeReallocateRingBuffer 9");
    }
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter maybeReallocateRingBuffer 10");
    s.ringBuffer = newBuffer;
    s.ringBufferSize = newSize;
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit maybeReallocateRingBuffer 10");
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit maybeReallocateRingBuffer 8");
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit maybeReallocateRingBuffer 6");
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit maybeReallocateRingBuffer 1");
  }

  private static void readNextMetablockHeader(State s) {
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readNextMetablockHeader 1");
    if (s.inputEnd != 0) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readNextMetablockHeader 2");
      s.nextRunningState = FINISHED;
      s.runningState = INIT_WRITE;
      return;
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readNextMetablockHeader 2");
    }
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readNextMetablockHeader 3");
    // TODO: Reset? Do we need this?
    s.hGroup0 = new int[0];
    s.hGroup1 = new int[0];
    s.hGroup2 = new int[0];

    BitReader.readMoreInput(s);
    decodeMetaBlockLength(s);
    if ((s.metaBlockLength == 0) && (s.isMetadata == 0)) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readNextMetablockHeader 4");
      return;
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readNextMetablockHeader 4");
    }
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readNextMetablockHeader 5");
    if ((s.isUncompressed != 0) || (s.isMetadata != 0)) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readNextMetablockHeader 6");
      BitReader.jumpToByteBoundary(s);
      s.runningState = (s.isMetadata != 0) ? READ_METADATA : COPY_UNCOMPRESSED;
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readNextMetablockHeader 6");
    } else {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readNextMetablockHeader 7");
      s.runningState = COMPRESSED_BLOCK_START;
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readNextMetablockHeader 7");
    }

    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readNextMetablockHeader 8");
    if (s.isMetadata != 0) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readNextMetablockHeader 9");
      return;
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readNextMetablockHeader 9");
    }
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readNextMetablockHeader 10");
    s.expectedTotalSize += s.metaBlockLength;
    if (s.expectedTotalSize > 1 << 30) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readNextMetablockHeader 11");
      s.expectedTotalSize = 1 << 30;
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readNextMetablockHeader 11");
    }
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readNextMetablockHeader 12");
    if (s.ringBufferSize < s.maxRingBufferSize) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readNextMetablockHeader 13");
      maybeReallocateRingBuffer(s);
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readNextMetablockHeader 13");
    }
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readNextMetablockHeader 12");
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readNextMetablockHeader 10");
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readNextMetablockHeader 8");
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readNextMetablockHeader 5");
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readNextMetablockHeader 3");
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readNextMetablockHeader 1");
  }

  private static int readMetablockPartition(State s, int treeType, int numBlockTypes) {
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readMetablockPartition 1");
    if (numBlockTypes <= 1) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readMetablockPartition 2");
      return 1 << 28;
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readMetablockPartition 2");
    }
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readMetablockPartition 3");
    readHuffmanCode(numBlockTypes + 2, s.blockTrees, treeType * HUFFMAN_TABLE_SIZE, s);
    readHuffmanCode(NUM_BLOCK_LENGTH_CODES, s.blockTrees, (treeType + 3) * HUFFMAN_TABLE_SIZE, s);
    return readBlockLength(s.blockTrees, (treeType + 3) * HUFFMAN_TABLE_SIZE, s);
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readMetablockPartition 3");
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readMetablockPartition 1");
  }

  private static void readMetablockHuffmanCodesAndContextMaps(State s) {
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readMetablockHuffmanCodesAndContextMaps 1");
    s.numLiteralBlockTypes = decodeVarLenUnsignedByte(s) + 1;
    s.literalBlockLength = readMetablockPartition(s, 0, s.numLiteralBlockTypes);
    s.numCommandBlockTypes = decodeVarLenUnsignedByte(s) + 1;
    s.commandBlockLength = readMetablockPartition(s, 1, s.numCommandBlockTypes);
    s.numDistanceBlockTypes = decodeVarLenUnsignedByte(s) + 1;
    s.distanceBlockLength = readMetablockPartition(s, 2, s.numDistanceBlockTypes);

    BitReader.readMoreInput(s);
    BitReader.fillBitWindow(s);
    s.distancePostfixBits = BitReader.readFewBits(s, 2);
    s.numDirectDistanceCodes =
        NUM_DISTANCE_SHORT_CODES + (BitReader.readFewBits(s, 4) << s.distancePostfixBits);
    s.distancePostfixMask = (1 << s.distancePostfixBits) - 1;
    int numDistanceCodes = s.numDirectDistanceCodes + (48 << s.distancePostfixBits);
    // TODO: Reuse?
    s.contextModes = new byte[s.numLiteralBlockTypes];
    for (int i = 0; i < s.numLiteralBlockTypes;) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readMetablockHuffmanCodesAndContextMaps 2");
      /* Ensure that less than 256 bits read between readMoreInput. */
      int limit = Math.min(i + 96, s.numLiteralBlockTypes);
      for (; i < limit; ++i) {
        System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readMetablockHuffmanCodesAndContextMaps 3");
        BitReader.fillBitWindow(s);
        s.contextModes[i] = (byte) (BitReader.readFewBits(s, 2));
        // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readMetablockHuffmanCodesAndContextMaps 3");
      }
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readMetablockHuffmanCodesAndContextMaps 4");
      BitReader.readMoreInput(s);
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readMetablockHuffmanCodesAndContextMaps 4");
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readMetablockHuffmanCodesAndContextMaps 2");
    }

    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readMetablockHuffmanCodesAndContextMaps 5");
    // TODO: Reuse?
    s.contextMap = new byte[s.numLiteralBlockTypes << LITERAL_CONTEXT_BITS];
    int numLiteralTrees = decodeContextMap(s.numLiteralBlockTypes << LITERAL_CONTEXT_BITS,
        s.contextMap, s);
    s.trivialLiteralContext = 1;
    for (int j = 0; j < s.numLiteralBlockTypes << LITERAL_CONTEXT_BITS; j++) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readMetablockHuffmanCodesAndContextMaps 6");
      if (s.contextMap[j] != j >> LITERAL_CONTEXT_BITS) {
        System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readMetablockHuffmanCodesAndContextMaps 7");
        s.trivialLiteralContext = 0;
        break;
        // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readMetablockHuffmanCodesAndContextMaps 7");
      }
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readMetablockHuffmanCodesAndContextMaps 6");
    }

    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter readMetablockHuffmanCodesAndContextMaps 8");
    // TODO: Reuse?
    s.distContextMap = new byte[s.numDistanceBlockTypes << DISTANCE_CONTEXT_BITS];
    int numDistTrees = decodeContextMap(s.numDistanceBlockTypes << DISTANCE_CONTEXT_BITS,
        s.distContextMap, s);

    s.hGroup0 = decodeHuffmanTreeGroup(NUM_LITERAL_CODES, numLiteralTrees, s);
    s.hGroup1 =
        decodeHuffmanTreeGroup(NUM_INSERT_AND_COPY_CODES, s.numCommandBlockTypes, s);
    s.hGroup2 = decodeHuffmanTreeGroup(numDistanceCodes, numDistTrees, s);

    s.contextMapSlice = 0;
    s.distContextMapSlice = 0;
    s.contextLookupOffset1 = (int) (s.contextModes[0]) << 9;
    s.contextLookupOffset2 = s.contextLookupOffset1 + 256;
    s.literalTreeIndex = 0;
    s.literalTree = s.hGroup0[0];
    s.treeCommandOffset = s.hGroup1[0];

    s.rings[4] = 1;
    s.rings[5] = 0;
    s.rings[6] = 1;
    s.rings[7] = 0;
    s.rings[8] = 1;
    s.rings[9] = 0;
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readMetablockHuffmanCodesAndContextMaps 8");
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readMetablockHuffmanCodesAndContextMaps 5");
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit readMetablockHuffmanCodesAndContextMaps 1");
  }

  private static void copyUncompressedData(State s) {
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter copyUncompressedData 1");
    final byte[] ringBuffer = s.ringBuffer;

    // Could happen if block ends at ring buffer end.
    if (s.metaBlockLength <= 0) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter copyUncompressedData 2");
      BitReader.reload(s);
      s.runningState = BLOCK_START;
      return;
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit copyUncompressedData 2");
    }

    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter copyUncompressedData 3");
    int chunkLength = Math.min(s.ringBufferSize - s.pos, s.metaBlockLength);
    BitReader.copyBytes(s, ringBuffer, s.pos, chunkLength);
    s.metaBlockLength -= chunkLength;
    s.pos += chunkLength;
    if (s.pos == s.ringBufferSize) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter copyUncompressedData 4");
        s.nextRunningState = COPY_UNCOMPRESSED;
        s.runningState = INIT_WRITE;
        return;
        // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit copyUncompressedData 4");
      }

    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter copyUncompressedData 5");
    BitReader.reload(s);
    s.runningState = BLOCK_START;
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit copyUncompressedData 5");
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit copyUncompressedData 3");
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit copyUncompressedData 1");
  }

  private static int writeRingBuffer(State s) {
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter writeRingBuffer 1");
    int toWrite = Math.min(s.outputLength - s.outputUsed,
        s.ringBufferBytesReady - s.ringBufferBytesWritten);
    if (toWrite != 0) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter writeRingBuffer 2");
      System.arraycopy(s.ringBuffer, s.ringBufferBytesWritten, s.output,
          s.outputOffset + s.outputUsed, toWrite);
      s.outputUsed += toWrite;
      s.ringBufferBytesWritten += toWrite;
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit writeRingBuffer 2");
    }

    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter writeRingBuffer 3");
    if (s.outputUsed < s.outputLength) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter writeRingBuffer 4");
      return 1;
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit writeRingBuffer 4");
    } else {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter writeRingBuffer 5");
      return 0;
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit writeRingBuffer 5");
    }
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit writeRingBuffer 3");
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit writeRingBuffer 1");
  }

  private static int[] decodeHuffmanTreeGroup(int alphabetSize, int n, State s) {
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeHuffmanTreeGroup 1");
    int[] group = new int[n + (n * HUFFMAN_TABLE_SIZE)];
    int next = n;
    for (int i = 0; i < n; i++) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeHuffmanTreeGroup 2");
      group[i] = next;
      Decode.readHuffmanCode(alphabetSize, group, next, s);
      next += HUFFMAN_TABLE_SIZE;
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeHuffmanTreeGroup 2");
    }
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter decodeHuffmanTreeGroup 3");
    return group;
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeHuffmanTreeGroup 3");
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit decodeHuffmanTreeGroup 1");
  }

  // Returns offset in ringBuffer that should trigger WRITE when filled.
  private static int calculateFence(State s) {
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter calculateFence 1");
    int result = s.ringBufferSize;
    if (s.isEager != 0) {
      System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter calculateFence 2");
      result = Math.min(result, s.ringBufferBytesWritten + s.outputLength - s.outputUsed);
      // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit calculateFence 2");
    }
    System.err.println("[brotli/java/org/brotli/dec/Decode.java] enter calculateFence 3");
    return result;
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit calculateFence 3");
    // System.err.println("[brotli/java/org/brotli/dec/Decode.java] exit calculateFence 1");
  }
  /**
   * Actual decompress implementation.
   */
  static void decompress(State s) {
    System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 1\n");
    if (s.runningState == UNINITIALIZED) {
      System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 2\n");
      throw new IllegalStateException("Can't decompress until initialized");
      // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 2\n");
    }
    if (s.runningState == CLOSED) {
      System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 3\n");
      throw new IllegalStateException("Can't decompress after close");
      // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 3\n");
    }
    int fence = calculateFence(s);
    int ringBufferMask = s.ringBufferSize - 1;
    byte[] ringBuffer = s.ringBuffer;

    while (s.runningState != FINISHED) {
      System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 4\n");
      // TODO: extract cases to methods for the better readability.
      switch (s.runningState) {
        case BLOCK_START:
          System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 5\n");
          if (s.metaBlockLength < 0) {
            System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 6\n");
            throw new BrotliRuntimeException("Invalid metablock length");
            // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 6\n");
          }
          readNextMetablockHeader(s);
          /* Ring-buffer would be reallocated here. */
          fence = calculateFence(s);
          ringBufferMask = s.ringBufferSize - 1;
          ringBuffer = s.ringBuffer;
          continue;
          // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 5\n");

        case COMPRESSED_BLOCK_START:
          System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 7\n");
          readMetablockHuffmanCodesAndContextMaps(s);
          s.runningState = MAIN_LOOP;
          // Fall through
          // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 7\n");

        case MAIN_LOOP:
          System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 8\n");
          if (s.metaBlockLength <= 0) {
            System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 9\n");
            s.runningState = BLOCK_START;
            continue;
            // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 9\n");
          }
          BitReader.readMoreInput(s);
          if (s.commandBlockLength == 0) {
            System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 10\n");
            decodeCommandBlockSwitch(s);
            // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 10\n");
          }
          s.commandBlockLength--;
          BitReader.fillBitWindow(s);
          int cmdCode = readSymbol(s.hGroup1, s.treeCommandOffset, s);
          int rangeIdx = cmdCode >>> 6;
          s.distanceCode = 0;
          if (rangeIdx >= 2) {
            System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 11\n");
            rangeIdx -= 2;
            s.distanceCode = -1;
            // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 11\n");
          }
          int insertCode = INSERT_RANGE_LUT[rangeIdx] + ((cmdCode >>> 3) & 7);
          BitReader.fillBitWindow(s);
          int insertBits = INSERT_LENGTH_N_BITS[insertCode];
          int insertExtra = BitReader.readBits(s, insertBits);
          s.insertLength = INSERT_LENGTH_OFFSET[insertCode] + insertExtra;
          int copyCode = COPY_RANGE_LUT[rangeIdx] + (cmdCode & 7);
          BitReader.fillBitWindow(s);
          int copyBits = COPY_LENGTH_N_BITS[copyCode];
          int copyExtra = BitReader.readBits(s, copyBits);
          s.copyLength = COPY_LENGTH_OFFSET[copyCode] + copyExtra;

          s.j = 0;
          s.runningState = INSERT_LOOP;

          // Fall through
          // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 8\n");

        case INSERT_LOOP:
          System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 12\n");
          if (s.trivialLiteralContext != 0) {
            System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 13\n");
            while (s.j < s.insertLength) {
              System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 14\n");
              BitReader.readMoreInput(s);
              if (s.literalBlockLength == 0) {
                System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 15\n");
                decodeLiteralBlockSwitch(s);
                // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 15\n");
              }
              s.literalBlockLength--;
              BitReader.fillBitWindow(s);
              ringBuffer[s.pos] =
                  (byte) readSymbol(s.hGroup0, s.literalTree, s);
              s.pos++;
              s.j++;
              if (s.pos >= fence) {
                System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 16\n");
                s.nextRunningState = INSERT_LOOP;
                s.runningState = INIT_WRITE;
                break;
                // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 16\n");
              }
              // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 14\n");
            }
            // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 13\n");
          } else {
            System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 17\n");
            int prevByte1 = ringBuffer[(s.pos - 1) & ringBufferMask] & 0xFF;
            int prevByte2 = ringBuffer[(s.pos - 2) & ringBufferMask] & 0xFF;
            while (s.j < s.insertLength) {
              System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 18\n");
              BitReader.readMoreInput(s);
              if (s.literalBlockLength == 0) {
                System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 19\n");
                decodeLiteralBlockSwitch(s);
                // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 19\n");
              }
              int literalTreeIndex = s.contextMap[s.contextMapSlice
                + (Context.LOOKUP[s.contextLookupOffset1 + prevByte1]
                    | Context.LOOKUP[s.contextLookupOffset2 + prevByte2])] & 0xFF;
              s.literalBlockLength--;
              prevByte2 = prevByte1;
              BitReader.fillBitWindow(s);
              prevByte1 = readSymbol(
                  s.hGroup0, s.hGroup0[literalTreeIndex], s);
              ringBuffer[s.pos] = (byte) prevByte1;
              s.pos++;
              s.j++;
              if (s.pos >= fence) {
                System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 20\n");
                s.nextRunningState = INSERT_LOOP;
                s.runningState = INIT_WRITE;
                break;
                // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 20\n");
              }
              // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 18\n");
            }
            // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 17\n");
          }
          if (s.runningState != INSERT_LOOP) {
            System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 21\n");
            continue;
            // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 21\n");
          }
          s.metaBlockLength -= s.insertLength;
          if (s.metaBlockLength <= 0) {
            System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 22\n");
            s.runningState = MAIN_LOOP;
            continue;
            // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 22\n");
          }
          if (s.distanceCode < 0) {
            System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 23\n");
            BitReader.readMoreInput(s);
            if (s.distanceBlockLength == 0) {
              System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 24\n");
              decodeDistanceBlockSwitch(s);
              // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 24\n");
            }
            s.distanceBlockLength--;
            BitReader.fillBitWindow(s);
            s.distanceCode = readSymbol(s.hGroup2, s.hGroup2[
                s.distContextMap[s.distContextMapSlice
                    + (s.copyLength > 4 ? 3 : s.copyLength - 2)] & 0xFF], s);
            if (s.distanceCode >= s.numDirectDistanceCodes) {
              System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 25\n");
              s.distanceCode -= s.numDirectDistanceCodes;
              int postfix = s.distanceCode & s.distancePostfixMask;
              s.distanceCode >>>= s.distancePostfixBits;
              int n = (s.distanceCode >>> 1) + 1;
              int offset = ((2 + (s.distanceCode & 1)) << n) - 4;
              BitReader.fillBitWindow(s);
              int distanceExtra = BitReader.readBits(s, n);
              s.distanceCode = s.numDirectDistanceCodes + postfix
                  + ((offset + distanceExtra) << s.distancePostfixBits);
              // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 25\n");
            }
            // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 23\n");
          }

          // Convert the distance code to the actual distance by possibly looking up past distances
          // from the ringBuffer.
          s.distance = translateShortCodes(s.distanceCode, s.rings, s.distRbIdx);
          if (s.distance < 0) {
            System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 26\n");
            throw new BrotliRuntimeException("Negative distance"); // COV_NF_LINE
            // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 26\n");
          }

          if (s.maxDistance != s.maxBackwardDistance
              && s.pos < s.maxBackwardDistance) {
            System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 27\n");
            s.maxDistance = s.pos;
            // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 27\n");
          } else {
            System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 28\n");
            s.maxDistance = s.maxBackwardDistance;
            // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 28\n");
          }

          if (s.distance > s.maxDistance) {
            System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 29\n");
            s.runningState = TRANSFORM;
            continue;
            // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 29\n");
          }

          if (s.distanceCode > 0) {
            System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 30\n");
            s.rings[s.distRbIdx & 3] = s.distance;
            s.distRbIdx++;
            // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 30\n");
          }

          if (s.copyLength > s.metaBlockLength) {
            System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 31\n");
            throw new BrotliRuntimeException("Invalid backward reference"); // COV_NF_LINE
            // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 31\n");
          }
          s.j = 0;
          s.runningState = COPY_LOOP;
          // fall through
          // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 12\n");

        case COPY_LOOP:
          System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 32\n");
          int src = (s.pos - s.distance) & ringBufferMask;
          int dst = s.pos;
          int copyLength = s.copyLength - s.j;
          int srcEnd = src + copyLength;
          int dstEnd = dst + copyLength;
          if ((srcEnd < ringBufferMask) && (dstEnd < ringBufferMask)) {
            System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 33\n");
            if (copyLength < 12 || (srcEnd > dst && dstEnd > src)) {
              System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 34\n");
              for (int k = 0; k < copyLength; ++k) {
                System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 35\n");
                ringBuffer[dst++] = ringBuffer[src++];
                // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 35\n");
              }
              // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 34\n");
            } else {
              System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 36\n");
              Utils.copyBytesWithin(ringBuffer, dst, src, srcEnd);
              // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 36\n");
            }
            s.j += copyLength;
            s.metaBlockLength -= copyLength;
            s.pos += copyLength;
            // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 33\n");
          } else {
            System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 37\n");
            for (; s.j < s.copyLength;) {
              System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 38\n");
              ringBuffer[s.pos] =
                  ringBuffer[(s.pos - s.distance) & ringBufferMask];
              s.metaBlockLength--;
              s.pos++;
              s.j++;
              if (s.pos >= fence) {
                System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 39\n");
                s.nextRunningState = COPY_LOOP;
                s.runningState = INIT_WRITE;
                break;
                // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 39\n");
              }
              // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 38\n");
            }
            // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 37\n");
          }
          if (s.runningState == COPY_LOOP) {
            System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 40\n");
            s.runningState = MAIN_LOOP;
            // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 40\n");
          }
          continue;
          // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 32\n");

        case TRANSFORM:
          System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 41\n");
          if (s.copyLength >= MIN_WORD_LENGTH
              && s.copyLength <= MAX_WORD_LENGTH) {
            System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 42\n");
            int offset = DICTIONARY_OFFSETS_BY_LENGTH[s.copyLength];
            int wordId = s.distance - s.maxDistance - 1;
            int shift = DICTIONARY_SIZE_BITS_BY_LENGTH[s.copyLength];
            int mask = (1 << shift) - 1;
            int wordIdx = wordId & mask;
            int transformIdx = wordId >>> shift;
            offset += wordIdx * s.copyLength;
            if (transformIdx < Transform.NUM_TRANSFORMS) {
              System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 43\n");
              int len = Transform.transformDictionaryWord(ringBuffer, s.pos,
                  Dictionary.getData(), offset, s.copyLength, transformIdx);
              s.pos += len;
              s.metaBlockLength -= len;
              if (s.pos >= fence) {
                System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 44\n");
                s.nextRunningState = MAIN_LOOP;
                s.runningState = INIT_WRITE;
                continue;
                // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 44\n");
              }
              // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 43\n");
            } else {
              System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 45\n");
              throw new BrotliRuntimeException("Invalid backward reference"); // COV_NF_LINE
              // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 45\n");
            }
            // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 42\n");
          } else {
            System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 46\n");
            throw new BrotliRuntimeException("Invalid backward reference"); // COV_NF_LINE
            // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 46\n");
          }
          s.runningState = MAIN_LOOP;
          continue;
          // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 41\n");

        case READ_METADATA:
          System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 47\n");
          while (s.metaBlockLength > 0) {
            System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 48\n");
            BitReader.readMoreInput(s);
            // Optimize
            BitReader.fillBitWindow(s);
            BitReader.readFewBits(s, 8);
            s.metaBlockLength--;
            // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 48\n");
          }
          s.runningState = BLOCK_START;
          continue;
          // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 47\n");


        case COPY_UNCOMPRESSED:
          System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 49\n");
          copyUncompressedData(s);
          continue;
          // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 49\n");

        case INIT_WRITE:
          System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 50\n");
          s.ringBufferBytesReady = Math.min(s.pos, s.ringBufferSize);
          s.runningState = WRITE;
          // fall through
          // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 50\n");

        case WRITE:
          System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 51\n");
          if (writeRingBuffer(s) == 0) {
            System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 52\n");
            // Output buffer is full.
            return;
            // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 52\n");
          }
          if (s.pos >= s.maxBackwardDistance) {
            System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 53\n");
            s.maxDistance = s.maxBackwardDistance;
            // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 53\n");
          }
          // Wrap the ringBuffer.
          if (s.pos >= s.ringBufferSize) {
            System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 54\n");
            if (s.pos > s.ringBufferSize) {
              System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 55\n");
              Utils.copyBytesWithin(ringBuffer, 0, s.ringBufferSize, s.pos);
              // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 55\n");
            }
            s.pos &= ringBufferMask;
            s.ringBufferBytesWritten = 0;
            // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 54\n");
          }
          s.runningState = s.nextRunningState;
          continue;
          // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 51\n");

        default:
          System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 56\n");
          throw new BrotliRuntimeException("Unexpected state " + s.runningState);
          // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 56\n");
      }
      // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 4\n");
    }
    if (s.runningState == FINISHED) {
      System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 57\n");
      if (s.metaBlockLength < 0) {
        System.err.write("[brotli/java/org/brotli/dec/Decode.java] enter decompress 58\n");
        throw new BrotliRuntimeException("Invalid metablock length");
        // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 58\n");
      }
      BitReader.jumpToByteBoundary(s);
      BitReader.checkHealth(s, 1);
      // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 57\n");
    }
    // System.err.write("[brotli/java/org/brotli/dec/Decode.java] exit decompress 1\n");
  }
}
// Total cost: 0.727577
// Total split cost: 0.068791, input tokens: 13898, output tokens: 677, cache read tokens: 13889, cache write tokens: 14518, split chunks: [(0, 719), (719, 1008)]
// Total instrumented cost: 0.658786, input tokens: 16383, output tokens: 36507, cache read tokens: 16371, cache write tokens: 28329
