/* Copyright 2017 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

package org.brotli.wrapper.dec;

import java.io.IOException;
import java.io.InputStream;
import java.nio.channels.Channels;

/**
 * InputStream that wraps native brotli decoder.
 */
public class BrotliInputStream extends InputStream {
  /** The default internal buffer size used by the decoder. */
  private static final int DEFAULT_BUFFER_SIZE = 16384;

  private final Decoder decoder;

  /**
   * Creates a BrotliInputStream.
   *
   * @param source underlying source
   * @param bufferSize intermediate buffer size
   */
  public BrotliInputStream(InputStream source, int bufferSize)
      throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] enter BrotliInputStream 1");
    this.decoder = new Decoder(Channels.newChannel(source), bufferSize);
    // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] exit BrotliInputStream 1");
  }

  public BrotliInputStream(InputStream source) throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] enter BrotliInputStream 2");
    this(source, DEFAULT_BUFFER_SIZE);
    // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] exit BrotliInputStream 2");
  }

  public void setEager(boolean eager) {
    System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] enter setEager 1");
    decoder.setEager(eager);
    // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] exit setEager 1");
  }

  @Override
  public void close() throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] enter close 1");
    decoder.close();
    // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] exit close 1");
  }

  @Override
  public int available() {
    System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] enter available 1");
    return (decoder.buffer != null) ? decoder.buffer.remaining() : 0;
    // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] exit available 1");
  }

  @Override
  public int read() throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] enter read 1");
    if (decoder.closed) {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] enter read 2");
      throw new IOException("read after close");
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] exit read 2");
    }
    // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] exit read 1");
    
    System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] enter read 3");
    if (decoder.decode() == -1) {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] enter read 4");
      return -1;
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] exit read 4");
    }
    // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] exit read 3");
    
    System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] enter read 5");
    return decoder.buffer.get() & 0xFF;
    // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] exit read 5");
  }

  @Override
  public int read(byte[] b) throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] enter read_array 1");
    return read(b, 0, b.length);
    // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] exit read_array 1");
  }

  @Override
  public int read(byte[] b, int off, int len) throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] enter read_array_offset 1");
    if (decoder.closed) {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] enter read_array_offset 2");
      throw new IOException("read after close");
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] exit read_array_offset 2");
    }
    // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] exit read_array_offset 1");
    
    System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] enter read_array_offset 3");
    if (decoder.decode() == -1) {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] enter read_array_offset 4");
      return -1;
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] exit read_array_offset 4");
    }
    // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] exit read_array_offset 3");
    
    System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] enter read_array_offset 5");
    int result = 0;
    // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] exit read_array_offset 5");
    
    while (len > 0) {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] enter read_array_offset 6");
      int limit = Math.min(len, decoder.buffer.remaining());
      decoder.buffer.get(b, off, limit);
      off += limit;
      len -= limit;
      result += limit;
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] exit read_array_offset 6");
      
      System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] enter read_array_offset 7");
      if (decoder.decode() == -1) {
        System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] enter read_array_offset 8");
        break;
        // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] exit read_array_offset 8");
      }
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] exit read_array_offset 7");
    }
    
    System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] enter read_array_offset 9");
    return result;
    // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] exit read_array_offset 9");
  }

  @Override
  public long skip(long n) throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] enter skip 1");
    if (decoder.closed) {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] enter skip 2");
      throw new IOException("read after close");
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] exit skip 2");
    }
    // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] exit skip 1");
    
    System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] enter skip 3");
    long result = 0;
    // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] exit skip 3");
    
    while (n > 0) {
      System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] enter skip 4");
      if (decoder.decode() == -1) {
        System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] enter skip 5");
        break;
        // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] exit skip 5");
      }
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] exit skip 4");
      
      System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] enter skip 6");
      int limit = (int) Math.min(n, (long) decoder.buffer.remaining());
      decoder.discard(limit);
      result += limit;
      n -= limit;
      // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] exit skip 6");
    }
    
    System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] enter skip 7");
    return result;
    // System.err.println("[brotli/java/org/brotli/wrapper/dec/BrotliInputStream.java] exit skip 7");
  }
}
// Total cost: 0.060275
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 106)]
// Total instrumented cost: 0.060275, input tokens: 5646, output tokens: 3300, cache read tokens: 5638, cache write tokens: 2416
