/* Copyright 2015 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

package org.brotli.dec;

import java.io.IOException;
import java.io.InputStream;

/**
 * {@link InputStream} decorator that decompresses brotli data.
 *
 * <p> Not thread-safe.
 */
public class BrotliInputStream extends InputStream {

  public static final int DEFAULT_INTERNAL_BUFFER_SIZE = 256;

  /**
   * Internal buffer used for efficient byte-by-byte reading.
   */
  private byte[] buffer;

  /**
   * Number of decoded but still unused bytes in internal buffer.
   */
  private int remainingBufferBytes;

  /**
   * Next unused byte offset.
   */
  private int bufferOffset;

  /**
   * Decoder state.
   */
  private final State state = new State();

  /**
   * Creates a {@link InputStream} wrapper that decompresses brotli data.
   *
   * <p> For byte-by-byte reading ({@link #read()}) internal buffer with
   * {@link #DEFAULT_INTERNAL_BUFFER_SIZE} size is allocated and used.
   *
   * <p> Will block the thread until first {@link BitReader#CAPACITY} bytes of data of source
   * are available.
   *
   * @param source underlying data source
   * @throws IOException in case of corrupted data or source stream problems
   */
  public BrotliInputStream(InputStream source) throws IOException {
    System.err.println("[brotli/java/org/brotli/dec/BrotliInputStream.java] enter BrotliInputStream 1");
    this(source, DEFAULT_INTERNAL_BUFFER_SIZE);
    // System.err.println("[brotli/java/org/brotli/dec/BrotliInputStream.java] exit BrotliInputStream 1");
  }

  /**
   * Creates a {@link InputStream} wrapper that decompresses brotli data.
   *
   * <p> For byte-by-byte reading ({@link #read()}) internal buffer of specified size is
   * allocated and used.
   *
   * <p> Will block the thread until first {@link BitReader#CAPACITY} bytes of data of source
   * are available.
   *
   * @param source compressed data source
   * @param byteReadBufferSize size of internal buffer used in case of
   *        byte-by-byte reading
   * @throws IOException in case of corrupted data or source stream problems
   */
  public BrotliInputStream(InputStream source, int byteReadBufferSize) throws IOException {
    System.err.println("[brotli/java/org/brotli/dec/BrotliInputStream.java] enter BrotliInputStream 2");
    if (byteReadBufferSize <= 0) {
      System.err.println("[brotli/java/org/brotli/dec/BrotliInputStream.java] enter BrotliInputStream 3");
      throw new IllegalArgumentException("Bad buffer size:" + byteReadBufferSize);
      // System.err.println("[brotli/java/org/brotli/dec/BrotliInputStream.java] exit BrotliInputStream 3");
    } else if (source == null) {
      System.err.println("[brotli/java/org/brotli/dec/BrotliInputStream.java] enter BrotliInputStream 4");
      throw new IllegalArgumentException("source is null");
      // System.err.println("[brotli/java/org/brotli/dec/BrotliInputStream.java] exit BrotliInputStream 4");
    }
    this.buffer = new byte[byteReadBufferSize];
    this.remainingBufferBytes = 0;
    this.bufferOffset = 0;
    try {
      System.err.println("[brotli/java/org/brotli/dec/BrotliInputStream.java] enter BrotliInputStream 5");
      Decode.initState(state, source);
      // System.err.println("[brotli/java/org/brotli/dec/BrotliInputStream.java] exit BrotliInputStream 5");
    } catch (BrotliRuntimeException ex) {
      System.err.println("[brotli/java/org/brotli/dec/BrotliInputStream.java] enter BrotliInputStream 6");
      throw new IOException("Brotli decoder initialization failed", ex);
      // System.err.println("[brotli/java/org/brotli/dec/BrotliInputStream.java] exit BrotliInputStream 6");
    }
    // System.err.println("[brotli/java/org/brotli/dec/BrotliInputStream.java] exit BrotliInputStream 2");
  }

  public void setEager(boolean eager) {
    System.err.println("[brotli/java/org/brotli/dec/BrotliInputStream.java] enter setEager 1");
    state.isEager = eager ? 1 : 0;
    // System.err.println("[brotli/java/org/brotli/dec/BrotliInputStream.java] exit setEager 1");
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public void close() throws IOException {
    System.err.println("[brotli/java/org/brotli/dec/BrotliInputStream.java] enter close 1");
    Decode.close(state);
    // System.err.println("[brotli/java/org/brotli/dec/BrotliInputStream.java] exit close 1");
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public int read() throws IOException {
    System.err.println("[brotli/java/org/brotli/dec/BrotliInputStream.java] enter read 1");
    if (bufferOffset >= remainingBufferBytes) {
      System.err.println("[brotli/java/org/brotli/dec/BrotliInputStream.java] enter read 2");
      remainingBufferBytes = read(buffer, 0, buffer.length);
      bufferOffset = 0;
      if (remainingBufferBytes == -1) {
        System.err.println("[brotli/java/org/brotli/dec/BrotliInputStream.java] enter read 3");
        return -1;
        // System.err.println("[brotli/java/org/brotli/dec/BrotliInputStream.java] exit read 3");
      }
      // System.err.println("[brotli/java/org/brotli/dec/BrotliInputStream.java] exit read 2");
    }
    return buffer[bufferOffset++] & 0xFF;
    // System.err.println("[brotli/java/org/brotli/dec/BrotliInputStream.java] exit read 1");
  }

  /**
   * {@inheritDoc}
   */
  @Override
  public int read(byte[] destBuffer, int destOffset, int destLen) throws IOException {
    System.err.println("");
    if (destOffset < 0) {
      System.err.println("[brotli/java/org/brotli/dec/BrotliInputStream.java] enter read 5");
      throw new IllegalArgumentException("Bad offset: " + destOffset);
      // System.err.println("[brotli/java/org/brotli/dec/BrotliInputStream.java] exit read 5");
    } else if (destLen < 0) {
      System.err.println("[brotli/java/org/brotli/dec/BrotliInputStream.java] enter read 6");
      throw new IllegalArgumentException("Bad length: " + destLen);
      // System.err.println("[brotli/java/org/brotli/dec/BrotliInputStream.java] exit read 6");
    } else if (destOffset + destLen > destBuffer.length) {
      System.err.println("[brotli/java/org/brotli/dec/BrotliInputStream.java] enter read 7");
      throw new IllegalArgumentException(
          "Buffer overflow: " + (destOffset + destLen) + " > " + destBuffer.length);
      // System.err.println("[brotli/java/org/brotli/dec/BrotliInputStream.java] exit read 7");
    } else if (destLen == 0) {
      System.err.println("[brotli/java/org/brotli/dec/BrotliInputStream.java] enter read 8");
      return 0;
      // System.err.println("[brotli/java/org/brotli/dec/BrotliInputStream.java] exit read 8");
    }
    int copyLen = Math.max(remainingBufferBytes - bufferOffset, 0);
    if (copyLen != 0) {
      System.err.println("[brotli/java/org/brotli/dec/BrotliInputStream.java] enter read 9");
      copyLen = Math.min(copyLen, destLen);
      System.arraycopy(buffer, bufferOffset, destBuffer, destOffset, copyLen);
      bufferOffset += copyLen;
      destOffset += copyLen;
      destLen -= copyLen;
      if (destLen == 0) {
        System.err.println("[brotli/java/org/brotli/dec/BrotliInputStream.java] enter read 10");
        return copyLen;
        // System.err.println("[brotli/java/org/brotli/dec/BrotliInputStream.java] exit read 10");
      }
      // System.err.println("[brotli/java/org/brotli/dec/BrotliInputStream.java] exit read 9");
    }
    try {
      System.err.println("[brotli/java/org/brotli/dec/BrotliInputStream.java] enter read 11");
      state.output = destBuffer;
      state.outputOffset = destOffset;
      state.outputLength = destLen;
      state.outputUsed = 0;
      Decode.decompress(state);
      if (state.outputUsed == 0) {
        System.err.println("[brotli/java/org/brotli/dec/BrotliInputStream.java] enter read 12");
        return -1;
        // System.err.println("[brotli/java/org/brotli/dec/BrotliInputStream.java] exit read 12");
      }
      return state.outputUsed + copyLen;
      // System.err.println("[brotli/java/org/brotli/dec/BrotliInputStream.java] exit read 11");
    } catch (BrotliRuntimeException ex) {
      System.err.println("[brotli/java/org/brotli/dec/BrotliInputStream.java] enter read 13");
      throw new IOException("Brotli stream decoding failed", ex);
      // System.err.println("[brotli/java/org/brotli/dec/BrotliInputStream.java] exit read 13");
    }

    // <{[INJECTED CODE]}>
  }
}
// Total cost: 0.035598
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 156)]
// Total instrumented cost: 0.035598, input tokens: 2398, output tokens: 1964, cache read tokens: 2394, cache write tokens: 1442
