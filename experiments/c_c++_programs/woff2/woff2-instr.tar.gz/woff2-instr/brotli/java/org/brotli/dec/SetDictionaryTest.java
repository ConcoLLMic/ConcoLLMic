/* Copyright 2016 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

package org.brotli.dec;

import static org.junit.Assert.assertEquals;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

/**
 * Tests for {@link Dictionary}.
 */
@RunWith(JUnit4.class)
public class SetDictionaryTest {

  /** See {@link SynthTest} */
  private static final byte[] BASE_DICT_WORD = {
      (byte) 0x1b, (byte) 0x03, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x80,
      (byte) 0xe3, (byte) 0xb4, (byte) 0x0d, (byte) 0x00, (byte) 0x00, (byte) 0x07, (byte) 0x5b,
      (byte) 0x26, (byte) 0x31, (byte) 0x40, (byte) 0x02, (byte) 0x00, (byte) 0xe0, (byte) 0x4e,
      (byte) 0x1b, (byte) 0x41, (byte) 0x02
    };

  /** See {@link SynthTest} */
  private static final byte[] ONE_COMMAND = {
      (byte) 0x1b, (byte) 0x02, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x80,
      (byte) 0xe3, (byte) 0xb4, (byte) 0x0d, (byte) 0x00, (byte) 0x00, (byte) 0x07, (byte) 0x5b,
      (byte) 0x26, (byte) 0x31, (byte) 0x40, (byte) 0x02, (byte) 0x00, (byte) 0xe0, (byte) 0x4e,
      (byte) 0x1b, (byte) 0x11, (byte) 0x86, (byte) 0x02
    };

  @Test
  public void testSetDictionary() throws IOException {
    System.err.println("[brotli/java/org/brotli/dec/SetDictionaryTest.java] enter testSetDictionary 1");
    byte[] buffer = new byte[16];
    BrotliInputStream decoder;
    // System.err.println("[brotli/java/org/brotli/dec/SetDictionaryTest.java] exit testSetDictionary 1");

    // No dictionary set; still decoding should succeed, if no dictionary entries are used.
    System.err.println("[brotli/java/org/brotli/dec/SetDictionaryTest.java] enter testSetDictionary 2");
    decoder = new BrotliInputStream(new ByteArrayInputStream(ONE_COMMAND));
    assertEquals(3, decoder.read(buffer, 0, buffer.length));
    assertEquals("aaa", new String(buffer, 0, 3, "US-ASCII"));
    decoder.close();
    // System.err.println("[brotli/java/org/brotli/dec/SetDictionaryTest.java] exit testSetDictionary 2");

    // Decoding of dictionary item must fail.
    System.err.println("[brotli/java/org/brotli/dec/SetDictionaryTest.java] enter testSetDictionary 3");
    decoder = new BrotliInputStream(new ByteArrayInputStream(BASE_DICT_WORD));
    boolean decodingFailed = false;
    // System.err.println("[brotli/java/org/brotli/dec/SetDictionaryTest.java] exit testSetDictionary 3");
    
    try {
      System.err.println("[brotli/java/org/brotli/dec/SetDictionaryTest.java] enter testSetDictionary 4");
      decoder.read(buffer, 0, buffer.length);
      // System.err.println("[brotli/java/org/brotli/dec/SetDictionaryTest.java] exit testSetDictionary 4");
    } catch (IOException ex) {
      System.err.println("[brotli/java/org/brotli/dec/SetDictionaryTest.java] enter testSetDictionary 5");
      decodingFailed = true;
      // System.err.println("[brotli/java/org/brotli/dec/SetDictionaryTest.java] exit testSetDictionary 5");
    }
    
    System.err.println("[brotli/java/org/brotli/dec/SetDictionaryTest.java] enter testSetDictionary 6");
    assertEquals(true, decodingFailed);
    decoder.close();
    // System.err.println("[brotli/java/org/brotli/dec/SetDictionaryTest.java] exit testSetDictionary 6");

    // Load dictionary data.
    System.err.println("[brotli/java/org/brotli/dec/SetDictionaryTest.java] enter testSetDictionary 7");
    FileChannel dictionaryChannel =
        new FileInputStream(System.getProperty("RFC_DICTIONARY")).getChannel();
    ByteBuffer dictionary = dictionaryChannel.map(FileChannel.MapMode.READ_ONLY, 0, 122784).load();
    Dictionary.setData(dictionary);
    // System.err.println("[brotli/java/org/brotli/dec/SetDictionaryTest.java] exit testSetDictionary 7");

    // Retry decoding of dictionary item.
    System.err.println("[brotli/java/org/brotli/dec/SetDictionaryTest.java] enter testSetDictionary 8");
    decoder = new BrotliInputStream(new ByteArrayInputStream(BASE_DICT_WORD));
    assertEquals(4, decoder.read(buffer, 0, buffer.length));
    assertEquals("time", new String(buffer, 0, 4, "US-ASCII"));
    decoder.close();
    // System.err.println("[brotli/java/org/brotli/dec/SetDictionaryTest.java] exit testSetDictionary 8");
  }
}
// Total cost: 0.025323
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 76)]
// Total instrumented cost: 0.025323, input tokens: 2398, output tokens: 1354, cache read tokens: 2394, cache write tokens: 1142
