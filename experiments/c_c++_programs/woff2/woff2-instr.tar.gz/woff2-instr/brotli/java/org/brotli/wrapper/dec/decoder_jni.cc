/* Copyright 2017 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

#include <jni.h>

#include <new>

#include <brotli/decode.h>
#include <stdio.h>

namespace {
/* A structure used to persist the decoder's state in between calls. */
typedef struct DecoderHandle {
  BrotliDecoderState* state;

  uint8_t* input_start;
  size_t input_offset;
  size_t input_length;
} DecoderHandle;

/* Obtain handle from opaque pointer. */
DecoderHandle* getHandle(void* opaque) {
  fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] enter getHandle 1\n");
  return static_cast<DecoderHandle*>(opaque);
  // fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] exit getHandle 1\n");
}

}  /* namespace */

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Creates a new Decoder.
 *
 * Cookie to address created decoder is stored in out_cookie. In case of failure
 * cookie is 0.
 *
 * @param ctx {out_cookie, in_directBufferSize} tuple
 * @returns direct ByteBuffer if directBufferSize is not 0; otherwise null
 */
JNIEXPORT jobject JNICALL
Java_org_brotli_wrapper_dec_DecoderJNI_nativeCreate(
    JNIEnv* env, jobject /*jobj*/, jlongArray ctx) {
  fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] enter Java_org_brotli_wrapper_dec_DecoderJNI_nativeCreate 1\n");
  bool ok = true;
  DecoderHandle* handle = nullptr;
  jlong context[3];
  env->GetLongArrayRegion(ctx, 0, 3, context);
  size_t input_size = context[1];
  context[0] = 0;
  context[2] = 0;
  handle = new (std::nothrow) DecoderHandle();
  ok = !!handle;
  // fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] exit Java_org_brotli_wrapper_dec_DecoderJNI_nativeCreate 1\n");

  if (ok) {
    fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] enter Java_org_brotli_wrapper_dec_DecoderJNI_nativeCreate 2\n");
    handle->input_offset = 0;
    handle->input_length = 0;
    handle->input_start = nullptr;
    // fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] exit Java_org_brotli_wrapper_dec_DecoderJNI_nativeCreate 2\n");

    if (input_size == 0) {
      fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] enter Java_org_brotli_wrapper_dec_DecoderJNI_nativeCreate 3\n");
      ok = false;
      // fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] exit Java_org_brotli_wrapper_dec_DecoderJNI_nativeCreate 3\n");
    } else {
      fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] enter Java_org_brotli_wrapper_dec_DecoderJNI_nativeCreate 4\n");
      handle->input_start = new (std::nothrow) uint8_t[input_size];
      ok = !!handle->input_start;
      // fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] exit Java_org_brotli_wrapper_dec_DecoderJNI_nativeCreate 4\n");
    }
  }

  if (ok) {
    fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] enter Java_org_brotli_wrapper_dec_DecoderJNI_nativeCreate 5\n");
    handle->state = BrotliDecoderCreateInstance(nullptr, nullptr, nullptr);
    ok = !!handle->state;
    // fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] exit Java_org_brotli_wrapper_dec_DecoderJNI_nativeCreate 5\n");
  }

  if (ok) {
    fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] enter Java_org_brotli_wrapper_dec_DecoderJNI_nativeCreate 6\n");
    /* TODO: future versions (e.g. when 128-bit architecture comes)
                     might require thread-safe cookie<->handle mapping. */
    context[0] = reinterpret_cast<jlong>(handle);
    // fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] exit Java_org_brotli_wrapper_dec_DecoderJNI_nativeCreate 6\n");
  } else if (!!handle) {
    fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] enter Java_org_brotli_wrapper_dec_DecoderJNI_nativeCreate 7\n");
    if (!!handle->input_start) delete[] handle->input_start;
    delete handle;
    // fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] exit Java_org_brotli_wrapper_dec_DecoderJNI_nativeCreate 7\n");
  }

  fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] enter Java_org_brotli_wrapper_dec_DecoderJNI_nativeCreate 8\n");
  env->SetLongArrayRegion(ctx, 0, 3, context);
  // fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] exit Java_org_brotli_wrapper_dec_DecoderJNI_nativeCreate 8\n");

  if (!ok) {
    fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] enter Java_org_brotli_wrapper_dec_DecoderJNI_nativeCreate 9\n");
    return nullptr;
    // fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] exit Java_org_brotli_wrapper_dec_DecoderJNI_nativeCreate 9\n");
  }

  fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] enter Java_org_brotli_wrapper_dec_DecoderJNI_nativeCreate 10\n");
  return env->NewDirectByteBuffer(handle->input_start, input_size);
  // fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] exit Java_org_brotli_wrapper_dec_DecoderJNI_nativeCreate 10\n");
}

/**
 * Push data to decoder.
 *
 * status codes:
 *  - 0 error happened
 *  - 1 stream is finished, no more input / output expected
 *  - 2 needs more input to process further
 *  - 3 needs more output to process further
 *  - 4 ok, can proceed further without additional input
 *
 * @param ctx {in_cookie, out_status} tuple
 * @param input_length number of bytes provided in input or direct input;
 *                     0 to process further previous input
 */
JNIEXPORT void JNICALL
Java_org_brotli_wrapper_dec_DecoderJNI_nativePush(
    JNIEnv* env, jobject /*jobj*/, jlongArray ctx, jint input_length) {
  fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] enter Java_org_brotli_wrapper_dec_DecoderJNI_nativePush 1\n");
  jlong context[3];
  env->GetLongArrayRegion(ctx, 0, 3, context);
  DecoderHandle* handle = getHandle(reinterpret_cast<void*>(context[0]));
  context[1] = 0;  /* ERROR */
  context[2] = 0;
  env->SetLongArrayRegion(ctx, 0, 3, context);
  // fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] exit Java_org_brotli_wrapper_dec_DecoderJNI_nativePush 1\n");

  if (input_length != 0) {
    fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] enter Java_org_brotli_wrapper_dec_DecoderJNI_nativePush 2\n");
    /* Still have unconsumed data. Workflow is broken. */
    if (handle->input_offset < handle->input_length) {
      fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] enter Java_org_brotli_wrapper_dec_DecoderJNI_nativePush 3\n");
      return;
      // fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] exit Java_org_brotli_wrapper_dec_DecoderJNI_nativePush 3\n");
    }
    handle->input_offset = 0;
    handle->input_length = input_length;
    // fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] exit Java_org_brotli_wrapper_dec_DecoderJNI_nativePush 2\n");
  }

  fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] enter Java_org_brotli_wrapper_dec_DecoderJNI_nativePush 4\n");
  /* Actual decompression. */
  const uint8_t* in = handle->input_start + handle->input_offset;
  size_t in_size = handle->input_length - handle->input_offset;
  size_t out_size = 0;
  BrotliDecoderResult status = BrotliDecoderDecompressStream(
      handle->state, &in_size, &in, &out_size, nullptr, nullptr);
  handle->input_offset = handle->input_length - in_size;
  // fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] exit Java_org_brotli_wrapper_dec_DecoderJNI_nativePush 4\n");
  
  switch (status) {
    case BROTLI_DECODER_RESULT_SUCCESS:
      fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] enter Java_org_brotli_wrapper_dec_DecoderJNI_nativePush 5\n");
      /* Bytes after stream end are not allowed. */
      context[1] = (handle->input_offset == handle->input_length) ? 1 : 0;
      break;
      // fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] exit Java_org_brotli_wrapper_dec_DecoderJNI_nativePush 5\n");

    case BROTLI_DECODER_RESULT_NEEDS_MORE_INPUT:
      fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] enter Java_org_brotli_wrapper_dec_DecoderJNI_nativePush 6\n");
      context[1] = 2;
      break;
      // fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] exit Java_org_brotli_wrapper_dec_DecoderJNI_nativePush 6\n");

    case BROTLI_DECODER_RESULT_NEEDS_MORE_OUTPUT:
      fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] enter Java_org_brotli_wrapper_dec_DecoderJNI_nativePush 7\n");
      context[1] = 3;
      break;
      // fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] exit Java_org_brotli_wrapper_dec_DecoderJNI_nativePush 7\n");

    default:
      fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] enter Java_org_brotli_wrapper_dec_DecoderJNI_nativePush 8\n");
      context[1] = 0;
      break;
      // fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] exit Java_org_brotli_wrapper_dec_DecoderJNI_nativePush 8\n");
  }
  
  fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] enter Java_org_brotli_wrapper_dec_DecoderJNI_nativePush 9\n");
  context[2] = BrotliDecoderHasMoreOutput(handle->state) ? 1 : 0;
  env->SetLongArrayRegion(ctx, 0, 3, context);
  // fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] exit Java_org_brotli_wrapper_dec_DecoderJNI_nativePush 9\n");
}

/**
 * Pull decompressed data from decoder.
 *
 * @param ctx {in_cookie, out_status} tuple
 * @returns direct ByteBuffer; all the produced data MUST be consumed before
 *          any further invocation; null in case of error
 */
JNIEXPORT jobject JNICALL
Java_org_brotli_wrapper_dec_DecoderJNI_nativePull(
    JNIEnv* env, jobject /*jobj*/, jlongArray ctx) {
  fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] enter Java_org_brotli_wrapper_dec_DecoderJNI_nativePull 1\n");
  jlong context[3];
  env->GetLongArrayRegion(ctx, 0, 3, context);
  DecoderHandle* handle = getHandle(reinterpret_cast<void*>(context[0]));
  size_t data_length = 0;
  const uint8_t* data = BrotliDecoderTakeOutput(handle->state, &data_length);
  bool hasMoreOutput = !!BrotliDecoderHasMoreOutput(handle->state);
  // fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] exit Java_org_brotli_wrapper_dec_DecoderJNI_nativePull 1\n");
  
  if (hasMoreOutput) {
    fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] enter Java_org_brotli_wrapper_dec_DecoderJNI_nativePull 2\n");
    context[1] = 3;
    // fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] exit Java_org_brotli_wrapper_dec_DecoderJNI_nativePull 2\n");
  } else if (BrotliDecoderIsFinished(handle->state)) {
    fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] enter Java_org_brotli_wrapper_dec_DecoderJNI_nativePull 3\n");
    /* Bytes after stream end are not allowed. */
    context[1] = (handle->input_offset == handle->input_length) ? 1 : 0;
    // fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] exit Java_org_brotli_wrapper_dec_DecoderJNI_nativePull 3\n");
  } else {
    fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] enter Java_org_brotli_wrapper_dec_DecoderJNI_nativePull 4\n");
    /* Can proceed, or more data is required? */
    context[1] = (handle->input_offset == handle->input_length) ? 2 : 4;
    // fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] exit Java_org_brotli_wrapper_dec_DecoderJNI_nativePull 4\n");
  }
  
  fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] enter Java_org_brotli_wrapper_dec_DecoderJNI_nativePull 5\n");
  context[2] = hasMoreOutput ? 1 : 0;
  env->SetLongArrayRegion(ctx, 0, 3, context);
  return env->NewDirectByteBuffer(const_cast<uint8_t*>(data), data_length);
  // fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] exit Java_org_brotli_wrapper_dec_DecoderJNI_nativePull 5\n");
}

/**
 * Releases all used resources.
 *
 * @param ctx {in_cookie} tuple
 */
JNIEXPORT void JNICALL
Java_org_brotli_wrapper_dec_DecoderJNI_nativeDestroy(
    JNIEnv* env, jobject /*jobj*/, jlongArray ctx) {
  fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] enter Java_org_brotli_wrapper_dec_DecoderJNI_nativeDestroy 1\n");
  jlong context[3];
  env->GetLongArrayRegion(ctx, 0, 3, context);
  DecoderHandle* handle = getHandle(reinterpret_cast<void*>(context[0]));
  BrotliDecoderDestroyInstance(handle->state);
  delete[] handle->input_start;
  delete handle;
  // fprintf(stderr, "[brotli/java/org/brotli/wrapper/dec/decoder_jni.cc] exit Java_org_brotli_wrapper_dec_DecoderJNI_nativeDestroy 1\n");
}

#ifdef __cplusplus
}
#endif
// Total cost: 0.069171
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 202)]
// Total instrumented cost: 0.069171, input tokens: 2398, output tokens: 4006, cache read tokens: 2394, cache write tokens: 2227
