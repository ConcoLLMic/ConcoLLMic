/* Copyright 2015 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

package org.brotli.dec;

import java.io.IOException;
import java.io.InputStream;

/**
 * A set of utility methods.
 */
final class Utils {

  private static final byte[] BYTE_ZEROES = new byte[1024];

  private static final int[] INT_ZEROES = new int[1024];

  /**
   * Fills byte array with zeroes.
   *
   * <p> Current implementation uses {@link System#arraycopy}, so it should be used for length not
   * less than 16.
   *
   * @param dest array to fill with zeroes
   * @param offset the first byte to fill
   * @param length number of bytes to change
   */
  static void fillBytesWithZeroes(byte[] dest, int start, int end) {
    System.err.println("[brotli/java/org/brotli/dec/Utils.java] enter fillBytesWithZeroes 1");
    int cursor = start;
    while (cursor < end) {
      System.err.println("[brotli/java/org/brotli/dec/Utils.java] enter fillBytesWithZeroes 2");
      int step = Math.min(cursor + 1024, end) - cursor;
      System.arraycopy(BYTE_ZEROES, 0, dest, cursor, step);
      cursor += step;
      // System.err.println("[brotli/java/org/brotli/dec/Utils.java] exit fillBytesWithZeroes 2");
    }
    // System.err.println("[brotli/java/org/brotli/dec/Utils.java] exit fillBytesWithZeroes 1");
  }

  /**
   * Fills int array with zeroes.
   *
   * <p> Current implementation uses {@link System#arraycopy}, so it should be used for length not
   * less than 16.
   *
   * @param dest array to fill with zeroes
   * @param offset the first item to fill
   * @param length number of item to change
   */
  static void fillIntsWithZeroes(int[] dest, int start, int end) {
    System.err.println("[brotli/java/org/brotli/dec/Utils.java] enter fillIntsWithZeroes 1");
    int cursor = start;
    while (cursor < end) {
      System.err.println("[brotli/java/org/brotli/dec/Utils.java] enter fillIntsWithZeroes 2");
      int step = Math.min(cursor + 1024, end) - cursor;
      System.arraycopy(INT_ZEROES, 0, dest, cursor, step);
      cursor += step;
      // System.err.println("[brotli/java/org/brotli/dec/Utils.java] exit fillIntsWithZeroes 2");
    }
    // System.err.println("[brotli/java/org/brotli/dec/Utils.java] exit fillIntsWithZeroes 1");
  }

  static void copyBytesWithin(byte[] bytes, int target, int start, int end) {
    System.err.println("[brotli/java/org/brotli/dec/Utils.java] enter copyBytesWithin 1");
    System.arraycopy(bytes, start, bytes, target, end - start);
    // System.err.println("[brotli/java/org/brotli/dec/Utils.java] exit copyBytesWithin 1");
  }

  static int readInput(InputStream src, byte[] dst, int offset, int length) {
    System.err.println("[brotli/java/org/brotli/dec/Utils.java] enter readInput 1");
    try {
      return src.read(dst, offset, length);
      // System.err.println("[brotli/java/org/brotli/dec/Utils.java] exit readInput 1");
    } catch (IOException e) {
      System.err.println("[brotli/java/org/brotli/dec/Utils.java] enter readInput 2");
      throw new BrotliRuntimeException("Failed to read input", e);
      // System.err.println("[brotli/java/org/brotli/dec/Utils.java] exit readInput 2");
    }
  }

  static void closeInput(InputStream src) throws IOException {
    System.err.println("[brotli/java/org/brotli/dec/Utils.java] enter closeInput 1");
    src.close();
    // System.err.println("[brotli/java/org/brotli/dec/Utils.java] exit closeInput 1");
  }
}
// Total cost: 0.017695
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 74)]
// Total instrumented cost: 0.017695, input tokens: 2398, output tokens: 948, cache read tokens: 2394, cache write tokens: 732
