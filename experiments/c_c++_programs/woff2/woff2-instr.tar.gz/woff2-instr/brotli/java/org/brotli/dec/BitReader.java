/* Copyright 2015 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

package org.brotli.dec;

/**
 * Bit reading helpers.
 */
final class BitReader {

  // Possible values: {5, 6}.  5 corresponds to 32-bit build, 6 to 64-bit. This value is used for
  // conditional compilation -> produced artifacts might be binary INCOMPATIBLE (JLS 13.2).
  private static final int LOG_BITNESS = 6;
  private static final int BITNESS = 1 << LOG_BITNESS;

  private static final int BYTENESS = BITNESS / 8;
  private static final int CAPACITY = 4096;
  // After encountering the end of the input stream, this amount of zero bytes will be appended.
  private static final int SLACK = 64;
  private static final int BUFFER_SIZE = CAPACITY + SLACK;
  // Don't bother to replenish the buffer while this number of bytes is available.
  private static final int SAFEGUARD = 36;
  private static final int WATERLINE = CAPACITY - SAFEGUARD;

  // "Half" refers to "half of native integer type", i.e. on 64-bit machines it is 32-bit type,
  // on 32-bit machines it is 16-bit.
  private static final int HALF_BITNESS = BITNESS / 2;
  private static final int HALF_SIZE = BYTENESS / 2;
  private static final int HALVES_CAPACITY = CAPACITY / HALF_SIZE;
  private static final int HALF_BUFFER_SIZE = BUFFER_SIZE / HALF_SIZE;
  private static final int HALF_WATERLINE = WATERLINE / HALF_SIZE;

  private static final int LOG_HALF_SIZE = LOG_BITNESS - 4;

  /**
   * Fills up the input buffer.
   *
   * <p> No-op if there are at least 36 bytes present after current position.
   *
   * <p> After encountering the end of the input stream, 64 additional zero bytes are copied to the
   * buffer.
   */
  static void readMoreInput(State s) {
    System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter readMoreInput 1");
    if (s.halfOffset > HALF_WATERLINE) {
      System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter readMoreInput 2");
      doReadMoreInput(s);
      // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit readMoreInput 2");
    }
    // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit readMoreInput 1");
  }

  static void doReadMoreInput(State s) {
    System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter doReadMoreInput 1");
    if (s.endOfStreamReached != 0) {
      System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter doReadMoreInput 2");
      if (halfAvailable(s) >= -2) {
        System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter doReadMoreInput 3");
        return;
        // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit doReadMoreInput 3");
      }
      throw new BrotliRuntimeException("No more input");
      // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit doReadMoreInput 2");
    }
    int readOffset = s.halfOffset << LOG_HALF_SIZE;
    int bytesInBuffer = CAPACITY - readOffset;
    // Move unused bytes to the head of the buffer.
    Utils.copyBytesWithin(s.byteBuffer, 0, readOffset, CAPACITY);
    s.halfOffset = 0;
    while (bytesInBuffer < CAPACITY) {
      System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter doReadMoreInput 4");
      int spaceLeft = CAPACITY - bytesInBuffer;
      int len = Utils.readInput(s.input, s.byteBuffer, bytesInBuffer, spaceLeft);
      // EOF is -1 in Java, but 0 in C#.
      if (len <= 0) {
        System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter doReadMoreInput 5");
        s.endOfStreamReached = 1;
        s.tailBytes = bytesInBuffer;
        bytesInBuffer += HALF_SIZE - 1;
        break;
        // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit doReadMoreInput 5");
      }
      bytesInBuffer += len;
      // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit doReadMoreInput 4");
    }
    bytesToNibbles(s, bytesInBuffer);
    // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit doReadMoreInput 1");
  }

  static void checkHealth(State s, int endOfStream) {
    System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter checkHealth 1");
    if (s.endOfStreamReached == 0) {
      System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter checkHealth 2");
      return;
      // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit checkHealth 2");
    }
    int byteOffset = (s.halfOffset << LOG_HALF_SIZE) + ((s.bitOffset + 7) >> 3) - BYTENESS;
    if (byteOffset > s.tailBytes) {
      System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter checkHealth 3");
      throw new BrotliRuntimeException("Read after end");
      // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit checkHealth 3");
    }
    if ((endOfStream != 0) && (byteOffset != s.tailBytes)) {
      System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter checkHealth 4");
      throw new BrotliRuntimeException("Unused bytes after end");
      // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit checkHealth 4");
    }
    // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit checkHealth 1");
  }

  static void fillBitWindow(State s) {
    System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter fillBitWindow 1");
    if (s.bitOffset >= HALF_BITNESS) {
      System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter fillBitWindow 2");
      // Same as doFillBitWindow. JVM fails to inline it.
      if (BITNESS == 64) {
        System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter fillBitWindow 3");
        s.accumulator64 = ((long) s.intBuffer[s.halfOffset++] << HALF_BITNESS)
            | (s.accumulator64 >>> HALF_BITNESS);
        // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit fillBitWindow 3");
      } else {
        System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter fillBitWindow 4");
        s.accumulator32 = ((int) s.shortBuffer[s.halfOffset++] << HALF_BITNESS)
            | (s.accumulator32 >>> HALF_BITNESS);
        // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit fillBitWindow 4");
      }
      s.bitOffset -= HALF_BITNESS;
      // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit fillBitWindow 2");
    }
    // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit fillBitWindow 1");
  }

  private static void doFillBitWindow(State s) {
    System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter doFillBitWindow 1");
    if (BITNESS == 64) {
      System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter doFillBitWindow 2");
      s.accumulator64 = ((long) s.intBuffer[s.halfOffset++] << HALF_BITNESS)
          | (s.accumulator64 >>> HALF_BITNESS);
      // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit doFillBitWindow 2");
    } else {
      System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter doFillBitWindow 3");
      s.accumulator32 = ((int) s.shortBuffer[s.halfOffset++] << HALF_BITNESS)
          | (s.accumulator32 >>> HALF_BITNESS);
      // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit doFillBitWindow 3");
    }
    s.bitOffset -= HALF_BITNESS;
    // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit doFillBitWindow 1");
  }

  static int peekBits(State s) {
    System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter peekBits 1");
    if (BITNESS == 64) {
      System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter peekBits 2");
      return (int) (s.accumulator64 >>> s.bitOffset);
      // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit peekBits 2");
    } else {
      System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter peekBits 3");
      return s.accumulator32 >>> s.bitOffset;
      // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit peekBits 3");
    }
    // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit peekBits 1");
  }

  static int readFewBits(State s, int n) {
    System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter readFewBits 1");
    int val = peekBits(s) & ((1 << n) - 1);
    s.bitOffset += n;
    return val;
    // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit readFewBits 1");
  }

  static int readBits(State s, int n) {
    System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter readBits 1");
    if (HALF_BITNESS >= 24) {
      System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter readBits 2");
      return readFewBits(s, n);
      // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit readBits 2");
    } else {
      System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter readBits 3");
      return (n <= 16) ? readFewBits(s, n) : readManyBits(s, n);
      // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit readBits 3");
    }
    // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit readBits 1");
  }

  private static int readManyBits(State s, int n) {
    System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter readManyBits 1");
    int low = readFewBits(s, 16);
    doFillBitWindow(s);
    return low | (readFewBits(s, n - 16) << 16);
    // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit readManyBits 1");
  }

  static void initBitReader(State s) {
    System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter initBitReader 1");
    s.byteBuffer = new byte[BUFFER_SIZE];
    if (BITNESS == 64) {
      System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter initBitReader 2");
      s.accumulator64 = 0;
      s.intBuffer = new int[HALF_BUFFER_SIZE];
      // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit initBitReader 2");
    } else {
      System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter initBitReader 3");
      s.accumulator32 = 0;
      s.shortBuffer = new short[HALF_BUFFER_SIZE];
      // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit initBitReader 3");
    }
    s.bitOffset = BITNESS;
    s.halfOffset = HALVES_CAPACITY;
    s.endOfStreamReached = 0;
    prepare(s);
    // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit initBitReader 1");
  }

  private static void prepare(State s) {
    System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter prepare 1");
    readMoreInput(s);
    checkHealth(s, 0);
    doFillBitWindow(s);
    doFillBitWindow(s);
    // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit prepare 1");
  }

  static void reload(State s) {
    System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter reload 1");
    if (s.bitOffset == BITNESS) {
      System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter reload 2");
      prepare(s);
      // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit reload 2");
    }
    // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit reload 1");
  }

  static void jumpToByteBoundary(State s) {
    System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter jumpToByteBoundary 1");
    int padding = (BITNESS - s.bitOffset) & 7;
    if (padding != 0) {
      System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter jumpToByteBoundary 2");
      int paddingBits = readFewBits(s, padding);
      if (paddingBits != 0) {
        System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter jumpToByteBoundary 3");
        throw new BrotliRuntimeException("Corrupted padding bits");
        // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit jumpToByteBoundary 3");
      }
      // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit jumpToByteBoundary 2");
    }
    // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit jumpToByteBoundary 1");
  }

  static int halfAvailable(State s) {
    System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter halfAvailable 1");
    int limit = HALVES_CAPACITY;
    if (s.endOfStreamReached != 0) {
      System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter halfAvailable 2");
      limit = (s.tailBytes + (HALF_SIZE - 1)) >> LOG_HALF_SIZE;
      // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit halfAvailable 2");
    }
    return limit - s.halfOffset;
    // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit halfAvailable 1");
  }

  static void copyBytes(State s, byte[] data, int offset, int length) {
    System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter copyBytes 1");
    if ((s.bitOffset & 7) != 0) {
      System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter copyBytes 2");
      throw new BrotliRuntimeException("Unaligned copyBytes");
      // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit copyBytes 2");
    }

    // Drain accumulator.
    while ((s.bitOffset != BITNESS) && (length != 0)) {
      System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter copyBytes 3");
      data[offset++] = (byte) peekBits(s);
      s.bitOffset += 8;
      length--;
      // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit copyBytes 3");
    }
    if (length == 0) {
      System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter copyBytes 4");
      return;
      // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit copyBytes 4");
    }

    // Get data from shadow buffer with "sizeof(int)" granularity.
    int copyNibbles = Math.min(halfAvailable(s), length >> LOG_HALF_SIZE);
    if (copyNibbles > 0) {
      System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter copyBytes 5");
      int readOffset = s.halfOffset << LOG_HALF_SIZE;
      int delta = copyNibbles << LOG_HALF_SIZE;
      System.arraycopy(s.byteBuffer, readOffset, data, offset, delta);
      offset += delta;
      length -= delta;
      s.halfOffset += copyNibbles;
      // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit copyBytes 5");
    }
    if (length == 0) {
      System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter copyBytes 6");
      return;
      // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit copyBytes 6");
    }

    // Read tail bytes.
    if (halfAvailable(s) > 0) {
      System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter copyBytes 7");
      // length = 1..3
      fillBitWindow(s);
      while (length != 0) {
        System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter copyBytes 8");
        data[offset++] = (byte) peekBits(s);
        s.bitOffset += 8;
        length--;
        // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit copyBytes 8");
      }
      checkHealth(s, 0);
      return;
      // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit copyBytes 7");
    }

    // Now it is possible to copy bytes directly.
    while (length > 0) {
      System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter copyBytes 9");
      int len = Utils.readInput(s.input, data, offset, length);
      if (len == -1) {
        System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter copyBytes 10");
        throw new BrotliRuntimeException("Unexpected end of input");
        // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit copyBytes 10");
      }
      offset += len;
      length -= len;
      // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit copyBytes 9");
    }
    // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit copyBytes 1");
  }

  /**
   * Translates bytes to halves (int/short).
   */
  static void bytesToNibbles(State s, int byteLen) {
    System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter bytesToNibbles 1");
    byte[] byteBuffer = s.byteBuffer;
    int halfLen = byteLen >> LOG_HALF_SIZE;
    if (BITNESS == 64) {
      System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter bytesToNibbles 2");
      int[] intBuffer = s.intBuffer;
      for (int i = 0; i < halfLen; ++i) {
        System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter bytesToNibbles 3");
        intBuffer[i] = ((byteBuffer[i * 4] & 0xFF))
            | ((byteBuffer[(i * 4) + 1] & 0xFF) << 8)
            | ((byteBuffer[(i * 4) + 2] & 0xFF) << 16)
            | ((byteBuffer[(i * 4) + 3] & 0xFF) << 24);
        // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit bytesToNibbles 3");
      }
      // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit bytesToNibbles 2");
    } else {
      System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter bytesToNibbles 4");
      short[] shortBuffer = s.shortBuffer;
      for (int i = 0; i < halfLen; ++i) {
        System.err.println("[brotli/java/org/brotli/dec/BitReader.java] enter bytesToNibbles 5");
        shortBuffer[i] = (short) ((byteBuffer[i * 2] & 0xFF)
            | ((byteBuffer[(i * 2) + 1] & 0xFF) << 8));
        // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit bytesToNibbles 5");
      }
      // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit bytesToNibbles 4");
    }
    // System.err.println("[brotli/java/org/brotli/dec/BitReader.java] exit bytesToNibbles 1");
  }
}
// Total cost: 0.081381
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 266)]
// Total instrumented cost: 0.081381, input tokens: 2398, output tokens: 4622, cache read tokens: 2394, cache write tokens: 3019
