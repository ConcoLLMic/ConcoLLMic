/* Copyright 2015 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

package org.brotli.dec;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;

import java.nio.ByteBuffer;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

/**
 * Tests for {@link Transform}.
 */
@RunWith(JUnit4.class)
public class TransformTest {

  private static long crc64(byte[] data) {
    System.err.println("[brotli/java/org/brotli/dec/TransformTest.java] enter crc64 1");
    long crc = -1;
    for (int i = 0; i < data.length; ++i) {
      System.err.println("[brotli/java/org/brotli/dec/TransformTest.java] enter crc64 2");
      long c = (crc ^ (long) (data[i] & 0xFF)) & 0xFF;
      for (int k = 0; k < 8; k++) {
        System.err.println("[brotli/java/org/brotli/dec/TransformTest.java] enter crc64 3");
        c = (c >>> 1) ^ (-(c & 1L) & -3932672073523589310L);
        // System.err.println("[brotli/java/org/brotli/dec/TransformTest.java] exit crc64 3");
      }
      crc = c ^ (crc >>> 8);
      // System.err.println("[brotli/java/org/brotli/dec/TransformTest.java] exit crc64 2");
    }
    return ~crc;
    // System.err.println("[brotli/java/org/brotli/dec/TransformTest.java] exit crc64 1");
  }

  @Test
  public void testTrimAll() {
    System.err.println("[brotli/java/org/brotli/dec/TransformTest.java] enter testTrimAll 1");
    byte[] output = new byte[0];
    byte[] input = {119, 111, 114, 100}; // "word"
    Transform.transformDictionaryWord(
        output, 0, ByteBuffer.wrap(input), 0, input.length, 39);
    byte[] expectedOutput = new byte[0];
    assertArrayEquals(expectedOutput, output);
    // System.err.println("[brotli/java/org/brotli/dec/TransformTest.java] exit testTrimAll 1");
  }

  @Test
  public void testCapitalize() {
    System.err.println("[brotli/java/org/brotli/dec/TransformTest.java] enter testCapitalize 1");
    byte[] output = new byte[6];
    byte[] input = {113, -61, -90, -32, -92, -86}; // "qæप"
    Transform.transformDictionaryWord(
      output, 0, ByteBuffer.wrap(input), 0, input.length, 44);
    byte[] expectedOutput = {81, -61, -122, -32, -92, -81}; // "QÆय"
    assertArrayEquals(expectedOutput, output);
    // System.err.println("[brotli/java/org/brotli/dec/TransformTest.java] exit testCapitalize 1");
  }

  @Test
  public void testAllTransforms() {
    System.err.println("[brotli/java/org/brotli/dec/TransformTest.java] enter testAllTransforms 1");
    /* This string allows to apply all transforms: head and tail cutting, capitalization and
       turning to upper case; all results will be mutually different. */
    // "o123456789abcdef"
    byte[] testWord = {111, 49, 50, 51, 52, 53, 54, 55, 56, 57, 97, 98, 99, 100, 101, 102};
    byte[] output = new byte[2259];
    int offset = 0;
    for (int i = 0; i < Transform.NUM_TRANSFORMS; ++i) {
      System.err.println("[brotli/java/org/brotli/dec/TransformTest.java] enter testAllTransforms 2");
      offset += Transform.transformDictionaryWord(
          output, offset, ByteBuffer.wrap(testWord), 0, testWord.length, i);
      output[offset++] = -1;
      // System.err.println("[brotli/java/org/brotli/dec/TransformTest.java] exit testAllTransforms 2");
    }
    assertEquals(output.length, offset);
    assertEquals(8929191060211225186L, crc64(output));
    // System.err.println("[brotli/java/org/brotli/dec/TransformTest.java] exit testAllTransforms 1");
  }
}
// Total cost: 0.019555
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 71)]
// Total instrumented cost: 0.019555, input tokens: 2398, output tokens: 1035, cache read tokens: 2394, cache write tokens: 880
