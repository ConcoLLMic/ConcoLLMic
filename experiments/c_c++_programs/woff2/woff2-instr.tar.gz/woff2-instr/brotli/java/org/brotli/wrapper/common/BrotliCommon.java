/* Copyright 2017 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

package org.brotli.wrapper.common;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.Arrays;

/**
 * JNI wrapper for brotli common.
 */
public class BrotliCommon {
  public static final int RFC_DICTIONARY_SIZE = 122784;

  /* 96cecd2ee7a666d5aa3627d74735b32a */
  private static final byte[] RFC_DICTIONARY_MD5 = {
    -106, -50, -51, 46, -25, -90, 102, -43, -86, 54, 39, -41, 71, 53, -77, 42
  };

  /* 72b41051cb61a9281ba3c4414c289da50d9a7640 */
  private static final byte[] RFC_DICTIONARY_SHA_1 = {
    114, -76, 16, 81, -53, 97, -87, 40, 27, -93, -60, 65, 76, 40, -99, -91, 13, -102, 118, 64
  };

  /* 20e42eb1b511c21806d4d227d07e5dd06877d8ce7b3a817f378f313653f35c70 */
  private static final byte[] RFC_DICTIONARY_SHA_256 = {
    32, -28, 46, -79, -75, 17, -62, 24, 6, -44, -46, 39, -48, 126, 93, -48,
    104, 119, -40, -50, 123, 58, -127, 127, 55, -113, 49, 54, 83, -13, 92, 112
  };

  private static boolean isDictionaryDataSet;
  private static final Object mutex = new Object();

  /**
   * Checks if the given checksum matches MD5 checksum of the RFC dictionary.
   */
  public static boolean checkDictionaryDataMd5(byte[] digest) {
    System.err.println("[brotli/java/org/brotli/wrapper/common/BrotliCommon.java] enter checkDictionaryDataMd5 1");
    return Arrays.equals(RFC_DICTIONARY_MD5, digest);
    // System.err.println("[brotli/java/org/brotli/wrapper/common/BrotliCommon.java] exit checkDictionaryDataMd5 1");
  }

  /**
   * Checks if the given checksum matches SHA-1 checksum of the RFC dictionary.
   */
  public static boolean checkDictionaryDataSha1(byte[] digest) {
    System.err.println("[brotli/java/org/brotli/wrapper/common/BrotliCommon.java] enter checkDictionaryDataSha1 1");
    return Arrays.equals(RFC_DICTIONARY_SHA_1, digest);
    // System.err.println("[brotli/java/org/brotli/wrapper/common/BrotliCommon.java] exit checkDictionaryDataSha1 1");
  }

  /**
   * Checks if the given checksum matches SHA-256 checksum of the RFC dictionary.
   */
  public static boolean checkDictionaryDataSha256(byte[] digest) {
    System.err.println("[brotli/java/org/brotli/wrapper/common/BrotliCommon.java] enter checkDictionaryDataSha256 1");
    return Arrays.equals(RFC_DICTIONARY_SHA_256, digest);
    // System.err.println("[brotli/java/org/brotli/wrapper/common/BrotliCommon.java] exit checkDictionaryDataSha256 1");
  }

  /**
   * Copy bytes to a new direct ByteBuffer.
   *
   * Direct byte buffers are used to supply native code with large data chunks.
   */
  public static ByteBuffer makeNative(byte[] data) {
    System.err.println("[brotli/java/org/brotli/wrapper/common/BrotliCommon.java] enter makeNative 1");
    ByteBuffer result = ByteBuffer.allocateDirect(data.length);
    result.put(data);
    return result;
    // System.err.println("[brotli/java/org/brotli/wrapper/common/BrotliCommon.java] exit makeNative 1");
  }

  /**
   * Copies data and sets it to be brotli dictionary.
   */
  public static void setDictionaryData(byte[] data) {
    System.err.println("[brotli/java/org/brotli/wrapper/common/BrotliCommon.java] enter setDictionaryData_byte 1");
    if (data.length != RFC_DICTIONARY_SIZE) {
      System.err.println("[brotli/java/org/brotli/wrapper/common/BrotliCommon.java] enter setDictionaryData_byte 2");
      throw new IllegalArgumentException("invalid dictionary size");
      // System.err.println("[brotli/java/org/brotli/wrapper/common/BrotliCommon.java] exit setDictionaryData_byte 2");
    }
    synchronized (mutex) {
      System.err.println("[brotli/java/org/brotli/wrapper/common/BrotliCommon.java] enter setDictionaryData_byte 3");
      if (isDictionaryDataSet) {
        System.err.println("[brotli/java/org/brotli/wrapper/common/BrotliCommon.java] enter setDictionaryData_byte 4");
        return;
        // System.err.println("[brotli/java/org/brotli/wrapper/common/BrotliCommon.java] exit setDictionaryData_byte 4");
      }
      setDictionaryData(makeNative(data));
      // System.err.println("[brotli/java/org/brotli/wrapper/common/BrotliCommon.java] exit setDictionaryData_byte 3");
    }
    // System.err.println("[brotli/java/org/brotli/wrapper/common/BrotliCommon.java] exit setDictionaryData_byte 1");
  }

  /**
   * Reads data and sets it to be brotli dictionary.
   */
  public static void setDictionaryData(InputStream src) throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/common/BrotliCommon.java] enter setDictionaryData_stream 1");
    synchronized (mutex) {
      System.err.println("[brotli/java/org/brotli/wrapper/common/BrotliCommon.java] enter setDictionaryData_stream 2");
      if (isDictionaryDataSet) {
        System.err.println("[brotli/java/org/brotli/wrapper/common/BrotliCommon.java] enter setDictionaryData_stream 3");
        return;
        // System.err.println("[brotli/java/org/brotli/wrapper/common/BrotliCommon.java] exit setDictionaryData_stream 3");
      }
      ByteBuffer copy = ByteBuffer.allocateDirect(RFC_DICTIONARY_SIZE);
      byte[] buffer = new byte[4096];
      int readBytes;
      while ((readBytes = src.read(buffer)) != -1) {
        System.err.println("[brotli/java/org/brotli/wrapper/common/BrotliCommon.java] enter setDictionaryData_stream 4");
        if (copy.remaining() < readBytes) {
          System.err.println("[brotli/java/org/brotli/wrapper/common/BrotliCommon.java] enter setDictionaryData_stream 5");
          throw new IllegalArgumentException("invalid dictionary size");
          // System.err.println("[brotli/java/org/brotli/wrapper/common/BrotliCommon.java] exit setDictionaryData_stream 5");
        }
        copy.put(buffer, 0, readBytes);
        // System.err.println("[brotli/java/org/brotli/wrapper/common/BrotliCommon.java] exit setDictionaryData_stream 4");
      }
      System.err.println("[brotli/java/org/brotli/wrapper/common/BrotliCommon.java] enter setDictionaryData_stream 6");
      if (copy.remaining() != 0) {
        System.err.println("[brotli/java/org/brotli/wrapper/common/BrotliCommon.java] enter setDictionaryData_stream 7");
        throw new IllegalArgumentException("invalid dictionary size " + copy.remaining());
        // System.err.println("[brotli/java/org/brotli/wrapper/common/BrotliCommon.java] exit setDictionaryData_stream 7");
      }
      setDictionaryData(copy);
      // System.err.println("[brotli/java/org/brotli/wrapper/common/BrotliCommon.java] exit setDictionaryData_stream 6");
      // System.err.println("[brotli/java/org/brotli/wrapper/common/BrotliCommon.java] exit setDictionaryData_stream 2");
    }
    // System.err.println("[brotli/java/org/brotli/wrapper/common/BrotliCommon.java] exit setDictionaryData_stream 1");
  }

  /**
   * Sets data to be brotli dictionary.
   */
  public static void setDictionaryData(ByteBuffer data) {
    System.err.println("[brotli/java/org/brotli/wrapper/common/BrotliCommon.java] enter setDictionaryData_buffer 1");
    if (!data.isDirect()) {
      System.err.println("[brotli/java/org/brotli/wrapper/common/BrotliCommon.java] enter setDictionaryData_buffer 2");
      throw new IllegalArgumentException("direct byte buffer is expected");
      // System.err.println("[brotli/java/org/brotli/wrapper/common/BrotliCommon.java] exit setDictionaryData_buffer 2");
    }
    if (data.capacity() != RFC_DICTIONARY_SIZE) {
      System.err.println("[brotli/java/org/brotli/wrapper/common/BrotliCommon.java] enter setDictionaryData_buffer 3");
      throw new IllegalArgumentException("invalid dictionary size");
      // System.err.println("[brotli/java/org/brotli/wrapper/common/BrotliCommon.java] exit setDictionaryData_buffer 3");
    }
    synchronized (mutex) {
      System.err.println("[brotli/java/org/brotli/wrapper/common/BrotliCommon.java] enter setDictionaryData_buffer 4");
      if (isDictionaryDataSet) {
        System.err.println("[brotli/java/org/brotli/wrapper/common/BrotliCommon.java] enter setDictionaryData_buffer 5");
        return;
        // System.err.println("[brotli/java/org/brotli/wrapper/common/BrotliCommon.java] exit setDictionaryData_buffer 5");
      }
      if (!CommonJNI.nativeSetDictionaryData(data)) {
        System.err.println("[brotli/java/org/brotli/wrapper/common/BrotliCommon.java] enter setDictionaryData_buffer 6");
        throw new RuntimeException("setting dictionary failed");
        // System.err.println("[brotli/java/org/brotli/wrapper/common/BrotliCommon.java] exit setDictionaryData_buffer 6");
      }
      isDictionaryDataSet = true;
      // System.err.println("[brotli/java/org/brotli/wrapper/common/BrotliCommon.java] exit setDictionaryData_buffer 4");
    }
    // System.err.println("[brotli/java/org/brotli/wrapper/common/BrotliCommon.java] exit setDictionaryData_buffer 1");
  }
}
// Total cost: 0.038369
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 130)]
// Total instrumented cost: 0.038369, input tokens: 2398, output tokens: 2156, cache read tokens: 2394, cache write tokens: 1413
