/* Copyright 2017 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

package org.brotli.wrapper.enc;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.WritableByteChannel;
import java.util.ArrayList;

/**
 * Base class for OutputStream / Channel implementations.
 */
public class Encoder {
  private final WritableByteChannel destination;
  private final EncoderJNI.Wrapper encoder;
  final ByteBuffer inputBuffer;
  ByteBuffer buffer;
  boolean closed;

  /**
   * Brotli encoder settings.
   */
  public static final class Parameters {
    private int quality = -1;
    private int lgwin = -1;

    public Parameters() { }

    private Parameters(Parameters other) {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter Parameters 1");
      this.quality = other.quality;
      this.lgwin = other.lgwin;
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit Parameters 1");
    }

    /**
     * @param quality compression quality, or -1 for default
     */
    public Parameters setQuality(int quality) {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter setQuality 1");
      if (quality < -1 || quality > 11) {
        System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter setQuality 2");
        throw new IllegalArgumentException("quality should be in range [0, 11], or -1");
        // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit setQuality 2");
      }
      System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter setQuality 3");
      this.quality = quality;
      return this;
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit setQuality 3");
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit setQuality 1");
    }

    /**
     * @param lgwin log2(LZ window size), or -1 for default
     */
    public Parameters setWindow(int lgwin) {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter setWindow 1");
      if ((lgwin != -1) && ((lgwin < 10) || (lgwin > 24))) {
        System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter setWindow 2");
        throw new IllegalArgumentException("lgwin should be in range [10, 24], or -1");
        // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit setWindow 2");
      }
      System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter setWindow 3");
      this.lgwin = lgwin;
      return this;
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit setWindow 3");
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit setWindow 1");
    }
  }

  /**
   * Creates a Encoder wrapper.
   *
   * @param destination underlying destination
   * @param params encoding parameters
   * @param inputBufferSize read buffer size
   */
  Encoder(WritableByteChannel destination, Parameters params, int inputBufferSize)
      throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter Encoder 1");
    if (inputBufferSize <= 0) {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter Encoder 2");
      throw new IllegalArgumentException("buffer size must be positive");
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit Encoder 2");
    }
    System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter Encoder 3");
    if (destination == null) {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter Encoder 4");
      throw new NullPointerException("destination can not be null");
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit Encoder 4");
    }
    System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter Encoder 5");
    this.destination = destination;
    this.encoder = new EncoderJNI.Wrapper(inputBufferSize, params.quality, params.lgwin);
    this.inputBuffer = this.encoder.getInputBuffer();
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit Encoder 5");
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit Encoder 3");
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit Encoder 1");
  }

  private void fail(String message) throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter fail 1");
    try {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter fail 2");
      close();
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit fail 2");
    } catch (IOException ex) {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter fail 3");
      /* Ignore */
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit fail 3");
    }
    System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter fail 4");
    throw new IOException(message);
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit fail 4");
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit fail 1");
  }

  /**
   * @param force repeat pushing until all output is consumed
   * @return true if all encoder output is consumed
   */
  boolean pushOutput(boolean force) throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter pushOutput 1");
    while (buffer != null) {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter pushOutput 2");
      if (buffer.hasRemaining()) {
        System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter pushOutput 3");
        destination.write(buffer);
        // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit pushOutput 3");
      }
      System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter pushOutput 4");
      if (!buffer.hasRemaining()) {
        System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter pushOutput 5");
        buffer = null;
        // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit pushOutput 5");
      } else if (!force) {
        System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter pushOutput 6");
        return false;
        // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit pushOutput 6");
      }
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit pushOutput 4");
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit pushOutput 2");
    }
    System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter pushOutput 7");
    return true;
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit pushOutput 7");
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit pushOutput 1");
  }

  /**
   * @return true if there is space in inputBuffer.
   */
  boolean encode(EncoderJNI.Operation op) throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter encode 1");
    boolean force = (op != EncoderJNI.Operation.PROCESS);
    if (force) {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter encode 2");
      inputBuffer.limit(inputBuffer.position());
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit encode 2");
    } else if (inputBuffer.hasRemaining()) {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter encode 3");
      return true;
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit encode 3");
    }
    System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter encode 4");
    boolean hasInput = true;
    while (true) {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter encode 5");
      if (!encoder.isSuccess()) {
        System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter encode 6");
        fail("encoding failed");
        // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit encode 6");
      } else if (!pushOutput(force)) {
        System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter encode 7");
        return false;
        // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit encode 7");
      } else if (encoder.hasMoreOutput()) {
        System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter encode 8");
        buffer = encoder.pull();
        // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit encode 8");
      } else if (encoder.hasRemainingInput()) {
        System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter encode 9");
        encoder.push(op, 0);
        // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit encode 9");
      } else if (hasInput) {
        System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter encode 10");
        encoder.push(op, inputBuffer.limit());
        hasInput = false;
        // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit encode 10");
      } else {
        System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter encode 11");
        inputBuffer.clear();
        return true;
        // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit encode 11");
      }
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit encode 5");
    }
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit encode 4");
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit encode 1");
  }

  void flush() throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter flush 1");
    encode(EncoderJNI.Operation.FLUSH);
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit flush 1");
  }

  void close() throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter close 1");
    if (closed) {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter close 2");
      return;
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit close 2");
    }
    System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter close 3");
    closed = true;
    try {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter close 4");
      encode(EncoderJNI.Operation.FINISH);
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit close 4");
    } finally {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter close 5");
      encoder.destroy();
      destination.close();
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit close 5");
    }
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit close 3");
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit close 1");
  }

  /**
   * Encodes the given data buffer.
   */
  public static byte[] compress(byte[] data, Parameters params) throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter compress 1");
    EncoderJNI.Wrapper encoder = new EncoderJNI.Wrapper(data.length, params.quality, params.lgwin);
    ArrayList<byte[]> output = new ArrayList<byte[]>();
    int totalOutputSize = 0;
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit compress 1");
    
    try {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter compress 2");
      encoder.getInputBuffer().put(data);
      encoder.push(EncoderJNI.Operation.FINISH, data.length);
      while (true) {
        System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter compress 3");
        if (!encoder.isSuccess()) {
          System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter compress 4");
          throw new IOException("encoding failed");
          // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit compress 4");
        } else if (encoder.hasMoreOutput()) {
          System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter compress 5");
          ByteBuffer buffer = encoder.pull();
          byte[] chunk = new byte[buffer.remaining()];
          buffer.get(chunk);
          output.add(chunk);
          totalOutputSize += chunk.length;
          // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit compress 5");
        } else if (!encoder.isFinished()) {
          System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter compress 6");
          encoder.push(EncoderJNI.Operation.FINISH, 0);
          // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit compress 6");
        } else {
          System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter compress 7");
          break;
          // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit compress 7");
        }
        // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit compress 3");
      }
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit compress 2");
    } finally {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter compress 8");
      encoder.destroy();
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit compress 8");
    }
    
    System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter compress 9");
    if (output.size() == 1) {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter compress 10");
      return output.get(0);
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit compress 10");
    }
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit compress 9");
    
    System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter compress 11");
    byte[] result = new byte[totalOutputSize];
    int offset = 0;
    for (byte[] chunk : output) {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter compress 12");
      System.arraycopy(chunk, 0, result, offset, chunk.length);
      offset += chunk.length;
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit compress 12");
    }
    System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter compress 13");
    return result;
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit compress 13");
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit compress 11");
  }

  public static byte[] compress(byte[] data) throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] enter compress 14");
    return compress(data, new Parameters());
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/Encoder.java] exit compress 14");
  }
}
// Total cost: 0.245065
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 198)]
// Total instrumented cost: 0.245065, input tokens: 24052, output tokens: 12997, cache read tokens: 24036, cache write tokens: 11427
