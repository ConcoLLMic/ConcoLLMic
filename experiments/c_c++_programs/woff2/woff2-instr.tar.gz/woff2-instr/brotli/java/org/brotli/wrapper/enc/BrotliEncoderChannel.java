/* Copyright 2017 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

package org.brotli.wrapper.enc;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.ClosedChannelException;
import java.nio.channels.WritableByteChannel;

/**
 * WritableByteChannel that wraps native brotli encoder.
 */
public class BrotliEncoderChannel extends Encoder implements WritableByteChannel {
  /** The default internal buffer size used by the decoder. */
  private static final int DEFAULT_BUFFER_SIZE = 16384;

  private final Object mutex = new Object();

  /**
   * Creates a BrotliEncoderChannel.
   *
   * @param destination underlying destination
   * @param params encoding settings
   * @param bufferSize intermediate buffer size
   */
  public BrotliEncoderChannel(WritableByteChannel destination, Encoder.Parameters params,
      int bufferSize) throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannel.java] enter BrotliEncoderChannel 1");
    super(destination, params, bufferSize);
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannel.java] exit BrotliEncoderChannel 1");
  }

  public BrotliEncoderChannel(WritableByteChannel destination, Encoder.Parameters params)
      throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannel.java] enter BrotliEncoderChannel 2");
    this(destination, params, DEFAULT_BUFFER_SIZE);
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannel.java] exit BrotliEncoderChannel 2");
  }

  public BrotliEncoderChannel(WritableByteChannel destination) throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannel.java] enter BrotliEncoderChannel 3");
    this(destination, new Encoder.Parameters());
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannel.java] exit BrotliEncoderChannel 3");
  }

  @Override
  public boolean isOpen() {
    System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannel.java] enter isOpen 1");
    synchronized (mutex) {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannel.java] enter isOpen 2");
      return !closed;
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannel.java] exit isOpen 2");
    }
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannel.java] exit isOpen 1");
  }

  @Override
  public void close() throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannel.java] enter close 1");
    synchronized (mutex) {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannel.java] enter close 2");
      super.close();
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannel.java] exit close 2");
    }
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannel.java] exit close 1");
  }

  @Override
  public int write(ByteBuffer src) throws IOException {
    System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannel.java] enter write 1");
    synchronized (mutex) {
      System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannel.java] enter write 2");
      if (closed) {
        System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannel.java] enter write 3");
        throw new ClosedChannelException();
        // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannel.java] exit write 3");
      }
      int result = 0;
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannel.java] exit write 2");
      
      while (src.hasRemaining() && encode(EncoderJNI.Operation.PROCESS)) {
        System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannel.java] enter write 4");
        int limit = Math.min(src.remaining(), inputBuffer.remaining());
        ByteBuffer slice = src.slice();
        slice.limit(limit);
        inputBuffer.put(slice);
        result += limit;
        src.position(src.position() + limit);
        // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannel.java] exit write 4");
      }
      
      System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannel.java] enter write 5");
      return result;
      // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannel.java] exit write 5");
    }
    // System.err.println("[brotli/java/org/brotli/wrapper/enc/BrotliEncoderChannel.java] exit write 1");
  }
}
// Total cost: 0.017991
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 76)]
// Total instrumented cost: 0.017991, input tokens: 2398, output tokens: 979, cache read tokens: 2394, cache write tokens: 687
