/* Copyright 2015 Google Inc. All Rights Reserved.

Distributed under MIT license.
See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/
using System;

namespace Org.Brotli.Dec
{
	/// <summary>Contains a collection of huffman trees with the same alphabet size.</summary>
	internal sealed class HuffmanTreeGroup
	{
		/// <summary>The maximal alphabet size in this group.</summary>
		private int alphabetSize;

		/// <summary>Storage for Huffman lookup tables.</summary>
		internal int[] codes;

		/// <summary>
		/// Offsets of distinct lookup tables in
		/// <see cref="codes"/>
		/// storage.
		/// </summary>
		internal int[] trees;

		/// <summary>Initializes the Huffman tree group.</summary>
		/// <param name="group">POJO to be initialised</param>
		/// <param name="alphabetSize">the maximal alphabet size in this group</param>
		/// <param name="n">number of Huffman codes</param>
		internal static void Init(Org.Brotli.Dec.HuffmanTreeGroup group, int alphabetSize, int n)
		{
			Console.Error.Write("[brotli/csharp/org/brotli/dec/HuffmanTreeGroup.cs] enter Init 1\n");
			group.alphabetSize = alphabetSize;
			group.codes = new int[n * Org.Brotli.Dec.Huffman.HuffmanMaxTableSize];
			group.trees = new int[n];
			// Console.Error.Write("[brotli/csharp/org/brotli/dec/HuffmanTreeGroup.cs] exit Init 1\n");
		}

		/// <summary>Decodes Huffman trees from input stream and constructs lookup tables.</summary>
		/// <param name="group">target POJO</param>
		/// <param name="br">data source</param>
		internal static void Decode(Org.Brotli.Dec.HuffmanTreeGroup group, Org.Brotli.Dec.BitReader br)
		{
			Console.Error.Write("[brotli/csharp/org/brotli/dec/HuffmanTreeGroup.cs] enter Decode 1\n");
			int next = 0;
			int n = group.trees.Length;
			// Console.Error.Write("[brotli/csharp/org/brotli/dec/HuffmanTreeGroup.cs] exit Decode 1\n");
			
			for (int i = 0; i < n; i++)
			{
				Console.Error.Write("[brotli/csharp/org/brotli/dec/HuffmanTreeGroup.cs] enter Decode 2\n");
				group.trees[i] = next;
				Org.Brotli.Dec.Decode.ReadHuffmanCode(group.alphabetSize, group.codes, next, br);
				next += Org.Brotli.Dec.Huffman.HuffmanMaxTableSize;
				// Console.Error.Write("[brotli/csharp/org/brotli/dec/HuffmanTreeGroup.cs] exit Decode 2\n");
			}
		}
	}
}
// Total cost: 0.013615
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 50)]
// Total instrumented cost: 0.013615, input tokens: 2398, output tokens: 693, cache read tokens: 2394, cache write tokens: 664
