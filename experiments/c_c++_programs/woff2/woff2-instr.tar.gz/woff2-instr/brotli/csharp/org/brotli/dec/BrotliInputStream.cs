/* Copyright 2015 Google Inc. All Rights Reserved.

Distributed under MIT license.
See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/
namespace Org.Brotli.Dec
{
	using System;
	
	/// <summary>
	/// <see cref="System.IO.Stream"/>
	/// decorator that decompresses brotli data.
	/// <p> Not thread-safe.
	/// </summary>
	public class BrotliInputStream : System.IO.Stream
	{
		public const int DefaultInternalBufferSize = 16384;

		/// <summary>Internal buffer used for efficient byte-by-byte reading.</summary>
		private byte[] buffer;

		/// <summary>Number of decoded but still unused bytes in internal buffer.</summary>
		private int remainingBufferBytes;

		/// <summary>Next unused byte offset.</summary>
		private int bufferOffset;

		/// <summary>Decoder state.</summary>
		private readonly Org.Brotli.Dec.State state = new Org.Brotli.Dec.State();

		/// <summary>
		/// Creates a
		/// <see cref="System.IO.Stream"/>
		/// wrapper that decompresses brotli data.
		/// <p> For byte-by-byte reading (
		/// <see cref="ReadByte()"/>
		/// ) internal buffer with
		/// <see cref="DefaultInternalBufferSize"/>
		/// size is allocated and used.
		/// <p> Will block the thread until first kilobyte of data of source is available.
		/// </summary>
		/// <param name="source">underlying data source</param>
		/// <exception cref="System.IO.IOException">in case of corrupted data or source stream problems</exception>
		public BrotliInputStream(System.IO.Stream source)
			: this(source, DefaultInternalBufferSize, null)
		{
			Console.Error.WriteLine("");
			// Console.Error.WriteLine("");
		}

		/// <summary>
		/// Creates a
		/// <see cref="System.IO.Stream"/>
		/// wrapper that decompresses brotli data.
		/// <p> For byte-by-byte reading (
		/// <see cref="ReadByte()"/>
		/// ) internal buffer of specified size is
		/// allocated and used.
		/// <p> Will block the thread until first kilobyte of data of source is available.
		/// </summary>
		/// <param name="source">compressed data source</param>
		/// <param name="byteReadBufferSize">
		/// size of internal buffer used in case of
		/// byte-by-byte reading
		/// </param>
		/// <exception cref="System.IO.IOException">in case of corrupted data or source stream problems</exception>
		public BrotliInputStream(System.IO.Stream source, int byteReadBufferSize)
			: this(source, byteReadBufferSize, null)
		{
			Console.Error.WriteLine("");
			// Console.Error.WriteLine("");
		}

		/// <summary>
		/// Creates a
		/// <see cref="System.IO.Stream"/>
		/// wrapper that decompresses brotli data.
		/// <p> For byte-by-byte reading (
		/// <see cref="ReadByte()"/>
		/// ) internal buffer of specified size is
		/// allocated and used.
		/// <p> Will block the thread until first kilobyte of data of source is available.
		/// </summary>
		/// <param name="source">compressed data source</param>
		/// <param name="byteReadBufferSize">
		/// size of internal buffer used in case of
		/// byte-by-byte reading
		/// </param>
		/// <param name="customDictionary">
		/// custom dictionary data;
		/// <see langword="null"/>
		/// if not used
		/// </param>
		/// <exception cref="System.IO.IOException">in case of corrupted data or source stream problems</exception>
		public BrotliInputStream(System.IO.Stream source, int byteReadBufferSize, byte[] customDictionary)
		{
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] enter BrotliInputStream 3");
			if (byteReadBufferSize <= 0)
			{
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] enter BrotliInputStream 4");
				throw new System.ArgumentException("Bad buffer size:" + byteReadBufferSize);
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] exit BrotliInputStream 4");
			}
			else if (source == null)
			{
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] enter BrotliInputStream 5");
				throw new System.ArgumentException("source is null");
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] exit BrotliInputStream 5");
			}
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] enter BrotliInputStream 6");
			this.buffer = new byte[byteReadBufferSize];
			this.remainingBufferBytes = 0;
			this.bufferOffset = 0;
			try
			{
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] enter BrotliInputStream 7");
				Org.Brotli.Dec.State.SetInput(state, source);
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] exit BrotliInputStream 7");
			}
			catch (Org.Brotli.Dec.BrotliRuntimeException ex)
			{
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] enter BrotliInputStream 8");
				throw new System.IO.IOException("Brotli decoder initialization failed", ex);
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] exit BrotliInputStream 8");
			}
			if (customDictionary != null)
			{
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] enter BrotliInputStream 9");
				Org.Brotli.Dec.Decode.SetCustomDictionary(state, customDictionary);
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] exit BrotliInputStream 9");
			}
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] exit BrotliInputStream 6");
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] exit BrotliInputStream 3");
		}

		/// <summary><inheritDoc/></summary>
		/// <exception cref="System.IO.IOException"/>
		public override void Close()
		{
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] enter Close 1");
			Org.Brotli.Dec.State.Close(state);
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] exit Close 1");
		}

		/// <summary><inheritDoc/></summary>
		/// <exception cref="System.IO.IOException"/>
		public override int ReadByte()
		{
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] enter ReadByte 1");
			if (bufferOffset >= remainingBufferBytes)
			{
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] enter ReadByte 2");
				remainingBufferBytes = Read(buffer, 0, buffer.Length);
				bufferOffset = 0;
				if (remainingBufferBytes == -1)
				{
					Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] enter ReadByte 3");
					return -1;
					// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] exit ReadByte 3");
				}
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] exit ReadByte 2");
			}
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] enter ReadByte 4");
			return buffer[bufferOffset++] & unchecked((int)(0xFF));
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] exit ReadByte 4");
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] exit ReadByte 1");
		}

		/// <summary><inheritDoc/></summary>
		/// <exception cref="System.IO.IOException"/>
		public override int Read(byte[] destBuffer, int destOffset, int destLen)
		{
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] enter Read 1");
			if (destOffset < 0)
			{
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] enter Read 2");
				throw new System.ArgumentException("Bad offset: " + destOffset);
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] exit Read 2");
			}
			else if (destLen < 0)
			{
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] enter Read 3");
				throw new System.ArgumentException("Bad length: " + destLen);
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] exit Read 3");
			}
			else if (destOffset + destLen > destBuffer.Length)
			{
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] enter Read 4");
				throw new System.ArgumentException("Buffer overflow: " + (destOffset + destLen) + " > " + destBuffer.Length);
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] exit Read 4");
			}
			else if (destLen == 0)
			{
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] enter Read 5");
				return 0;
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] exit Read 5");
			}
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] enter Read 6");
			int copyLen = System.Math.Max(remainingBufferBytes - bufferOffset, 0);
			if (copyLen != 0)
			{
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] enter Read 7");
				copyLen = System.Math.Min(copyLen, destLen);
				System.Array.Copy(buffer, bufferOffset, destBuffer, destOffset, copyLen);
				bufferOffset += copyLen;
				destOffset += copyLen;
				destLen -= copyLen;
				if (destLen == 0)
				{
					Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] enter Read 8");
					return copyLen;
					// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] exit Read 8");
				}
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] exit Read 7");
			}
			try
			{
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] enter Read 9");
				state.output = destBuffer;
				state.outputOffset = destOffset;
				state.outputLength = destLen;
				state.outputUsed = 0;
				Org.Brotli.Dec.Decode.Decompress(state);
				if (state.outputUsed == 0)
				{
					Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] enter Read 10");
					return -1;
					// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] exit Read 10");
				}
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] enter Read 11");
				return state.outputUsed + copyLen;
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] exit Read 11");
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] exit Read 9");
			}
			catch (Org.Brotli.Dec.BrotliRuntimeException ex)
			{
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] enter Read 12");
				throw new System.IO.IOException("Brotli stream decoding failed", ex);
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] exit Read 12");
			}
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] exit Read 6");
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] exit Read 1");
		}
		// <{[INJECTED CODE]}>
		public override bool CanRead {
			get {
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] enter CanRead 1");
				return true;
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] exit CanRead 1");
			}
		}

		public override bool CanSeek {
			get {
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] enter CanSeek 1");
				return false;
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] exit CanSeek 1");
			}
		}
		public override long Length {
			get {
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] enter Length 1");
				throw new System.NotSupportedException();
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] exit Length 1");
			}
		}
		public override long Position {
			get {
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] enter Position_get 1");
				throw new System.NotSupportedException();
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] exit Position_get 1");
			}
			set {
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] enter Position_set 1");
				throw new System.NotSupportedException();
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] exit Position_set 1");
			}
		}
		public override long Seek(long offset, System.IO.SeekOrigin origin) {
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] enter Seek 1");
			throw new System.NotSupportedException();
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] exit Seek 1");
		}
		public override void SetLength(long value){
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] enter SetLength 1");
			throw new System.NotSupportedException();
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] exit SetLength 1");
		}

		public override bool CanWrite{
			get{
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] enter CanWrite 1");
				return false;
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] exit CanWrite 1");
			}
		}
		public override System.IAsyncResult BeginWrite(byte[] buffer, int offset,
				int count, System.AsyncCallback callback, object state) {
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] enter BeginWrite 1");
			throw new System.NotSupportedException();
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] exit BeginWrite 1");
		}
		public override void Write(byte[] buffer, int offset, int count) {
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] enter Write 1");
			throw new System.NotSupportedException();
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BrotliInputStream.cs] exit Write 1");
		}

		public override void Flush() {
			Console.Error.WriteLine("");
			// Console.Error.WriteLine("");
		}
	}
}
// Total cost: 0.058915
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 223)]
// Total instrumented cost: 0.058915, input tokens: 2398, output tokens: 3317, cache read tokens: 2394, cache write tokens: 2248
