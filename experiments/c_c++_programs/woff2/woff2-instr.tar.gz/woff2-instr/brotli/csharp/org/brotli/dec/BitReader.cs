/* Copyright 2015 Google Inc. All Rights Reserved.

Distributed under MIT license.
See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/
using System;

namespace Org.Brotli.Dec
{
	/// <summary>Bit reading helpers.</summary>
	internal sealed class BitReader
	{
		/// <summary>
		/// Input byte buffer, consist of a ring-buffer and a "slack" region where bytes from the start of
		/// the ring-buffer are copied.
		/// </summary>
		private const int Capacity = 1024;

		private const int Slack = 16;

		private const int IntBufferSize = Capacity + Slack;

		private const int ByteReadSize = Capacity << 2;

		private const int ByteBufferSize = IntBufferSize << 2;

		private readonly byte[] byteBuffer = new byte[ByteBufferSize];

		private readonly int[] intBuffer = new int[IntBufferSize];

		private readonly Org.Brotli.Dec.IntReader intReader = new Org.Brotli.Dec.IntReader();

		private System.IO.Stream input;

		/// <summary>Input stream is finished.</summary>
		private bool endOfStreamReached;

		/// <summary>Pre-fetched bits.</summary>
		internal long accumulator;

		/// <summary>Current bit-reading position in accumulator.</summary>
		internal int bitOffset;

		/// <summary>Offset of next item in intBuffer.</summary>
		private int intOffset;

		private int tailBytes = 0;

		/* Number of bytes in unfinished "int" item. */
		/// <summary>Fills up the input buffer.</summary>
		/// <remarks>
		/// Fills up the input buffer.
		/// <p> No-op if there are at least 36 bytes present after current position.
		/// <p> After encountering the end of the input stream, 64 additional zero bytes are copied to the
		/// buffer.
		/// </remarks>
		internal static void ReadMoreInput(Org.Brotli.Dec.BitReader br)
		{
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter ReadMoreInput 1");
			// TODO: Split to check and read; move read outside of decoding loop.
			if (br.intOffset <= Capacity - 9)
			{
				return;
			}
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit ReadMoreInput 1");
			
			if (br.endOfStreamReached)
			{
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter ReadMoreInput 2");
				if (IntAvailable(br) >= -2)
				{
					return;
				}
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit ReadMoreInput 2");
				
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter ReadMoreInput 3");
				throw new Org.Brotli.Dec.BrotliRuntimeException("No more input");
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit ReadMoreInput 3");
			}
			
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter ReadMoreInput 4");
			int readOffset = br.intOffset << 2;
			int bytesRead = ByteReadSize - readOffset;
			System.Array.Copy(br.byteBuffer, readOffset, br.byteBuffer, 0, bytesRead);
			br.intOffset = 0;
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit ReadMoreInput 4");
			
			try
			{
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter ReadMoreInput 5");
				while (bytesRead < ByteReadSize)
				{
					Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter ReadMoreInput 6");
					int len = br.input.Read(br.byteBuffer, bytesRead, ByteReadSize - bytesRead);
					// EOF is -1 in Java, but 0 in C#.
					if (len <= 0)
					{
						Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter ReadMoreInput 7");
						br.endOfStreamReached = true;
						br.tailBytes = bytesRead;
						bytesRead += 3;
						break;
						// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit ReadMoreInput 7");
					}
					// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit ReadMoreInput 6");
					
					Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter ReadMoreInput 8");
					bytesRead += len;
					// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit ReadMoreInput 8");
				}
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit ReadMoreInput 5");
			}
			catch (System.IO.IOException e)
			{
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter ReadMoreInput 9");
				throw new Org.Brotli.Dec.BrotliRuntimeException("Failed to read input", e);
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit ReadMoreInput 9");
			}
			
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter ReadMoreInput 10");
			Org.Brotli.Dec.IntReader.Convert(br.intReader, bytesRead >> 2);
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit ReadMoreInput 10");
		}

		internal static void CheckHealth(Org.Brotli.Dec.BitReader br, bool endOfStream)
		{
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter CheckHealth 1");
			if (!br.endOfStreamReached)
			{
				return;
			}
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit CheckHealth 1");
			
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter CheckHealth 2");
			int byteOffset = (br.intOffset << 2) + ((br.bitOffset + 7) >> 3) - 8;
			if (byteOffset > br.tailBytes)
			{
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter CheckHealth 3");
				throw new Org.Brotli.Dec.BrotliRuntimeException("Read after end");
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit CheckHealth 3");
			}
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit CheckHealth 2");
			
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter CheckHealth 4");
			if (endOfStream && (byteOffset != br.tailBytes))
			{
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter CheckHealth 5");
				throw new Org.Brotli.Dec.BrotliRuntimeException("Unused bytes after end");
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit CheckHealth 5");
			}
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit CheckHealth 4");
		}

		/// <summary>Advances the Read buffer by 5 bytes to make room for reading next 24 bits.</summary>
		internal static void FillBitWindow(Org.Brotli.Dec.BitReader br)
		{
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter FillBitWindow 1");
			if (br.bitOffset >= 32)
			{
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter FillBitWindow 2");
				br.accumulator = ((long)br.intBuffer[br.intOffset++] << 32) | ((long)(((ulong)br.accumulator) >> 32));
				br.bitOffset -= 32;
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit FillBitWindow 2");
			}
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit FillBitWindow 1");
		}

		/// <summary>Reads the specified number of bits from Read Buffer.</summary>
		internal static int ReadBits(Org.Brotli.Dec.BitReader br, int n)
		{
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter ReadBits 1");
			FillBitWindow(br);
			int val = (int)((long)(((ulong)br.accumulator) >> br.bitOffset)) & ((1 << n) - 1);
			br.bitOffset += n;
			return val;
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit ReadBits 1");
		}

		/// <summary>Initialize bit reader.</summary>
		/// <remarks>
		/// Initialize bit reader.
		/// <p> Initialisation turns bit reader to a ready state. Also a number of bytes is prefetched to
		/// accumulator. Because of that this method may block until enough data could be read from input.
		/// </remarks>
		/// <param name="br">BitReader POJO</param>
		/// <param name="input">data source</param>
		internal static void Init(Org.Brotli.Dec.BitReader br, System.IO.Stream input)
		{
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter Init 1");
			if (br.input != null)
			{
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter Init 2");
				throw new System.InvalidOperationException("Bit reader already has associated input stream");
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit Init 2");
			}
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit Init 1");
			
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter Init 3");
			Org.Brotli.Dec.IntReader.Init(br.intReader, br.byteBuffer, br.intBuffer);
			br.input = input;
			br.accumulator = 0;
			br.bitOffset = 64;
			br.intOffset = Capacity;
			br.endOfStreamReached = false;
			Prepare(br);
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit Init 3");
		}

		private static void Prepare(Org.Brotli.Dec.BitReader br)
		{
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter Prepare 1");
			ReadMoreInput(br);
			CheckHealth(br, false);
			FillBitWindow(br);
			FillBitWindow(br);
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit Prepare 1");
		}

		internal static void Reload(Org.Brotli.Dec.BitReader br)
		{
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter Reload 1");
			if (br.bitOffset == 64)
			{
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter Reload 2");
				Prepare(br);
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit Reload 2");
			}
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit Reload 1");
		}

		/// <exception cref="System.IO.IOException"/>
		internal static void Close(Org.Brotli.Dec.BitReader br)
		{
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter Close 1");
			System.IO.Stream @is = br.input;
			br.input = null;
			if (@is != null)
			{
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter Close 2");
				@is.Close();
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit Close 2");
			}
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit Close 1");
		}

		internal static void JumpToByteBoundary(Org.Brotli.Dec.BitReader br)
		{
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter JumpToByteBoundary 1");
			int padding = (64 - br.bitOffset) & 7;
			if (padding != 0)
			{
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter JumpToByteBoundary 2");
				int paddingBits = Org.Brotli.Dec.BitReader.ReadBits(br, padding);
				if (paddingBits != 0)
				{
					Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter JumpToByteBoundary 3");
					throw new Org.Brotli.Dec.BrotliRuntimeException("Corrupted padding bits");
					// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit JumpToByteBoundary 3");
				}
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit JumpToByteBoundary 2");
			}
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit JumpToByteBoundary 1");
		}

		internal static int IntAvailable(Org.Brotli.Dec.BitReader br)
		{
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter IntAvailable 1");
			int limit = Capacity;
			if (br.endOfStreamReached)
			{
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter IntAvailable 2");
				limit = (br.tailBytes + 3) >> 2;
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit IntAvailable 2");
			}
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit IntAvailable 1");
			
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter IntAvailable 3");
			return limit - br.intOffset;
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit IntAvailable 3");
		}

		internal static void CopyBytes(Org.Brotli.Dec.BitReader br, byte[] data, int offset, int length)
		{
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter CopyBytes 1");
			if ((br.bitOffset & 7) != 0)
			{
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter CopyBytes 2");
				throw new Org.Brotli.Dec.BrotliRuntimeException("Unaligned copyBytes");
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit CopyBytes 2");
			}
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit CopyBytes 1");
			
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter CopyBytes 3");
			// Drain accumulator.
			while ((br.bitOffset != 64) && (length != 0))
			{
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter CopyBytes 4");
				data[offset++] = unchecked((byte)((long)(((ulong)br.accumulator) >> br.bitOffset)));
				br.bitOffset += 8;
				length--;
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit CopyBytes 4");
			}
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit CopyBytes 3");
			
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter CopyBytes 5");
			if (length == 0)
			{
				return;
			}
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit CopyBytes 5");
			
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter CopyBytes 6");
			// Get data from shadow buffer with "sizeof(int)" granularity.
			int copyInts = System.Math.Min(IntAvailable(br), length >> 2);
			if (copyInts > 0)
			{
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter CopyBytes 7");
				int readOffset = br.intOffset << 2;
				System.Array.Copy(br.byteBuffer, readOffset, data, offset, copyInts << 2);
				offset += copyInts << 2;
				length -= copyInts << 2;
				br.intOffset += copyInts;
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit CopyBytes 7");
			}
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit CopyBytes 6");
			
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter CopyBytes 8");
			if (length == 0)
			{
				return;
			}
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit CopyBytes 8");
			
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter CopyBytes 9");
			// Read tail bytes.
			if (IntAvailable(br) > 0)
			{
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter CopyBytes 10");
				// length = 1..3
				FillBitWindow(br);
				while (length != 0)
				{
					Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter CopyBytes 11");
					data[offset++] = unchecked((byte)((long)(((ulong)br.accumulator) >> br.bitOffset)));
					br.bitOffset += 8;
					length--;
					// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit CopyBytes 11");
				}
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit CopyBytes 10");
				
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter CopyBytes 12");
				CheckHealth(br, false);
				return;
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit CopyBytes 12");
			}
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit CopyBytes 9");
			
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter CopyBytes 13");
			// Now it is possible to copy bytes directly.
			try
			{
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter CopyBytes 14");
				while (length > 0)
				{
					Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter CopyBytes 15");
					int len = br.input.Read(data, offset, length);
					if (len == -1)
					{
						Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter CopyBytes 16");
						throw new Org.Brotli.Dec.BrotliRuntimeException("Unexpected end of input");
						// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit CopyBytes 16");
					}
					// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit CopyBytes 15");
					
					Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter CopyBytes 17");
					offset += len;
					length -= len;
					// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit CopyBytes 17");
				}
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit CopyBytes 14");
			}
			catch (System.IO.IOException e)
			{
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] enter CopyBytes 18");
				throw new Org.Brotli.Dec.BrotliRuntimeException("Failed to read input", e);
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit CopyBytes 18");
			}
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReader.cs] exit CopyBytes 13");
		}
	}
}
// Total cost: 0.074883
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 271)]
// Total instrumented cost: 0.074883, input tokens: 2398, output tokens: 4259, cache read tokens: 2394, cache write tokens: 2738
