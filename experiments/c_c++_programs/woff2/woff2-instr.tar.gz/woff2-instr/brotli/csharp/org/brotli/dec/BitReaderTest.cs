/* Copyright 2015 Google Inc. All Rights Reserved.

Distributed under MIT license.
See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/
using System;

namespace Org.Brotli.Dec
{
	/// <summary>
	/// Tests for
	/// <see cref="BitReader"/>
	/// .
	/// </summary>
	public class BitReaderTest
	{
		[NUnit.Framework.Test]
		public virtual void TestReadAfterEos()
		{
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReaderTest.cs] enter TestReadAfterEos 1");
			Org.Brotli.Dec.BitReader reader = new Org.Brotli.Dec.BitReader();
			Org.Brotli.Dec.BitReader.Init(reader, new System.IO.MemoryStream(new byte[1]));
			Org.Brotli.Dec.BitReader.ReadBits(reader, 9);
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReaderTest.cs] exit TestReadAfterEos 1");
			try
			{
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReaderTest.cs] enter TestReadAfterEos 2");
				Org.Brotli.Dec.BitReader.CheckHealth(reader, false);
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReaderTest.cs] exit TestReadAfterEos 2");
			}
			catch (Org.Brotli.Dec.BrotliRuntimeException)
			{
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReaderTest.cs] enter TestReadAfterEos 3");
				// This exception is expected.
				return;
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReaderTest.cs] exit TestReadAfterEos 3");
			}
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReaderTest.cs] enter TestReadAfterEos 4");
			NUnit.Framework.Assert.Fail("BrotliRuntimeException should have been thrown by BitReader.checkHealth");
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/BitReaderTest.cs] exit TestReadAfterEos 4");
		}
	}
}
// Total cost: 0.009678
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 33)]
// Total instrumented cost: 0.009678, input tokens: 2398, output tokens: 493, cache read tokens: 2394, cache write tokens: 414
