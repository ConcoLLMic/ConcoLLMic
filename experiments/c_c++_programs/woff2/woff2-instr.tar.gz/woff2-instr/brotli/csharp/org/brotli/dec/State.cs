/* Copyright 2015 Google Inc. All Rights Reserved.

Distributed under MIT license.
See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/
using System;

namespace Org.Brotli.Dec
{
	internal sealed class State
	{
		internal int runningState = Org.Brotli.Dec.RunningState.Uninitialized;

		internal int nextRunningState;

		internal readonly Org.Brotli.Dec.BitReader br = new Org.Brotli.Dec.BitReader();

		internal byte[] ringBuffer;

		internal readonly int[] blockTypeTrees = new int[3 * Org.Brotli.Dec.Huffman.HuffmanMaxTableSize];

		internal readonly int[] blockLenTrees = new int[3 * Org.Brotli.Dec.Huffman.HuffmanMaxTableSize];

		internal int metaBlockLength;

		internal bool inputEnd;

		internal bool isUncompressed;

		internal bool isMetadata;

		internal readonly Org.Brotli.Dec.HuffmanTreeGroup hGroup0 = new Org.Brotli.Dec.HuffmanTreeGroup();

		internal readonly Org.Brotli.Dec.HuffmanTreeGroup hGroup1 = new Org.Brotli.Dec.HuffmanTreeGroup();

		internal readonly Org.Brotli.Dec.HuffmanTreeGroup hGroup2 = new Org.Brotli.Dec.HuffmanTreeGroup();

		internal readonly int[] blockLength = new int[3];

		internal readonly int[] numBlockTypes = new int[3];

		internal readonly int[] blockTypeRb = new int[6];

		internal readonly int[] distRb = new int[] { 16, 15, 11, 4 };

		internal int pos = 0;

		internal int maxDistance = 0;

		internal int distRbIdx = 0;

		internal bool trivialLiteralContext = false;

		internal int literalTreeIndex = 0;

		internal int literalTree;

		internal int j;

		internal int insertLength;

		internal byte[] contextModes;

		internal byte[] contextMap;

		internal int contextMapSlice;

		internal int distContextMapSlice;

		internal int contextLookupOffset1;

		internal int contextLookupOffset2;

		internal int treeCommandOffset;

		internal int distanceCode;

		internal byte[] distContextMap;

		internal int numDirectDistanceCodes;

		internal int distancePostfixMask;

		internal int distancePostfixBits;

		internal int distance;

		internal int copyLength;

		internal int copyDst;

		internal int maxBackwardDistance;

		internal int maxRingBufferSize;

		internal int ringBufferSize = 0;

		internal long expectedTotalSize = 0;

		internal byte[] customDictionary = new byte[0];

		internal int bytesToIgnore = 0;

		internal int outputOffset;

		internal int outputLength;

		internal int outputUsed;

		internal int bytesWritten;

		internal int bytesToWrite;

		internal byte[] output;

		// Current meta-block header information.
		// TODO: Update to current spec.
		private static int DecodeWindowBits(Org.Brotli.Dec.BitReader br)
		{
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/State.cs] enter DecodeWindowBits 1");
			if (Org.Brotli.Dec.BitReader.ReadBits(br, 1) == 0)
			{
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/State.cs] enter DecodeWindowBits 2");
				return 16;
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/State.cs] exit DecodeWindowBits 2");
			}
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/State.cs] exit DecodeWindowBits 1");
			
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/State.cs] enter DecodeWindowBits 3");
			int n = Org.Brotli.Dec.BitReader.ReadBits(br, 3);
			if (n != 0)
			{
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/State.cs] enter DecodeWindowBits 4");
				return 17 + n;
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/State.cs] exit DecodeWindowBits 4");
			}
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/State.cs] exit DecodeWindowBits 3");
			
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/State.cs] enter DecodeWindowBits 5");
			n = Org.Brotli.Dec.BitReader.ReadBits(br, 3);
			if (n != 0)
			{
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/State.cs] enter DecodeWindowBits 6");
				return 8 + n;
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/State.cs] exit DecodeWindowBits 6");
			}
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/State.cs] exit DecodeWindowBits 5");
			
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/State.cs] enter DecodeWindowBits 7");
			return 17;
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/State.cs] exit DecodeWindowBits 7");
		}

		/// <summary>Associate input with decoder state.</summary>
		/// <param name="state">uninitialized state without associated input</param>
		/// <param name="input">compressed data source</param>
		internal static void SetInput(Org.Brotli.Dec.State state, System.IO.Stream input)
		{
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/State.cs] enter SetInput 1");
			if (state.runningState != Org.Brotli.Dec.RunningState.Uninitialized)
			{
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/State.cs] enter SetInput 2");
				throw new System.InvalidOperationException("State MUST be uninitialized");
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/State.cs] exit SetInput 2");
			}
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/State.cs] exit SetInput 1");
			
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/State.cs] enter SetInput 3");
			Org.Brotli.Dec.BitReader.Init(state.br, input);
			int windowBits = DecodeWindowBits(state.br);
			if (windowBits == 9)
			{
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/State.cs] enter SetInput 4");
				/* Reserved case for future expansion. */
				throw new Org.Brotli.Dec.BrotliRuntimeException("Invalid 'windowBits' code");
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/State.cs] exit SetInput 4");
			}
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/State.cs] exit SetInput 3");
			
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/State.cs] enter SetInput 5");
			state.maxRingBufferSize = 1 << windowBits;
			state.maxBackwardDistance = state.maxRingBufferSize - 16;
			state.runningState = Org.Brotli.Dec.RunningState.BlockStart;
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/State.cs] exit SetInput 5");
		}

		/// <exception cref="System.IO.IOException"/>
		internal static void Close(Org.Brotli.Dec.State state)
		{
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/State.cs] enter Close 1");
			if (state.runningState == Org.Brotli.Dec.RunningState.Uninitialized)
			{
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/State.cs] enter Close 2");
				throw new System.InvalidOperationException("State MUST be initialized");
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/State.cs] exit Close 2");
			}
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/State.cs] exit Close 1");
			
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/State.cs] enter Close 3");
			if (state.runningState == Org.Brotli.Dec.RunningState.Closed)
			{
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/State.cs] enter Close 4");
				return;
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/State.cs] exit Close 4");
			}
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/State.cs] exit Close 3");
			
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/State.cs] enter Close 5");
			state.runningState = Org.Brotli.Dec.RunningState.Closed;
			Org.Brotli.Dec.BitReader.Close(state.br);
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/State.cs] exit Close 5");
		}
	}
}
// Total cost: 0.077305
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 171)]
// Total instrumented cost: 0.077305, input tokens: 6350, output tokens: 4124, cache read tokens: 6342, cache write tokens: 3605
