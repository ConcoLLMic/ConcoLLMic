/* Copyright 2015 Google Inc. All Rights Reserved.

Distributed under MIT license.
See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/
using System;

namespace Org.Brotli.Dec
{
	/// <summary>Unchecked exception used internally.</summary>
	[System.Serializable]
	internal class BrotliRuntimeException : System.Exception
	{
		internal BrotliRuntimeException(string message)
			: base(message)
		{
			Console.Error.WriteLine("");
			// Console.Error.WriteLine("");
		}

		internal BrotliRuntimeException(string message, System.Exception cause)
			: base(message, cause)
		{
			Console.Error.WriteLine("");
			// Console.Error.WriteLine("");
		}
	}
}
// Total cost: 0.005613
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 22)]
// Total instrumented cost: 0.005613, input tokens: 2398, output tokens: 261, cache read tokens: 2394, cache write tokens: 258
