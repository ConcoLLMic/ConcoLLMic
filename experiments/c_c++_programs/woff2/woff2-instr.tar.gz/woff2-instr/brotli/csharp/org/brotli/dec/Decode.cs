/* Copyright 2015 Google Inc. All Rights Reserved.

Distributed under MIT license.
See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/
using System;

namespace Org.Brotli.Dec
{
	/// <summary>API for Brotli decompression.</summary>
	internal sealed class Decode
	{
		private const int DefaultCodeLength = 8;

		private const int CodeLengthRepeatCode = 16;

		private const int NumLiteralCodes = 256;

		private const int NumInsertAndCopyCodes = 704;

		private const int NumBlockLengthCodes = 26;

		private const int LiteralContextBits = 6;

		private const int DistanceContextBits = 2;

		private const int HuffmanTableBits = 8;

		private const int HuffmanTableMask = unchecked((int)(0xFF));

		private const int CodeLengthCodes = 18;

		private static readonly int[] CodeLengthCodeOrder = new int[] { 1, 2, 3, 4, 0, 5, 17, 6, 16, 7, 8, 9, 10, 11, 12, 13, 14, 15 };

		private const int NumDistanceShortCodes = 16;

		private static readonly int[] DistanceShortCodeIndexOffset = new int[] { 3, 2, 1, 0, 3, 3, 3, 3, 3, 3, 2, 2, 2, 2, 2, 2 };

		private static readonly int[] DistanceShortCodeValueOffset = new int[] { 0, 0, 0, 0, -1, 1, -2, 2, -3, 3, -1, 1, -2, 2, -3, 3 };

		/// <summary>Static Huffman code for the code length code lengths.</summary>
		private static readonly int[] FixedTable = new int[] { unchecked((int)(0x020000)), unchecked((int)(0x020004)), unchecked((int)(0x020003)), unchecked((int)(0x030002)), unchecked((int)(0x020000)), unchecked((int)(0x020004)), unchecked((int)(0x020003
			)), unchecked((int)(0x040001)), unchecked((int)(0x020000)), unchecked((int)(0x020004)), unchecked((int)(0x020003)), unchecked((int)(0x030002)), unchecked((int)(0x020000)), unchecked((int)(0x020004)), unchecked((int)(0x020003)), unchecked((int
			)(0x040005)) };

		/// <summary>Decodes a number in the range [0..255], by reading 1 - 11 bits.</summary>
		private static int DecodeVarLenUnsignedByte(Org.Brotli.Dec.BitReader br)
		{
			Console.Error.WriteLine("enter DecodeVarLenUnsignedByte 1");
			if (Org.Brotli.Dec.BitReader.ReadBits(br, 1) != 0)
			{
				Console.Error.WriteLine("enter DecodeVarLenUnsignedByte 2");
				int n = Org.Brotli.Dec.BitReader.ReadBits(br, 3);
				if (n == 0)
				{
					Console.Error.WriteLine("enter DecodeVarLenUnsignedByte 3");
					return 1;
					// Console.Error.WriteLine("exit DecodeVarLenUnsignedByte 3");
				}
				else
				{
					Console.Error.WriteLine("enter DecodeVarLenUnsignedByte 4");
					return Org.Brotli.Dec.BitReader.ReadBits(br, n) + (1 << n);
					// Console.Error.WriteLine("exit DecodeVarLenUnsignedByte 4");
				}
				// Console.Error.WriteLine("exit DecodeVarLenUnsignedByte 2");
			}
			Console.Error.WriteLine("enter DecodeVarLenUnsignedByte 5");
			return 0;
			// Console.Error.WriteLine("exit DecodeVarLenUnsignedByte 5");
			// Console.Error.WriteLine("exit DecodeVarLenUnsignedByte 1");
		}

		private static void DecodeMetaBlockLength(Org.Brotli.Dec.BitReader br, Org.Brotli.Dec.State state)
		{
			Console.Error.WriteLine("enter DecodeMetaBlockLength 1");
			state.inputEnd = Org.Brotli.Dec.BitReader.ReadBits(br, 1) == 1;
			state.metaBlockLength = 0;
			state.isUncompressed = false;
			state.isMetadata = false;
			// Console.Error.WriteLine("exit DecodeMetaBlockLength 1");
			
			if (state.inputEnd && Org.Brotli.Dec.BitReader.ReadBits(br, 1) != 0)
			{
				Console.Error.WriteLine("enter DecodeMetaBlockLength 2");
				return;
				// Console.Error.WriteLine("exit DecodeMetaBlockLength 2");
			}
			
			Console.Error.WriteLine("enter DecodeMetaBlockLength 3");
			int sizeNibbles = Org.Brotli.Dec.BitReader.ReadBits(br, 2) + 4;
			// Console.Error.WriteLine("exit DecodeMetaBlockLength 3");
			
			if (sizeNibbles == 7)
			{
				Console.Error.WriteLine("enter DecodeMetaBlockLength 4");
				state.isMetadata = true;
				// Console.Error.WriteLine("exit DecodeMetaBlockLength 4");
				
				if (Org.Brotli.Dec.BitReader.ReadBits(br, 1) != 0)
				{
					Console.Error.WriteLine("enter DecodeMetaBlockLength 5");
					throw new Org.Brotli.Dec.BrotliRuntimeException("Corrupted reserved bit");
					// Console.Error.WriteLine("exit DecodeMetaBlockLength 5");
				}
				
				Console.Error.WriteLine("enter DecodeMetaBlockLength 6");
				int sizeBytes = Org.Brotli.Dec.BitReader.ReadBits(br, 2);
				// Console.Error.WriteLine("exit DecodeMetaBlockLength 6");
				
				if (sizeBytes == 0)
				{
					Console.Error.WriteLine("enter DecodeMetaBlockLength 7");
					return;
					// Console.Error.WriteLine("exit DecodeMetaBlockLength 7");
				}
				
				Console.Error.WriteLine("enter DecodeMetaBlockLength 8");
				for (int i = 0; i < sizeBytes; i++)
				{
					Console.Error.WriteLine("enter DecodeMetaBlockLength 9");
					int bits = Org.Brotli.Dec.BitReader.ReadBits(br, 8);
					// Console.Error.WriteLine("exit DecodeMetaBlockLength 9");
					
					if (bits == 0 && i + 1 == sizeBytes && sizeBytes > 1)
					{
						Console.Error.WriteLine("enter DecodeMetaBlockLength 10");
						throw new Org.Brotli.Dec.BrotliRuntimeException("Exuberant nibble");
						// Console.Error.WriteLine("exit DecodeMetaBlockLength 10");
					}
					
					Console.Error.WriteLine("enter DecodeMetaBlockLength 11");
					state.metaBlockLength |= bits << (i * 8);
					// Console.Error.WriteLine("exit DecodeMetaBlockLength 11");
				}
				// Console.Error.WriteLine("exit DecodeMetaBlockLength 8");
			}
			else
			{
				Console.Error.WriteLine("enter DecodeMetaBlockLength 12");
				for (int i = 0; i < sizeNibbles; i++)
				{
					Console.Error.WriteLine("enter DecodeMetaBlockLength 13");
					int bits = Org.Brotli.Dec.BitReader.ReadBits(br, 4);
					// Console.Error.WriteLine("exit DecodeMetaBlockLength 13");
					
					if (bits == 0 && i + 1 == sizeNibbles && sizeNibbles > 4)
					{
						Console.Error.WriteLine("enter DecodeMetaBlockLength 14");
						throw new Org.Brotli.Dec.BrotliRuntimeException("Exuberant nibble");
						// Console.Error.WriteLine("exit DecodeMetaBlockLength 14");
					}
					
					Console.Error.WriteLine("enter DecodeMetaBlockLength 15");
					state.metaBlockLength |= bits << (i * 4);
					// Console.Error.WriteLine("exit DecodeMetaBlockLength 15");
				}
				// Console.Error.WriteLine("exit DecodeMetaBlockLength 12");
			}
			
			Console.Error.WriteLine("enter DecodeMetaBlockLength 16");
			state.metaBlockLength++;
			// Console.Error.WriteLine("exit DecodeMetaBlockLength 16");
			
			if (!state.inputEnd)
			{
				Console.Error.WriteLine("enter DecodeMetaBlockLength 17");
				state.isUncompressed = Org.Brotli.Dec.BitReader.ReadBits(br, 1) == 1;
				// Console.Error.WriteLine("exit DecodeMetaBlockLength 17");
			}
		}

		/// <summary>Decodes the next Huffman code from bit-stream.</summary>
		private static int ReadSymbol(int[] table, int offset, Org.Brotli.Dec.BitReader br)
		{
			Console.Error.WriteLine("enter ReadSymbol 1");
			int val = (int)((long)(((ulong)br.accumulator) >> br.bitOffset));
			offset += val & HuffmanTableMask;
			int bits = table[offset] >> 16;
			int sym = table[offset] & unchecked((int)(0xFFFF));
			// Console.Error.WriteLine("exit ReadSymbol 1");
			
			if (bits <= HuffmanTableBits)
			{
				Console.Error.WriteLine("enter ReadSymbol 2");
				br.bitOffset += bits;
				return sym;
				// Console.Error.WriteLine("exit ReadSymbol 2");
			}
			
			Console.Error.WriteLine("enter ReadSymbol 3");
			offset += sym;
			int mask = (1 << bits) - 1;
			offset += (int)(((uint)(val & mask)) >> HuffmanTableBits);
			br.bitOffset += ((table[offset] >> 16) + HuffmanTableBits);
			return table[offset] & unchecked((int)(0xFFFF));
			// Console.Error.WriteLine("exit ReadSymbol 3");
		}

		private static int ReadBlockLength(int[] table, int offset, Org.Brotli.Dec.BitReader br)
		{
			Console.Error.WriteLine("enter ReadBlockLength 1");
			Org.Brotli.Dec.BitReader.FillBitWindow(br);
			int code = ReadSymbol(table, offset, br);
			int n = Org.Brotli.Dec.Prefix.BlockLengthNBits[code];
			return Org.Brotli.Dec.Prefix.BlockLengthOffset[code] + Org.Brotli.Dec.BitReader.ReadBits(br, n);
			// Console.Error.WriteLine("exit ReadBlockLength 1");
		}

		private static int TranslateShortCodes(int code, int[] ringBuffer, int index)
		{
			Console.Error.WriteLine("enter TranslateShortCodes 1");
			if (code < NumDistanceShortCodes)
			{
				Console.Error.WriteLine("enter TranslateShortCodes 2");
				index += DistanceShortCodeIndexOffset[code];
				index &= 3;
				return ringBuffer[index] + DistanceShortCodeValueOffset[code];
				// Console.Error.WriteLine("exit TranslateShortCodes 2");
			}
			
			Console.Error.WriteLine("enter TranslateShortCodes 3");
			return code - NumDistanceShortCodes + 1;
			// Console.Error.WriteLine("exit TranslateShortCodes 3");
			// Console.Error.WriteLine("exit TranslateShortCodes 1");
		}

		private static void MoveToFront(int[] v, int index)
		{
			Console.Error.WriteLine("enter MoveToFront 1");
			int value = v[index];
			for (; index > 0; index--)
			{
				Console.Error.WriteLine("enter MoveToFront 2");
				v[index] = v[index - 1];
				// Console.Error.WriteLine("exit MoveToFront 2");
			}
			
			Console.Error.WriteLine("enter MoveToFront 3");
			v[0] = value;
			// Console.Error.WriteLine("exit MoveToFront 3");
			// Console.Error.WriteLine("exit MoveToFront 1");
		}

		private static void InverseMoveToFrontTransform(byte[] v, int vLen)
		{
			Console.Error.WriteLine("enter InverseMoveToFrontTransform 1");
			int[] mtf = new int[256];
			for (int i = 0; i < 256; i++)
			{
				Console.Error.WriteLine("enter InverseMoveToFrontTransform 2");
				mtf[i] = i;
				// Console.Error.WriteLine("exit InverseMoveToFrontTransform 2");
			}
			
			Console.Error.WriteLine("enter InverseMoveToFrontTransform 3");
			for (int i = 0; i < vLen; i++)
			{
				Console.Error.WriteLine("enter InverseMoveToFrontTransform 4");
				int index = v[i] & unchecked((int)(0xFF));
				v[i] = unchecked((byte)mtf[index]);
				// Console.Error.WriteLine("exit InverseMoveToFrontTransform 4");
				
				if (index != 0)
				{
					Console.Error.WriteLine("enter InverseMoveToFrontTransform 5");
					MoveToFront(mtf, index);
					// Console.Error.WriteLine("exit InverseMoveToFrontTransform 5");
				}
			}
			// Console.Error.WriteLine("exit InverseMoveToFrontTransform 3");
			// Console.Error.WriteLine("exit InverseMoveToFrontTransform 1");
		}

		private static void ReadHuffmanCodeLengths(int[] codeLengthCodeLengths, int numSymbols, int[] codeLengths, Org.Brotli.Dec.BitReader br)
		{
			Console.Error.WriteLine("enter ReadHuffmanCodeLengths 1");
			int symbol = 0;
			int prevCodeLen = DefaultCodeLength;
			int repeat = 0;
			int repeatCodeLen = 0;
			int space = 32768;
			int[] table = new int[32];
			Org.Brotli.Dec.Huffman.BuildHuffmanTable(table, 0, 5, codeLengthCodeLengths, CodeLengthCodes);
			// Console.Error.WriteLine("exit ReadHuffmanCodeLengths 1");
			
			while (symbol < numSymbols && space > 0)
			{
				Console.Error.WriteLine("enter ReadHuffmanCodeLengths 2");
				Org.Brotli.Dec.BitReader.ReadMoreInput(br);
				Org.Brotli.Dec.BitReader.FillBitWindow(br);
				int p = (int)(((long)(((ulong)br.accumulator) >> br.bitOffset))) & 31;
				br.bitOffset += table[p] >> 16;
				int codeLen = table[p] & unchecked((int)(0xFFFF));
				// Console.Error.WriteLine("exit ReadHuffmanCodeLengths 2");
				
				if (codeLen < CodeLengthRepeatCode)
				{
					Console.Error.WriteLine("enter ReadHuffmanCodeLengths 3");
					repeat = 0;
					codeLengths[symbol++] = codeLen;
					// Console.Error.WriteLine("exit ReadHuffmanCodeLengths 3");
					
					if (codeLen != 0)
					{
						Console.Error.WriteLine("enter ReadHuffmanCodeLengths 4");
						prevCodeLen = codeLen;
						space -= 32768 >> codeLen;
						// Console.Error.WriteLine("exit ReadHuffmanCodeLengths 4");
					}
				}
				else
				{
					Console.Error.WriteLine("enter ReadHuffmanCodeLengths 5");
					int extraBits = codeLen - 14;
					int newLen = 0;
					// Console.Error.WriteLine("exit ReadHuffmanCodeLengths 5");
					
					if (codeLen == CodeLengthRepeatCode)
					{
						Console.Error.WriteLine("enter ReadHuffmanCodeLengths 6");
						newLen = prevCodeLen;
						// Console.Error.WriteLine("exit ReadHuffmanCodeLengths 6");
					}
					
					Console.Error.WriteLine("enter ReadHuffmanCodeLengths 7");
					if (repeatCodeLen != newLen)
					{
						Console.Error.WriteLine("enter ReadHuffmanCodeLengths 8");
						repeat = 0;
						repeatCodeLen = newLen;
						// Console.Error.WriteLine("exit ReadHuffmanCodeLengths 8");
					}
					
					int oldRepeat = repeat;
					// Console.Error.WriteLine("exit ReadHuffmanCodeLengths 7");
					
					if (repeat > 0)
					{
						Console.Error.WriteLine("enter ReadHuffmanCodeLengths 9");
						repeat -= 2;
						repeat <<= extraBits;
						// Console.Error.WriteLine("exit ReadHuffmanCodeLengths 9");
					}
					
					Console.Error.WriteLine("enter ReadHuffmanCodeLengths 10");
					repeat += Org.Brotli.Dec.BitReader.ReadBits(br, extraBits) + 3;
					int repeatDelta = repeat - oldRepeat;
					// Console.Error.WriteLine("exit ReadHuffmanCodeLengths 10");
					
					if (symbol + repeatDelta > numSymbols)
					{
						Console.Error.WriteLine("enter ReadHuffmanCodeLengths 11");
						throw new Org.Brotli.Dec.BrotliRuntimeException("symbol + repeatDelta > numSymbols");
						// Console.Error.WriteLine("exit ReadHuffmanCodeLengths 11");
					}
					
					Console.Error.WriteLine("enter ReadHuffmanCodeLengths 12");
					// COV_NF_LINE
					for (int i = 0; i < repeatDelta; i++)
					{
						Console.Error.WriteLine("enter ReadHuffmanCodeLengths 13");
						codeLengths[symbol++] = repeatCodeLen;
						// Console.Error.WriteLine("exit ReadHuffmanCodeLengths 13");
					}
					// Console.Error.WriteLine("exit ReadHuffmanCodeLengths 12");
					
					if (repeatCodeLen != 0)
					{
						Console.Error.WriteLine("enter ReadHuffmanCodeLengths 14");
						space -= repeatDelta << (15 - repeatCodeLen);
						// Console.Error.WriteLine("exit ReadHuffmanCodeLengths 14");
					}
				}
			}
			
			Console.Error.WriteLine("enter ReadHuffmanCodeLengths 15");
			if (space != 0)
			{
				Console.Error.WriteLine("enter ReadHuffmanCodeLengths 16");
				throw new Org.Brotli.Dec.BrotliRuntimeException("Unused space");
				// Console.Error.WriteLine("exit ReadHuffmanCodeLengths 16");
			}
			
			// COV_NF_LINE
			// TODO: Pass max_symbol to Huffman table builder instead?
			Org.Brotli.Dec.Utils.FillWithZeroes(codeLengths, symbol, numSymbols - symbol);
			// Console.Error.WriteLine("exit ReadHuffmanCodeLengths 15");
		}

		// TODO: Use specialized versions for smaller tables.
		internal static void ReadHuffmanCode(int alphabetSize, int[] table, int offset, Org.Brotli.Dec.BitReader br)
		{
			Console.Error.WriteLine("enter ReadHuffmanCode 1");
			bool ok = true;
			int simpleCodeOrSkip;
			Org.Brotli.Dec.BitReader.ReadMoreInput(br);
			// TODO: Avoid allocation.
			int[] codeLengths = new int[alphabetSize];
			simpleCodeOrSkip = Org.Brotli.Dec.BitReader.ReadBits(br, 2);
			// Console.Error.WriteLine("exit ReadHuffmanCode 1");
			
			if (simpleCodeOrSkip == 1)
			{
				Console.Error.WriteLine("enter ReadHuffmanCode 2");
				// Read symbols, codes & code lengths directly.
				int maxBitsCounter = alphabetSize - 1;
				int maxBits = 0;
				int[] symbols = new int[4];
				int numSymbols = Org.Brotli.Dec.BitReader.ReadBits(br, 2) + 1;
				// Console.Error.WriteLine("exit ReadHuffmanCode 2");
				
				while (maxBitsCounter != 0)
				{
					Console.Error.WriteLine("enter ReadHuffmanCode 3");
					maxBitsCounter >>= 1;
					maxBits++;
					// Console.Error.WriteLine("exit ReadHuffmanCode 3");
				}
				
				Console.Error.WriteLine("enter ReadHuffmanCode 4");
				// TODO: uncomment when codeLengths is reused.
				// Utils.fillWithZeroes(codeLengths, 0, alphabetSize);
				for (int i = 0; i < numSymbols; i++)
				{
					Console.Error.WriteLine("enter ReadHuffmanCode 5");
					symbols[i] = Org.Brotli.Dec.BitReader.ReadBits(br, maxBits) % alphabetSize;
					codeLengths[symbols[i]] = 2;
					// Console.Error.WriteLine("exit ReadHuffmanCode 5");
				}
				
				codeLengths[symbols[0]] = 1;
				// Console.Error.WriteLine("exit ReadHuffmanCode 4");
				
				switch (numSymbols)
				{
					case 1:
					{
						Console.Error.WriteLine("enter ReadHuffmanCode 6");
						break;
						// Console.Error.WriteLine("exit ReadHuffmanCode 6");
					}

					case 2:
					{
						Console.Error.WriteLine("enter ReadHuffmanCode 7");
						ok = symbols[0] != symbols[1];
						codeLengths[symbols[1]] = 1;
						break;
						// Console.Error.WriteLine("exit ReadHuffmanCode 7");
					}

					case 3:
					{
						Console.Error.WriteLine("enter ReadHuffmanCode 8");
						ok = symbols[0] != symbols[1] && symbols[0] != symbols[2] && symbols[1] != symbols[2];
						break;
						// Console.Error.WriteLine("exit ReadHuffmanCode 8");
					}

					case 4:
					default:
					{
						Console.Error.WriteLine("enter ReadHuffmanCode 9");
						ok = symbols[0] != symbols[1] && symbols[0] != symbols[2] && symbols[0] != symbols[3] && symbols[1] != symbols[2] && symbols[1] != symbols[3] && symbols[2] != symbols[3];
						// Console.Error.WriteLine("exit ReadHuffmanCode 9");
						
						if (Org.Brotli.Dec.BitReader.ReadBits(br, 1) == 1)
						{
							Console.Error.WriteLine("enter ReadHuffmanCode 10");
							codeLengths[symbols[2]] = 3;
							codeLengths[symbols[3]] = 3;
							// Console.Error.WriteLine("exit ReadHuffmanCode 10");
						}
						else
						{
							Console.Error.WriteLine("enter ReadHuffmanCode 11");
							codeLengths[symbols[0]] = 2;
							// Console.Error.WriteLine("exit ReadHuffmanCode 11");
						}
						break;
					}
				}
			}
			else
			{
				Console.Error.WriteLine("enter ReadHuffmanCode 12");
				// Decode Huffman-coded code lengths.
				int[] codeLengthCodeLengths = new int[CodeLengthCodes];
				int space = 32;
				int numCodes = 0;
				// Console.Error.WriteLine("exit ReadHuffmanCode 12");
				
				for (int i = simpleCodeOrSkip; i < CodeLengthCodes && space > 0; i++)
				{
					Console.Error.WriteLine("enter ReadHuffmanCode 13");
					int codeLenIdx = CodeLengthCodeOrder[i];
					Org.Brotli.Dec.BitReader.FillBitWindow(br);
					int p = (int)((long)(((ulong)br.accumulator) >> br.bitOffset)) & 15;
					// TODO: Demultiplex FIXED_TABLE.
					br.bitOffset += FixedTable[p] >> 16;
					int v = FixedTable[p] & unchecked((int)(0xFFFF));
					codeLengthCodeLengths[codeLenIdx] = v;
					// Console.Error.WriteLine("exit ReadHuffmanCode 13");
					
					if (v != 0)
					{
						Console.Error.WriteLine("enter ReadHuffmanCode 14");
						space -= (32 >> v);
						numCodes++;
						// Console.Error.WriteLine("exit ReadHuffmanCode 14");
					}
				}
				
				Console.Error.WriteLine("enter ReadHuffmanCode 15");
				ok = (numCodes == 1 || space == 0);
				ReadHuffmanCodeLengths(codeLengthCodeLengths, alphabetSize, codeLengths, br);
				// Console.Error.WriteLine("exit ReadHuffmanCode 15");
			}
			
			Console.Error.WriteLine("enter ReadHuffmanCode 16");
			if (!ok)
			{
				Console.Error.WriteLine("enter ReadHuffmanCode 17");
				throw new Org.Brotli.Dec.BrotliRuntimeException("Can't readHuffmanCode");
				// Console.Error.WriteLine("exit ReadHuffmanCode 17");
			}
			
			// COV_NF_LINE
			Org.Brotli.Dec.Huffman.BuildHuffmanTable(table, offset, HuffmanTableBits, codeLengths, alphabetSize);
			// Console.Error.WriteLine("exit ReadHuffmanCode 16");
		}

		private static int DecodeContextMap(int contextMapSize, byte[] contextMap, Org.Brotli.Dec.BitReader br)
		{
			Console.Error.WriteLine("enter DecodeContextMap 1");
			Org.Brotli.Dec.BitReader.ReadMoreInput(br);
			int numTrees = DecodeVarLenUnsignedByte(br) + 1;
			// Console.Error.WriteLine("exit DecodeContextMap 1");
			
			if (numTrees == 1)
			{
				Console.Error.WriteLine("enter DecodeContextMap 2");
				Org.Brotli.Dec.Utils.FillWithZeroes(contextMap, 0, contextMapSize);
				return numTrees;
				// Console.Error.WriteLine("exit DecodeContextMap 2");
			}
			
			Console.Error.WriteLine("enter DecodeContextMap 3");
			bool useRleForZeros = Org.Brotli.Dec.BitReader.ReadBits(br, 1) == 1;
			int maxRunLengthPrefix = 0;
			// Console.Error.WriteLine("exit DecodeContextMap 3");
			
			if (useRleForZeros)
			{
				Console.Error.WriteLine("enter DecodeContextMap 4");
				maxRunLengthPrefix = Org.Brotli.Dec.BitReader.ReadBits(br, 4) + 1;
				// Console.Error.WriteLine("exit DecodeContextMap 4");
			}
			
			Console.Error.WriteLine("enter DecodeContextMap 5");
			int[] table = new int[Org.Brotli.Dec.Huffman.HuffmanMaxTableSize];
			ReadHuffmanCode(numTrees + maxRunLengthPrefix, table, 0, br);
			// Console.Error.WriteLine("exit DecodeContextMap 5");
			
			for (int i = 0; i < contextMapSize; )
			{
				Console.Error.WriteLine("enter DecodeContextMap 6");
				Org.Brotli.Dec.BitReader.ReadMoreInput(br);
				Org.Brotli.Dec.BitReader.FillBitWindow(br);
				int code = ReadSymbol(table, 0, br);
				// Console.Error.WriteLine("exit DecodeContextMap 6");
				
				if (code == 0)
				{
					Console.Error.WriteLine("enter DecodeContextMap 7");
					contextMap[i] = 0;
					i++;
					// Console.Error.WriteLine("exit DecodeContextMap 7");
				}
				else if (code <= maxRunLengthPrefix)
				{
					Console.Error.WriteLine("enter DecodeContextMap 8");
					int reps = (1 << code) + Org.Brotli.Dec.BitReader.ReadBits(br, code);
					// Console.Error.WriteLine("exit DecodeContextMap 8");
					
					while (reps != 0)
					{
						Console.Error.WriteLine("enter DecodeContextMap 9");
						if (i >= contextMapSize)
						{
							Console.Error.WriteLine("enter DecodeContextMap 10");
							throw new Org.Brotli.Dec.BrotliRuntimeException("Corrupted context map");
							// Console.Error.WriteLine("exit DecodeContextMap 10");
						}
						
						// COV_NF_LINE
						contextMap[i] = 0;
						i++;
						reps--;
						// Console.Error.WriteLine("exit DecodeContextMap 9");
					}
				}
				else
				{
					Console.Error.WriteLine("enter DecodeContextMap 11");
					contextMap[i] = unchecked((byte)(code - maxRunLengthPrefix));
					i++;
					// Console.Error.WriteLine("exit DecodeContextMap 11");
				}
			}
			
			Console.Error.WriteLine("enter DecodeContextMap 12");
			if (Org.Brotli.Dec.BitReader.ReadBits(br, 1) == 1)
			{
				Console.Error.WriteLine("enter DecodeContextMap 13");
				InverseMoveToFrontTransform(contextMap, contextMapSize);
				// Console.Error.WriteLine("exit DecodeContextMap 13");
			}
			
			return numTrees;
			// Console.Error.WriteLine("exit DecodeContextMap 12");
		}

		private static void DecodeBlockTypeAndLength(Org.Brotli.Dec.State state, int treeType)
		{
			Console.Error.WriteLine("enter DecodeBlockTypeAndLength 1");
			Org.Brotli.Dec.BitReader br = state.br;
			int[] ringBuffers = state.blockTypeRb;
			int offset = treeType * 2;
			Org.Brotli.Dec.BitReader.FillBitWindow(br);
			int blockType = ReadSymbol(state.blockTypeTrees, treeType * Org.Brotli.Dec.Huffman.HuffmanMaxTableSize, br);
			state.blockLength[treeType] = ReadBlockLength(state.blockLenTrees, treeType * Org.Brotli.Dec.Huffman.HuffmanMaxTableSize, br);
			// Console.Error.WriteLine("exit DecodeBlockTypeAndLength 1");
			
			if (blockType == 1)
			{
				Console.Error.WriteLine("enter DecodeBlockTypeAndLength 2");
				blockType = ringBuffers[offset + 1] + 1;
				// Console.Error.WriteLine("exit DecodeBlockTypeAndLength 2");
			}
			else if (blockType == 0)
			{
				Console.Error.WriteLine("enter DecodeBlockTypeAndLength 3");
				blockType = ringBuffers[offset];
				// Console.Error.WriteLine("exit DecodeBlockTypeAndLength 3");
			}
			else
			{
				Console.Error.WriteLine("enter DecodeBlockTypeAndLength 4");
				blockType -= 2;
				// Console.Error.WriteLine("exit DecodeBlockTypeAndLength 4");
			}
			
			Console.Error.WriteLine("enter DecodeBlockTypeAndLength 5");
			if (blockType >= state.numBlockTypes[treeType])
			{
				Console.Error.WriteLine("enter DecodeBlockTypeAndLength 6");
				blockType -= state.numBlockTypes[treeType];
				// Console.Error.WriteLine("exit DecodeBlockTypeAndLength 6");
			}
			
			ringBuffers[offset] = ringBuffers[offset + 1];
			ringBuffers[offset + 1] = blockType;
			// Console.Error.WriteLine("exit DecodeBlockTypeAndLength 5");
		}

		private static void DecodeLiteralBlockSwitch(Org.Brotli.Dec.State state)
		{
			Console.Error.WriteLine("enter DecodeLiteralBlockSwitch 1");
			DecodeBlockTypeAndLength(state, 0);
			int literalBlockType = state.blockTypeRb[1];
			state.contextMapSlice = literalBlockType << LiteralContextBits;
			state.literalTreeIndex = state.contextMap[state.contextMapSlice] & unchecked((int)(0xFF));
			state.literalTree = state.hGroup0.trees[state.literalTreeIndex];
			int contextMode = state.contextModes[literalBlockType];
			state.contextLookupOffset1 = Org.Brotli.Dec.Context.LookupOffsets[contextMode];
			state.contextLookupOffset2 = Org.Brotli.Dec.Context.LookupOffsets[contextMode + 1];
			// Console.Error.WriteLine("exit DecodeLiteralBlockSwitch 1");
		}

		private static void DecodeCommandBlockSwitch(Org.Brotli.Dec.State state)
		{
			Console.Error.WriteLine("enter DecodeCommandBlockSwitch 1");
			DecodeBlockTypeAndLength(state, 1);
			state.treeCommandOffset = state.hGroup1.trees[state.blockTypeRb[3]];
			// Console.Error.WriteLine("exit DecodeCommandBlockSwitch 1");
		}

		private static void DecodeDistanceBlockSwitch(Org.Brotli.Dec.State state)
		{
			Console.Error.WriteLine("enter DecodeDistanceBlockSwitch 1");
			DecodeBlockTypeAndLength(state, 2);
			state.distContextMapSlice = state.blockTypeRb[5] << DistanceContextBits;
			// Console.Error.WriteLine("exit DecodeDistanceBlockSwitch 1");
		}

		private static void MaybeReallocateRingBuffer(Org.Brotli.Dec.State state)
		{
			Console.Error.WriteLine("enter MaybeReallocateRingBuffer 1");
			int newSize = state.maxRingBufferSize;
			// Console.Error.WriteLine("exit MaybeReallocateRingBuffer 1");
			
			if ((long)newSize > state.expectedTotalSize)
			{
				Console.Error.WriteLine("enter MaybeReallocateRingBuffer 2");
				/* TODO: Handle 2GB+ cases more gracefully. */
				int minimalNewSize = (int)state.expectedTotalSize + state.customDictionary.Length;
				// Console.Error.WriteLine("exit MaybeReallocateRingBuffer 2");
				
				while ((newSize >> 1) > minimalNewSize)
				{
					Console.Error.WriteLine("enter MaybeReallocateRingBuffer 3");
					newSize >>= 1;
					// Console.Error.WriteLine("exit MaybeReallocateRingBuffer 3");
				}
				
				Console.Error.WriteLine("enter MaybeReallocateRingBuffer 4");
				if (!state.inputEnd && newSize < 16384 && state.maxRingBufferSize >= 16384)
				{
					Console.Error.WriteLine("enter MaybeReallocateRingBuffer 5");
					newSize = 16384;
					// Console.Error.WriteLine("exit MaybeReallocateRingBuffer 5");
				}
				// Console.Error.WriteLine("exit MaybeReallocateRingBuffer 4");
			}
			
			Console.Error.WriteLine("enter MaybeReallocateRingBuffer 6");
			if (newSize <= state.ringBufferSize)
			{
				Console.Error.WriteLine("enter MaybeReallocateRingBuffer 7");
				return;
				// Console.Error.WriteLine("exit MaybeReallocateRingBuffer 7");
			}
			
			int ringBufferSizeWithSlack = newSize + Org.Brotli.Dec.Dictionary.MaxTransformedWordLength;
			byte[] newBuffer = new byte[ringBufferSizeWithSlack];
			// Console.Error.WriteLine("exit MaybeReallocateRingBuffer 6");
			
			if (state.ringBuffer != null)
			{
				Console.Error.WriteLine("enter MaybeReallocateRingBuffer 8");
				System.Array.Copy(state.ringBuffer, 0, newBuffer, 0, state.ringBufferSize);
				// Console.Error.WriteLine("exit MaybeReallocateRingBuffer 8");
			}
			else if (state.customDictionary.Length != 0)
			{
				Console.Error.WriteLine("enter MaybeReallocateRingBuffer 9");
				/* Prepend custom dictionary, if any. */
				int length = state.customDictionary.Length;
				int offset = 0;
				// Console.Error.WriteLine("exit MaybeReallocateRingBuffer 9");
				
				if (length > state.maxBackwardDistance)
				{
					Console.Error.WriteLine("enter MaybeReallocateRingBuffer 10");
					offset = length - state.maxBackwardDistance;
					length = state.maxBackwardDistance;
					// Console.Error.WriteLine("exit MaybeReallocateRingBuffer 10");
				}
				
				Console.Error.WriteLine("enter MaybeReallocateRingBuffer 11");
				System.Array.Copy(state.customDictionary, offset, newBuffer, 0, length);
				state.pos = length;
				state.bytesToIgnore = length;
				// Console.Error.WriteLine("exit MaybeReallocateRingBuffer 11");
			}
			
			Console.Error.WriteLine("enter MaybeReallocateRingBuffer 12");
			state.ringBuffer = newBuffer;
			state.ringBufferSize = newSize;
			// Console.Error.WriteLine("exit MaybeReallocateRingBuffer 12");
		}

		/// <summary>Reads next metablock header.</summary>
		/// <param name="state">decoding state</param>
		private static void ReadMetablockInfo(Org.Brotli.Dec.State state)
		{
			Console.Error.WriteLine("enter ReadMetablockInfo 1");
			Org.Brotli.Dec.BitReader br = state.br;
			// Console.Error.WriteLine("exit ReadMetablockInfo 1");
			
			if (state.inputEnd)
			{
				Console.Error.WriteLine("enter ReadMetablockInfo 2");
				state.nextRunningState = Org.Brotli.Dec.RunningState.Finished;
				state.bytesToWrite = state.pos;
				state.bytesWritten = 0;
				state.runningState = Org.Brotli.Dec.RunningState.Write;
				return;
				// Console.Error.WriteLine("exit ReadMetablockInfo 2");
			}
			
			Console.Error.WriteLine("enter ReadMetablockInfo 3");
			// TODO: Reset? Do we need this?
			state.hGroup0.codes = null;
			state.hGroup0.trees = null;
			state.hGroup1.codes = null;
			state.hGroup1.trees = null;
			state.hGroup2.codes = null;
			state.hGroup2.trees = null;
			Org.Brotli.Dec.BitReader.ReadMoreInput(br);
			DecodeMetaBlockLength(br, state);
			// Console.Error.WriteLine("exit ReadMetablockInfo 3");
			
			if (state.metaBlockLength == 0 && !state.isMetadata)
			{
				Console.Error.WriteLine("enter ReadMetablockInfo 4");
				return;
				// Console.Error.WriteLine("exit ReadMetablockInfo 4");
			}
			
			Console.Error.WriteLine("enter ReadMetablockInfo 5");
			if (state.isUncompressed || state.isMetadata)
			{
				Console.Error.WriteLine("enter ReadMetablockInfo 6");
				Org.Brotli.Dec.BitReader.JumpToByteBoundary(br);
				state.runningState = state.isMetadata ? Org.Brotli.Dec.RunningState.ReadMetadata : Org.Brotli.Dec.RunningState.CopyUncompressed;
				// Console.Error.WriteLine("exit ReadMetablockInfo 6");
			}
			else
			{
				Console.Error.WriteLine("enter ReadMetablockInfo 7");
				state.runningState = Org.Brotli.Dec.RunningState.CompressedBlockStart;
				// Console.Error.WriteLine("exit ReadMetablockInfo 7");
			}
			// Console.Error.WriteLine("exit ReadMetablockInfo 5");
			
			if (state.isMetadata)
			{
				Console.Error.WriteLine("enter ReadMetablockInfo 8");
				return;
				// Console.Error.WriteLine("exit ReadMetablockInfo 8");
			}
			
			Console.Error.WriteLine("enter ReadMetablockInfo 9");
			state.expectedTotalSize += state.metaBlockLength;
			// Console.Error.WriteLine("exit ReadMetablockInfo 9");
			
			if (state.ringBufferSize < state.maxRingBufferSize)
			{
				Console.Error.WriteLine("enter ReadMetablockInfo 10");
				MaybeReallocateRingBuffer(state);
				// Console.Error.WriteLine("exit ReadMetablockInfo 10");
			}
		}

		private static void ReadMetablockHuffmanCodesAndContextMaps(Org.Brotli.Dec.State state)
		{
			Console.Error.WriteLine("enter ReadMetablockHuffmanCodesAndContextMaps 1");
			Org.Brotli.Dec.BitReader br = state.br;
			for (int i = 0; i < 3; i++)
			{
				Console.Error.WriteLine("enter ReadMetablockHuffmanCodesAndContextMaps 2");
				state.numBlockTypes[i] = DecodeVarLenUnsignedByte(br) + 1;
				state.blockLength[i] = 1 << 28;
				// Console.Error.WriteLine("exit ReadMetablockHuffmanCodesAndContextMaps 2");
				
				if (state.numBlockTypes[i] > 1)
				{
					Console.Error.WriteLine("enter ReadMetablockHuffmanCodesAndContextMaps 3");
					ReadHuffmanCode(state.numBlockTypes[i] + 2, state.blockTypeTrees, i * Org.Brotli.Dec.Huffman.HuffmanMaxTableSize, br);
					ReadHuffmanCode(NumBlockLengthCodes, state.blockLenTrees, i * Org.Brotli.Dec.Huffman.HuffmanMaxTableSize, br);
					state.blockLength[i] = ReadBlockLength(state.blockLenTrees, i * Org.Brotli.Dec.Huffman.HuffmanMaxTableSize, br);
					// Console.Error.WriteLine("exit ReadMetablockHuffmanCodesAndContextMaps 3");
				}
			}
			
			Org.Brotli.Dec.BitReader.ReadMoreInput(br);
			state.distancePostfixBits = Org.Brotli.Dec.BitReader.ReadBits(br, 2);
			state.numDirectDistanceCodes = NumDistanceShortCodes + (Org.Brotli.Dec.BitReader.ReadBits(br, 4) << state.distancePostfixBits);
			state.distancePostfixMask = (1 << state.distancePostfixBits) - 1;
			int numDistanceCodes = state.numDirectDistanceCodes + (48 << state.distancePostfixBits);
			// TODO: Reuse?
			state.contextModes = new byte[state.numBlockTypes[0]];
			// Console.Error.WriteLine("exit ReadMetablockHuffmanCodesAndContextMaps 1");
			
			for (int i = 0; i < state.numBlockTypes[0]; )
			{
				Console.Error.WriteLine("enter ReadMetablockHuffmanCodesAndContextMaps 4");
				/* Ensure that less than 256 bits read between readMoreInput. */
				int limit = System.Math.Min(i + 96, state.numBlockTypes[0]);
				// Console.Error.WriteLine("exit ReadMetablockHuffmanCodesAndContextMaps 4");
				
				for (; i < limit; ++i)
				{
					Console.Error.WriteLine("enter ReadMetablockHuffmanCodesAndContextMaps 5");
					state.contextModes[i] = unchecked((byte)(Org.Brotli.Dec.BitReader.ReadBits(br, 2) << 1));
					// Console.Error.WriteLine("exit ReadMetablockHuffmanCodesAndContextMaps 5");
				}
				
				Console.Error.WriteLine("enter ReadMetablockHuffmanCodesAndContextMaps 6");
				Org.Brotli.Dec.BitReader.ReadMoreInput(br);
				// Console.Error.WriteLine("exit ReadMetablockHuffmanCodesAndContextMaps 6");
			}
			
			Console.Error.WriteLine("enter ReadMetablockHuffmanCodesAndContextMaps 7");
			// TODO: Reuse?
			state.contextMap = new byte[state.numBlockTypes[0] << LiteralContextBits];
			int numLiteralTrees = DecodeContextMap(state.numBlockTypes[0] << LiteralContextBits, state.contextMap, br);
			state.trivialLiteralContext = true;
			// Console.Error.WriteLine("exit ReadMetablockHuffmanCodesAndContextMaps 7");
			
			for (int j = 0; j < state.numBlockTypes[0] << LiteralContextBits; j++)
			{
				Console.Error.WriteLine("enter ReadMetablockHuffmanCodesAndContextMaps 8");
				if (state.contextMap[j] != j >> LiteralContextBits)
				{
					Console.Error.WriteLine("enter ReadMetablockHuffmanCodesAndContextMaps 9");
					state.trivialLiteralContext = false;
					break;
					// Console.Error.WriteLine("exit ReadMetablockHuffmanCodesAndContextMaps 9");
				}
				// Console.Error.WriteLine("exit ReadMetablockHuffmanCodesAndContextMaps 8");
			}
			
			Console.Error.WriteLine("enter ReadMetablockHuffmanCodesAndContextMaps 10");
			// TODO: Reuse?
			state.distContextMap = new byte[state.numBlockTypes[2] << DistanceContextBits];
			int numDistTrees = DecodeContextMap(state.numBlockTypes[2] << DistanceContextBits, state.distContextMap, br);
			Org.Brotli.Dec.HuffmanTreeGroup.Init(state.hGroup0, NumLiteralCodes, numLiteralTrees);
			Org.Brotli.Dec.HuffmanTreeGroup.Init(state.hGroup1, NumInsertAndCopyCodes, state.numBlockTypes[1]);
			Org.Brotli.Dec.HuffmanTreeGroup.Init(state.hGroup2, numDistanceCodes, numDistTrees);
			Org.Brotli.Dec.HuffmanTreeGroup.Decode(state.hGroup0, br);
			Org.Brotli.Dec.HuffmanTreeGroup.Decode(state.hGroup1, br);
			Org.Brotli.Dec.HuffmanTreeGroup.Decode(state.hGroup2, br);
			state.contextMapSlice = 0;
			state.distContextMapSlice = 0;
			state.contextLookupOffset1 = Org.Brotli.Dec.Context.LookupOffsets[state.contextModes[0]];
			state.contextLookupOffset2 = Org.Brotli.Dec.Context.LookupOffsets[state.contextModes[0] + 1];
			state.literalTreeIndex = 0;
			state.literalTree = state.hGroup0.trees[0];
			state.treeCommandOffset = state.hGroup1.trees[0];
			// TODO: == 0?
			state.blockTypeRb[0] = state.blockTypeRb[2] = state.blockTypeRb[4] = 1;
			state.blockTypeRb[1] = state.blockTypeRb[3] = state.blockTypeRb[5] = 0;
			// Console.Error.WriteLine("exit ReadMetablockHuffmanCodesAndContextMaps 10");
		}

		private static void CopyUncompressedData(Org.Brotli.Dec.State state)
		{
			Console.Error.WriteLine("enter CopyUncompressedData 1");
			Org.Brotli.Dec.BitReader br = state.br;
			byte[] ringBuffer = state.ringBuffer;
			// Could happen if block ends at ring buffer end.
			// Console.Error.WriteLine("exit CopyUncompressedData 1");
			
			if (state.metaBlockLength <= 0)
			{
				Console.Error.WriteLine("enter CopyUncompressedData 2");
				Org.Brotli.Dec.BitReader.Reload(br);
				state.runningState = Org.Brotli.Dec.RunningState.BlockStart;
				return;
				// Console.Error.WriteLine("exit CopyUncompressedData 2");
			}
			
			Console.Error.WriteLine("enter CopyUncompressedData 3");
			int chunkLength = System.Math.Min(state.ringBufferSize - state.pos, state.metaBlockLength);
			Org.Brotli.Dec.BitReader.CopyBytes(br, ringBuffer, state.pos, chunkLength);
			state.metaBlockLength -= chunkLength;
			state.pos += chunkLength;
			// Console.Error.WriteLine("exit CopyUncompressedData 3");
			
			if (state.pos == state.ringBufferSize)
			{
				Console.Error.WriteLine("enter CopyUncompressedData 4");
				state.nextRunningState = Org.Brotli.Dec.RunningState.CopyUncompressed;
				state.bytesToWrite = state.ringBufferSize;
				state.bytesWritten = 0;
				state.runningState = Org.Brotli.Dec.RunningState.Write;
				return;
				// Console.Error.WriteLine("exit CopyUncompressedData 4");
			}
			
			Console.Error.WriteLine("enter CopyUncompressedData 5");
			Org.Brotli.Dec.BitReader.Reload(br);
			state.runningState = Org.Brotli.Dec.RunningState.BlockStart;
			// Console.Error.WriteLine("exit CopyUncompressedData 5");
		}

		private static bool WriteRingBuffer(Org.Brotli.Dec.State state)
		{
			Console.Error.WriteLine("enter WriteRingBuffer 1");
			/* Ignore custom dictionary bytes. */
			if (state.bytesToIgnore != 0)
			{
				Console.Error.WriteLine("enter WriteRingBuffer 2");
				state.bytesWritten += state.bytesToIgnore;
				state.bytesToIgnore = 0;
				// Console.Error.WriteLine("exit WriteRingBuffer 2");
			}
			
			int toWrite = System.Math.Min(state.outputLength - state.outputUsed, state.bytesToWrite - state.bytesWritten);
			// Console.Error.WriteLine("exit WriteRingBuffer 1");
			
			if (toWrite != 0)
			{
				Console.Error.WriteLine("enter WriteRingBuffer 3");
				System.Array.Copy(state.ringBuffer, state.bytesWritten, state.output, state.outputOffset + state.outputUsed, toWrite);
				state.outputUsed += toWrite;
				state.bytesWritten += toWrite;
				// Console.Error.WriteLine("exit WriteRingBuffer 3");
			}
			
			Console.Error.WriteLine("enter WriteRingBuffer 4");
			return state.outputUsed < state.outputLength;
			// Console.Error.WriteLine("exit WriteRingBuffer 4");
		}

		internal static void SetCustomDictionary(Org.Brotli.Dec.State state, byte[] data)
		{
			Console.Error.WriteLine("enter SetCustomDictionary 1");
			state.customDictionary = (data == null) ? new byte[0] : data;
			// Console.Error.WriteLine("exit SetCustomDictionary 1");
		}
