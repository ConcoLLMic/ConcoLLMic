/* Copyright 2015 Google Inc. All Rights Reserved.

Distributed under MIT license.
See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/
using System;

namespace Org.Brotli.Dec
{
	/// <summary>
	/// Tests for
	/// <see cref="Dictionary"/>
	/// .
	/// </summary>
	public class DictionaryTest
	{
		private static long Crc64(byte[] data)
		{
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/DictionaryTest.cs] enter Crc64 1");
			long crc = -1;
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/DictionaryTest.cs] exit Crc64 1");
			
			for (int i = 0; i < data.Length; ++i)
			{
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/DictionaryTest.cs] enter Crc64 2");
				long c = (crc ^ (long)(data[i] & unchecked((int)(0xFF)))) & unchecked((int)(0xFF));
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/DictionaryTest.cs] exit Crc64 2");
				
				for (int k = 0; k < 8; k++)
				{
					Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/DictionaryTest.cs] enter Crc64 3");
					c = ((long)(((ulong)c) >> 1)) ^ (-(c & 1L) & -3932672073523589310L);
					// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/DictionaryTest.cs] exit Crc64 3");
				}
				
				Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/DictionaryTest.cs] enter Crc64 4");
				crc = c ^ ((long)(((ulong)crc) >> 8));
				// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/DictionaryTest.cs] exit Crc64 4");
			}
			
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/DictionaryTest.cs] enter Crc64 5");
			return ~crc;
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/DictionaryTest.cs] exit Crc64 5");
		}

		[NUnit.Framework.Test]
		public virtual void TestGetData()
		{
			Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/DictionaryTest.cs] enter TestGetData 1");
			NUnit.Framework.Assert.AreEqual(37084801881332636L, Crc64(Org.Brotli.Dec.Dictionary.GetData()));
			// Console.Error.WriteLine("[brotli/csharp/org/brotli/dec/DictionaryTest.cs] exit TestGetData 1");
		}
	}
}
// Total cost: 0.011043
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 36)]
// Total instrumented cost: 0.011043, input tokens: 2398, output tokens: 577, cache read tokens: 2394, cache write tokens: 442
