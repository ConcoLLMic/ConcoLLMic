/* Copyright 2017 Google Inc. All Rights Reserved.

Distributed under MIT license.
See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/
using System;

namespace Org.Brotli.Dec
{
	/// <summary>Byte-to-int conversion magic.</summary>
	internal sealed class IntReader
	{
		private byte[] byteBuffer;

		private int[] intBuffer;

		internal static void Init(Org.Brotli.Dec.IntReader ir, byte[] byteBuffer, int[] intBuffer)
		{
			Console.Error.Write("[brotli/csharp/org/brotli/dec/IntReader.cs] enter Init 1\n");
			ir.byteBuffer = byteBuffer;
			ir.intBuffer = intBuffer;
			// Console.Error.Write("[brotli/csharp/org/brotli/dec/IntReader.cs] exit Init 1\n");
		}

		/// <summary>Translates bytes to ints.</summary>
		/// <remarks>
		/// Translates bytes to ints.
		/// NB: intLen == 4 * byteSize!
		/// NB: intLen should be less or equal to intBuffer length.
		/// </remarks>
		internal static void Convert(Org.Brotli.Dec.IntReader ir, int intLen)
		{
			Console.Error.Write("[brotli/csharp/org/brotli/dec/IntReader.cs] enter Convert 1\n");
			for (int i = 0; i < intLen; ++i)
			{
				Console.Error.Write("[brotli/csharp/org/brotli/dec/IntReader.cs] enter Convert 2\n");
				ir.intBuffer[i] = ((ir.byteBuffer[i * 4] & unchecked((int)(0xFF)))) | ((ir.byteBuffer[(i * 4) + 1] & unchecked((int)(0xFF))) << 8) | ((ir.byteBuffer[(i * 4) + 2] & unchecked((int)(0xFF))) << 16) | ((ir.byteBuffer[(i * 4) + 3] & unchecked((int
					)(0xFF))) << 24);
				// Console.Error.Write("[brotli/csharp/org/brotli/dec/IntReader.cs] exit Convert 2\n");
			}
			// Console.Error.Write("[brotli/csharp/org/brotli/dec/IntReader.cs] exit Convert 1\n");
		}
	}
}
// Total cost: 0.010758
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 36)]
// Total instrumented cost: 0.010758, input tokens: 2398, output tokens: 540, cache read tokens: 2394, cache write tokens: 514
