/* Copyright 2016 Google Inc. All Rights Reserved.
   Author: zip753@gmail.com (Ivan Nikulin)

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

/* Tool for generating optimal backward references for the input file. Uses
   sais-lite library for building suffix array. */

#include <algorithm>
#include <cassert>
#include <cstdio>
#include <cstring>
#include <functional>
#include <utility>
#include <vector>

#include <gflags/gflags.h>
using gflags::ParseCommandLineFlags;

#include "./esaxx/sais.hxx"

DEFINE_bool(advanced, false, "Advanced searching mode: finds all longest "
    "matches at positions that are not covered by matches of length at least "
    "max_length. WARNING: uses much more memory than simple mode, especially "
    "for small values of min_length.");
DEFINE_int32(min_length, 1, "Minimal length of found backward references.");
/* For advanced mode. */
DEFINE_int32(long_length, 32,
             "Maximal length of found backward references for advanced mode.");
DEFINE_int32(skip, 1, "Number of bytes to skip.");

const size_t kFileBufferSize = (1 << 16);  // 64KB

typedef int sarray_type;  // Can't make it unsigned because of templates :(
typedef uint8_t input_type;
typedef uint32_t lcp_type;
typedef std::pair<int, std::vector<int> > entry_type;
typedef std::function<void(sarray_type*, lcp_type*, size_t, int, int, int, int,
                           int)> Fn;

void ReadInput(FILE* fin, input_type* storage, size_t input_size) {
  fprintf(stderr, "[brotli/research/find_opt_references.cc] enter ReadInput 1\n");
  size_t last_pos = 0;
  size_t available_in;
  fseek(fin, 0, SEEK_SET);
  do {
    fprintf(stderr, "[brotli/research/find_opt_references.cc] enter ReadInput 2\n");
    available_in = fread(storage + last_pos, 1, kFileBufferSize, fin);
    last_pos += available_in;
    // fprintf(stderr, "[brotli/research/find_opt_references.cc] exit ReadInput 2\n");
  } while (available_in != 0);
  assert(last_pos == input_size);
  // fprintf(stderr, "[brotli/research/find_opt_references.cc] exit ReadInput 1\n");
}

void BuildLCP(input_type* storage, sarray_type* sarray, lcp_type* lcp,
              size_t size, uint32_t* pos) {
  fprintf(stderr, "[brotli/research/find_opt_references.cc] enter BuildLCP 1\n");
  for (int i = 0; i < size; ++i) {
    fprintf(stderr, "[brotli/research/find_opt_references.cc] enter BuildLCP 2\n");
    pos[sarray[i]] = i;
    // fprintf(stderr, "[brotli/research/find_opt_references.cc] exit BuildLCP 2\n");
  }
  uint32_t k = 0;
  lcp[size - 1] = 0;
  for (int i = 0; i < size; ++i) {
    fprintf(stderr, "[brotli/research/find_opt_references.cc] enter BuildLCP 3\n");
    if (pos[i] == size - 1) {
      fprintf(stderr, "[brotli/research/find_opt_references.cc] enter BuildLCP 4\n");
      k = 0;
      continue;
      // fprintf(stderr, "[brotli/research/find_opt_references.cc] exit BuildLCP 4\n");
    }
    uint32_t j = sarray[pos[i] + 1];  // Suffix which follow i-th suffix in SA.
    while (i + k < size && j + k < size && storage[i + k] == storage[j + k]) {
      fprintf(stderr, "[brotli/research/find_opt_references.cc] enter BuildLCP 5\n");
      ++k;
      // fprintf(stderr, "[brotli/research/find_opt_references.cc] exit BuildLCP 5\n");
    }
    lcp[pos[i]] = k;
    if (k > 0) --k;
    // fprintf(stderr, "[brotli/research/find_opt_references.cc] exit BuildLCP 3\n");
  }
  // fprintf(stderr, "[brotli/research/find_opt_references.cc] exit BuildLCP 1\n");
}

inline void PrintReference(sarray_type* sarray, lcp_type* lcp, size_t size,
                           int idx, int left_ix, int right_ix, int left_lcp,
                           int right_lcp, FILE* fout) {
  fprintf(stderr, "[brotli/research/find_opt_references.cc] enter PrintReference 1\n");
  int max_lcp_ix;
  if (right_ix == size - 1 || (left_ix >= 0 && left_lcp >= right_lcp)) {
    fprintf(stderr, "[brotli/research/find_opt_references.cc] enter PrintReference 2\n");
    max_lcp_ix = left_ix;
    // fprintf(stderr, "[brotli/research/find_opt_references.cc] exit PrintReference 2\n");
  } else {
    fprintf(stderr, "[brotli/research/find_opt_references.cc] enter PrintReference 3\n");
    max_lcp_ix = right_ix;
    // fprintf(stderr, "[brotli/research/find_opt_references.cc] exit PrintReference 3\n");
  }
  int dist = idx - sarray[max_lcp_ix];
  assert(dist > 0);
  fputc(1, fout);
  fwrite(&idx, sizeof(int), 1, fout);   // Position in input.
  fwrite(&dist, sizeof(int), 1, fout);  // Backward distance.
  // fprintf(stderr, "[brotli/research/find_opt_references.cc] exit PrintReference 1\n");
}

inline void GoLeft(sarray_type* sarray, lcp_type* lcp, int idx, int left_ix,
                   int left_lcp, entry_type* entry) {
  fprintf(stderr, "[brotli/research/find_opt_references.cc] enter GoLeft 1\n");
  entry->first = left_lcp;
  if (left_lcp > FLAGS_long_length) return;
  for (; left_ix >= 0; --left_ix) {
    fprintf(stderr, "[brotli/research/find_opt_references.cc] enter GoLeft 2\n");
    if (lcp[left_ix] < left_lcp) break;
    if (sarray[left_ix] < idx) {
      fprintf(stderr, "[brotli/research/find_opt_references.cc] enter GoLeft 3\n");
      entry->second.push_back(idx - sarray[left_ix]);
      // fprintf(stderr, "[brotli/research/find_opt_references.cc] exit GoLeft 3\n");
    }
    // fprintf(stderr, "[brotli/research/find_opt_references.cc] exit GoLeft 2\n");
  }
  // fprintf(stderr, "[brotli/research/find_opt_references.cc] exit GoLeft 1\n");
}

inline void GoRight(sarray_type* sarray, lcp_type* lcp, int idx, size_t size,
                    int right_ix, int right_lcp, entry_type* entry) {
  fprintf(stderr, "[brotli/research/find_opt_references.cc] enter GoRight 1\n");
  entry->first = right_lcp;
  if (right_lcp > FLAGS_long_length) return;
  for (; right_ix < size - 1; ++right_ix) {
    fprintf(stderr, "[brotli/research/find_opt_references.cc] enter GoRight 2\n");
    if (lcp[right_ix] < right_lcp) break;
    if (sarray[right_ix] < idx) {
      fprintf(stderr, "[brotli/research/find_opt_references.cc] enter GoRight 3\n");
      entry->second.push_back(idx - sarray[right_ix]);
      // fprintf(stderr, "[brotli/research/find_opt_references.cc] exit GoRight 3\n");
    }
    // fprintf(stderr, "[brotli/research/find_opt_references.cc] exit GoRight 2\n");
  }
  // fprintf(stderr, "[brotli/research/find_opt_references.cc] exit GoRight 1\n");
}

inline void StoreReference(sarray_type* sarray, lcp_type* lcp, size_t size,
                           int idx, int left_ix, int right_ix, int left_lcp,
                           int right_lcp, entry_type* entries) {
  fprintf(stderr, "[brotli/research/find_opt_references.cc] enter StoreReference 1\n");
  if (right_ix == size - 1 || (left_ix >= 0 && left_lcp > right_lcp)) {
    fprintf(stderr, "[brotli/research/find_opt_references.cc] enter StoreReference 2\n");
    // right is invalid or left is better
    GoLeft(sarray, lcp, idx, left_ix, left_lcp, &entries[idx]);
    // fprintf(stderr, "[brotli/research/find_opt_references.cc] exit StoreReference 2\n");
  } else if (left_ix < 0 || (right_ix < size - 1 && right_lcp > left_lcp)) {
    fprintf(stderr, "[brotli/research/find_opt_references.cc] enter StoreReference 3\n");
    // left is invalid or right is better
    GoRight(sarray, lcp, idx, size, right_ix, right_lcp, &entries[idx]);
    // fprintf(stderr, "[brotli/research/find_opt_references.cc] exit StoreReference 3\n");
  } else {  // both are valid and of equal length
    fprintf(stderr, "[brotli/research/find_opt_references.cc] enter StoreReference 4\n");
    GoLeft(sarray, lcp, idx, left_ix, left_lcp, &entries[idx]);
    GoRight(sarray, lcp, idx, size, right_ix, right_lcp, &entries[idx]);
    // fprintf(stderr, "[brotli/research/find_opt_references.cc] exit StoreReference 4\n");
  }
  // fprintf(stderr, "[brotli/research/find_opt_references.cc] exit StoreReference 1\n");
}

void ProcessReferences(sarray_type* sarray, lcp_type* lcp, size_t size,
                       uint32_t* pos, const Fn& process_output) {
  fprintf(stderr, "[brotli/research/find_opt_references.cc] enter ProcessReferences 1\n");
  int min_length = FLAGS_min_length;
  for (int idx = FLAGS_skip; idx < size; ++idx) {
    fprintf(stderr, "[brotli/research/find_opt_references.cc] enter ProcessReferences 2\n");
    int left_lcp = -1;
    int left_ix;
    for (left_ix = pos[idx] - 1; left_ix >= 0; --left_ix) {
      fprintf(stderr, "[brotli/research/find_opt_references.cc] enter ProcessReferences 3\n");
      if (left_lcp == -1 || left_lcp > lcp[left_ix]) {
        fprintf(stderr, "[brotli/research/find_opt_references.cc] enter ProcessReferences 4\n");
        left_lcp = lcp[left_ix];
        // fprintf(stderr, "[brotli/research/find_opt_references.cc] exit ProcessReferences 4\n");
      }
      if (left_lcp == 0) break;
      if (sarray[left_ix] < idx) break;
      // fprintf(stderr, "[brotli/research/find_opt_references.cc] exit ProcessReferences 3\n");
    }

    int right_lcp = -1;
    int right_ix;
    for (right_ix = pos[idx]; right_ix < size - 1; ++right_ix) {
      fprintf(stderr, "[brotli/research/find_opt_references.cc] enter ProcessReferences 5\n");
      if (right_lcp == -1 || right_lcp > lcp[right_ix]) {
        fprintf(stderr, "[brotli/research/find_opt_references.cc] enter ProcessReferences 6\n");
        right_lcp = lcp[right_ix];
        // fprintf(stderr, "[brotli/research/find_opt_references.cc] exit ProcessReferences 6\n");
      }
      // Stop if we have better result from the left side already.
      if (right_lcp < left_lcp && left_ix >= 0) break;
      if (right_lcp == 0) break;
      if (sarray[right_ix] < idx) break;
      // fprintf(stderr, "[brotli/research/find_opt_references.cc] exit ProcessReferences 5\n");
    }

    if ((left_ix >= 0 && left_lcp >= min_length) ||
        (right_ix < size - 1 && right_lcp >= min_length)) {
      fprintf(stderr, "[brotli/research/find_opt_references.cc] enter ProcessReferences 7\n");
      process_output(sarray, lcp, size, idx, left_ix, right_ix, left_lcp,
                     right_lcp);
      // fprintf(stderr, "[brotli/research/find_opt_references.cc] exit ProcessReferences 7\n");
    }
    // fprintf(stderr, "[brotli/research/find_opt_references.cc] exit ProcessReferences 2\n");
  }
  // fprintf(stderr, "[brotli/research/find_opt_references.cc] exit ProcessReferences 1\n");
}

void ProcessEntries(entry_type* entries, size_t size, FILE* fout) {
  fprintf(stderr, "[brotli/research/find_opt_references.cc] enter ProcessEntries 1\n");
  int long_length = FLAGS_long_length;
  std::vector<std::pair<int, int> > segments;
  size_t idx;
  for (idx = 0; idx < size;) {
    fprintf(stderr, "[brotli/research/find_opt_references.cc] enter ProcessEntries 2\n");
    entry_type& entry = entries[idx];
    if (entry.first > long_length) {
      fprintf(stderr, "[brotli/research/find_opt_references.cc] enter ProcessEntries 3\n");
      // Add segment.
      if (segments.empty() || segments.back().second < idx) {
        fprintf(stderr, "[brotli/research/find_opt_references.cc] enter ProcessEntries 4\n");
        segments.push_back({idx, idx + entry.first});
        // fprintf(stderr, "[brotli/research/find_opt_references.cc] exit ProcessEntries 4\n");
      } else {
        fprintf(stderr, "[brotli/research/find_opt_references.cc] enter ProcessEntries 5\n");
        segments.back().second = idx + entry.first;
        // fprintf(stderr, "[brotli/research/find_opt_references.cc] exit ProcessEntries 5\n");
      }
      // fprintf(stderr, "[brotli/research/find_opt_references.cc] exit ProcessEntries 3\n");
    }
    ++idx;
    // fprintf(stderr, "[brotli/research/find_opt_references.cc] exit ProcessEntries 2\n");
  }
  printf("Segments generated.\n");
  size_t segments_ix = 0;
  for (idx = 0; idx < size;) {
    fprintf(stderr, "[brotli/research/find_opt_references.cc] enter ProcessEntries 6\n");
    if (idx == segments[segments_ix].first) {
      fprintf(stderr, "[brotli/research/find_opt_references.cc] enter ProcessEntries 7\n");
      // Skip segment.
      idx = segments[segments_ix].second;
      // fprintf(stderr, "[brotli/research/find_opt_references.cc] exit ProcessEntries 7\n");
    } else {
      fprintf(stderr, "[brotli/research/find_opt_references.cc] enter ProcessEntries 8\n");
      for (auto& dist : entries[idx].second) {
        fprintf(stderr, "[brotli/research/find_opt_references.cc] enter ProcessEntries 9\n");
        fputc(1, fout);
        fwrite(&idx, sizeof(int), 1, fout);   // Position in input.
        fwrite(&dist, sizeof(int), 1, fout);  // Backward distance.
        // fprintf(stderr, "[brotli/research/find_opt_references.cc] exit ProcessEntries 9\n");
      }
      ++idx;
      // fprintf(stderr, "[brotli/research/find_opt_references.cc] exit ProcessEntries 8\n");
    }
    // fprintf(stderr, "[brotli/research/find_opt_references.cc] exit ProcessEntries 6\n");
  }
  // fprintf(stderr, "[brotli/research/find_opt_references.cc] exit ProcessEntries 1\n");
}

int main(int argc, char* argv[]) {
  fprintf(stderr, "[brotli/research/find_opt_references.cc] enter main 1\n");
  ParseCommandLineFlags(&argc, &argv, true);
  if (argc != 3) {
    fprintf(stderr, "[brotli/research/find_opt_references.cc] enter main 2\n");
    printf("usage: %s input_file output_file\n", argv[0]);
    return 1;
    // fprintf(stderr, "[brotli/research/find_opt_references.cc] exit main 2\n");
  }

  FILE* fin = fopen(argv[1], "rb");
  FILE* fout = fopen(argv[2], "w");

  fseek(fin, 0, SEEK_END);
  int input_size = ftell(fin);
  fseek(fin, 0, SEEK_SET);
  printf("The file size is %u bytes\n", input_size);

  input_type* storage = new input_type[input_size];

  ReadInput(fin, storage, input_size);
  fclose(fin);

  sarray_type* sarray = new sarray_type[input_size];
  saisxx(storage, sarray, input_size);
  printf("Suffix array calculated.\n");

  // Inverse suffix array.
  uint32_t* pos = new uint32_t[input_size];

  lcp_type* lcp = new lcp_type[input_size];
  BuildLCP(storage, sarray, lcp, input_size, pos);
  printf("LCP array constructed.\n");
  delete[] storage;

  using std::placeholders::_1;
  using std::placeholders::_2;
  using std::placeholders::_3;
  using std::placeholders::_4;
  using std::placeholders::_5;
  using std::placeholders::_6;
  using std::placeholders::_7;
  using std::placeholders::_8;
  entry_type* entries;
  if (FLAGS_advanced) {
    fprintf(stderr, "[brotli/research/find_opt_references.cc] enter main 3\n");
    entries = new entry_type[input_size];
    for (size_t i = 0; i < input_size; ++i) entries[i].first = -1;
    // fprintf(stderr, "[brotli/research/find_opt_references.cc] exit main 3\n");
  }
  Fn print = std::bind(PrintReference, _1, _2, _3, _4, _5, _6, _7, _8, fout);
  Fn store = std::bind(StoreReference, _1, _2, _3, _4, _5, _6, _7, _8, entries);

  ProcessReferences(sarray, lcp, input_size, pos,
                    FLAGS_advanced ? store : print);
  printf("References processed.\n");

  if (FLAGS_advanced) {
    fprintf(stderr, "[brotli/research/find_opt_references.cc] enter main 4\n");
    int good_cnt = 0;
    uint64_t avg_cnt = 0;
    for (size_t i = 0; i < input_size; ++i) {
      fprintf(stderr, "[brotli/research/find_opt_references.cc] enter main 5\n");
      if (entries[i].first != -1) {
        fprintf(stderr, "[brotli/research/find_opt_references.cc] enter main 6\n");
        ++good_cnt;
        avg_cnt += entries[i].second.size();
        // fprintf(stderr, "[brotli/research/find_opt_references.cc] exit main 6\n");
      }
      // fprintf(stderr, "[brotli/research/find_opt_references.cc] exit main 5\n");
    }
    printf("Number of covered positions = %d\n", good_cnt);
    printf("Average number of references per covered position = %.4lf\n",
            static_cast<double>(avg_cnt) / good_cnt);
    ProcessEntries(entries, input_size, fout);
    printf("Entries processed.\n");
    // fprintf(stderr, "[brotli/research/find_opt_references.cc] exit main 4\n");
  }

  fclose(fout);
  return 0;
  // fprintf(stderr, "[brotli/research/find_opt_references.cc] exit main 1\n");
}
// Total cost: 0.081726
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 267)]
// Total instrumented cost: 0.081726, input tokens: 2398, output tokens: 4575, cache read tokens: 2394, cache write tokens: 3299
