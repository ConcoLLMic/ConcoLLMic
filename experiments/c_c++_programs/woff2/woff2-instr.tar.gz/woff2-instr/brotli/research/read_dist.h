/* Copyright 2016 Google Inc. All Rights Reserved.
   Author: zip753@gmail.com (Ivan Nikulin)

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

/* API for reading distances from *.dist file.
   The format of *.dist file is as follows: for each backward reference there is
   a position-distance pair, also a copy length may be specified. Copy length is
   prefixed with flag byte 0, position-distance pair is prefixed with flag
   byte 1. Each number is a 32-bit integer. Copy length always comes before
   position-distance pair. Standalone copy length is allowed, in this case it is
   ignored. */

#ifndef BROTLI_RESEARCH_READ_DIST_H_
#define BROTLI_RESEARCH_READ_DIST_H_

#include <cstdio>
#include <cstdlib>  /* exit, EXIT_FAILURE */

#ifndef CHECK
#define CHECK(X) if (!(X)) exit(EXIT_FAILURE);
#endif

/* Reads backwards reference from .dist file. Sets all missing fields to -1.
   Returns false when EOF is met or input is corrupt. */
bool ReadBackwardReference(FILE* fin, int* copy, int* pos, int* dist) {
  fprintf(stderr, "[brotli/research/read_dist.h] enter ReadBackwardReference 1\n");
  int c = getc(fin);
  if (c == EOF) return false;
  // fprintf(stderr, "[brotli/research/read_dist.h] exit ReadBackwardReference 1\n");
  
  if (c == 0) {
    fprintf(stderr, "[brotli/research/read_dist.h] enter ReadBackwardReference 2\n");
    CHECK(fread(copy, sizeof(int), 1, fin) == 1);
    // fprintf(stderr, "[brotli/research/read_dist.h] exit ReadBackwardReference 2\n");
    
    if ((c = getc(fin)) != 1) {
      fprintf(stderr, "[brotli/research/read_dist.h] enter ReadBackwardReference 3\n");
      ungetc(c, fin);
      *pos = *dist = -1;
      // fprintf(stderr, "[brotli/research/read_dist.h] exit ReadBackwardReference 3\n");
    } else {
      fprintf(stderr, "[brotli/research/read_dist.h] enter ReadBackwardReference 4\n");
      CHECK(fread(pos, sizeof(int), 1, fin) == 1);
      CHECK(fread(dist, sizeof(int), 1, fin) == 1);
      // fprintf(stderr, "[brotli/research/read_dist.h] exit ReadBackwardReference 4\n");
    }
  } else if (c != 1) {
    fprintf(stderr, "[brotli/research/read_dist.h] enter ReadBackwardReference 5\n");
    return false;
    // fprintf(stderr, "[brotli/research/read_dist.h] exit ReadBackwardReference 5\n");
  } else {
    fprintf(stderr, "[brotli/research/read_dist.h] enter ReadBackwardReference 6\n");
    CHECK(fread(pos, sizeof(int), 1, fin) == 1);
    CHECK(fread(dist, sizeof(int), 1, fin) == 1);
    *copy = -1;
    // fprintf(stderr, "[brotli/research/read_dist.h] exit ReadBackwardReference 6\n");
  }
  
  fprintf(stderr, "[brotli/research/read_dist.h] enter ReadBackwardReference 7\n");
  return true;
  // fprintf(stderr, "[brotli/research/read_dist.h] exit ReadBackwardReference 7\n");
}

#endif  /* BROTLI_RESEARCH_READ_DIST_H_ */
// Total cost: 0.015753
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 50)]
// Total instrumented cost: 0.015753, input tokens: 2398, output tokens: 839, cache read tokens: 2394, cache write tokens: 650
