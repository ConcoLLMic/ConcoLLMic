#include <iostream>
#include <string>
#include <vector>
#include <map>
#include "cmdline.h"
#include "esa.hxx"

using namespace std;

int readFile(const char* fn, vector<int>& T){
  fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] enter readFile 1\n");
  FILE* fp = fopen(fn, "rb");
  if (fp == NULL){
    fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] enter readFile 2\n");
    cerr << "cannot open " << fn << endl;
    return -1;
    // fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] exit readFile 2\n");
  }
  // fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] exit readFile 1\n");

  fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] enter readFile 3\n");
  if (fseek(fp, 0, SEEK_END) != 0){
    fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] enter readFile 4\n");
    cerr << "cannot fseek " << fn << endl;
    fclose(fp);
    return -1;
    // fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] exit readFile 4\n");
  }
  // fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] exit readFile 3\n");
  
  fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] enter readFile 5\n");
  int n = ftell(fp);
  rewind(fp);
  if (n < 0){
    fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] enter readFile 6\n");
    cerr << "cannot ftell " << fn << endl;
    fclose(fp);
    return -1;
    // fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] exit readFile 6\n");
  }
  // fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] exit readFile 5\n");
  
  fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] enter readFile 7\n");
  T.resize(n);
  if (fread(&T[0], sizeof(unsigned char), (size_t)n, fp) != (size_t) n){
    fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] enter readFile 8\n");
    cerr << "fread error " << fn << endl;
    fclose(fp);
    return -1;
    // fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] exit readFile 8\n");
  }
  // fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] exit readFile 7\n");

  fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] enter readFile 9\n");
  fclose(fp);
  return 0;
  // fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] exit readFile 9\n");
}

int getID(const string& str, map<string, int>& word2id){
  fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] enter getID 1\n");
  map<string, int>::const_iterator it = word2id.find(str);
  if (it == word2id.end()){
    fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] enter getID 2\n");
    int newID = (int)word2id.size();
    word2id[str] = newID;
    return newID;
    // fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] exit getID 2\n");
  } else {
    fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] enter getID 3\n");
    return it->second;
    // fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] exit getID 3\n");
  }
  // fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] exit getID 1\n");
}

void printSnipet(const vector<int>& T, const int beg, const int len, const vector<string>& id2word){
  fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] enter printSnipet 1\n");
  for (int i = 0; i < len; ++i){
    fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] enter printSnipet 2\n");
    int c = T[beg + i];
    if (id2word.size() > 0){
      fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] enter printSnipet 3\n");
      cout << id2word[c] << " ";
      // fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] exit printSnipet 3\n");
    } else {
      fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] enter printSnipet 4\n");
      cout << (isspace((char)c) ? '_' : (char)c);
      // fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] exit printSnipet 4\n");
    }
    // fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] exit printSnipet 2\n");
  }
  // fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] exit printSnipet 1\n");
}

int main(int argc, char* argv[]){
  fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] enter main 1\n");
  cmdline::parser p;
  p.add("word", 'w', "word type");

  if (!p.parse(argc, argv)){
    fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] enter main 2\n");
    cerr << p.error() << endl
	 << p.usage() << endl;
    return -1;
    // fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] exit main 2\n");
  }
  // fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] exit main 1\n");

  fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] enter main 3\n");
  if (p.rest().size() > 0){
    fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] enter main 4\n");
    cerr << p.usage() << endl;
    return -1;
    // fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] exit main 4\n");
  }
  // fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] exit main 3\n");

  fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] enter main 5\n");
  vector<int> T;

  bool isWord = p.exist("word");
  map<string, int> word2id;
  istreambuf_iterator<char> isit(cin);
  istreambuf_iterator<char> end;

  size_t origLen = 0;
  if (isWord){
    fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] enter main 6\n");
    string word;
    while (isit != end){
      fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] enter main 7\n");
      char c = *isit++;
      if (!isspace(c)){
        fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] enter main 8\n");
	word += c;
        // fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] exit main 8\n");
      } else if (word.size() > 0){
        fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] enter main 9\n");
	T.push_back(getID(word, word2id));
	word = "";
        // fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] exit main 9\n");
      }
      ++origLen;
      // fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] exit main 7\n");
    }
    
    fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] enter main 10\n");
    if (word.size() > 0){
      fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] enter main 11\n");
      T.push_back(getID(word, word2id));
      // fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] exit main 11\n");
    }
    // fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] exit main 10\n");
    // fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] exit main 6\n");
  } else {
    fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] enter main 12\n");
    while (isit != end){
      fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] enter main 13\n");
      T.push_back((unsigned char)(*isit++));
      // fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] exit main 13\n");
    }
    
    fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] enter main 14\n");
    origLen = T.size();
    // fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] exit main 14\n");
    // fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] exit main 12\n");
  }
  // fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] exit main 5\n");

  fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] enter main 15\n");
  vector<string> id2word(word2id.size());
  for (map<string, int>::const_iterator it = word2id.begin();
       it != word2id.end(); ++it){
    fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] enter main 16\n");
    id2word[it->second] = it->first;
    // fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] exit main 16\n");
  }
  // fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] exit main 15\n");

  fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] enter main 17\n");
  vector<int> SA(T.size());
  vector<int> L (T.size());
  vector<int> R (T.size());
  vector<int> D (T.size());

  int k = (isWord) ? (int)id2word.size() : 0x100;
  if (isWord){
    fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] enter main 18\n");
    cerr << "origN:" << origLen << endl;
    // fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] exit main 18\n");
  }
  // fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] exit main 17\n");
  
  fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] enter main 19\n");
  cerr << "    n:" << T.size() << endl;
  cerr << "alpha:" << k        << endl;

  int nodeNum = 0;
  if (esaxx(T.begin(), SA.begin(), 
	    L.begin(), R.begin(), D.begin(), 
	    (int)T.size(), k, nodeNum) == -1){
    fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] enter main 20\n");
    return -1;
    // fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] exit main 20\n");
  }
  // fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] exit main 19\n");
  
  fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] enter main 21\n");
  cerr << " node:" << nodeNum << endl;

  for (int i = 0; i < nodeNum; ++i){
    fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] enter main 22\n");
    cout << i << "\t" << R[i] - L[i] << "\t"  << D[i] << "\t";
    printSnipet(T, SA[L[i]], D[i], id2word);
    cout << endl;
    // fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] exit main 22\n");
  }
  // fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] exit main 21\n");

  fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] enter main 23\n");
  return 0;
  // fprintf(stderr, "[brotli/research/esaxx/enumSubstring.cpp] exit main 23\n");
}
// Total cost: 0.089038
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 140)]
// Total instrumented cost: 0.089038, input tokens: 6148, output tokens: 4859, cache read tokens: 6140, cache write tokens: 3810
