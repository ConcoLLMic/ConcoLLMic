/*
Copyright (c) 2009, Hideyuki Tanaka
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.
    * Neither the name of the <organization> nor the
      names of its contributors may be used to endorse or promote products
      derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY <copyright holder> ''AS IS'' AND ANY
EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL <copyright holder> BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#pragma once

#include <iostream>
#include <sstream>
#include <vector>
#include <map>
#include <string>
#include <stdexcept>
#include <typeinfo>
#include <cstring>
#include <algorithm>
#include <cxxabi.h>

namespace cmdline{

namespace detail{

template <typename Target, typename Source, bool Same>
class lexical_cast_t{
public:
  static Target cast(const Source &arg){
    fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter lexical_cast_t::cast 1\n");
    Target ret;
    std::stringstream ss;
    if (!(ss<<arg && ss>>ret && ss.eof()))
      throw std::bad_cast();
    
    return ret;
    // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit lexical_cast_t::cast 1\n");
  }
};

template <typename Target, typename Source>
class lexical_cast_t<Target, Source, true>{
public:
  static Target cast(const Source &arg){
    fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter lexical_cast_t::cast 2\n");
    return arg;
    // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit lexical_cast_t::cast 2\n");
  }  
};

template <typename Source>
class lexical_cast_t<std::string, Source, false>{
public:
  static std::string cast(const Source &arg){
    fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter lexical_cast_t::cast 3\n");
    std::ostringstream ss;
    ss<<arg;
    return ss.str();
    // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit lexical_cast_t::cast 3\n");
  }
};

template <typename Target>
class lexical_cast_t<Target, std::string, false>{
public:
  static Target cast(const std::string &arg){
    fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter lexical_cast_t::cast 4\n");
    Target ret;
    std::istringstream ss(arg);
    if (!(ss>>ret && ss.eof()))
      throw std::bad_cast();
    return ret;
    // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit lexical_cast_t::cast 4\n");
  }
};

template <typename T1, typename T2>
struct is_same {
  static const bool value = false;
};

template <typename T>
struct is_same<T, T>{
  static const bool value = true;
};

template<typename Target, typename Source>
Target lexical_cast(const Source &arg)
{
  fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter lexical_cast 1\n");
  return lexical_cast_t<Target, Source, detail::is_same<Target, Source>::value>::cast(arg);
  // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit lexical_cast 1\n");
}

static inline std::string demangle(const std::string &name)
{
  fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter demangle 1\n");
  int status=0;
  char *p=abi::__cxa_demangle(name.c_str(), 0, 0, &status);
  std::string ret(p);
  free(p);
  return ret;
  // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit demangle 1\n");
}

template <class T>
std::string readable_typename()
{
  fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter readable_typename 1\n");
  return demangle(typeid(T).name());
  // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit readable_typename 1\n");
}

template <>
std::string readable_typename<std::string>()
{
  fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter readable_typename 2\n");
  return "string";
  // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit readable_typename 2\n");
}

} // detail

//-----

class cmdline_error : public std::exception {
public:
  cmdline_error(const std::string &msg): msg(msg){
    fprintf(stderr, "\n");
    // fprintf(stderr, "\n");
  }
  ~cmdline_error() throw() {
    fprintf(stderr, "\n");
    // fprintf(stderr, "\n");
  }
  const char *what() const throw() { 
    fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter cmdline_error::what 1\n");
    return msg.c_str(); 
    // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit cmdline_error::what 1\n");
  }
private:
  std::string msg;
};

template <class T>
struct default_reader{
  T operator()(const std::string &str){
    fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter default_reader::operator() 1\n");
    return detail::lexical_cast<T>(str);
    // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit default_reader::operator() 1\n");
  }
};

template <class T>
struct range_reader{
  range_reader(const T &low, const T &high): low(low), high(high) {
    fprintf(stderr, "\n");
    // fprintf(stderr, "\n");
  }
  T operator()(const std::string &s) const {
    fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter range_reader::operator() 1\n");
    T ret=default_reader<T>()(s);
    if (!(ret>=low && ret<=high)) throw cmdline::cmdline_error("range_error");
    return ret;
    // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit range_reader::operator() 1\n");
  }
private:
  T low, high;
};

template <class T>
range_reader<T> range(const T &low, const T &high)
{
  fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter range 1\n");
  return range_reader<T>(low, high);
  // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit range 1\n");
}

template <class T>
struct oneof_reader{
  T operator()(const std::string &s){
    fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter oneof_reader::operator() 1\n");
    T ret=default_reader<T>()(s);
    if (std::find(alt.begin(), alt.end(), s)==alt.end())
      throw cmdline_error("");
    return ret;
    // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit oneof_reader::operator() 1\n");
  }
  void add(const T &v){ 
    fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter oneof_reader::add 1\n");
    alt.push_back(v); 
    // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit oneof_reader::add 1\n");
  }
private:
  std::vector<T> alt;
};

template <class T>
oneof_reader<T> oneof(T a1)
{
  fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter oneof 1\n");
  oneof_reader<T> ret;
  ret.add(a1);
  return ret;
  // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit oneof 1\n");
}

template <class T>
oneof_reader<T> oneof(T a1, T a2)
{
  fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter oneof 2\n");
  oneof_reader<T> ret;
  ret.add(a1);
  ret.add(a2);
  return ret;
  // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit oneof 2\n");
}

template <class T>
oneof_reader<T> oneof(T a1, T a2, T a3)
{
  fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter oneof 3\n");
  oneof_reader<T> ret;
  ret.add(a1);
  ret.add(a2);
  ret.add(a3);
  return ret;
  // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit oneof 3\n");
}

template <class T>
oneof_reader<T> oneof(T a1, T a2, T a3, T a4)
{
  fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter oneof 4\n");
  oneof_reader<T> ret;
  ret.add(a1);
  ret.add(a2);
  ret.add(a3);
  ret.add(a4);
  return ret;
  // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit oneof 4\n");
}

template <class T>
oneof_reader<T> oneof(T a1, T a2, T a3, T a4, T a5)
{
  fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter oneof 5\n");
  oneof_reader<T> ret;
  ret.add(a1);
  ret.add(a2);
  ret.add(a3);
  ret.add(a4);
  ret.add(a5);
  return ret;
  // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit oneof 5\n");
}

template <class T>
oneof_reader<T> oneof(T a1, T a2, T a3, T a4, T a5, T a6)
{
  fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter oneof 6\n");
  oneof_reader<T> ret;
  ret.add(a1);
  ret.add(a2);
  ret.add(a3);
  ret.add(a4);
  ret.add(a5);
  ret.add(a6);
  return ret;
  // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit oneof 6\n");
}

template <class T>
oneof_reader<T> oneof(T a1, T a2, T a3, T a4, T a5, T a6, T a7)
{
  fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter oneof 7\n");
  oneof_reader<T> ret;
  ret.add(a1);
  ret.add(a2);
  ret.add(a3);
  ret.add(a4);
  ret.add(a5);
  ret.add(a6);
  ret.add(a7);
  return ret;
  // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit oneof 7\n");
}

template <class T>
oneof_reader<T> oneof(T a1, T a2, T a3, T a4, T a5, T a6, T a7, T a8)
{
  fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter oneof 8\n");
  oneof_reader<T> ret;
  ret.add(a1);
  ret.add(a2);
  ret.add(a3);
  ret.add(a4);
  ret.add(a5);
  ret.add(a6);
  ret.add(a7);
  ret.add(a8);
  return ret;
  // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit oneof 8\n");
}

template <class T>
oneof_reader<T> oneof(T a1, T a2, T a3, T a4, T a5, T a6, T a7, T a8, T a9)
{
  fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter oneof 9\n");
  oneof_reader<T> ret;
  ret.add(a1);
  ret.add(a2);
  ret.add(a3);
  ret.add(a4);
  ret.add(a5);
  ret.add(a6);
  ret.add(a7);
  ret.add(a8);
  ret.add(a9);
  return ret;
  // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit oneof 9\n");
}

template <class T>
oneof_reader<T> oneof(T a1, T a2, T a3, T a4, T a5, T a6, T a7, T a8, T a9, T a10)
{
  fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter oneof 10\n");
  oneof_reader<T> ret;
  ret.add(a1);
  ret.add(a2);
  ret.add(a3);
  ret.add(a4);
  ret.add(a5);
  ret.add(a6);
  ret.add(a7);
  ret.add(a8);
  ret.add(a9);
  ret.add(a10);
  return ret;
  // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit oneof 10\n");
}

//-----

class parser{
public:
  parser(){
    fprintf(stderr, "\n");
    // fprintf(stderr, "\n");
  }
  ~parser(){
    fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter parser::~parser 1\n");
    for (std::map<std::string, option_base*>::iterator p=options.begin();
	 p!=options.end(); p++)
      delete p->second;
    // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit parser::~parser 1\n");
  }

  void add(const std::string &name,
	   char short_name=0,
	   const std::string &desc=""){
    fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter parser::add 1\n");
    if (options.count(name)) throw cmdline_error("multiple definition: "+name);
    options[name]=new option_without_value(name, short_name, desc);
    ordered.push_back(options[name]);
    // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit parser::add 1\n");
  }

  template <class T>
  void add(const std::string &name,
	   char short_name=0,
	   const std::string &desc="",
	   bool need=true,
	   const T def=T()){
    fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter parser::add 2\n");
    add(name, short_name, desc, need, def, default_reader<T>());
    // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit parser::add 2\n");
  }

  template <class T, class F>
  void add(const std::string &name,
	   char short_name=0,
	   const std::string &desc="",
	   bool need=true,
	   const T def=T(),
	   F reader=F()){
    fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter parser::add 3\n");
    if (options.count(name)) throw cmdline_error("multiple definition: "+name);
    options[name]=new option_with_value_with_reader<T, F>(name, short_name, need, def, desc, reader);
    ordered.push_back(options[name]);
    // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit parser::add 3\n");
  }

  void footer(const std::string &f){
    fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter parser::footer 1\n");
    ftr=f;
    // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit parser::footer 1\n");
  }

  void set_program_name(const std::string &name){
    fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter parser::set_program_name 1\n");
    prog_name=name;
    // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit parser::set_program_name 1\n");
  }

  bool exist(const std::string &name){
    fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter parser::exist 1\n");
    if (options.count(name)==0) throw cmdline_error("there is no flag: --"+name);
    return options[name]->has_set();
    // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit parser::exist 1\n");
  }

  template <class T>
  const T &get(const std::string &name) const {
    fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter parser::get 1\n");
    if (options.count(name)==0) throw cmdline_error("there is no flag: --"+name);
    const option_with_value<T> *p=dynamic_cast<const option_with_value<T>*>(options.find(name)->second);
    if (p==NULL) throw cmdline_error("type mismatch flag '"+name+"'");
    return p->get();
    // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit parser::get 1\n");
  }

  const std::vector<std::string> &rest() const {
    fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter parser::rest 1\n");
    return others;
    // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit parser::rest 1\n");
  }

  bool parse(int argc, char *argv[]){
    fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter parser::parse 1\n");
    errors.clear();
    others.clear();

    if (argc<1){
      fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter parser::parse 2\n");
      errors.push_back("argument number must be longer than 0");
      return false;
      // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit parser::parse 2\n");
    }
    if (prog_name=="")
      prog_name=argv[0];

    std::map<char, std::string> lookup;
    for (std::map<std::string, option_base*>::iterator p=options.begin();
	 p!=options.end(); p++){
      fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter parser::parse 3\n");
      if (p->first.length()==0) continue;
      char initial=p->second->short_name();
      if (initial){
        fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter parser::parse 4\n");
	if (lookup.count(initial)>0){
          fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter parser::parse 5\n");
	  lookup[initial]="";
	  errors.push_back(std::string("short option '")+initial+"' is ambiguous");
	  return false;
          // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit parser::parse 5\n");
	}
	else lookup[initial]=p->first;
        // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit parser::parse 4\n");
      }
      // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit parser::parse 3\n");
    }

    for (int i=1; i<argc; i++){
      fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter parser::parse 6\n");
      if (strncmp(argv[i], "--", 2)==0){
        fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter parser::parse 7\n");
	char *p=strchr(argv[i]+2, '=');
	if (p){
          fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter parser::parse 8\n");
	  std::string name(argv[i]+2, p);
	  std::string val(p+1);
	  set_option(name, val);
          // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit parser::parse 8\n");
	}
	else{
          fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter parser::parse 9\n");
	  std::string name(argv[i]+2);
	  set_option(name);
          // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit parser::parse 9\n");
	}
        // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit parser::parse 7\n");
      }
      else if (strncmp(argv[i], "-", 1)==0){
        fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter parser::parse 10\n");
	if (!argv[i][1]) continue;
	char last=argv[i][1];
	for (int j=2; argv[i][j]; j++){
          fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter parser::parse 11\n");
	  last=argv[i][j];
	  if (lookup.count(argv[i][j-1])==0){
            fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter parser::parse 12\n");
	    errors.push_back(std::string("undefined short option: -")+argv[i][j-1]);
	    continue;
            // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit parser::parse 12\n");
	  }
	  if (lookup[argv[i][j-1]]==""){
            fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter parser::parse 13\n");
	    errors.push_back(std::string("ambiguous short option: -")+argv[i][j-1]);
	    continue;
            // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit parser::parse 13\n");
	  }
	  set_option(lookup[argv[i][j-1]]);
          // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit parser::parse 11\n");
	}

	if (lookup.count(last)==0){
          fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter parser::parse 14\n");
	  errors.push_back(std::string("undefined short option: -")+last);
	  continue;
          // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit parser::parse 14\n");
	}
	if (lookup[last]==""){
          fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter parser::parse 15\n");
	  errors.push_back(std::string("ambiguous short option: -")+last);
	  continue;
          // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit parser::parse 15\n");
	}

	if (i+1<argc && options[lookup[last]]->has_value()){
          fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter parser::parse 16\n");
	  set_option(lookup[last], argv[i+1]);
	  i++;
          // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit parser::parse 16\n");
	}
	else{
          fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter parser::parse 17\n");
	  set_option(lookup[last]);
          // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit parser::parse 17\n");
	}
        // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit parser::parse 10\n");
      }
      else{
        fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter parser::parse 18\n");
	others.push_back(argv[i]);
        // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit parser::parse 18\n");
      }
      // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit parser::parse 6\n");
    }

    for (std::map<std::string, option_base*>::iterator p=options.begin();
	 p!=options.end(); p++)
      if (!p->second->valid()){
        fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter parser::parse 19\n");
	errors.push_back("need option: --"+std::string(p->first));
        // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit parser::parse 19\n");
      }

    return errors.size()==0;
    // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit parser::parse 1\n");
  }

  std::string error() const{
    fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter parser::error 1\n");
    return errors.size()>0?errors[0]:"";
    // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit parser::error 1\n");
  }

  std::string error_full() const{
    fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter parser::error_full 1\n");
    std::ostringstream oss;
    for (size_t i=0; i<errors.size(); i++)
      oss<<errors[i]<<std::endl;
    return oss.str();
    // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit parser::error_full 1\n");
  }

  std::string usage() const {
    fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter parser::usage 1\n");
    std::ostringstream oss;
    oss<<"usage: "<<prog_name<<" ";
    for (size_t i=0; i<ordered.size(); i++){
      fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter parser::usage 2\n");
      if (ordered[i]->must())
	oss<<ordered[i]->short_description()<<" ";
      // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit parser::usage 2\n");
    }
    
    oss<<"[options] ... "<<ftr<<std::endl;
    oss<<"options:"<<std::endl;

    size_t max_width=0;
    for (size_t i=0; i<ordered.size(); i++){
      fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter parser::usage 3\n");
      max_width=std::max(max_width, ordered[i]->name().length());
      // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit parser::usage 3\n");
    }
    for (size_t i=0; i<ordered.size(); i++){
      fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter parser::usage 4\n");
      if (ordered[i]->short_name()){
        fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter parser::usage 5\n");
	oss<<"  -"<<ordered[i]->short_name()<<", ";
        // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit parser::usage 5\n");
      }
      else{
        fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter parser::usage 6\n");
	oss<<"      ";
        // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit parser::usage 6\n");
      }

      oss<<"--"<<ordered[i]->name();
      for (size_t j=ordered[i]->name().length(); j<max_width+4; j++)
	oss<<' ';
      oss<<ordered[i]->description()<<std::endl;
      // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit parser::usage 4\n");
    }
    return oss.str();
    // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit parser::usage 1\n");
  }

private:

  void set_option(const std::string &name){
    fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter parser::set_option 1\n");
    if (options.count(name)==0){
      fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter parser::set_option 2\n");
      errors.push_back("undefined option: --"+name);
      return;
      // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit parser::set_option 2\n");
    }
    if (!options[name]->set()){
      fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter parser::set_option 3\n");
      errors.push_back("option needs value: --"+name);
      return;
      // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit parser::set_option 3\n");
    }
    // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit parser::set_option 1\n");
  }

  void set_option(const std::string &name, const std::string &value){
    fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter parser::set_option 4\n");
    if (options.count(name)==0){
      fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter parser::set_option 5\n");
      errors.push_back("undefined option: --"+name);
      return;
      // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit parser::set_option 5\n");
    }
    if (!options[name]->set(value)){
      fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter parser::set_option 6\n");
      errors.push_back("option value is invalid: --"+name+"="+value);
      return;
      // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit parser::set_option 6\n");
    }
    // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit parser::set_option 4\n");
  }

  class option_base{
  public:
    virtual ~option_base(){
      fprintf(stderr, "\n");
      // fprintf(stderr, "\n");
    }

    virtual bool has_value() const=0;
    virtual bool set()=0;
    virtual bool set(const std::string &value)=0;
    virtual bool has_set() const=0;
    virtual bool valid() const=0;
    virtual bool must() const=0;

    virtual const std::string &name() const=0;
    virtual char short_name() const=0;
    virtual const std::string &description() const=0;
    virtual std::string short_description() const=0;
  };

  class option_without_value : public option_base {
  public:
    option_without_value(const std::string &name,
			 char short_name,
			 const std::string &desc)
      :nam(name), snam(short_name), desc(desc), has(false){
      fprintf(stderr, "\n");
      // fprintf(stderr, "\n");
    }
    ~option_without_value(){
      fprintf(stderr, "\n");
      // fprintf(stderr, "\n");
    }

    bool has_value() const { 
      fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter option_without_value::has_value 1\n");
      return false; 
      // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit option_without_value::has_value 1\n");
    }

    bool set(){
      fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter option_without_value::set 1\n");
      has=true;
      return true;
      // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit option_without_value::set 1\n");
    }

    bool set(const std::string &){
      fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter option_without_value::set 2\n");
      return false;
      // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit option_without_value::set 2\n");
    }

    bool has_set() const {
      fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter option_without_value::has_set 1\n");
      return has;
      // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit option_without_value::has_set 1\n");
    }

    bool valid() const{
      fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter option_without_value::valid 1\n");
      return true;
      // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit option_without_value::valid 1\n");
    }

    bool must() const{
      fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter option_without_value::must 1\n");
      return false;
      // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit option_without_value::must 1\n");
    }

    const std::string &name() const{
      fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter option_without_value::name 1\n");
      return nam;
      // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit option_without_value::name 1\n");
    }

    char short_name() const{
      fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter option_without_value::short_name 1\n");
      return snam;
      // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit option_without_value::short_name 1\n");
    }

    const std::string &description() const {
      fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter option_without_value::description 1\n");
      return desc;
      // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit option_without_value::description 1\n");
    }

    std::string short_description() const{
      fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter option_without_value::short_description 1\n");
      return "--"+nam;
      // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit option_without_value::short_description 1\n");
    }

  private:
    std::string nam;
    char snam;
    std::string desc;
    bool has;
  };

  template <class T>
  class option_with_value : public option_base {
  public:
    option_with_value(const std::string &name,
		      char short_name,
		      bool need,
		      const T &def,
		      const std::string &desc)
      : nam(name), snam(short_name), need(need), has(false)
      , def(def), actual(def) {
      fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter option_with_value::option_with_value 1\n");
      this->desc=full_description(desc);
      // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit option_with_value::option_with_value 1\n");
    }
    ~option_with_value(){
      fprintf(stderr, "\n");
      // fprintf(stderr, "\n");
    }

    const T &get() const {
      fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter option_with_value::get 1\n");
      return actual;
      // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit option_with_value::get 1\n");
    }

    bool has_value() const { 
      fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter option_with_value::has_value 1\n");
      return true; 
      // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit option_with_value::has_value 1\n");
    }

    bool set(){
      fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter option_with_value::set 1\n");
      return false;
      // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit option_with_value::set 1\n");
    }

    bool set(const std::string &value){
      fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter option_with_value::set 2\n");
      try{
        fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter option_with_value::set 3\n");
	actual=read(value);
	has=true;
        // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit option_with_value::set 3\n");
      }
      catch(const std::exception &e){
        fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter option_with_value::set 4\n");
	return false;
        // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit option_with_value::set 4\n");
      }
      return true;
      // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit option_with_value::set 2\n");
    }

    bool has_set() const{
      fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter option_with_value::has_set 1\n");
      return has;
      // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit option_with_value::has_set 1\n");
    }

    bool valid() const{
      fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter option_with_value::valid 1\n");
      if (need && !has) return false;
      return true;
      // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit option_with_value::valid 1\n");
    }

    bool must() const{
      fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter option_with_value::must 1\n");
      return need;
      // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit option_with_value::must 1\n");
    }

    const std::string &name() const{
      fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter option_with_value::name 1\n");
      return nam;
      // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit option_with_value::name 1\n");
    }

    char short_name() const{
      fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter option_with_value::short_name 1\n");
      return snam;
      // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit option_with_value::short_name 1\n");
    }

    const std::string &description() const {
      fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter option_with_value::description 1\n");
      return desc;
      // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit option_with_value::description 1\n");
    }

    std::string short_description() const{
      fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter option_with_value::short_description 1\n");
      return "--"+nam+"="+detail::readable_typename<T>();
      // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit option_with_value::short_description 1\n");
    }

  protected:
    std::string full_description(const std::string &desc){
      fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter option_with_value::full_description 1\n");
      return
	desc+" ("+detail::readable_typename<T>()+
	(need?"":" [="+detail::lexical_cast<std::string>(def)+"]")
	+")";
      // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit option_with_value::full_description 1\n");
    }

    virtual T read(const std::string &s)=0;

    std::string nam;
    char snam;
    bool need;
    std::string desc;

    bool has;
    T def;
    T actual;
  };

  template <class T, class F>
  class option_with_value_with_reader : public option_with_value<T> {
  public:
    option_with_value_with_reader(const std::string &name,
				  char short_name,
				  bool need,
				  const T def,
				  const std::string &desc,
				  F reader)
      : option_with_value<T>(name, short_name, need, def, desc), reader(reader){
      fprintf(stderr, "\n");
      // fprintf(stderr, "\n");
    }

  private:
    T read(const std::string &s){
      fprintf(stderr, "[brotli/research/esaxx/cmdline.h] enter option_with_value_with_reader::read 1\n");
      return reader(s);
      // fprintf(stderr, "[brotli/research/esaxx/cmdline.h] exit option_with_value_with_reader::read 1\n");
    }

    F reader;
  };

  std::map<std::string, option_base*> options;
  std::vector<option_base*> ordered;
  std::string ftr;

  std::string prog_name;
  std::vector<std::string> others;

  std::vector<std::string> errors;
};

} // cmdline
// Total cost: 0.165640
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 704)]
// Total instrumented cost: 0.165640, input tokens: 2398, output tokens: 9552, cache read tokens: 2394, cache write tokens: 5768
