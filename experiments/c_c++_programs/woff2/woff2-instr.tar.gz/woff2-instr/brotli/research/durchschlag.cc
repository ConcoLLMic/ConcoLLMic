#include "./durchschlag.h"

#include <algorithm>
#include <exception>  /* terminate */

#include "divsufsort.h"

/* Pointer to position in text. */
typedef DurchschlagTextIdx TextIdx;

/* (Sum of) value(s) of slice(s). */
typedef uint32_t Score;

typedef struct HashSlot {
  TextIdx next;
  TextIdx offset;
} HashSlot;

typedef struct MetaSlot {
  TextIdx mark;
  Score score;
} MetaSlot;

typedef struct Range {
  TextIdx start;
  TextIdx end;
} Range;

typedef struct Candidate {
  Score score;
  TextIdx position;
} Candidate;

struct greaterScore {
  bool operator()(const Candidate& a, const Candidate& b) const {
    fprintf(stderr, "[brotli/research/durchschlag.cc] enter greaterScore 1\n");
    return (a.score > b.score) ||
        ((a.score == b.score) && (a.position < b.position));
    // fprintf(stderr, "[brotli/research/durchschlag.cc] exit greaterScore 1\n");
  }
};

struct lessScore {
  bool operator()(const Candidate& a, const Candidate& b) const {
    fprintf(stderr, "[brotli/research/durchschlag.cc] enter lessScore 1\n");
    return (a.score < b.score) ||
        ((a.score == b.score) && (a.position > b.position));
    // fprintf(stderr, "[brotli/research/durchschlag.cc] exit lessScore 1\n");
  }
};

#define CANDIDATE_BUNDLE_SIZE (1 << 18)

static void fatal(const char* error) {
  fprintf(stderr, "[brotli/research/durchschlag.cc] enter fatal 1\n");
  fprintf(stderr, "%s\n", error);
  std::terminate();
  // fprintf(stderr, "[brotli/research/durchschlag.cc] exit fatal 1\n");
}

static TextIdx calculateDictionarySize(const std::vector<Range>& ranges) {
  fprintf(stderr, "[brotli/research/durchschlag.cc] enter calculateDictionarySize 1\n");
  TextIdx result = 0;
  // fprintf(stderr, "[brotli/research/durchschlag.cc] exit calculateDictionarySize 1\n");
  
  for (size_t i = 0; i < ranges.size(); ++i) {
    fprintf(stderr, "[brotli/research/durchschlag.cc] enter calculateDictionarySize 2\n");
    const Range& r = ranges[i];
    result += r.end - r.start;
    // fprintf(stderr, "[brotli/research/durchschlag.cc] exit calculateDictionarySize 2\n");
  }
  
  fprintf(stderr, "[brotli/research/durchschlag.cc] enter calculateDictionarySize 3\n");
  return result;
  // fprintf(stderr, "[brotli/research/durchschlag.cc] exit calculateDictionarySize 3\n");
}

static std::string createDictionary(
    const uint8_t* data, const std::vector<Range>& ranges, size_t limit) {
  fprintf(stderr, "[brotli/research/durchschlag.cc] enter createDictionary 1\n");
  std::string output;
  output.reserve(calculateDictionarySize(ranges));
  // fprintf(stderr, "[brotli/research/durchschlag.cc] exit createDictionary 1\n");
  
  for (size_t i = 0; i < ranges.size(); ++i) {
    fprintf(stderr, "[brotli/research/durchschlag.cc] enter createDictionary 2\n");
    const Range& r = ranges[i];
    output.insert(output.end(), &data[r.start], &data[r.end]);
    // fprintf(stderr, "[brotli/research/durchschlag.cc] exit createDictionary 2\n");
  }
  
  fprintf(stderr, "[brotli/research/durchschlag.cc] enter createDictionary 3\n");
  if (output.size() > limit) {
    fprintf(stderr, "[brotli/research/durchschlag.cc] enter createDictionary 4\n");
    output.resize(limit);
    // fprintf(stderr, "[brotli/research/durchschlag.cc] exit createDictionary 4\n");
  }
  
  return output;
  // fprintf(stderr, "[brotli/research/durchschlag.cc] exit createDictionary 3\n");
}

static Score buildCandidatesList(std::vector<Candidate>* candidates,
    std::vector<MetaSlot>* map, TextIdx span, const TextIdx* shortcut,
    TextIdx end) {
  fprintf(stderr, "[brotli/research/durchschlag.cc] enter buildCandidatesList 1\n");
  candidates->resize(0);

  size_t n = map->size();
  MetaSlot* slots = map->data();
  // fprintf(stderr, "[brotli/research/durchschlag.cc] exit buildCandidatesList 1\n");
  
  for (size_t j = 0; j < n; ++j) {
    fprintf(stderr, "[brotli/research/durchschlag.cc] enter buildCandidatesList 2\n");
    slots[j].mark = 0;
    // fprintf(stderr, "[brotli/research/durchschlag.cc] exit buildCandidatesList 2\n");
  }

  fprintf(stderr, "[brotli/research/durchschlag.cc] enter buildCandidatesList 3\n");
  Score score = 0;
  // fprintf(stderr, "[brotli/research/durchschlag.cc] exit buildCandidatesList 3\n");
  
  for (size_t j = 0; j < span; ++j) {
    fprintf(stderr, "[brotli/research/durchschlag.cc] enter buildCandidatesList 4\n");
    MetaSlot& item = slots[shortcut[j]];
    if (item.mark == 0) {
      fprintf(stderr, "[brotli/research/durchschlag.cc] enter buildCandidatesList 5\n");
      score += item.score;
      // fprintf(stderr, "[brotli/research/durchschlag.cc] exit buildCandidatesList 5\n");
    }
    item.mark++;
    // fprintf(stderr, "[brotli/research/durchschlag.cc] exit buildCandidatesList 4\n");
  }

  fprintf(stderr, "[brotli/research/durchschlag.cc] enter buildCandidatesList 6\n");
  TextIdx i = 0;
  TextIdx limit = std::min<TextIdx>(end, CANDIDATE_BUNDLE_SIZE);
  Score maxScore = 0;
  // fprintf(stderr, "[brotli/research/durchschlag.cc] exit buildCandidatesList 6\n");
  
  for (; i < limit; ++i) {
    fprintf(stderr, "[brotli/research/durchschlag.cc] enter buildCandidatesList 7\n");
    MetaSlot& pick = slots[shortcut[i + span]];
    if (pick.mark == 0) {
      fprintf(stderr, "[brotli/research/durchschlag.cc] enter buildCandidatesList 8\n");
      score += pick.score;
      // fprintf(stderr, "[brotli/research/durchschlag.cc] exit buildCandidatesList 8\n");
    }
    pick.mark++;

    if (score > maxScore) {
      fprintf(stderr, "[brotli/research/durchschlag.cc] enter buildCandidatesList 9\n");
      maxScore = score;
      // fprintf(stderr, "[brotli/research/durchschlag.cc] exit buildCandidatesList 9\n");
    }
    candidates->push_back({score, i});

    MetaSlot& drop = slots[shortcut[i]];
    drop.mark--;
    if (drop.mark == 0) {
      fprintf(stderr, "[brotli/research/durchschlag.cc] enter buildCandidatesList 10\n");
      score -= drop.score;
      // fprintf(stderr, "[brotli/research/durchschlag.cc] exit buildCandidatesList 10\n");
    }
    // fprintf(stderr, "[brotli/research/durchschlag.cc] exit buildCandidatesList 7\n");
  }

  fprintf(stderr, "[brotli/research/durchschlag.cc] enter buildCandidatesList 11\n");
  std::make_heap(candidates->begin(), candidates->end(), greaterScore());
  Score minScore = candidates->at(0).score;
  // fprintf(stderr, "[brotli/research/durchschlag.cc] exit buildCandidatesList 11\n");
  
  for (; i < end; ++i) {
    fprintf(stderr, "[brotli/research/durchschlag.cc] enter buildCandidatesList 12\n");
    MetaSlot& pick = slots[shortcut[i + span]];
    if (pick.mark == 0) {
      fprintf(stderr, "[brotli/research/durchschlag.cc] enter buildCandidatesList 13\n");
      score += pick.score;
      // fprintf(stderr, "[brotli/research/durchschlag.cc] exit buildCandidatesList 13\n");
    }
    pick.mark++;

    if (score > maxScore) {
      fprintf(stderr, "[brotli/research/durchschlag.cc] enter buildCandidatesList 14\n");
      maxScore = score;
      // fprintf(stderr, "[brotli/research/durchschlag.cc] exit buildCandidatesList 14\n");
    }
    if (score >= minScore) {
      fprintf(stderr, "[brotli/research/durchschlag.cc] enter buildCandidatesList 15\n");
      candidates->push_back({score, i});
      std::push_heap(candidates->begin(), candidates->end(), greaterScore());
      if (candidates->size() > CANDIDATE_BUNDLE_SIZE && maxScore != minScore) {
        fprintf(stderr, "[brotli/research/durchschlag.cc] enter buildCandidatesList 16\n");
        while (candidates->at(0).score == minScore) {
          fprintf(stderr, "[brotli/research/durchschlag.cc] enter buildCandidatesList 17\n");
          std::pop_heap(candidates->begin(), candidates->end(), greaterScore());
          candidates->pop_back();
          // fprintf(stderr, "[brotli/research/durchschlag.cc] exit buildCandidatesList 17\n");
        }
        minScore = candidates->at(0).score;
        // fprintf(stderr, "[brotli/research/durchschlag.cc] exit buildCandidatesList 16\n");
      }
      // fprintf(stderr, "[brotli/research/durchschlag.cc] exit buildCandidatesList 15\n");
    }

    MetaSlot& drop = slots[shortcut[i]];
    drop.mark--;
    if (drop.mark == 0) {
      fprintf(stderr, "[brotli/research/durchschlag.cc] enter buildCandidatesList 18\n");
      score -= drop.score;
      // fprintf(stderr, "[brotli/research/durchschlag.cc] exit buildCandidatesList 18\n");
    }
    // fprintf(stderr, "[brotli/research/durchschlag.cc] exit buildCandidatesList 12\n");
  }

  fprintf(stderr, "[brotli/research/durchschlag.cc] enter buildCandidatesList 19\n");
  for (size_t j = 0; j < n; ++j) {
    fprintf(stderr, "[brotli/research/durchschlag.cc] enter buildCandidatesList 20\n");
    slots[j].mark = 0;
    // fprintf(stderr, "[brotli/research/durchschlag.cc] exit buildCandidatesList 20\n");
  }

  std::make_heap(candidates->begin(), candidates->end(), lessScore());
  return minScore;
  // fprintf(stderr, "[brotli/research/durchschlag.cc] exit buildCandidatesList 19\n");
}

static Score rebuildCandidatesList(std::vector<TextIdx>* candidates,
    std::vector<MetaSlot>* map, TextIdx span, const TextIdx* shortcut,
    TextIdx end, TextIdx* next) {
  fprintf(stderr, "[brotli/research/durchschlag.cc] enter rebuildCandidatesList 1\n");
  size_t n = candidates->size();
  TextIdx* data = candidates->data();
  // fprintf(stderr, "[brotli/research/durchschlag.cc] exit rebuildCandidatesList 1\n");
  
  for (size_t i = 0; i < n; ++i) {
    fprintf(stderr, "[brotli/research/durchschlag.cc] enter rebuildCandidatesList 2\n");
    data[i] = 0;
    // fprintf(stderr, "[brotli/research/durchschlag.cc] exit rebuildCandidatesList 2\n");
  }

  fprintf(stderr, "[brotli/research/durchschlag.cc] enter rebuildCandidatesList 3\n");
  n = map->size();
  MetaSlot* slots = map->data();
  // fprintf(stderr, "[brotli/research/durchschlag.cc] exit rebuildCandidatesList 3\n");
  
  for (size_t i = 0; i < n; ++i) {
    fprintf(stderr, "[brotli/research/durchschlag.cc] enter rebuildCandidatesList 4\n");
    slots[i].mark = 0;
    // fprintf(stderr, "[brotli/research/durchschlag.cc] exit rebuildCandidatesList 4\n");
  }

  fprintf(stderr, "[brotli/research/durchschlag.cc] enter rebuildCandidatesList 5\n");
  Score score = 0;
  // fprintf(stderr, "[brotli/research/durchschlag.cc] exit rebuildCandidatesList 5\n");
  
  for (TextIdx i = 0; i < span; ++i) {
    fprintf(stderr, "[brotli/research/durchschlag.cc] enter rebuildCandidatesList 6\n");
    MetaSlot& item = slots[shortcut[i]];
    if (item.mark == 0) {
      fprintf(stderr, "[brotli/research/durchschlag.cc] enter rebuildCandidatesList 7\n");
      score += item.score;
      // fprintf(stderr, "[brotli/research/durchschlag.cc] exit rebuildCandidatesList 7\n");
    }
    item.mark++;
    // fprintf(stderr, "[brotli/research/durchschlag.cc] exit rebuildCandidatesList 6\n");
  }

  fprintf(stderr, "[brotli/research/durchschlag.cc] enter rebuildCandidatesList 8\n");
  Score maxScore = 0;
  // fprintf(stderr, "[brotli/research/durchschlag.cc] exit rebuildCandidatesList 8\n");
  
  for (TextIdx i = 0; i < end; ++i) {
    fprintf(stderr, "[brotli/research/durchschlag.cc] enter rebuildCandidatesList 9\n");
    MetaSlot& pick = slots[shortcut[i + span]];
    if (pick.mark == 0) {
      fprintf(stderr, "[brotli/research/durchschlag.cc] enter rebuildCandidatesList 10\n");
      score += pick.score;
      // fprintf(stderr, "[brotli/research/durchschlag.cc] exit rebuildCandidatesList 10\n");
    }
    pick.mark++;

    if (candidates->size() <= score) {
      fprintf(stderr, "[brotli/research/durchschlag.cc] enter rebuildCandidatesList 11\n");
      candidates->resize(score + 1);
      // fprintf(stderr, "[brotli/research/durchschlag.cc] exit rebuildCandidatesList 11\n");
    }
    if (score > maxScore) {
      fprintf(stderr, "[brotli/research/durchschlag.cc] enter rebuildCandidatesList 12\n");
      maxScore = score;
      // fprintf(stderr, "[brotli/research/durchschlag.cc] exit rebuildCandidatesList 12\n");
    }
    next[i] = candidates->at(score);
    candidates->at(score) = i;

    MetaSlot& drop = slots[shortcut[i]];
    drop.mark--;
    if (drop.mark == 0) {
      fprintf(stderr, "[brotli/research/durchschlag.cc] enter rebuildCandidatesList 13\n");
      score -= drop.score;
      // fprintf(stderr, "[brotli/research/durchschlag.cc] exit rebuildCandidatesList 13\n");
    }
    // fprintf(stderr, "[brotli/research/durchschlag.cc] exit rebuildCandidatesList 9\n");
  }

  fprintf(stderr, "[brotli/research/durchschlag.cc] enter rebuildCandidatesList 14\n");
  for (size_t i = 0; i < n; ++i) {
    fprintf(stderr, "[brotli/research/durchschlag.cc] enter rebuildCandidatesList 15\n");
    slots[i].mark = 0;
    // fprintf(stderr, "[brotli/research/durchschlag.cc] exit rebuildCandidatesList 15\n");
  }

  candidates->resize(maxScore + 1);
  return maxScore;
  // fprintf(stderr, "[brotli/research/durchschlag.cc] exit rebuildCandidatesList 14\n");
}

static void addRange(std::vector<Range>* ranges, TextIdx start, TextIdx end) {
  fprintf(stderr, "\n");
  for (auto it = ranges->begin(); it != ranges->end();) {
    fprintf(stderr, "[brotli/research/durchschlag.cc] enter addRange 2\n");
    if (end < it->start) {
      fprintf(stderr, "[brotli/research/durchschlag.cc] enter addRange 3\n");
      ranges->insert(it, {start, end});
      return;
      // fprintf(stderr, "[brotli/research/durchschlag.cc] exit addRange 3\n");
    }
    if (it->end < start) {
      fprintf(stderr, "[brotli/research/durchschlag.cc] enter addRange 4\n");
      it++;
      // fprintf(stderr, "[brotli/research/durchschlag.cc] exit addRange 4\n");
      continue;
    }
    // Combine with existing.
    start = std::min(start, it->start);
    end = std::max(end, it->end);
    // Remove consumed vector and continue.
    it = ranges->erase(it);
    // fprintf(stderr, "[brotli/research/durchschlag.cc] exit addRange 2\n");
  }
  fprintf(stderr, "[brotli/research/durchschlag.cc] enter addRange 5\n");
  ranges->push_back({start, end});
  // fprintf(stderr, "[brotli/research/durchschlag.cc] exit addRange 5\n");
}

std::string durchschlag_generate(
    size_t dictionary_size_limit, size_t slice_len, size_t block_len,
    const std::vector<size_t>& sample_sizes, const uint8_t* sample_data) {
  fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_generate 1\n");
  DurchschlagContext ctx = durchschlag_prepare(
      slice_len, sample_sizes, sample_data);
  return durchschlag_generate(DURCHSCHLAG_COLLABORATIVE,
      dictionary_size_limit, block_len, ctx, sample_data);
  // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_generate 1\n");
}

DurchschlagContext durchschlag_prepare(size_t slice_len,
    const std::vector<size_t>& sample_sizes, const uint8_t* sample_data) {
  fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_prepare 1\n");
  /* Parameters aliasing */
  TextIdx sliceLen = static_cast<TextIdx>(slice_len);
  if (sliceLen != slice_len) fatal("slice_len is too large");
  if (sliceLen < 1) fatal("slice_len is too small");
  const uint8_t* data = sample_data;

  TextIdx total = 0;
  std::vector<TextIdx> offsets;
  offsets.reserve(sample_sizes.size());
  // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_prepare 1\n");
  
  for (size_t i = 0; i < sample_sizes.size(); ++i) {
    fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_prepare 2\n");
    TextIdx delta = static_cast<TextIdx>(sample_sizes[i]);
    if (delta != sample_sizes[i]) fatal("sample is too large");
    if (delta == 0) fatal("0-length samples are prohibited");
    TextIdx next_total = total + delta;
    if (next_total <= total) fatal("corpus is too large");
    total = next_total;
    offsets.push_back(total);
    // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_prepare 2\n");
  }

  fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_prepare 3\n");
  if (total < sliceLen) fatal("slice_len is larger than corpus size");
  TextIdx end = total - static_cast<TextIdx>(sliceLen) + 1;
  TextIdx hashLen = 11;
  // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_prepare 3\n");
  
  while (hashLen < 29 && ((1u << hashLen) < end)) {
    fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_prepare 4\n");
    hashLen += 3;
    // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_prepare 4\n");
  }
  
  fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_prepare 5\n");
  hashLen -= 3;
  TextIdx hashMask = (1u << hashLen) - 1u;
  std::vector<TextIdx> hashHead(1 << hashLen);
  TextIdx hash = 0;
  TextIdx lShift = 3;
  TextIdx rShift = hashLen - lShift;
  // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_prepare 5\n");
  
  for (TextIdx i = 0; i < sliceLen - 1; ++i) {
    fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_prepare 6\n");
    TextIdx v = data[i];
    hash = (((hash << lShift) | (hash >> rShift)) & hashMask) ^ v;
    // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_prepare 6\n");
  }
  
  fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_prepare 7\n");
  TextIdx lShiftX = (lShift * (sliceLen - 1)) % hashLen;
  TextIdx rShiftX = hashLen - lShiftX;

  std::vector<HashSlot> map;
  map.push_back({0, 0});
  TextIdx hashSlot = 1;
  std::vector<TextIdx> sliceMap;
  sliceMap.reserve(end);
  // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_prepare 7\n");
  
  for (TextIdx i = 0; i < end; ++i) {
    fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_prepare 8\n");
    TextIdx v = data[i + sliceLen - 1];
    TextIdx bucket = (((hash << lShift) | (hash >> rShift)) & hashMask) ^ v;
    v = data[i];
    hash = bucket ^ (((v << lShiftX) | (v >> rShiftX)) & hashMask);
    TextIdx slot = hashHead[bucket];
    // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_prepare 8\n");
    
    while (slot != 0) {
      fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_prepare 9\n");
      HashSlot& item = map[slot];
      TextIdx start = item.offset;
      bool miss = false;
      // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_prepare 9\n");
      
      for (TextIdx j = 0; j < sliceLen; ++j) {
        fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_prepare 10\n");
        if (data[i + j] != data[start + j]) {
          fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_prepare 11\n");
          miss = true;
          break;
          // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_prepare 11\n");
        }
        // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_prepare 10\n");
      }
      
      fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_prepare 12\n");
      if (!miss) {
        fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_prepare 13\n");
        sliceMap.push_back(slot);
        break;
        // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_prepare 13\n");
      }
      slot = item.next;
      // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_prepare 12\n");
    }
    
    fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_prepare 14\n");
    if (slot == 0) {
      fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_prepare 15\n");
      map.push_back({hashHead[bucket], i});
      hashHead[bucket] = hashSlot;
      sliceMap.push_back(hashSlot);
      hashSlot++;
      // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_prepare 15\n");
    }
    // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_prepare 14\n");
  }

  fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_prepare 16\n");
  return {total, sliceLen, static_cast<TextIdx>(map.size()),
      std::move(offsets), std::move(sliceMap)};
  // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_prepare 16\n");
}

DurchschlagContext durchschlag_prepare(size_t slice_len,
    const std::vector<size_t>& sample_sizes, const DurchschlagIndex& index) {
  fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_prepare 17\n");
  /* Parameters aliasing */
  TextIdx sliceLen = static_cast<TextIdx>(slice_len);
  if (sliceLen != slice_len) fatal("slice_len is too large");
  if (sliceLen < 1) fatal("slice_len is too small");
  const TextIdx* lcp = index.lcp.data();
  const TextIdx* sa = index.sa.data();

  TextIdx total = 0;
  std::vector<TextIdx> offsets;
  offsets.reserve(sample_sizes.size());
  // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_prepare 17\n");
  
  for (size_t i = 0; i < sample_sizes.size(); ++i) {
    fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_prepare 18\n");
    TextIdx delta = static_cast<TextIdx>(sample_sizes[i]);
    if (delta != sample_sizes[i]) fatal("sample is too large");
    if (delta == 0) fatal("0-length samples are prohibited");
    TextIdx next_total = total + delta;
    if (next_total <= total) fatal("corpus is too large");
    total = next_total;
    offsets.push_back(total);
    // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_prepare 18\n");
  }

  fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_prepare 19\n");
  if (total < sliceLen) fatal("slice_len is larger than corpus size");
  TextIdx counter = 1;
  TextIdx end = total - sliceLen + 1;
  std::vector<TextIdx> sliceMap(total);
  TextIdx last = 0;
  TextIdx current = 1;
  // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_prepare 19\n");
  
  while (current <= total) {
    fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_prepare 20\n");
    if (lcp[current - 1] < sliceLen) {
      fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_prepare 21\n");
      for (TextIdx i = last; i < current; ++i) {
        fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_prepare 22\n");
        sliceMap[sa[i]] = counter;
        // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_prepare 22\n");
      }
      counter++;
      last = current;
      // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_prepare 21\n");
    }
    current++;
    // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_prepare 20\n");
  }
  
  fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_prepare 23\n");
  sliceMap.resize(end);

  // Reorder items for the better locality.
  std::vector<TextIdx> reorder(counter);
  counter = 1;
  // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_prepare 23\n");
  
  for (TextIdx i = 0; i < end; ++i) {
    fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_prepare 24\n");
    if (reorder[sliceMap[i]] == 0) {
      fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_prepare 25\n");
      reorder[sliceMap[i]] = counter++;
      // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_prepare 25\n");
    }
    // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_prepare 24\n");
  }
  
  fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_prepare 26\n");
  for (TextIdx i = 0; i < end; ++i) {
    fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_prepare 27\n");
    sliceMap[i] = reorder[sliceMap[i]];
    // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_prepare 27\n");
  }

  return {total, sliceLen, counter, std::move(offsets), std::move(sliceMap)};
  // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_prepare 26\n");
}

DurchschlagIndex durchschlag_index(const std::vector<uint8_t>& data) {
  fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_index 1\n");
  TextIdx total = static_cast<TextIdx>(data.size());
  if (total != data.size()) fatal("corpus is too large");
  saidx_t saTotal = static_cast<saidx_t>(total);
  if (saTotal < 0) fatal("corpus is too large");
  if (static_cast<TextIdx>(saTotal) != total) fatal("corpus is too large");
  std::vector<TextIdx> sa(total);
  /* Hopefully, non-negative int32_t values match TextIdx ones. */
  if (sizeof(TextIdx) != sizeof(int32_t)) fatal("type length mismatch");
  int32_t* saData = reinterpret_cast<int32_t*>(sa.data());
  divsufsort(data.data(), saData, saTotal);

  std::vector<TextIdx> isa(total);
  // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_index 1\n");
  
  for (TextIdx i = 0; i < total; ++i) {
    fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_index 2\n");
    isa[sa[i]] = i;
    // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_index 2\n");
  }

  fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_index 3\n");
  // TODO: borrowed -> unknown efficiency.
  std::vector<TextIdx> lcp(total);
  TextIdx k = 0;
  lcp[total - 1] = 0;
  // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_index 3\n");
  
  for (TextIdx i = 0; i < total; ++i) {
    fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_index 4\n");
    TextIdx current = isa[i];
    if (current == total - 1) {
      fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_index 5\n");
      k = 0;
      continue;
      // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_index 5\n");
    }
    TextIdx j = sa[current + 1];  // Suffix which follow i-th suffix.
    // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_index 4\n");
    
    while ((i + k < total) && (j + k < total) && (data[i + k] == data[j + k])) {
      fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_index 6\n");
      ++k;
      // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_index 6\n");
    }
    
    fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_index 7\n");
    lcp[current] = k;
    if (k > 0) --k;
    // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_index 7\n");
  }

  fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_index 8\n");
  return {std::move(lcp), std::move(sa)};
  // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_index 8\n");
}

static void ScoreSlices(const std::vector<TextIdx>& offsets,
    std::vector<MetaSlot>& map, const TextIdx* shortcut, TextIdx end) {
  fprintf(stderr, "[brotli/research/durchschlag.cc] enter ScoreSlices 1\n");
  TextIdx piece = 0;
  /* Fresh map contains all zeroes -> initial mark should be different. */
  TextIdx mark = 1;
  // fprintf(stderr, "[brotli/research/durchschlag.cc] exit ScoreSlices 1\n");
  
  for (TextIdx i = 0; i < end; ++i) {
    fprintf(stderr, "[brotli/research/durchschlag.cc] enter ScoreSlices 2\n");
    if (offsets[piece] == i) {
      fprintf(stderr, "[brotli/research/durchschlag.cc] enter ScoreSlices 3\n");
      piece++;
      mark++;
      // fprintf(stderr, "[brotli/research/durchschlag.cc] exit ScoreSlices 3\n");
    }
    MetaSlot& item = map[shortcut[i]];
    if (item.mark != mark) {
      fprintf(stderr, "[brotli/research/durchschlag.cc] enter ScoreSlices 4\n");
      item.mark = mark;
      item.score++;
      // fprintf(stderr, "[brotli/research/durchschlag.cc] exit ScoreSlices 4\n");
    }
    // fprintf(stderr, "[brotli/research/durchschlag.cc] exit ScoreSlices 2\n");
  }
}

static std::string durchschlagGenerateExclusive(
    size_t dictionary_size_limit, size_t block_len,
    const DurchschlagContext& context, const uint8_t* sample_data) {
  fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlagGenerateExclusive 1\n");
  /* Parameters aliasing */
  TextIdx targetSize = static_cast<TextIdx>(dictionary_size_limit);
  if (targetSize != dictionary_size_limit) {
    fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlagGenerateExclusive 2\n");
    fprintf(stderr, "dictionary_size_limit is too large\n");
    return "";
    // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlagGenerateExclusive 2\n");
  }
  TextIdx sliceLen = context.sliceLen;
  TextIdx total = context.dataSize;
  TextIdx blockLen = static_cast<TextIdx>(block_len);
  if (blockLen != block_len) {
    fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlagGenerateExclusive 3\n");
    fprintf(stderr, "block_len is too large\n");
    return "";
    // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlagGenerateExclusive 3\n");
  }
  const uint8_t* data = sample_data;
  const std::vector<TextIdx>& offsets = context.offsets;
  std::vector<MetaSlot> map(context.numUniqueSlices);
  const TextIdx* shortcut = context.sliceMap.data();

  /* Initialization */
  if (blockLen < sliceLen) {
    fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlagGenerateExclusive 4\n");
    fprintf(stderr, "sliceLen is larger than block_len\n");
    return "";
    // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlagGenerateExclusive 4\n");
  }
  if (targetSize < blockLen || total < blockLen) {
    fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlagGenerateExclusive 5\n");
    fprintf(stderr, "block_len is too large\n");
    return "";
    // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlagGenerateExclusive 5\n");
  }
  TextIdx end = total - sliceLen + 1;
  ScoreSlices(offsets, map, shortcut, end);
  end = total - blockLen + 1;
  std::vector<TextIdx> candidates;
  std::vector<TextIdx> next(end);
  TextIdx span = blockLen - sliceLen + 1;
  Score maxScore = rebuildCandidatesList(
      &candidates, &map, span, shortcut, end, next.data());

  /* Block selection */
  const size_t triesLimit = (600 * 1000000) / span;
  const size_t candidatesLimit = (150 * 1000000) / span;
  std::vector<Range> ranges;
  TextIdx mark = 0;
  size_t numTries = 0;
  // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlagGenerateExclusive 1\n");
  
  while (true) {
    fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlagGenerateExclusive 6\n");
    TextIdx dictSize = calculateDictionarySize(ranges);
    size_t numCandidates = 0;
    if (dictSize > targetSize - blockLen) {
      fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlagGenerateExclusive 7\n");
      break;
      // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlagGenerateExclusive 7\n");
    }
    if (maxScore == 0) {
      fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlagGenerateExclusive 8\n");
      break;
      // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlagGenerateExclusive 8\n");
    }
    // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlagGenerateExclusive 6\n");
    
    while (true) {
      fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlagGenerateExclusive 9\n");
      TextIdx candidate = 0;
      // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlagGenerateExclusive 9\n");
      
      while (maxScore > 0) {
        fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlagGenerateExclusive 10\n");
        if (candidates[maxScore] != 0) {
          fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlagGenerateExclusive 11\n");
          candidate = candidates[maxScore];
          candidates[maxScore] = next[candidate];
          break;
          // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlagGenerateExclusive 11\n");
        }
        maxScore--;
        // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlagGenerateExclusive 10\n");
      }
      
      fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlagGenerateExclusive 12\n");
      if (maxScore == 0) {
        fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlagGenerateExclusive 13\n");
        break;
        // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlagGenerateExclusive 13\n");
      }
      mark++;
      numTries++;
      numCandidates++;
      Score score = 0;
      // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlagGenerateExclusive 12\n");
      
      for (size_t j = candidate; j <= candidate + span; ++j) {
        fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlagGenerateExclusive 14\n");
        MetaSlot& item = map[shortcut[j]];
        if (item.mark != mark) {
          fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlagGenerateExclusive 15\n");
          score += item.score;
          item.mark = mark;
          // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlagGenerateExclusive 15\n");
        }
        // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlagGenerateExclusive 14\n");
      }
      
      fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlagGenerateExclusive 16\n");
      if (score < maxScore) {
        fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlagGenerateExclusive 17\n");
        if (numTries < triesLimit && numCandidates < candidatesLimit) {
          fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlagGenerateExclusive 18\n");
          next[candidate] = candidates[score];
          candidates[score] = candidate;
          // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlagGenerateExclusive 18\n");
        } else {
          fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlagGenerateExclusive 19\n");
          maxScore = rebuildCandidatesList(
              &candidates, &map, span, shortcut, end, next.data());
          mark = 0;
          numTries = 0;
          numCandidates = 0;
          // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlagGenerateExclusive 19\n");
        }
        continue;
        // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlagGenerateExclusive 17\n");
      } else if (score > maxScore) {
        fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlagGenerateExclusive 20\n");
        fprintf(stderr, "Broken invariant\n");
        return "";
        // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlagGenerateExclusive 20\n");
      }
      // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlagGenerateExclusive 16\n");
      
      for (TextIdx j = candidate; j <= candidate + span; ++j) {
        fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlagGenerateExclusive 21\n");
        MetaSlot& item = map[shortcut[j]];
        item.score = 0;
        // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlagGenerateExclusive 21\n");
      }
      
      fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlagGenerateExclusive 22\n");
      addRange(&ranges, candidate, candidate + blockLen);
      break;
      // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlagGenerateExclusive 22\n");
    }
  }

  fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlagGenerateExclusive 23\n");
  return createDictionary(data, ranges, targetSize);
  // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlagGenerateExclusive 23\n");
}

static std::string durchschlagGenerateCollaborative(
    size_t dictionary_size_limit, size_t block_len,
    const DurchschlagContext& context, const uint8_t* sample_data) {
  fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlagGenerateCollaborative 1\n");
  /* Parameters aliasing */
  TextIdx targetSize = static_cast<TextIdx>(dictionary_size_limit);
  if (targetSize != dictionary_size_limit) {
    fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlagGenerateCollaborative 2\n");
    fprintf(stderr, "dictionary_size_limit is too large\n");
    return "";
    // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlagGenerateCollaborative 2\n");
  }
  TextIdx sliceLen = context.sliceLen;
  TextIdx total = context.dataSize;
  TextIdx blockLen = static_cast<TextIdx>(block_len);
  if (blockLen != block_len) {
    fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlagGenerateCollaborative 3\n");
    fprintf(stderr, "block_len is too large\n");
    return "";
    // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlagGenerateCollaborative 3\n");
  }
  const uint8_t* data = sample_data;
  const std::vector<TextIdx>& offsets = context.offsets;
  std::vector<MetaSlot> map(context.numUniqueSlices);
  const TextIdx* shortcut = context.sliceMap.data();

  /* Initialization */
  if (blockLen < sliceLen) {
    fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlagGenerateCollaborative 4\n");
    fprintf(stderr, "sliceLen is larger than block_len\n");
    return "";
    // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlagGenerateCollaborative 4\n");
  }
  if (targetSize < blockLen || total < blockLen) {
    fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlagGenerateCollaborative 5\n");
    fprintf(stderr, "block_len is too large\n");
    return "";
    // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlagGenerateCollaborative 5\n");
  }
  TextIdx end = total - sliceLen + 1;
  ScoreSlices(offsets, map, shortcut, end);
  end = total - blockLen + 1;
  std::vector<Candidate> candidates;
  candidates.reserve(CANDIDATE_BUNDLE_SIZE + 1024);
  TextIdx span = blockLen - sliceLen + 1;
  Score minScore = buildCandidatesList(&candidates, &map, span, shortcut, end);

  /* Block selection */
  std::vector<Range> ranges;
  TextIdx mark = 0;
  // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlagGenerateCollaborative 1\n");
  
  while (true) {
    fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlagGenerateCollaborative 6\n");
    TextIdx dictSize = calculateDictionarySize(ranges);
    if (dictSize > targetSize - blockLen) {
      fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlagGenerateCollaborative 7\n");
      break;
      // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlagGenerateCollaborative 7\n");
    }
    if (minScore == 0 && candidates.empty()) {
      fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlagGenerateCollaborative 8\n");
      break;
      // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlagGenerateCollaborative 8\n");
    }
    // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlagGenerateCollaborative 6\n");
    
    while (true) {
      fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlagGenerateCollaborative 9\n");
      if (candidates.empty()) {
        fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlagGenerateCollaborative 10\n");
        minScore = buildCandidatesList(&candidates, &map, span, shortcut, end);
        mark = 0;
        // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlagGenerateCollaborative 10\n");
      }
      TextIdx candidate = candidates[0].position;
      Score expectedScore = candidates[0].score;
      if (expectedScore == 0) {
        fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlagGenerateCollaborative 11\n");
        candidates.resize(0);
        break;
        // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlagGenerateCollaborative 11\n");
      }
      std::pop_heap(candidates.begin(), candidates.end(), lessScore());
      candidates.pop_back();
      mark++;
      Score score = 0;
      // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlagGenerateCollaborative 9\n");
      
      for (TextIdx j = candidate; j <= candidate + span; ++j) {
        fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlagGenerateCollaborative 12\n");
        MetaSlot& item = map[shortcut[j]];
        if (item.mark != mark) {
          fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlagGenerateCollaborative 13\n");
          score += item.score;
          item.mark = mark;
          // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlagGenerateCollaborative 13\n");
        }
        // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlagGenerateCollaborative 12\n");
      }
      
      fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlagGenerateCollaborative 14\n");
      if (score < expectedScore) {
        fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlagGenerateCollaborative 15\n");
        if (score >= minScore) {
          fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlagGenerateCollaborative 16\n");
          candidates.push_back({score, candidate});
          std::push_heap(candidates.begin(), candidates.end(), lessScore());
          // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlagGenerateCollaborative 16\n");
        }
        continue;
        // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlagGenerateCollaborative 15\n");
      } else if (score > expectedScore) {
        fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlagGenerateCollaborative 17\n");
        fatal("Broken invariant");
        // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlagGenerateCollaborative 17\n");
      }
      // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlagGenerateCollaborative 14\n");
      
      for (TextIdx j = candidate; j <= candidate + span; ++j) {
        fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlagGenerateCollaborative 18\n");
        MetaSlot& item = map[shortcut[j]];
        item.score = 0;
        // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlagGenerateCollaborative 18\n");
      }
      
      fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlagGenerateCollaborative 19\n");
      addRange(&ranges, candidate, candidate + blockLen);
      break;
      // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlagGenerateCollaborative 19\n");
    }
  }

  fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlagGenerateCollaborative 20\n");
  return createDictionary(data, ranges, targetSize);
  // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlagGenerateCollaborative 20\n");
}

std::string durchschlag_generate(DurchschalgResourceStrategy strategy,
    size_t dictionary_size_limit, size_t block_len,
    const DurchschlagContext& context, const uint8_t* sample_data) {
  fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_generate 2\n");
  if (strategy == DURCHSCHLAG_COLLABORATIVE) {
    fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_generate 3\n");
    return durchschlagGenerateCollaborative(
        dictionary_size_limit, block_len, context, sample_data);
    // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_generate 3\n");
  } else {
    fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_generate 4\n");
    return durchschlagGenerateExclusive(
        dictionary_size_limit, block_len, context, sample_data);
    // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_generate 4\n");
  }
  // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_generate 2\n");
}

void durchschlag_distill(size_t slice_len, size_t minimum_population,
    std::vector<size_t>* sample_sizes, uint8_t* sample_data) {
  fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_distill 1\n");
  /* Parameters aliasing */
  uint8_t* data = sample_data;

  /* Build slice map. */
  DurchschlagContext context = durchschlag_prepare(
      slice_len, *sample_sizes, data);

  /* Calculate slice population. */
  const std::vector<TextIdx>& offsets = context.offsets;
  std::vector<MetaSlot> map(context.numUniqueSlices);
  const TextIdx* shortcut = context.sliceMap.data();
  TextIdx sliceLen = context.sliceLen;
  TextIdx total = context.dataSize;
  TextIdx end = total - sliceLen + 1;
  ScoreSlices(offsets, map, shortcut, end);

  /* Condense samples, omitting unique slices. */
  TextIdx readPos = 0;
  TextIdx writePos = 0;
  TextIdx lastNonUniquePos = 0;
  // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_distill 1\n");
  
  for (TextIdx i = 0; i < sample_sizes->size(); ++i) {
    fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_distill 2\n");
    TextIdx sampleStart = writePos;
    TextIdx oldSampleEnd =
        readPos + static_cast<TextIdx>(sample_sizes->at(i));
    // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_distill 2\n");
    
    while (readPos < oldSampleEnd) {
      fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_distill 3\n");
      if (readPos < end) {
        fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_distill 4\n");
        MetaSlot& item = map[shortcut[readPos]];
        if (item.score >= minimum_population) {
          fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_distill 5\n");
          lastNonUniquePos = readPos + sliceLen;
          // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_distill 5\n");
        }
        // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_distill 4\n");
      }
      if (readPos < lastNonUniquePos) {
        fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_distill 6\n");
        data[writePos++] = data[readPos];
        // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_distill 6\n");
      }
      readPos++;
      // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_distill 3\n");
    }
    
    fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_distill 7\n");
    sample_sizes->at(i) = writePos - sampleStart;
    // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_distill 7\n");
  }
}

void durchschlag_purify(size_t slice_len, size_t minimum_population,
    const std::vector<size_t>& sample_sizes, uint8_t* sample_data) {
  fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_purify 1\n");
  /* Parameters aliasing */
  uint8_t* data = sample_data;

  /* Build slice map. */
  DurchschlagContext context = durchschlag_prepare(
      slice_len, sample_sizes, data);

  /* Calculate slice population. */
  const std::vector<TextIdx>& offsets = context.offsets;
  std::vector<MetaSlot> map(context.numUniqueSlices);
  const TextIdx* shortcut = context.sliceMap.data();
  TextIdx sliceLen = context.sliceLen;
  TextIdx total = context.dataSize;
  TextIdx end = total - sliceLen + 1;
  ScoreSlices(offsets, map, shortcut, end);

  /* Rewrite samples, zeroing out unique slices. */
  TextIdx lastNonUniquePos = 0;
  // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_purify 1\n");
  
  for (TextIdx readPos = 0; readPos < total; ++readPos) {
    fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_purify 2\n");
    if (readPos < end) {
      fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_purify 3\n");
      MetaSlot& item = map[shortcut[readPos]];
      if (item.score >= minimum_population) {
        fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_purify 4\n");
        lastNonUniquePos = readPos + sliceLen;
        // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_purify 4\n");
      }
      // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_purify 3\n");
    }
    if (readPos >= lastNonUniquePos) {
      fprintf(stderr, "[brotli/research/durchschlag.cc] enter durchschlag_purify 5\n");
      data[readPos] = 0;
      // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_purify 5\n");
    }
    // fprintf(stderr, "[brotli/research/durchschlag.cc] exit durchschlag_purify 2\n");
  }
}
// Total cost: 0.228115
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 714)]
// Total instrumented cost: 0.228115, input tokens: 2398, output tokens: 13292, cache read tokens: 2394, cache write tokens: 7468
