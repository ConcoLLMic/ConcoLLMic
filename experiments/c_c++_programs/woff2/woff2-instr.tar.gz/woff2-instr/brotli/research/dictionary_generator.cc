#include <cstddef>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <vector>

#include "./deorummolae.h"
#include "./durchschlag.h"
#include "./sieve.h"

#define METHOD_DM 0
#define METHOD_SIEVE 1
#define METHOD_DURCHSCHLAG 2
#define METHOD_DISTILL 3
#define METHOD_PURIFY 4

static size_t readInt(const char* str) {
  fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter readInt 1\n");
  size_t result = 0;
  if (str[0] == 0 || str[0] == '0') {
    fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter readInt 2\n");
    return 0;
    // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit readInt 2\n");
  }
  
  for (size_t i = 0; i < 13; ++i) {
    fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter readInt 3\n");
    if (str[i] == 0) {
      fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter readInt 4\n");
      return result;
      // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit readInt 4\n");
    }
    
    if (str[i] == 'k' || str[i] == 'K') {
      fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter readInt 5\n");
      if ((str[i + 1] == 0) && ((result << 10) > result)) {
        fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter readInt 6\n");
        return result << 10;
        // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit readInt 6\n");
      }
      return 0;
      // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit readInt 5\n");
    }
    
    if (str[i] == 'm' || str[i] == 'M') {
      fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter readInt 7\n");
      if ((str[i + 1] == 0) && ((result << 20) > result)) {
        fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter readInt 8\n");
        return result << 20;
        // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit readInt 8\n");
      }
      return 0;
      // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit readInt 7\n");
    }
    
    if (str[i] < '0' || str[i] > '9') {
      fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter readInt 9\n");
      return 0;
      // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit readInt 9\n");
    }
    
    fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter readInt 10\n");
    size_t next = (10 * result) + (str[i] - '0');
    if (next <= result) {
      fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter readInt 11\n");
      return 0;
      // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit readInt 11\n");
    }
    result = next;
    // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit readInt 10\n");
    // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit readInt 3\n");
  }
  
  fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter readInt 12\n");
  return 0;
  // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit readInt 12\n");
  // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit readInt 1\n");
}

static std::string readFile(const std::string& path) {
  fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter readFile 1\n");
  std::ifstream file(path);
  std::string content(
      (std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
  return content;
  // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit readFile 1\n");
}

static void writeFile(const char* file, const std::string& content) {
  fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter writeFile 1\n");
  std::ofstream outfile(file, std::ofstream::binary);
  outfile.write(content.c_str(), static_cast<std::streamsize>(content.size()));
  outfile.close();
  // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit writeFile 1\n");
}

static void writeSamples(char const* argv[], const std::vector<int>& pathArgs,
    const std::vector<size_t>& sizes, const uint8_t* data) {
  fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter writeSamples 1\n");
  size_t offset = 0;
  
  for (size_t i = 0; i < pathArgs.size(); ++i) {
    fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter writeSamples 2\n");
    int j = pathArgs[i];
    const char* file = argv[j];
    size_t sampleSize = sizes[i];
    std::ofstream outfile(file, std::ofstream::binary);
    outfile.write(reinterpret_cast<const char*>(data + offset),
        static_cast<std::streamsize>(sampleSize));
    outfile.close();
    offset += sampleSize;
    // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit writeSamples 2\n");
  }
  // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit writeSamples 1\n");
}

/* Returns "base file name" or its tail, if it contains '/' or '\'. */
static const char* fileName(const char* path) {
  fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter fileName 1\n");
  const char* separator_position = strrchr(path, '/');
  if (separator_position) {
    fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter fileName 2\n");
    path = separator_position + 1;
    // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit fileName 2\n");
  }
  separator_position = strrchr(path, '\\');
  if (separator_position) {
    fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter fileName 3\n");
    path = separator_position + 1;
    // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit fileName 3\n");
  }
  return path;
  // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit fileName 1\n");
}

static void printHelp(const char* name) {
  fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter printHelp 1\n");
  fprintf(stderr, "Usage: %s [OPTION]... DICTIONARY [SAMPLE]...\n", name);
  fprintf(stderr,
      "Options:\n"
      "  --dm       use 'deorummolae' engine\n"
      "  --distill  rewrite samples; unique text parts are removed\n"
      "  --dsh      use 'durchschlag' engine (default)\n"
      "  --purify   rewrite samples; unique text parts are zeroed out\n"
      "  --sieve    use 'sieve' engine\n"
      "  -b#        set block length for 'durchschlag'; default: 1024\n"
      "  -s#        set slice length for 'distill', 'durchschlag', 'purify'\n"
      "             and 'sieve'; default: 16\n"
      "  -t#        set target dictionary size (limit); default: 16K\n"
      "  -u#        set minimum slice population (for rewrites); default: 2\n"
      "# is a decimal number with optional k/K/m/M suffix.\n"
      "WARNING: 'distill' and 'purify' will overwrite original samples!\n"
      "         Completely unique samples might become empty files.\n\n");
  // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit printHelp 1\n");
}

int main(int argc, char const* argv[]) {
  fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter main 1\n");
  int dictionaryArg = -1;
  int method = METHOD_DURCHSCHLAG;
  size_t sliceLen = 16;
  size_t targetSize = 16 << 10;
  size_t blockSize = 1024;
  size_t minimumPopulation = 2;

  std::vector<uint8_t> data;
  std::vector<size_t> sizes;
  std::vector<int> pathArgs;
  size_t total = 0;
  // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit main 1\n");
  
  for (int i = 1; i < argc; ++i) {
    fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter main 2\n");
    if (argv[i] == nullptr) {
      fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter main 3\n");
      continue;
      // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit main 3\n");
    }
    if (argv[i][0] == '-') {
      fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter main 4\n");
      if (argv[i][1] == '-') {
        fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter main 5\n");
        if (dictionaryArg != -1) {
          fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter main 6\n");
          fprintf(stderr,
              "Method should be specified before dictionary / sample '%s'\n",
              argv[i]);
          exit(1);
          // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit main 6\n");
        }
        if (std::strcmp("--sieve", argv[i]) == 0) {
          fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter main 7\n");
          method = METHOD_SIEVE;
          continue;
          // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit main 7\n");
        }
        if (std::strcmp("--dm", argv[i]) == 0) {
          fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter main 8\n");
          method = METHOD_DM;
          continue;
          // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit main 8\n");
        }
        if (std::strcmp("--dsh", argv[i]) == 0) {
          fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter main 9\n");
          method = METHOD_DURCHSCHLAG;
          continue;
          // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit main 9\n");
        }
        if (std::strcmp("--distill", argv[i]) == 0) {
          fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter main 10\n");
          method = METHOD_DISTILL;
          continue;
          // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit main 10\n");
        }
        if (std::strcmp("--purify", argv[i]) == 0) {
          fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter main 11\n");
          method = METHOD_PURIFY;
          continue;
          // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit main 11\n");
        }
        
        fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter main 12\n");
        printHelp(fileName(argv[0]));
        fprintf(stderr, "Invalid option '%s'\n", argv[i]);
        exit(1);
        // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit main 12\n");
        // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit main 5\n");
      }
      if (argv[i][1] == 'b') {
        fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter main 13\n");
        blockSize = readInt(&argv[i][2]);
        if (blockSize < 16 || blockSize > 65536) {
          fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter main 14\n");
          printHelp(fileName(argv[0]));
          fprintf(stderr, "Invalid option '%s'\n", argv[i]);
          exit(1);
          // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit main 14\n");
        }
        // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit main 13\n");
      } else if (argv[i][1] == 's') {
        fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter main 15\n");
        sliceLen = readInt(&argv[i][2]);
        if (sliceLen < 4 || sliceLen > 256) {
          fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter main 16\n");
          printHelp(fileName(argv[0]));
          fprintf(stderr, "Invalid option '%s'\n", argv[i]);
          exit(1);
          // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit main 16\n");
        }
        // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit main 15\n");
      } else if (argv[i][1] == 't') {
        fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter main 17\n");
        targetSize = readInt(&argv[i][2]);
        if (targetSize < 256 || targetSize > (1 << 25)) {
          fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter main 18\n");
          printHelp(fileName(argv[0]));
          fprintf(stderr, "Invalid option '%s'\n", argv[i]);
          exit(1);
          // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit main 18\n");
        }
        // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit main 17\n");
      } else if (argv[i][1] == 'u') {
        fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter main 19\n");
        minimumPopulation = readInt(&argv[i][2]);
        if (minimumPopulation < 256 || minimumPopulation > 65536) {
          fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter main 20\n");
          printHelp(fileName(argv[0]));
          fprintf(stderr, "Invalid option '%s'\n", argv[i]);
          exit(1);
          // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit main 20\n");
        }
        // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit main 19\n");
      } else {
        fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter main 21\n");
        printHelp(fileName(argv[0]));
        fprintf(stderr, "Unrecognized option '%s'\n", argv[i]);
        exit(1);
        // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit main 21\n");
      }
      continue;
      // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit main 4\n");
    }
    if (dictionaryArg == -1) {
      fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter main 22\n");
      if (method != METHOD_DISTILL && method != METHOD_PURIFY) {
        fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter main 23\n");
        dictionaryArg = i;
        continue;
        // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit main 23\n");
      }
      // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit main 22\n");
    }
    
    fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter main 24\n");
    std::string content = readFile(argv[i]);
    data.insert(data.end(), content.begin(), content.end());
    total += content.size();
    pathArgs.push_back(i);
    sizes.push_back(content.size());
    // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit main 24\n");
    // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit main 2\n");
  }
  
  fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter main 25\n");
  bool wantDictionary = (dictionaryArg == -1);
  if (method == METHOD_DISTILL || method == METHOD_PURIFY) {
    fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter main 26\n");
    wantDictionary = false;
    // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit main 26\n");
  }
  if (wantDictionary || total == 0) {
    fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter main 27\n");
    printHelp(fileName(argv[0]));
    fprintf(stderr, "Not enough arguments\n");
    exit(1);
    // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit main 27\n");
  }

  if (method == METHOD_SIEVE) {
    fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter main 28\n");
    writeFile(argv[dictionaryArg], sieve_generate(
        targetSize, sliceLen, sizes, data.data()));
    // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit main 28\n");
  } else if (method == METHOD_DM) {
    fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter main 29\n");
    writeFile(argv[dictionaryArg], DM_generate(
        targetSize, sizes, data.data()));
    // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit main 29\n");
  } else if (method == METHOD_DURCHSCHLAG) {
    fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter main 30\n");
    writeFile(argv[dictionaryArg], durchschlag_generate(
        targetSize, sliceLen, blockSize, sizes, data.data()));
    // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit main 30\n");
  } else if (method == METHOD_DISTILL) {
    fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter main 31\n");
    durchschlag_distill(sliceLen, minimumPopulation, &sizes, data.data());
    writeSamples(argv, pathArgs, sizes, data.data());
    // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit main 31\n");
  } else if (method == METHOD_PURIFY) {
    fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter main 32\n");
    durchschlag_purify(sliceLen, minimumPopulation, sizes, data.data());
    writeSamples(argv, pathArgs, sizes, data.data());
    // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit main 32\n");
  } else {
    fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter main 33\n");
    printHelp(fileName(argv[0]));
    fprintf(stderr, "Unknown generator\n");
    exit(1);
    // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit main 33\n");
  }
  
  fprintf(stderr, "[brotli/research/dictionary_generator.cc] enter main 34\n");
  return 0;
  // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit main 34\n");
  // fprintf(stderr, "[brotli/research/dictionary_generator.cc] exit main 25\n");
}
// Total cost: 0.946206
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 232)]
// Total instrumented cost: 0.946206, input tokens: 91324, output tokens: 52142, cache read tokens: 91280, cache write tokens: 36416
