#ifndef BROTLI_RESEARCH_DEORUMMOLAE_H_
#define BROTLI_RESEARCH_DEORUMMOLAE_H_

#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

/* log2(maximal number of files). Value 6 provides some speedups. */
#define DM_LOG_MAX_FILES 6

/* Non tunable definitions. */
#define DM_MAX_FILES (1 << DM_LOG_MAX_FILES)

/**
 * Generate a dictionary for given samples.
 *
 * @param dictionary_size_limit maximal dictionary size
 * @param sample_sizes vector with sample sizes
 * @param sample_data concatenated samples
 * @return generated dictionary
 */
std::string DM_generate(size_t dictionary_size_limit,
    const std::vector<size_t>& sample_sizes, const uint8_t* sample_data);

#endif  // BROTLI_RESEARCH_DEORUMMOLAE_H_
// Total cost: 0.002376
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 26)]
// Total instrumented cost: 0.002376, input tokens: 2398, output tokens: 23, cache read tokens: 2394, cache write tokens: 347
