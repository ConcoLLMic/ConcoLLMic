/* Copyright 2018 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include <brotli/decode.h>

#define BUFFER_SIZE (1u << 20)

typedef struct Context {
  FILE* fin;
  FILE* fout;
  uint8_t* input_buffer;
  uint8_t* output_buffer;
  BrotliDecoderState* decoder;
} Context;

void init(Context* ctx) {
  fprintf(stderr, "[brotli/research/brotli_decoder.c] enter init 1\n");
  ctx->fin = 0;
  ctx->fout = 0;
  ctx->input_buffer = 0;
  ctx->output_buffer = 0;
  ctx->decoder = 0;
  // fprintf(stderr, "[brotli/research/brotli_decoder.c] exit init 1\n");
}

void cleanup(Context* ctx) {
  fprintf(stderr, "[brotli/research/brotli_decoder.c] enter cleanup 1\n");
  if (ctx->decoder) BrotliDecoderDestroyInstance(ctx->decoder);
  if (ctx->output_buffer) free(ctx->output_buffer);
  if (ctx->input_buffer) free(ctx->input_buffer);
  if (ctx->fout) fclose(ctx->fout);
  if (ctx->fin) fclose(ctx->fin);
  // fprintf(stderr, "[brotli/research/brotli_decoder.c] exit cleanup 1\n");
}

void fail(Context* ctx, const char* message) {
  fprintf(stderr, "[brotli/research/brotli_decoder.c] enter fail 1\n");
  fprintf(stderr, "%s\n", message);
  exit(1);
  // fprintf(stderr, "[brotli/research/brotli_decoder.c] exit fail 1\n");
}

int main(int argc, char** argv) {
  fprintf(stderr, "[brotli/research/brotli_decoder.c] enter main 1\n");
  Context ctx;
  BrotliDecoderResult result = BROTLI_DECODER_RESULT_NEEDS_MORE_INPUT;
  size_t available_in;
  const uint8_t* next_in;
  size_t available_out = BUFFER_SIZE;
  uint8_t* next_out;
  init(&ctx);

  ctx.fin = fdopen(STDIN_FILENO, "rb");
  if (!ctx.fin) {
    fprintf(stderr, "[brotli/research/brotli_decoder.c] enter main 2\n");
    fail(&ctx, "can't open input file");
    // fprintf(stderr, "[brotli/research/brotli_decoder.c] exit main 2\n");
  }
  
  ctx.fout = fdopen(STDOUT_FILENO, "wb");
  if (!ctx.fout) {
    fprintf(stderr, "[brotli/research/brotli_decoder.c] enter main 3\n");
    fail(&ctx, "can't open output file");
    // fprintf(stderr, "[brotli/research/brotli_decoder.c] exit main 3\n");
  }
  
  ctx.input_buffer = (uint8_t*)malloc(BUFFER_SIZE);
  if (!ctx.input_buffer) {
    fprintf(stderr, "[brotli/research/brotli_decoder.c] enter main 4\n");
    fail(&ctx, "out of memory / input buffer");
    // fprintf(stderr, "[brotli/research/brotli_decoder.c] exit main 4\n");
  }
  
  ctx.output_buffer = (uint8_t*)malloc(BUFFER_SIZE);
  if (!ctx.output_buffer) {
    fprintf(stderr, "[brotli/research/brotli_decoder.c] enter main 5\n");
    fail(&ctx, "out of memory / output buffer");
    // fprintf(stderr, "[brotli/research/brotli_decoder.c] exit main 5\n");
  }
  
  ctx.decoder = BrotliDecoderCreateInstance(0, 0, 0);
  if (!ctx.decoder) {
    fprintf(stderr, "[brotli/research/brotli_decoder.c] enter main 6\n");
    fail(&ctx, "out of memory / decoder");
    // fprintf(stderr, "[brotli/research/brotli_decoder.c] exit main 6\n");
  }
  
  BrotliDecoderSetParameter(ctx.decoder, BROTLI_DECODER_PARAM_LARGE_WINDOW, 1);

  next_out = ctx.output_buffer;
  while (1) {
    fprintf(stderr, "[brotli/research/brotli_decoder.c] enter main 7\n");
    if (result == BROTLI_DECODER_RESULT_NEEDS_MORE_INPUT) {
      fprintf(stderr, "[brotli/research/brotli_decoder.c] enter main 8\n");
      if (feof(ctx.fin)) {
        fprintf(stderr, "[brotli/research/brotli_decoder.c] enter main 9\n");
        break;
        // fprintf(stderr, "[brotli/research/brotli_decoder.c] exit main 9\n");
      }
      available_in = fread(ctx.input_buffer, 1, BUFFER_SIZE, ctx.fin);
      next_in = ctx.input_buffer;
      if (ferror(ctx.fin)) {
        fprintf(stderr, "[brotli/research/brotli_decoder.c] enter main 10\n");
        break;
        // fprintf(stderr, "[brotli/research/brotli_decoder.c] exit main 10\n");
      }
      // fprintf(stderr, "[brotli/research/brotli_decoder.c] exit main 8\n");
    } else if (result == BROTLI_DECODER_RESULT_NEEDS_MORE_OUTPUT) {
      fprintf(stderr, "[brotli/research/brotli_decoder.c] enter main 11\n");
      fwrite(ctx.output_buffer, 1, BUFFER_SIZE, ctx.fout);
      if (ferror(ctx.fout)) {
        fprintf(stderr, "[brotli/research/brotli_decoder.c] enter main 12\n");
        break;
        // fprintf(stderr, "[brotli/research/brotli_decoder.c] exit main 12\n");
      }
      available_out = BUFFER_SIZE;
      next_out = ctx.output_buffer;
      // fprintf(stderr, "[brotli/research/brotli_decoder.c] exit main 11\n");
    } else {
      fprintf(stderr, "[brotli/research/brotli_decoder.c] enter main 13\n");
      break;
      // fprintf(stderr, "[brotli/research/brotli_decoder.c] exit main 13\n");
    }
    result = BrotliDecoderDecompressStream(
        ctx.decoder, &available_in, &next_in, &available_out, &next_out, 0);
    // fprintf(stderr, "[brotli/research/brotli_decoder.c] exit main 7\n");
  }
  
  if (next_out != ctx.output_buffer) {
    fprintf(stderr, "[brotli/research/brotli_decoder.c] enter main 14\n");
    fwrite(ctx.output_buffer, 1, next_out - ctx.output_buffer, ctx.fout);
    // fprintf(stderr, "[brotli/research/brotli_decoder.c] exit main 14\n");
  }
  
  if ((result == BROTLI_DECODER_RESULT_NEEDS_MORE_OUTPUT) || ferror(ctx.fout)) {
    fprintf(stderr, "[brotli/research/brotli_decoder.c] enter main 15\n");
    fail(&ctx, "failed to write output");
    // fprintf(stderr, "[brotli/research/brotli_decoder.c] exit main 15\n");
  } else if (result != BROTLI_DECODER_RESULT_SUCCESS) {
    fprintf(stderr, "[brotli/research/brotli_decoder.c] enter main 16\n");
    fail(&ctx, "corrupt input");
    // fprintf(stderr, "[brotli/research/brotli_decoder.c] exit main 16\n");
  }
  
  cleanup(&ctx);
  return 0;
  // fprintf(stderr, "[brotli/research/brotli_decoder.c] exit main 1\n");
}
// Total cost: 0.030951
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 93)]
// Total instrumented cost: 0.030951, input tokens: 2398, output tokens: 1722, cache read tokens: 2394, cache write tokens: 1171
