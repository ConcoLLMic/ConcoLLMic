#include "./sieve.h"
#include <stdio.h>

/* Pointer to position in (combined corpus) text. */
typedef uint32_t TextIdx;

/* Index of sample / generation. */
typedef uint16_t SampleIdx;

typedef struct Slot {
  TextIdx next;
  TextIdx offset;
  SampleIdx presence;
  SampleIdx mark;
} Slot;

static const TextIdx kNowhere = static_cast<TextIdx>(-1);

static TextIdx dryRun(TextIdx sliceLen, Slot* map, TextIdx* shortcut,
    TextIdx end, TextIdx middle, SampleIdx minPresence, SampleIdx iteration) {
  fprintf(stderr, "[brotli/research/sieve.cc] enter dryRun 1\n");
  TextIdx from = kNowhere;
  TextIdx to = kNowhere;
  TextIdx result = 0;
  SampleIdx targetPresence = minPresence;
  // fprintf(stderr, "[brotli/research/sieve.cc] exit dryRun 1\n");
  
  for (TextIdx i = 0; i < end; ++i) {
    fprintf(stderr, "[brotli/research/sieve.cc] enter dryRun 2\n");
    if (i == middle) {
      fprintf(stderr, "[brotli/research/sieve.cc] enter dryRun 3\n");
      targetPresence++;
      // fprintf(stderr, "[brotli/research/sieve.cc] exit dryRun 3\n");
    }
    Slot& item = map[shortcut[i]];
    if (item.mark != iteration) {
      fprintf(stderr, "[brotli/research/sieve.cc] enter dryRun 4\n");
      item.mark = iteration;
      if (item.presence >= targetPresence) {
        fprintf(stderr, "[brotli/research/sieve.cc] enter dryRun 5\n");
        if ((to == kNowhere) || (to < i)) {
          fprintf(stderr, "[brotli/research/sieve.cc] enter dryRun 6\n");
          if (from != kNowhere) {
            fprintf(stderr, "[brotli/research/sieve.cc] enter dryRun 7\n");
            result += to - from;
            // fprintf(stderr, "[brotli/research/sieve.cc] exit dryRun 7\n");
          }
          from = i;
          // fprintf(stderr, "[brotli/research/sieve.cc] exit dryRun 6\n");
        }
        to = i + sliceLen;
        // fprintf(stderr, "[brotli/research/sieve.cc] exit dryRun 5\n");
      }
      // fprintf(stderr, "[brotli/research/sieve.cc] exit dryRun 4\n");
    }
    // fprintf(stderr, "[brotli/research/sieve.cc] exit dryRun 2\n");
  }
  
  fprintf(stderr, "[brotli/research/sieve.cc] enter dryRun 8\n");
  if (from != kNowhere) {
    fprintf(stderr, "[brotli/research/sieve.cc] enter dryRun 9\n");
    result += to - from;
    // fprintf(stderr, "[brotli/research/sieve.cc] exit dryRun 9\n");
  }
  return result;
  // fprintf(stderr, "[brotli/research/sieve.cc] exit dryRun 8\n");
}

static std::string createDictionary(const uint8_t* data, TextIdx sliceLen,
    Slot* map, TextIdx* shortcut, TextIdx end, TextIdx middle,
    SampleIdx minPresence, SampleIdx iteration) {
  fprintf(stderr, "[brotli/research/sieve.cc] enter createDictionary 1\n");
  std::string output;
  TextIdx from = kNowhere;
  TextIdx to = kNowhere;
  SampleIdx targetPresence = minPresence;
  // fprintf(stderr, "[brotli/research/sieve.cc] exit createDictionary 1\n");
  
  for (TextIdx i = 0; i < end; ++i) {
    fprintf(stderr, "[brotli/research/sieve.cc] enter createDictionary 2\n");
    if (i == middle) {
      fprintf(stderr, "[brotli/research/sieve.cc] enter createDictionary 3\n");
      targetPresence++;
      // fprintf(stderr, "[brotli/research/sieve.cc] exit createDictionary 3\n");
    }
    Slot& item = map[shortcut[i]];
    if (item.mark != iteration) {
      fprintf(stderr, "[brotli/research/sieve.cc] enter createDictionary 4\n");
      item.mark = iteration;
      if (item.presence >= targetPresence) {
        fprintf(stderr, "[brotli/research/sieve.cc] enter createDictionary 5\n");
        if ((to == kNowhere) || (to < i)) {
          fprintf(stderr, "[brotli/research/sieve.cc] enter createDictionary 6\n");
          if (from != kNowhere) {
            fprintf(stderr, "[brotli/research/sieve.cc] enter createDictionary 7\n");
            output.insert(output.end(), &data[from], &data[to]);
            // fprintf(stderr, "[brotli/research/sieve.cc] exit createDictionary 7\n");
          }
          from = i;
          // fprintf(stderr, "[brotli/research/sieve.cc] exit createDictionary 6\n");
        }
        to = i + sliceLen;
        // fprintf(stderr, "[brotli/research/sieve.cc] exit createDictionary 5\n");
      }
      // fprintf(stderr, "[brotli/research/sieve.cc] exit createDictionary 4\n");
    }
    // fprintf(stderr, "[brotli/research/sieve.cc] exit createDictionary 2\n");
  }
  
  fprintf(stderr, "[brotli/research/sieve.cc] enter createDictionary 8\n");
  if (from != kNowhere) {
    fprintf(stderr, "[brotli/research/sieve.cc] enter createDictionary 9\n");
    output.insert(output.end(), &data[from], &data[to]);
    // fprintf(stderr, "[brotli/research/sieve.cc] exit createDictionary 9\n");
  }
  return output;
  // fprintf(stderr, "[brotli/research/sieve.cc] exit createDictionary 8\n");
}

std::string sieve_generate(size_t dictionary_size_limit, size_t slice_len,
    const std::vector<size_t>& sample_sizes, const uint8_t* sample_data) {
  fprintf(stderr, "[brotli/research/sieve.cc] enter sieve_generate 1\n");
  /* Parameters aliasing */
  TextIdx targetSize = static_cast<TextIdx>(dictionary_size_limit);
  if (targetSize != dictionary_size_limit) {
    fprintf(stderr, "[brotli/research/sieve.cc] enter sieve_generate 2\n");
    fprintf(stderr, "dictionary_size_limit is too large\n");
    return "";
    // fprintf(stderr, "[brotli/research/sieve.cc] exit sieve_generate 2\n");
  }
  TextIdx sliceLen = static_cast<TextIdx>(slice_len);
  if (sliceLen != slice_len) {
    fprintf(stderr, "[brotli/research/sieve.cc] enter sieve_generate 3\n");
    fprintf(stderr, "slice_len is too large\n");
    return "";
    // fprintf(stderr, "[brotli/research/sieve.cc] exit sieve_generate 3\n");
  }
  if (sliceLen < 1) {
    fprintf(stderr, "[brotli/research/sieve.cc] enter sieve_generate 4\n");
    fprintf(stderr, "slice_len is too small\n");
    return "";
    // fprintf(stderr, "[brotli/research/sieve.cc] exit sieve_generate 4\n");
  }
  SampleIdx numSamples = static_cast<SampleIdx>(sample_sizes.size());
  if ((numSamples != sample_sizes.size()) || (numSamples * 2 < numSamples)) {
    fprintf(stderr, "[brotli/research/sieve.cc] enter sieve_generate 5\n");
    fprintf(stderr, "too many samples\n");
    return "";
    // fprintf(stderr, "[brotli/research/sieve.cc] exit sieve_generate 5\n");
  }
  const uint8_t* data = sample_data;

  TextIdx total = 0;
  std::vector<TextIdx> offsets;
  // fprintf(stderr, "[brotli/research/sieve.cc] exit sieve_generate 1\n");
  
  for (SampleIdx i = 0; i < numSamples; ++i) {
    fprintf(stderr, "[brotli/research/sieve.cc] enter sieve_generate 6\n");
    TextIdx delta = static_cast<TextIdx>(sample_sizes[i]);
    if (delta != sample_sizes[i]) {
      fprintf(stderr, "[brotli/research/sieve.cc] enter sieve_generate 7\n");
      fprintf(stderr, "sample is too large\n");
      return "";
      // fprintf(stderr, "[brotli/research/sieve.cc] exit sieve_generate 7\n");
    }
    if (delta == 0) {
      fprintf(stderr, "[brotli/research/sieve.cc] enter sieve_generate 8\n");
      fprintf(stderr, "empty samples are prohibited\n");
      return "";
      // fprintf(stderr, "[brotli/research/sieve.cc] exit sieve_generate 8\n");
    }
    if (total + delta <= total) {
      fprintf(stderr, "[brotli/research/sieve.cc] enter sieve_generate 9\n");
      fprintf(stderr, "corpus is too large\n");
      return "";
      // fprintf(stderr, "[brotli/research/sieve.cc] exit sieve_generate 9\n");
    }
    total += delta;
    offsets.push_back(total);
    // fprintf(stderr, "[brotli/research/sieve.cc] exit sieve_generate 6\n");
  }

  fprintf(stderr, "[brotli/research/sieve.cc] enter sieve_generate 10\n");
  if (total * 2 < total) {
    fprintf(stderr, "[brotli/research/sieve.cc] enter sieve_generate 11\n");
    fprintf(stderr, "corpus is too large\n");
    return "";
    // fprintf(stderr, "[brotli/research/sieve.cc] exit sieve_generate 11\n");
  }

  if (total < sliceLen) {
    fprintf(stderr, "[brotli/research/sieve.cc] enter sieve_generate 12\n");
    fprintf(stderr, "slice_len is larger than corpus size\n");
    return "";
    // fprintf(stderr, "[brotli/research/sieve.cc] exit sieve_generate 12\n");
  }

  /*****************************************************************************
   * Build coverage map.
   ****************************************************************************/
  std::vector<Slot> map;
  std::vector<TextIdx> shortcut;
  map.push_back({0, 0, 0, 0});
  TextIdx end = total - sliceLen;
  TextIdx hashLen = 11;
  while (hashLen < 29 && ((1u << hashLen) < end)) {
    fprintf(stderr, "[brotli/research/sieve.cc] enter sieve_generate 13\n");
    hashLen += 3;
    // fprintf(stderr, "[brotli/research/sieve.cc] exit sieve_generate 13\n");
  }
  hashLen -= 3;
  TextIdx hashMask = (1u << hashLen) - 1u;
  std::vector<TextIdx> hashHead(1 << hashLen);
  TextIdx hashSlot = 1;
  SampleIdx piece = 0;
  TextIdx hash = 0;
  TextIdx lShift = 3;
  TextIdx rShift = hashLen - lShift;
  // fprintf(stderr, "[brotli/research/sieve.cc] exit sieve_generate 10\n");
  
  for (TextIdx i = 0; i < sliceLen - 1; ++i) {
    fprintf(stderr, "[brotli/research/sieve.cc] enter sieve_generate 14\n");
    TextIdx v = data[i];
    hash = (((hash << lShift) | (hash >> rShift)) & hashMask) ^ v;
    // fprintf(stderr, "[brotli/research/sieve.cc] exit sieve_generate 14\n");
  }
  
  fprintf(stderr, "[brotli/research/sieve.cc] enter sieve_generate 15\n");
  TextIdx lShiftX = (lShift * (sliceLen - 1)) % hashLen;
  TextIdx rShiftX = hashLen - lShiftX;
  // fprintf(stderr, "[brotli/research/sieve.cc] exit sieve_generate 15\n");
  
  for (TextIdx i = 0; i < end; ++i) {
    fprintf(stderr, "[brotli/research/sieve.cc] enter sieve_generate 16\n");
    TextIdx v = data[i + sliceLen - 1];
    hash = (((hash << lShift) | (hash >> rShift)) & hashMask) ^ v;

    if (offsets[piece] == i) {
      fprintf(stderr, "[brotli/research/sieve.cc] enter sieve_generate 17\n");
      piece++;
      // fprintf(stderr, "[brotli/research/sieve.cc] exit sieve_generate 17\n");
    }
    TextIdx slot = hashHead[hash];
    while (slot != 0) {
      fprintf(stderr, "[brotli/research/sieve.cc] enter sieve_generate 18\n");
      Slot& item = map[slot];
      TextIdx start = item.offset;
      bool miss = false;
      // fprintf(stderr, "[brotli/research/sieve.cc] exit sieve_generate 18\n");
      
      for (TextIdx j = 0; j < sliceLen; ++j) {
        fprintf(stderr, "[brotli/research/sieve.cc] enter sieve_generate 19\n");
        if (data[i + j] != data[start + j]) {
          fprintf(stderr, "[brotli/research/sieve.cc] enter sieve_generate 20\n");
          miss = true;
          break;
          // fprintf(stderr, "[brotli/research/sieve.cc] exit sieve_generate 20\n");
        }
        // fprintf(stderr, "[brotli/research/sieve.cc] exit sieve_generate 19\n");
      }
      
      fprintf(stderr, "[brotli/research/sieve.cc] enter sieve_generate 21\n");
      if (!miss) {
        fprintf(stderr, "[brotli/research/sieve.cc] enter sieve_generate 22\n");
        if (item.mark != piece) {
          fprintf(stderr, "[brotli/research/sieve.cc] enter sieve_generate 23\n");
          item.mark = piece;
          item.presence++;
          // fprintf(stderr, "[brotli/research/sieve.cc] exit sieve_generate 23\n");
        }
        shortcut.push_back(slot);
        break;
        // fprintf(stderr, "[brotli/research/sieve.cc] exit sieve_generate 22\n");
      }
      slot = item.next;
      // fprintf(stderr, "[brotli/research/sieve.cc] exit sieve_generate 21\n");
    }
    
    fprintf(stderr, "[brotli/research/sieve.cc] enter sieve_generate 24\n");
    if (slot == 0) {
      fprintf(stderr, "[brotli/research/sieve.cc] enter sieve_generate 25\n");
      map.push_back({hashHead[hash], i, 1, piece});
      hashHead[hash] = hashSlot;
      shortcut.push_back(hashSlot);
      hashSlot++;
      // fprintf(stderr, "[brotli/research/sieve.cc] exit sieve_generate 25\n");
    }
    v = data[i];
    hash ^= ((v << lShiftX) | (v >> rShiftX)) & hashMask;
    // fprintf(stderr, "[brotli/research/sieve.cc] exit sieve_generate 24\n");
    // fprintf(stderr, "[brotli/research/sieve.cc] exit sieve_generate 16\n");
  }

  /*****************************************************************************
   * Build dictionary of specified size.
   ****************************************************************************/
  fprintf(stderr, "[brotli/research/sieve.cc] enter sieve_generate 26\n");
  SampleIdx a = 1;
  TextIdx size = dryRun(
      sliceLen, map.data(), shortcut.data(), end, end, a, ++piece);
  /* Maximal output is smaller than target. */
  if (size <= targetSize) {
    fprintf(stderr, "[brotli/research/sieve.cc] enter sieve_generate 27\n");
    return createDictionary(
        data, sliceLen, map.data(), shortcut.data(), end, end, a, ++piece);
    // fprintf(stderr, "[brotli/research/sieve.cc] exit sieve_generate 27\n");
  }

  SampleIdx b = numSamples;
  size = dryRun(sliceLen, map.data(), shortcut.data(), end, end, b, ++piece);
  if (size == targetSize) {
    fprintf(stderr, "[brotli/research/sieve.cc] enter sieve_generate 28\n");
    return createDictionary(
        data, sliceLen, map.data(), shortcut.data(), end, end, b, ++piece);
    // fprintf(stderr, "[brotli/research/sieve.cc] exit sieve_generate 28\n");
  }
  /* Run binary search. */
  if (size < targetSize) {
    fprintf(stderr, "[brotli/research/sieve.cc] enter sieve_generate 29\n");
    /* size(a) > targetSize > size(b) && a < m < b */
    while (a + 1 < b) {
      fprintf(stderr, "[brotli/research/sieve.cc] enter sieve_generate 30\n");
      SampleIdx m = static_cast<SampleIdx>((a + b) / 2);
      size = dryRun(
          sliceLen, map.data(), shortcut.data(), end, end, m, ++piece);
      if (size < targetSize) {
        fprintf(stderr, "[brotli/research/sieve.cc] enter sieve_generate 31\n");
        b = m;
        // fprintf(stderr, "[brotli/research/sieve.cc] exit sieve_generate 31\n");
      } else if (size > targetSize) {
        fprintf(stderr, "[brotli/research/sieve.cc] enter sieve_generate 32\n");
        a = m;
        // fprintf(stderr, "[brotli/research/sieve.cc] exit sieve_generate 32\n");
      } else {
        fprintf(stderr, "[brotli/research/sieve.cc] enter sieve_generate 33\n");
        return createDictionary(
            data, sliceLen, map.data(), shortcut.data(), end, end, b, ++piece);
        // fprintf(stderr, "[brotli/research/sieve.cc] exit sieve_generate 33\n");
      }
      // fprintf(stderr, "[brotli/research/sieve.cc] exit sieve_generate 30\n");
    }
    // fprintf(stderr, "[brotli/research/sieve.cc] exit sieve_generate 29\n");
  } else {
    fprintf(stderr, "[brotli/research/sieve.cc] enter sieve_generate 34\n");
    a = b;
    // fprintf(stderr, "[brotli/research/sieve.cc] exit sieve_generate 34\n");
  }
  /* size(minPresence) > targetSize > size(minPresence + 1) */
  SampleIdx minPresence = a;
  TextIdx c = 0;
  TextIdx d = end;
  /* size(a) < targetSize < size(b) && a < m < b */
  while (c + 1 < d) {
    fprintf(stderr, "[brotli/research/sieve.cc] enter sieve_generate 35\n");
    TextIdx m = (c + d) / 2;
    size = dryRun(
        sliceLen, map.data(), shortcut.data(), end, m, minPresence, ++piece);
    if (size < targetSize) {
      fprintf(stderr, "[brotli/research/sieve.cc] enter sieve_generate 36\n");
      c = m;
      // fprintf(stderr, "[brotli/research/sieve.cc] exit sieve_generate 36\n");
    } else if (size > targetSize) {
      fprintf(stderr, "[brotli/research/sieve.cc] enter sieve_generate 37\n");
      d = m;
      // fprintf(stderr, "[brotli/research/sieve.cc] exit sieve_generate 37\n");
    } else {
      fprintf(stderr, "[brotli/research/sieve.cc] enter sieve_generate 38\n");
      return createDictionary(data, sliceLen, map.data(), shortcut.data(), end,
          m, minPresence, ++piece);
      // fprintf(stderr, "[brotli/research/sieve.cc] exit sieve_generate 38\n");
    }
    // fprintf(stderr, "[brotli/research/sieve.cc] exit sieve_generate 35\n");
  }

  fprintf(stderr, "[brotli/research/sieve.cc] enter sieve_generate 39\n");
  bool unrestricted = false;
  if (minPresence <= 2 && !unrestricted) {
    fprintf(stderr, "[brotli/research/sieve.cc] enter sieve_generate 40\n");
    minPresence = 2;
    c = end;
    // fprintf(stderr, "[brotli/research/sieve.cc] exit sieve_generate 40\n");
  }
  return createDictionary(data, sliceLen, map.data(), shortcut.data(), end, c,
      minPresence, ++piece);
  // fprintf(stderr, "[brotli/research/sieve.cc] exit sieve_generate 39\n");
  // fprintf(stderr, "[brotli/research/sieve.cc] exit sieve_generate 26\n");
}
// Total cost: 0.081753
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 259)]
// Total instrumented cost: 0.081753, input tokens: 2398, output tokens: 4721, cache read tokens: 2394, cache write tokens: 2722
