/*
 * utils.c for libdivsufsort
 * Copyright (c) 2003-2008 Yuta Mori All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */

#include "divsufsort_private.h"
#include <stdio.h>


/*- Private Function -*/

/* Binary search for inverse bwt. */
static
saidx_t
binarysearch_lower(const saidx_t *A, saidx_t size, saidx_t value) {
  fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter binarysearch_lower 1\n");
  saidx_t half, i;
  for(i = 0, half = size >> 1;
      0 < size;
      size = half, half >>= 1) {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter binarysearch_lower 2\n");
    if(A[i + half] < value) {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter binarysearch_lower 3\n");
      i += half + 1;
      half -= (size & 1) ^ 1;
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit binarysearch_lower 3\n");
    }
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit binarysearch_lower 2\n");
  }
  return i;
  // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit binarysearch_lower 1\n");
}


/*- Functions -*/

/* Burrows-Wheeler transform. */
saint_t
bw_transform(const sauchar_t *T, sauchar_t *U, saidx_t *SA,
             saidx_t n, saidx_t *idx) {
  fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter bw_transform 1\n");
  saidx_t *A, i, j, p, t;
  saint_t c;

  /* Check arguments. */
  if((T == NULL) || (U == NULL) || (n < 0) || (idx == NULL)) { 
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter bw_transform 2\n");
    return -1; 
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit bw_transform 2\n");
  }
  if(n <= 1) {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter bw_transform 3\n");
    if(n == 1) { 
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter bw_transform 4\n");
      U[0] = T[0]; 
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit bw_transform 4\n");
    }
    *idx = n;
    return 0;
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit bw_transform 3\n");
  }

  if((A = SA) == NULL) {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter bw_transform 5\n");
    i = divbwt(T, U, NULL, n);
    if(0 <= i) { 
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter bw_transform 6\n");
      *idx = i; 
      i = 0; 
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit bw_transform 6\n");
    }
    return (saint_t)i;
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit bw_transform 5\n");
  }

  /* BW transform. */
  if(T == U) {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter bw_transform 7\n");
    t = n;
    for(i = 0, j = 0; i < n; ++i) {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter bw_transform 8\n");
      p = t - 1;
      t = A[i];
      if(0 <= p) {
        fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter bw_transform 9\n");
        c = T[j];
        U[j] = (j <= p) ? T[p] : (sauchar_t)A[p];
        A[j] = c;
        j++;
        // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit bw_transform 9\n");
      } else {
        fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter bw_transform 10\n");
        *idx = i;
        // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit bw_transform 10\n");
      }
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit bw_transform 8\n");
    }
    p = t - 1;
    if(0 <= p) {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter bw_transform 11\n");
      c = T[j];
      U[j] = (j <= p) ? T[p] : (sauchar_t)A[p];
      A[j] = c;
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit bw_transform 11\n");
    } else {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter bw_transform 12\n");
      *idx = i;
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit bw_transform 12\n");
    }
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit bw_transform 7\n");
  } else {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter bw_transform 13\n");
    U[0] = T[n - 1];
    for(i = 0; A[i] != 0; ++i) { 
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter bw_transform 14\n");
      U[i + 1] = T[A[i] - 1]; 
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit bw_transform 14\n");
    }
    *idx = i + 1;
    for(++i; i < n; ++i) { 
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter bw_transform 15\n");
      U[i] = T[A[i] - 1]; 
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit bw_transform 15\n");
    }
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit bw_transform 13\n");
  }

  if(SA == NULL) {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter bw_transform 16\n");
    /* Deallocate memory. */
    free(A);
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit bw_transform 16\n");
  }

  return 0;
  // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit bw_transform 1\n");
}

/* Inverse Burrows-Wheeler transform. */
saint_t
inverse_bw_transform(const sauchar_t *T, sauchar_t *U, saidx_t *A,
                     saidx_t n, saidx_t idx) {
  fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter inverse_bw_transform 1\n");
  saidx_t C[ALPHABET_SIZE];
  sauchar_t D[ALPHABET_SIZE];
  saidx_t *B;
  saidx_t i, p;
  saint_t c, d;

  /* Check arguments. */
  if((T == NULL) || (U == NULL) || (n < 0) || (idx < 0) ||
     (n < idx) || ((0 < n) && (idx == 0))) {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter inverse_bw_transform 2\n");
    return -1;
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit inverse_bw_transform 2\n");
  }
  if(n <= 1) { 
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter inverse_bw_transform 3\n");
    return 0; 
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit inverse_bw_transform 3\n");
  }

  if((B = A) == NULL) {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter inverse_bw_transform 4\n");
    /* Allocate n*sizeof(saidx_t) bytes of memory. */
    if((B = (saidx_t *)malloc((size_t)n * sizeof(saidx_t))) == NULL) { 
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter inverse_bw_transform 5\n");
      return -2; 
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit inverse_bw_transform 5\n");
    }
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit inverse_bw_transform 4\n");
  }

  /* Inverse BW transform. */
  for(c = 0; c < ALPHABET_SIZE; ++c) { 
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter inverse_bw_transform 6\n");
    C[c] = 0; 
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit inverse_bw_transform 6\n");
  }
  for(i = 0; i < n; ++i) { 
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter inverse_bw_transform 7\n");
    ++C[T[i]]; 
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit inverse_bw_transform 7\n");
  }
  for(c = 0, d = 0, i = 0; c < ALPHABET_SIZE; ++c) {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter inverse_bw_transform 8\n");
    p = C[c];
    if(0 < p) {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter inverse_bw_transform 9\n");
      C[c] = i;
      D[d++] = (sauchar_t)c;
      i += p;
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit inverse_bw_transform 9\n");
    }
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit inverse_bw_transform 8\n");
  }
  for(i = 0; i < idx; ++i) { 
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter inverse_bw_transform 10\n");
    B[C[T[i]]++] = i; 
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit inverse_bw_transform 10\n");
  }
  for( ; i < n; ++i) { 
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter inverse_bw_transform 11\n");
    B[C[T[i]]++] = i + 1; 
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit inverse_bw_transform 11\n");
  }
  for(c = 0; c < d; ++c) { 
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter inverse_bw_transform 12\n");
    C[c] = C[D[c]]; 
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit inverse_bw_transform 12\n");
  }
  for(i = 0, p = idx; i < n; ++i) {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter inverse_bw_transform 13\n");
    U[i] = D[binarysearch_lower(C, d, p)];
    p = B[p - 1];
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit inverse_bw_transform 13\n");
  }

  if(A == NULL) {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter inverse_bw_transform 14\n");
    /* Deallocate memory. */
    free(B);
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit inverse_bw_transform 14\n");
  }

  return 0;
  // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit inverse_bw_transform 1\n");
}

/* Checks the suffix array SA of the string T. */
saint_t
sufcheck(const sauchar_t *T, const saidx_t *SA,
         saidx_t n, saint_t verbose) {
  fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sufcheck 1\n");
  saidx_t C[ALPHABET_SIZE];
  saidx_t i, p, q, t;
  saint_t c;

  if(verbose) { 
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sufcheck 2\n");
    fprintf(stderr, "sufcheck: "); 
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sufcheck 2\n");
  }

  /* Check arguments. */
  if((T == NULL) || (SA == NULL) || (n < 0)) {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sufcheck 3\n");
    if(verbose) { 
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sufcheck 4\n");
      fprintf(stderr, "Invalid arguments.\n"); 
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sufcheck 4\n");
    }
    return -1;
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sufcheck 3\n");
  }
  if(n == 0) {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sufcheck 5\n");
    if(verbose) { 
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sufcheck 6\n");
      fprintf(stderr, "Done.\n"); 
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sufcheck 6\n");
    }
    return 0;
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sufcheck 5\n");
  }

  /* check range: [0..n-1] */
  for(i = 0; i < n; ++i) {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sufcheck 7\n");
    if((SA[i] < 0) || (n <= SA[i])) {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sufcheck 8\n");
      if(verbose) {
        fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sufcheck 9\n");
        fprintf(stderr, "Out of the range [0,%" PRIdSAIDX_T "].\n"
                        "  SA[%" PRIdSAIDX_T "]=%" PRIdSAIDX_T "\n",
                        n - 1, i, SA[i]);
        // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sufcheck 9\n");
      }
      return -2;
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sufcheck 8\n");
    }
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sufcheck 7\n");
  }

  /* check first characters. */
  for(i = 1; i < n; ++i) {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sufcheck 10\n");
    if(T[SA[i - 1]] > T[SA[i]]) {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sufcheck 11\n");
      if(verbose) {
        fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sufcheck 12\n");
        fprintf(stderr, "Suffixes in wrong order.\n"
                        "  T[SA[%" PRIdSAIDX_T "]=%" PRIdSAIDX_T "]=%d"
                        " > T[SA[%" PRIdSAIDX_T "]=%" PRIdSAIDX_T "]=%d\n",
                        i - 1, SA[i - 1], T[SA[i - 1]], i, SA[i], T[SA[i]]);
        // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sufcheck 12\n");
      }
      return -3;
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sufcheck 11\n");
    }
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sufcheck 10\n");
  }

  /* check suffixes. */
  for(i = 0; i < ALPHABET_SIZE; ++i) { 
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sufcheck 13\n");
    C[i] = 0; 
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sufcheck 13\n");
  }
  for(i = 0; i < n; ++i) { 
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sufcheck 14\n");
    ++C[T[i]]; 
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sufcheck 14\n");
  }
  for(i = 0, p = 0; i < ALPHABET_SIZE; ++i) {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sufcheck 15\n");
    t = C[i];
    C[i] = p;
    p += t;
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sufcheck 15\n");
  }

  q = C[T[n - 1]];
  C[T[n - 1]] += 1;
  for(i = 0; i < n; ++i) {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sufcheck 16\n");
    p = SA[i];
    if(0 < p) {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sufcheck 17\n");
      c = T[--p];
      t = C[c];
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sufcheck 17\n");
    } else {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sufcheck 18\n");
      c = T[p = n - 1];
      t = q;
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sufcheck 18\n");
    }
    if((t < 0) || (p != SA[t])) {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sufcheck 19\n");
      if(verbose) {
        fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sufcheck 20\n");
        fprintf(stderr, "Suffix in wrong position.\n"
                        "  SA[%" PRIdSAIDX_T "]=%" PRIdSAIDX_T " or\n"
                        "  SA[%" PRIdSAIDX_T "]=%" PRIdSAIDX_T "\n",
                        t, (0 <= t) ? SA[t] : -1, i, SA[i]);
        // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sufcheck 20\n");
      }
      return -4;
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sufcheck 19\n");
    }
    if(t != q) {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sufcheck 21\n");
      ++C[c];
      if((n <= C[c]) || (T[SA[C[c]]] != c)) { 
        fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sufcheck 22\n");
        C[c] = -1; 
        // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sufcheck 22\n");
      }
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sufcheck 21\n");
    }
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sufcheck 16\n");
  }

  if(1 <= verbose) { 
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sufcheck 23\n");
    fprintf(stderr, "Done.\n"); 
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sufcheck 23\n");
  }
  return 0;
  // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sufcheck 1\n");
}


static
int
_compare(const sauchar_t *T, saidx_t Tsize,
         const sauchar_t *P, saidx_t Psize,
         saidx_t suf, saidx_t *match) {
  fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter _compare 1\n");
  saidx_t i, j;
  saint_t r;
  for(i = suf + *match, j = *match, r = 0;
      (i < Tsize) && (j < Psize) && ((r = T[i] - P[j]) == 0); ++i, ++j) { 
    fprintf(stderr, "\n");
    // fprintf(stderr, "\n");
  }
  *match = j;
  return (r == 0) ? -(j != Psize) : r;
  // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit _compare 1\n");
}

/* Search for the pattern P in the string T. */
saidx_t
sa_search(const sauchar_t *T, saidx_t Tsize,
          const sauchar_t *P, saidx_t Psize,
          const saidx_t *SA, saidx_t SAsize,
          saidx_t *idx) {
  fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sa_search 1\n");
  saidx_t size, lsize, rsize, half;
  saidx_t match, lmatch, rmatch;
  saidx_t llmatch, lrmatch, rlmatch, rrmatch;
  saidx_t i, j, k;
  saint_t r;

  if(idx != NULL) { 
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sa_search 2\n");
    *idx = -1; 
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sa_search 2\n");
  }
  if((T == NULL) || (P == NULL) || (SA == NULL) ||
     (Tsize < 0) || (Psize < 0) || (SAsize < 0)) { 
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sa_search 3\n");
    return -1; 
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sa_search 3\n");
  }
  if((Tsize == 0) || (SAsize == 0)) { 
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sa_search 4\n");
    return 0; 
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sa_search 4\n");
  }
  if(Psize == 0) { 
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sa_search 5\n");
    if(idx != NULL) { 
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sa_search 6\n");
      *idx = 0; 
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sa_search 6\n");
    } 
    return SAsize; 
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sa_search 5\n");
  }

  for(i = j = k = 0, lmatch = rmatch = 0, size = SAsize, half = size >> 1;
      0 < size;
      size = half, half >>= 1) {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sa_search 7\n");
    match = MIN(lmatch, rmatch);
    r = _compare(T, Tsize, P, Psize, SA[i + half], &match);
    if(r < 0) {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sa_search 8\n");
      i += half + 1;
      half -= (size & 1) ^ 1;
      lmatch = match;
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sa_search 8\n");
    } else if(r > 0) {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sa_search 9\n");
      rmatch = match;
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sa_search 9\n");
    } else {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sa_search 10\n");
      lsize = half, j = i, rsize = size - half - 1, k = i + half + 1;

      /* left part */
      for(llmatch = lmatch, lrmatch = match, half = lsize >> 1;
          0 < lsize;
          lsize = half, half >>= 1) {
        fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sa_search 11\n");
        lmatch = MIN(llmatch, lrmatch);
        r = _compare(T, Tsize, P, Psize, SA[j + half], &lmatch);
        if(r < 0) {
          fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sa_search 12\n");
          j += half + 1;
          half -= (lsize & 1) ^ 1;
          llmatch = lmatch;
          // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sa_search 12\n");
        } else {
          fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sa_search 13\n");
          lrmatch = lmatch;
          // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sa_search 13\n");
        }
        // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sa_search 11\n");
      }

      /* right part */
      for(rlmatch = match, rrmatch = rmatch, half = rsize >> 1;
          0 < rsize;
          rsize = half, half >>= 1) {
        fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sa_search 14\n");
        rmatch = MIN(rlmatch, rrmatch);
        r = _compare(T, Tsize, P, Psize, SA[k + half], &rmatch);
        if(r <= 0) {
          fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sa_search 15\n");
          k += half + 1;
          half -= (rsize & 1) ^ 1;
          rlmatch = rmatch;
          // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sa_search 15\n");
        } else {
          fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sa_search 16\n");
          rrmatch = rmatch;
          // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sa_search 16\n");
        }
        // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sa_search 14\n");
      }

      break;
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sa_search 10\n");
    }
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sa_search 7\n");
  }

  if(idx != NULL) { 
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sa_search 17\n");
    *idx = (0 < (k - j)) ? j : i; 
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sa_search 17\n");
  }
  return k - j;
  // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sa_search 1\n");
}

/* Search for the character c in the string T. */
saidx_t
sa_simplesearch(const sauchar_t *T, saidx_t Tsize,
                const saidx_t *SA, saidx_t SAsize,
                saint_t c, saidx_t *idx) {
  fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sa_simplesearch 1\n");
  saidx_t size, lsize, rsize, half;
  saidx_t i, j, k, p;
  saint_t r;

  if(idx != NULL) { 
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sa_simplesearch 2\n");
    *idx = -1; 
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sa_simplesearch 2\n");
  }
  if((T == NULL) || (SA == NULL) || (Tsize < 0) || (SAsize < 0)) { 
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sa_simplesearch 3\n");
    return -1; 
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sa_simplesearch 3\n");
  }
  if((Tsize == 0) || (SAsize == 0)) { 
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sa_simplesearch 4\n");
    return 0; 
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sa_simplesearch 4\n");
  }

  for(i = j = k = 0, size = SAsize, half = size >> 1;
      0 < size;
      size = half, half >>= 1) {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sa_simplesearch 5\n");
    p = SA[i + half];
    r = (p < Tsize) ? T[p] - c : -1;
    if(r < 0) {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sa_simplesearch 6\n");
      i += half + 1;
      half -= (size & 1) ^ 1;
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sa_simplesearch 6\n");
    } else if(r == 0) {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sa_simplesearch 7\n");
      lsize = half, j = i, rsize = size - half - 1, k = i + half + 1;

      /* left part */
      for(half = lsize >> 1;
          0 < lsize;
          lsize = half, half >>= 1) {
        fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sa_simplesearch 8\n");
        p = SA[j + half];
        r = (p < Tsize) ? T[p] - c : -1;
        if(r < 0) {
          fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sa_simplesearch 9\n");
          j += half + 1;
          half -= (lsize & 1) ^ 1;
          // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sa_simplesearch 9\n");
        }
        // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sa_simplesearch 8\n");
      }

      /* right part */
      for(half = rsize >> 1;
          0 < rsize;
          rsize = half, half >>= 1) {
        fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sa_simplesearch 10\n");
        p = SA[k + half];
        r = (p < Tsize) ? T[p] - c : -1;
        if(r <= 0) {
          fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sa_simplesearch 11\n");
          k += half + 1;
          half -= (rsize & 1) ^ 1;
          // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sa_simplesearch 11\n");
        }
        // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sa_simplesearch 10\n");
      }

      break;
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sa_simplesearch 7\n");
    }
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sa_simplesearch 5\n");
  }

  if(idx != NULL) { 
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] enter sa_simplesearch 12\n");
    *idx = (0 < (k - j)) ? j : i; 
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sa_simplesearch 12\n");
  }
  return k - j;
  // fprintf(stderr, "[brotli/research/libdivsufsort/lib/utils.c] exit sa_simplesearch 1\n");
}
// Total cost: 0.130540
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 381)]
// Total instrumented cost: 0.130540, input tokens: 2398, output tokens: 7548, cache read tokens: 2394, cache write tokens: 4424
