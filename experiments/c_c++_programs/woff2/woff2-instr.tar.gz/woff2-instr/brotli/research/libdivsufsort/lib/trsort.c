/*
 * trsort.c for libdivsufsort
 * Copyright (c) 2003-2008 Yuta Mori All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */

#include "divsufsort_private.h"
#include <stdio.h>


/*- Private Functions -*/

static const saint_t lg_table[256]= {
 -1,0,1,1,2,2,2,2,3,3,3,3,3,3,3,3,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,
  5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,
  6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,
  6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,
  7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
  7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
  7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,
  7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7
};

static INLINE
saint_t
tr_ilg(saidx_t n) {
  fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_ilg 1\n");
#if defined(BUILD_DIVSUFSORT64)
  return (n >> 32) ?
          ((n >> 48) ?
            ((n >> 56) ?
              56 + lg_table[(n >> 56) & 0xff] :
              48 + lg_table[(n >> 48) & 0xff]) :
            ((n >> 40) ?
              40 + lg_table[(n >> 40) & 0xff] :
              32 + lg_table[(n >> 32) & 0xff])) :
          ((n & 0xffff0000) ?
            ((n & 0xff000000) ?
              24 + lg_table[(n >> 24) & 0xff] :
              16 + lg_table[(n >> 16) & 0xff]) :
            ((n & 0x0000ff00) ?
               8 + lg_table[(n >>  8) & 0xff] :
               0 + lg_table[(n >>  0) & 0xff]));
#else
  return (n & 0xffff0000) ?
          ((n & 0xff000000) ?
            24 + lg_table[(n >> 24) & 0xff] :
            16 + lg_table[(n >> 16) & 0xff]) :
          ((n & 0x0000ff00) ?
             8 + lg_table[(n >>  8) & 0xff] :
             0 + lg_table[(n >>  0) & 0xff]);
#endif
  // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_ilg 1\n");
}


/*---------------------------------------------------------------------------*/

/* Simple insertionsort for small size groups. */
static
void
tr_insertionsort(const saidx_t *ISAd, saidx_t *first, saidx_t *last) {
  fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_insertionsort 1\n");
  saidx_t *a, *b;
  saidx_t t, r;

  for(a = first + 1; a < last; ++a) {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_insertionsort 2\n");
    for(t = *a, b = a - 1; 0 > (r = ISAd[t] - ISAd[*b]);) {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_insertionsort 3\n");
      do { *(b + 1) = *b; } while((first <= --b) && (*b < 0));
      if(b < first) { break; }
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_insertionsort 3\n");
    }
    if(r == 0) { 
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_insertionsort 4\n");
      *b = ~*b; 
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_insertionsort 4\n");
    }
    *(b + 1) = t;
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_insertionsort 2\n");
  }
  // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_insertionsort 1\n");
}


/*---------------------------------------------------------------------------*/

static INLINE
void
tr_fixdown(const saidx_t *ISAd, saidx_t *SA, saidx_t i, saidx_t size) {
  fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_fixdown 1\n");
  saidx_t j, k;
  saidx_t v;
  saidx_t c, d, e;

  for(v = SA[i], c = ISAd[v]; (j = 2 * i + 1) < size; SA[i] = SA[k], i = k) {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_fixdown 2\n");
    d = ISAd[SA[k = j++]];
    if(d < (e = ISAd[SA[j]])) { 
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_fixdown 3\n");
      k = j; d = e; 
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_fixdown 3\n");
    }
    if(d <= c) { break; }
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_fixdown 2\n");
  }
  SA[i] = v;
  // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_fixdown 1\n");
}

/* Simple top-down heapsort. */
static
void
tr_heapsort(const saidx_t *ISAd, saidx_t *SA, saidx_t size) {
  fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_heapsort 1\n");
  saidx_t i, m;
  saidx_t t;

  m = size;
  if((size % 2) == 0) {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_heapsort 2\n");
    m--;
    if(ISAd[SA[m / 2]] < ISAd[SA[m]]) { SWAP(SA[m], SA[m / 2]); }
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_heapsort 2\n");
  }

  for(i = m / 2 - 1; 0 <= i; --i) { 
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_heapsort 3\n");
    tr_fixdown(ISAd, SA, i, m); 
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_heapsort 3\n");
  }
  if((size % 2) == 0) { 
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_heapsort 4\n");
    SWAP(SA[0], SA[m]); tr_fixdown(ISAd, SA, 0, m); 
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_heapsort 4\n");
  }
  for(i = m - 1; 0 < i; --i) {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_heapsort 5\n");
    t = SA[0], SA[0] = SA[i];
    tr_fixdown(ISAd, SA, 0, i);
    SA[i] = t;
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_heapsort 5\n");
  }
  // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_heapsort 1\n");
}


/*---------------------------------------------------------------------------*/

/* Returns the median of three elements. */
static INLINE
saidx_t *
tr_median3(const saidx_t *ISAd, saidx_t *v1, saidx_t *v2, saidx_t *v3) {
  fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_median3 1\n");
  saidx_t *t;
  if(ISAd[*v1] > ISAd[*v2]) { 
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_median3 2\n");
    SWAP(v1, v2); 
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_median3 2\n");
  }
  if(ISAd[*v2] > ISAd[*v3]) {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_median3 3\n");
    if(ISAd[*v1] > ISAd[*v3]) { 
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_median3 4\n");
      return v1; 
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_median3 4\n");
    }
    else { 
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_median3 5\n");
      return v3; 
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_median3 5\n");
    }
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_median3 3\n");
  }
  return v2;
  // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_median3 1\n");
}

/* Returns the median of five elements. */
static INLINE
saidx_t *
tr_median5(const saidx_t *ISAd,
           saidx_t *v1, saidx_t *v2, saidx_t *v3, saidx_t *v4, saidx_t *v5) {
  fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_median5 1\n");
  saidx_t *t;
  if(ISAd[*v2] > ISAd[*v3]) { 
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_median5 2\n");
    SWAP(v2, v3); 
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_median5 2\n");
  }
  if(ISAd[*v4] > ISAd[*v5]) { 
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_median5 3\n");
    SWAP(v4, v5); 
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_median5 3\n");
  }
  if(ISAd[*v2] > ISAd[*v4]) { 
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_median5 4\n");
    SWAP(v2, v4); SWAP(v3, v5); 
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_median5 4\n");
  }
  if(ISAd[*v1] > ISAd[*v3]) { 
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_median5 5\n");
    SWAP(v1, v3); 
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_median5 5\n");
  }
  if(ISAd[*v1] > ISAd[*v4]) { 
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_median5 6\n");
    SWAP(v1, v4); SWAP(v3, v5); 
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_median5 6\n");
  }
  if(ISAd[*v3] > ISAd[*v4]) { 
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_median5 7\n");
    return v4; 
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_median5 7\n");
  }
  return v3;
  // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_median5 1\n");
}

/* Returns the pivot element. */
static INLINE
saidx_t *
tr_pivot(const saidx_t *ISAd, saidx_t *first, saidx_t *last) {
  fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_pivot 1\n");
  saidx_t *middle;
  saidx_t t;

  t = last - first;
  middle = first + t / 2;

  if(t <= 512) {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_pivot 2\n");
    if(t <= 32) {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_pivot 3\n");
      return tr_median3(ISAd, first, middle, last - 1);
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_pivot 3\n");
    } else {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_pivot 4\n");
      t >>= 2;
      return tr_median5(ISAd, first, first + t, middle, last - 1 - t, last - 1);
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_pivot 4\n");
    }
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_pivot 2\n");
  }
  t >>= 3;
  first  = tr_median3(ISAd, first, first + t, first + (t << 1));
  middle = tr_median3(ISAd, middle - t, middle, middle + t);
  last   = tr_median3(ISAd, last - 1 - (t << 1), last - 1 - t, last - 1);
  return tr_median3(ISAd, first, middle, last);
  // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_pivot 1\n");
}


/*---------------------------------------------------------------------------*/

typedef struct _trbudget_t trbudget_t;
struct _trbudget_t {
  saidx_t chance;
  saidx_t remain;
  saidx_t incval;
  saidx_t count;
};

static INLINE
void
trbudget_init(trbudget_t *budget, saidx_t chance, saidx_t incval) {
  fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter trbudget_init 1\n");
  budget->chance = chance;
  budget->remain = budget->incval = incval;
  // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit trbudget_init 1\n");
}

static INLINE
saint_t
trbudget_check(trbudget_t *budget, saidx_t size) {
  fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter trbudget_check 1\n");
  if(size <= budget->remain) { 
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter trbudget_check 2\n");
    budget->remain -= size; 
    return 1; 
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit trbudget_check 2\n");
  }
  if(budget->chance == 0) { 
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter trbudget_check 3\n");
    budget->count += size; 
    return 0; 
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit trbudget_check 3\n");
  }
  budget->remain += budget->incval - size;
  budget->chance -= 1;
  return 1;
  // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit trbudget_check 1\n");
}


/*---------------------------------------------------------------------------*/

static INLINE
void
tr_partition(const saidx_t *ISAd,
             saidx_t *first, saidx_t *middle, saidx_t *last,
             saidx_t **pa, saidx_t **pb, saidx_t v) {
  fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_partition 1\n");
  saidx_t *a, *b, *c, *d, *e, *f;
  saidx_t t, s;
  saidx_t x = 0;

  for(b = middle - 1; (++b < last) && ((x = ISAd[*b]) == v);) { }
  if(((a = b) < last) && (x < v)) {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_partition 2\n");
    for(; (++b < last) && ((x = ISAd[*b]) <= v);) {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_partition 3\n");
      if(x == v) { 
        fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_partition 4\n");
        SWAP(*b, *a); ++a; 
        // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_partition 4\n");
      }
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_partition 3\n");
    }
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_partition 2\n");
  }
  for(c = last; (b < --c) && ((x = ISAd[*c]) == v);) { }
  if((b < (d = c)) && (x > v)) {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_partition 5\n");
    for(; (b < --c) && ((x = ISAd[*c]) >= v);) {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_partition 6\n");
      if(x == v) { 
        fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_partition 7\n");
        SWAP(*c, *d); --d; 
        // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_partition 7\n");
      }
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_partition 6\n");
    }
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_partition 5\n");
  }
  for(; b < c;) {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_partition 8\n");
    SWAP(*b, *c);
    for(; (++b < c) && ((x = ISAd[*b]) <= v);) {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_partition 9\n");
      if(x == v) { 
        fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_partition 10\n");
        SWAP(*b, *a); ++a; 
        // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_partition 10\n");
      }
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_partition 9\n");
    }
    for(; (b < --c) && ((x = ISAd[*c]) >= v);) {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_partition 11\n");
      if(x == v) { 
        fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_partition 12\n");
        SWAP(*c, *d); --d; 
        // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_partition 12\n");
      }
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_partition 11\n");
    }
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_partition 8\n");
  }

  if(a <= d) {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_partition 13\n");
    c = b - 1;
    if((s = a - first) > (t = b - a)) { s = t; }
    for(e = first, f = b - s; 0 < s; --s, ++e, ++f) { 
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_partition 14\n");
      SWAP(*e, *f); 
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_partition 14\n");
    }
    if((s = d - c) > (t = last - d - 1)) { s = t; }
    for(e = b, f = last - s; 0 < s; --s, ++e, ++f) { 
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_partition 15\n");
      SWAP(*e, *f); 
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_partition 15\n");
    }
    first += (b - a), last -= (d - c);
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_partition 13\n");
  }
  *pa = first, *pb = last;
  // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_partition 1\n");
}

static
void
tr_copy(saidx_t *ISA, const saidx_t *SA,
        saidx_t *first, saidx_t *a, saidx_t *b, saidx_t *last,
        saidx_t depth) {
  fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_copy 1\n");
  /* sort suffixes of middle partition
     by using sorted order of suffixes of left and right partition. */
  saidx_t *c, *d, *e;
  saidx_t s, v;

  v = b - SA - 1;
  for(c = first, d = a - 1; c <= d; ++c) {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_copy 2\n");
    if((0 <= (s = *c - depth)) && (ISA[s] == v)) {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_copy 3\n");
      *++d = s;
      ISA[s] = d - SA;
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_copy 3\n");
    }
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_copy 2\n");
  }
  for(c = last - 1, e = d + 1, d = b; e < d; --c) {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_copy 4\n");
    if((0 <= (s = *c - depth)) && (ISA[s] == v)) {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_copy 5\n");
      *--d = s;
      ISA[s] = d - SA;
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_copy 5\n");
    }
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_copy 4\n");
  }
  // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_copy 1\n");
}

static
void
tr_partialcopy(saidx_t *ISA, const saidx_t *SA,
               saidx_t *first, saidx_t *a, saidx_t *b, saidx_t *last,
               saidx_t depth) {
  fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_partialcopy 1\n");
  saidx_t *c, *d, *e;
  saidx_t s, v;
  saidx_t rank, lastrank, newrank = -1;

  v = b - SA - 1;
  lastrank = -1;
  for(c = first, d = a - 1; c <= d; ++c) {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_partialcopy 2\n");
    if((0 <= (s = *c - depth)) && (ISA[s] == v)) {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_partialcopy 3\n");
      *++d = s;
      rank = ISA[s + depth];
      if(lastrank != rank) { 
        fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_partialcopy 4\n");
        lastrank = rank; newrank = d - SA; 
        // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_partialcopy 4\n");
      }
      ISA[s] = newrank;
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_partialcopy 3\n");
    }
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_partialcopy 2\n");
  }

  lastrank = -1;
  for(e = d; first <= e; --e) {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_partialcopy 5\n");
    rank = ISA[*e];
    if(lastrank != rank) { 
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_partialcopy 6\n");
      lastrank = rank; newrank = e - SA; 
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_partialcopy 6\n");
    }
    if(newrank != rank) { 
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_partialcopy 7\n");
      ISA[*e] = newrank; 
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_partialcopy 7\n");
    }
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_partialcopy 5\n");
  }

  lastrank = -1;
  for(c = last - 1, e = d + 1, d = b; e < d; --c) {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_partialcopy 8\n");
    if((0 <= (s = *c - depth)) && (ISA[s] == v)) {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_partialcopy 9\n");
      *--d = s;
      rank = ISA[s + depth];
      if(lastrank != rank) { 
        fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_partialcopy 10\n");
        lastrank = rank; newrank = d - SA; 
        // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_partialcopy 10\n");
      }
      ISA[s] = newrank;
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_partialcopy 9\n");
    }
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_partialcopy 8\n");
  }
  // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_partialcopy 1\n");
}

static
void
tr_introsort(saidx_t *ISA, const saidx_t *ISAd,
             saidx_t *SA, saidx_t *first, saidx_t *last,
             trbudget_t *budget) {
  fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 1\n");
#define STACK_SIZE TR_STACKSIZE
  struct { const saidx_t *a; saidx_t *b, *c; saint_t d, e; }stack[STACK_SIZE];
  saidx_t *a, *b, *c;
  saidx_t t;
  saidx_t v, x = 0;
  saidx_t incr = ISAd - ISA;
  saint_t limit, next;
  saint_t ssize, trlink = -1;

  for(ssize = 0, limit = tr_ilg(last - first);;) {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 2\n");

    if(limit < 0) {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 3\n");
      if(limit == -1) {
        fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 4\n");
        /* tandem repeat partition */
        tr_partition(ISAd - incr, first, first, last, &a, &b, last - SA - 1);

        /* update ranks */
        if(a < last) {
          fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 5\n");
          for(c = first, v = a - SA - 1; c < a; ++c) { 
            fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 6\n");
            ISA[*c] = v; 
            // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 6\n");
          }
          // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 5\n");
        }
        if(b < last) {
          fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 7\n");
          for(c = a, v = b - SA - 1; c < b; ++c) { 
            fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 8\n");
            ISA[*c] = v; 
            // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 8\n");
          }
          // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 7\n");
        }

        /* push */
        if(1 < (b - a)) {
          fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 9\n");
          STACK_PUSH5(NULL, a, b, 0, 0);
          STACK_PUSH5(ISAd - incr, first, last, -2, trlink);
          trlink = ssize - 2;
          // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 9\n");
        }
        if((a - first) <= (last - b)) {
          fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 10\n");
          if(1 < (a - first)) {
            fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 11\n");
            STACK_PUSH5(ISAd, b, last, tr_ilg(last - b), trlink);
            last = a, limit = tr_ilg(a - first);
            // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 11\n");
          } else if(1 < (last - b)) {
            fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 12\n");
            first = b, limit = tr_ilg(last - b);
            // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 12\n");
          } else {
            fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 13\n");
            STACK_POP5(ISAd, first, last, limit, trlink);
            // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 13\n");
          }
          // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 10\n");
        } else {
          fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 14\n");
          if(1 < (last - b)) {
            fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 15\n");
            STACK_PUSH5(ISAd, first, a, tr_ilg(a - first), trlink);
            first = b, limit = tr_ilg(last - b);
            // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 15\n");
          } else if(1 < (a - first)) {
            fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 16\n");
            last = a, limit = tr_ilg(a - first);
            // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 16\n");
          } else {
            fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 17\n");
            STACK_POP5(ISAd, first, last, limit, trlink);
            // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 17\n");
          }
          // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 14\n");
        }
        // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 4\n");
      } else if(limit == -2) {
        fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 18\n");
        /* tandem repeat copy */
        a = stack[--ssize].b, b = stack[ssize].c;
        if(stack[ssize].d == 0) {
          fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 19\n");
          tr_copy(ISA, SA, first, a, b, last, ISAd - ISA);
          // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 19\n");
        } else {
          fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 20\n");
          if(0 <= trlink) { 
            fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 21\n");
            stack[trlink].d = -1; 
            // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 21\n");
          }
          tr_partialcopy(ISA, SA, first, a, b, last, ISAd - ISA);
          // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 20\n");
        }
        STACK_POP5(ISAd, first, last, limit, trlink);
        // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 18\n");
      } else {
        fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 22\n");
        /* sorted partition */
        if(0 <= *first) {
          fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 23\n");
          a = first;
          do { 
            fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 24\n");
            ISA[*a] = a - SA; 
            // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 24\n");
          } while((++a < last) && (0 <= *a));
          first = a;
          // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 23\n");
        }
        if(first < last) {
          fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 25\n");
          a = first; 
          do { 
            fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 26\n");
            *a = ~*a; 
            // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 26\n");
          } while(*++a < 0);
          next = (ISA[*a] != ISAd[*a]) ? tr_ilg(a - first + 1) : -1;
          if(++a < last) { 
            fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 27\n");
            for(b = first, v = a - SA - 1; b < a; ++b) { 
              fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 28\n");
              ISA[*b] = v; 
              // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 28\n");
            }
            // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 27\n");
          }

          /* push */
          if(trbudget_check(budget, a - first)) {
            fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 29\n");
            if((a - first) <= (last - a)) {
              fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 30\n");
              STACK_PUSH5(ISAd, a, last, -3, trlink);
              ISAd += incr, last = a, limit = next;
              // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 30\n");
            } else {
              fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 31\n");
              if(1 < (last - a)) {
                fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 32\n");
                STACK_PUSH5(ISAd + incr, first, a, next, trlink);
                first = a, limit = -3;
                // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 32\n");
              } else {
                fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 33\n");
                ISAd += incr, last = a, limit = next;
                // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 33\n");
              }
              // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 31\n");
            }
            // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 29\n");
          } else {
            fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 34\n");
            if(0 <= trlink) { 
              fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 35\n");
              stack[trlink].d = -1; 
              // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 35\n");
            }
            if(1 < (last - a)) {
              fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 36\n");
              first = a, limit = -3;
              // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 36\n");
            } else {
              fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 37\n");
              STACK_POP5(ISAd, first, last, limit, trlink);
              // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 37\n");
            }
            // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 34\n");
          }
          // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 25\n");
        } else {
          fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 38\n");
          STACK_POP5(ISAd, first, last, limit, trlink);
          // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 38\n");
        }
        // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 22\n");
      }
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 3\n");
      continue;
    }

    if((last - first) <= TR_INSERTIONSORT_THRESHOLD) {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 39\n");
      tr_insertionsort(ISAd, first, last);
      limit = -3;
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 39\n");
      continue;
    }

    if(limit-- == 0) {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 40\n");
      tr_heapsort(ISAd, first, last - first);
      for(a = last - 1; first < a; a = b) {
        fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 41\n");
        for(x = ISAd[*a], b = a - 1; (first <= b) && (ISAd[*b] == x); --b) { 
          fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 42\n");
          *b = ~*b; 
          // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 42\n");
        }
        // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 41\n");
      }
      limit = -3;
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 40\n");
      continue;
    }

    /* choose pivot */
    a = tr_pivot(ISAd, first, last);
    SWAP(*first, *a);
    v = ISAd[*first];

    /* partition */
    tr_partition(ISAd, first, first + 1, last, &a, &b, v);
    if((last - first) != (b - a)) {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 43\n");
      next = (ISA[*a] != v) ? tr_ilg(b - a) : -1;

      /* update ranks */
      for(c = first, v = a - SA - 1; c < a; ++c) { 
        fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 44\n");
        ISA[*c] = v; 
        // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 44\n");
      }
      if(b < last) { 
        fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 45\n");
        for(c = a, v = b - SA - 1; c < b; ++c) { 
          fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 46\n");
          ISA[*c] = v; 
          // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 46\n");
        }
        // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 45\n");
      }

      /* push */
      if((1 < (b - a)) && (trbudget_check(budget, b - a))) {
        fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 47\n");
        if((a - first) <= (last - b)) {
          fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 48\n");
          if((last - b) <= (b - a)) {
            fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 49\n");
            if(1 < (a - first)) {
              fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 50\n");
              STACK_PUSH5(ISAd + incr, a, b, next, trlink);
              STACK_PUSH5(ISAd, b, last, limit, trlink);
              last = a;
              // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 50\n");
            } else if(1 < (last - b)) {
              fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 51\n");
              STACK_PUSH5(ISAd + incr, a, b, next, trlink);
              first = b;
              // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 51\n");
            } else {
              fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 52\n");
              ISAd += incr, first = a, last = b, limit = next;
              // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 52\n");
            }
            // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 49\n");
          } else if((a - first) <= (b - a)) {
            fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 53\n");
            if(1 < (a - first)) {
              fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 54\n");
              STACK_PUSH5(ISAd, b, last, limit, trlink);
              STACK_PUSH5(ISAd + incr, a, b, next, trlink);
              last = a;
              // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 54\n");
            } else {
              fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 55\n");
              STACK_PUSH5(ISAd, b, last, limit, trlink);
              ISAd += incr, first = a, last = b, limit = next;
              // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 55\n");
            }
            // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 53\n");
          } else {
            fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 56\n");
            STACK_PUSH5(ISAd, b, last, limit, trlink);
            STACK_PUSH5(ISAd, first, a, limit, trlink);
            ISAd += incr, first = a, last = b, limit = next;
            // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 56\n");
          }
          // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 48\n");
        } else {
          fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 57\n");
          if((a - first) <= (b - a)) {
            fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 58\n");
            if(1 < (last - b)) {
              fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 59\n");
              STACK_PUSH5(ISAd + incr, a, b, next, trlink);
              STACK_PUSH5(ISAd, first, a, limit, trlink);
              first = b;
              // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 59\n");
            } else if(1 < (a - first)) {
              fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 60\n");
              STACK_PUSH5(ISAd + incr, a, b, next, trlink);
              last = a;
              // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 60\n");
            } else {
              fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 61\n");
              ISAd += incr, first = a, last = b, limit = next;
              // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 61\n");
            }
            // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 58\n");
          } else if((last - b) <= (b - a)) {
            fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 62\n");
            if(1 < (last - b)) {
              fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 63\n");
              STACK_PUSH5(ISAd, first, a, limit, trlink);
              STACK_PUSH5(ISAd + incr, a, b, next, trlink);
              first = b;
              // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 63\n");
            } else {
              fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 64\n");
              STACK_PUSH5(ISAd, first, a, limit, trlink);
              ISAd += incr, first = a, last = b, limit = next;
              // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 64\n");
            }
            // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 62\n");
          } else {
            fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 65\n");
            STACK_PUSH5(ISAd, first, a, limit, trlink);
            STACK_PUSH5(ISAd, b, last, limit, trlink);
            ISAd += incr, first = a, last = b, limit = next;
            // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 65\n");
          }
          // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 57\n");
        }
        // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 47\n");
      } else {
        fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 66\n");
        if((1 < (b - a)) && (0 <= trlink)) { 
          fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 67\n");
          stack[trlink].d = -1; 
          // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 67\n");
        }
        if((a - first) <= (last - b)) {
          fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 68\n");
          if(1 < (a - first)) {
            fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 69\n");
            STACK_PUSH5(ISAd, b, last, limit, trlink);
            last = a;
            // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 69\n");
          } else if(1 < (last - b)) {
            fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 70\n");
            first = b;
            // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 70\n");
          } else {
            fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 71\n");
            STACK_POP5(ISAd, first, last, limit, trlink);
            // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 71\n");
          }
          // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 68\n");
        } else {
          fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 72\n");
          if(1 < (last - b)) {
            fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 73\n");
            STACK_PUSH5(ISAd, first, a, limit, trlink);
            first = b;
            // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 73\n");
          } else if(1 < (a - first)) {
            fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 74\n");
            last = a;
            // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 74\n");
          } else {
            fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 75\n");
            STACK_POP5(ISAd, first, last, limit, trlink);
            // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 75\n");
          }
          // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 72\n");
        }
        // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 66\n");
      }
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 43\n");
    } else {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 76\n");
      if(trbudget_check(budget, last - first)) {
        fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 77\n");
        limit = tr_ilg(last - first), ISAd += incr;
        // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 77\n");
      } else {
        fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 78\n");
        if(0 <= trlink) { 
          fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter tr_introsort 79\n");
          stack[trlink].d = -1; 
          // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 79\n");
        }
        STACK_POP5(ISAd, first, last, limit, trlink);
        // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 78\n");
      }
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 76\n");
    }
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 2\n");
  }
#undef STACK_SIZE
  // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit tr_introsort 1\n");
}



/*---------------------------------------------------------------------------*/

/*- Function -*/

/* Tandem repeat sort */
void
trsort(saidx_t *ISA, saidx_t *SA, saidx_t n, saidx_t depth) {
  fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter trsort 1\n");
  saidx_t *ISAd;
  saidx_t *first, *last;
  trbudget_t budget;
  saidx_t t, skip, unsorted;

  trbudget_init(&budget, tr_ilg(n) * 2 / 3, n);
/*  trbudget_init(&budget, tr_ilg(n) * 3 / 4, n); */
  for(ISAd = ISA + depth; -n < *SA; ISAd += ISAd - ISA) {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter trsort 2\n");
    first = SA;
    skip = 0;
    unsorted = 0;
    do {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter trsort 3\n");
      if((t = *first) < 0) { 
        fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter trsort 4\n");
        first -= t; skip += t; 
        // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit trsort 4\n");
      }
      else {
        fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter trsort 5\n");
        if(skip != 0) { 
          fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter trsort 6\n");
          *(first + skip) = skip; skip = 0; 
          // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit trsort 6\n");
        }
        last = SA + ISA[t] + 1;
        if(1 < (last - first)) {
          fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter trsort 7\n");
          budget.count = 0;
          tr_introsort(ISA, ISAd, SA, first, last, &budget);
          if(budget.count != 0) { 
            fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter trsort 8\n");
            unsorted += budget.count; 
            // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit trsort 8\n");
          }
          else { 
            fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter trsort 9\n");
            skip = first - last; 
            // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit trsort 9\n");
          }
          // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit trsort 7\n");
        } else if((last - first) == 1) {
          fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter trsort 10\n");
          skip = -1;
          // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit trsort 10\n");
        }
        first = last;
        // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit trsort 5\n");
      }
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit trsort 3\n");
    } while(first < (SA + n));
    if(skip != 0) { 
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter trsort 11\n");
      *(first + skip) = skip; 
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit trsort 11\n");
    }
    if(unsorted == 0) { 
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] enter trsort 12\n");
      break; 
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit trsort 12\n");
    }
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit trsort 2\n");
  }
  // fprintf(stderr, "[brotli/research/libdivsufsort/lib/trsort.c] exit trsort 1\n");
}
// Total cost: 0.233339
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 586)]
// Total instrumented cost: 0.233339, input tokens: 2398, output tokens: 13557, cache read tokens: 2394, cache write tokens: 7801
