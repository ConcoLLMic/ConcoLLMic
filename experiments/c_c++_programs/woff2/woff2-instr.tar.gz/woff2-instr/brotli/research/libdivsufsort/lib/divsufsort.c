/*
 * divsufsort.c for libdivsufsort
 * Copyright (c) 2003-2008 Yuta Mori All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use,
 * copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following
 * conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 * OTHER DEALINGS IN THE SOFTWARE.
 */

#include "divsufsort_private.h"
#include <stdio.h>
#ifdef _OPENMP
# include <omp.h>
#endif


/*- Private Functions -*/

/* Sorts suffixes of type B*. */
static
saidx_t
sort_typeBstar(const sauchar_t *T, saidx_t *SA,
               saidx_t *bucket_A, saidx_t *bucket_B,
               saidx_t n) {
  fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter sort_typeBstar 1\n");
  saidx_t *PAb, *ISAb, *buf;
#ifdef _OPENMP
  saidx_t *curbuf;
  saidx_t l;
#endif
  saidx_t i, j, k, t, m, bufsize;
  saint_t c0, c1;
#ifdef _OPENMP
  saint_t d0, d1;
  int tmp;
#endif

  /* Initialize bucket arrays. */
  for(i = 0; i < BUCKET_A_SIZE; ++i) { bucket_A[i] = 0; }
  for(i = 0; i < BUCKET_B_SIZE; ++i) { bucket_B[i] = 0; }
  // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit sort_typeBstar 1\n");

  /* Count the number of occurrences of the first one or two characters of each
     type A, B and B* suffix. Moreover, store the beginning position of all
     type B* suffixes into the array SA. */
  fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter sort_typeBstar 2\n");
  for(i = n - 1, m = n, c0 = T[n - 1]; 0 <= i;) {
    /* type A suffix. */
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter sort_typeBstar 3\n");
    do { ++BUCKET_A(c1 = c0); } while((0 <= --i) && ((c0 = T[i]) >= c1));
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit sort_typeBstar 3\n");
    if(0 <= i) {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter sort_typeBstar 4\n");
      /* type B* suffix. */
      ++BUCKET_BSTAR(c0, c1);
      SA[--m] = i;
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit sort_typeBstar 4\n");
      /* type B suffix. */
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter sort_typeBstar 5\n");
      for(--i, c1 = c0; (0 <= i) && ((c0 = T[i]) <= c1); --i, c1 = c0) {
        fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter sort_typeBstar 6\n");
        ++BUCKET_B(c0, c1);
        // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit sort_typeBstar 6\n");
      }
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit sort_typeBstar 5\n");
    }
  }
  m = n - m;
  // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit sort_typeBstar 2\n");
/*
note:
  A type B* suffix is lexicographically smaller than a type B suffix that
  begins with the same first two characters.
*/

  /* Calculate the index of start/end point of each bucket. */
  fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter sort_typeBstar 7\n");
  for(c0 = 0, i = 0, j = 0; c0 < ALPHABET_SIZE; ++c0) {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter sort_typeBstar 8\n");
    t = i + BUCKET_A(c0);
    BUCKET_A(c0) = i + j; /* start point */
    i = t + BUCKET_B(c0, c0);
    for(c1 = c0 + 1; c1 < ALPHABET_SIZE; ++c1) {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter sort_typeBstar 9\n");
      j += BUCKET_BSTAR(c0, c1);
      BUCKET_BSTAR(c0, c1) = j; /* end point */
      i += BUCKET_B(c0, c1);
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit sort_typeBstar 9\n");
    }
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit sort_typeBstar 8\n");
  }
  // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit sort_typeBstar 7\n");

  if(0 < m) {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter sort_typeBstar 10\n");
    /* Sort the type B* suffixes by their first two characters. */
    PAb = SA + n - m; ISAb = SA + m;
    for(i = m - 2; 0 <= i; --i) {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter sort_typeBstar 11\n");
      t = PAb[i], c0 = T[t], c1 = T[t + 1];
      SA[--BUCKET_BSTAR(c0, c1)] = i;
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit sort_typeBstar 11\n");
    }
    t = PAb[m - 1], c0 = T[t], c1 = T[t + 1];
    SA[--BUCKET_BSTAR(c0, c1)] = m - 1;

    /* Sort the type B* substrings using sssort. */
#ifdef _OPENMP
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter sort_typeBstar 12\n");
    tmp = omp_get_max_threads();
    buf = SA + m, bufsize = (n - (2 * m)) / tmp;
    c0 = ALPHABET_SIZE - 2, c1 = ALPHABET_SIZE - 1, j = m;
#pragma omp parallel default(shared) private(curbuf, k, l, d0, d1, tmp)
    {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter sort_typeBstar 13\n");
      tmp = omp_get_thread_num();
      curbuf = buf + tmp * bufsize;
      k = 0;
      for(;;) {
        fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter sort_typeBstar 14\n");
        #pragma omp critical(sssort_lock)
        {
          fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter sort_typeBstar 15\n");
          if(0 < (l = j)) {
            fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter sort_typeBstar 16\n");
            d0 = c0, d1 = c1;
            do {
              fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter sort_typeBstar 17\n");
              k = BUCKET_BSTAR(d0, d1);
              if(--d1 <= d0) {
                fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter sort_typeBstar 18\n");
                d1 = ALPHABET_SIZE - 1;
                if(--d0 < 0) { break; }
                // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit sort_typeBstar 18\n");
              }
              // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit sort_typeBstar 17\n");
            } while(((l - k) <= 1) && (0 < (l = k)));
            c0 = d0, c1 = d1, j = k;
            // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit sort_typeBstar 16\n");
          }
          // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit sort_typeBstar 15\n");
        }
        if(l == 0) { break; }
        fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter sort_typeBstar 19\n");
        sssort(T, PAb, SA + k, SA + l,
               curbuf, bufsize, 2, n, *(SA + k) == (m - 1));
        // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit sort_typeBstar 19\n");
        // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit sort_typeBstar 14\n");
      }
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit sort_typeBstar 13\n");
    }
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit sort_typeBstar 12\n");
#else
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter sort_typeBstar 20\n");
    buf = SA + m, bufsize = n - (2 * m);
    for(c0 = ALPHABET_SIZE - 2, j = m; 0 < j; --c0) {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter sort_typeBstar 21\n");
      for(c1 = ALPHABET_SIZE - 1; c0 < c1; j = i, --c1) {
        fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter sort_typeBstar 22\n");
        i = BUCKET_BSTAR(c0, c1);
        if(1 < (j - i)) {
          fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter sort_typeBstar 23\n");
          sssort(T, PAb, SA + i, SA + j,
                 buf, bufsize, 2, n, *(SA + i) == (m - 1));
          // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit sort_typeBstar 23\n");
        }
        // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit sort_typeBstar 22\n");
      }
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit sort_typeBstar 21\n");
    }
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit sort_typeBstar 20\n");
#endif

    /* Compute ranks of type B* substrings. */
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter sort_typeBstar 24\n");
    for(i = m - 1; 0 <= i; --i) {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter sort_typeBstar 25\n");
      if(0 <= SA[i]) {
        fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter sort_typeBstar 26\n");
        j = i;
        do { ISAb[SA[i]] = i; } while((0 <= --i) && (0 <= SA[i]));
        SA[i + 1] = i - j;
        if(i <= 0) { break; }
        // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit sort_typeBstar 26\n");
      }
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter sort_typeBstar 27\n");
      j = i;
      do { ISAb[SA[i] = ~SA[i]] = j; } while(SA[--i] < 0);
      ISAb[SA[i]] = j;
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit sort_typeBstar 27\n");
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit sort_typeBstar 25\n");
    }
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit sort_typeBstar 24\n");

    /* Construct the inverse suffix array of type B* suffixes using trsort. */
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter sort_typeBstar 28\n");
    trsort(ISAb, SA, m, 1);
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit sort_typeBstar 28\n");

    /* Set the sorted order of tyoe B* suffixes. */
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter sort_typeBstar 29\n");
    for(i = n - 1, j = m, c0 = T[n - 1]; 0 <= i;) {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter sort_typeBstar 30\n");
      for(--i, c1 = c0; (0 <= i) && ((c0 = T[i]) >= c1); --i, c1 = c0) { }
      if(0 <= i) {
        fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter sort_typeBstar 31\n");
        t = i;
        for(--i, c1 = c0; (0 <= i) && ((c0 = T[i]) <= c1); --i, c1 = c0) { }
        SA[ISAb[--j]] = ((t == 0) || (1 < (t - i))) ? t : ~t;
        // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit sort_typeBstar 31\n");
      }
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit sort_typeBstar 30\n");
    }
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit sort_typeBstar 29\n");

    /* Calculate the index of start/end point of each bucket. */
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter sort_typeBstar 32\n");
    BUCKET_B(ALPHABET_SIZE - 1, ALPHABET_SIZE - 1) = n; /* end point */
    for(c0 = ALPHABET_SIZE - 2, k = m - 1; 0 <= c0; --c0) {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter sort_typeBstar 33\n");
      i = BUCKET_A(c0 + 1) - 1;
      for(c1 = ALPHABET_SIZE - 1; c0 < c1; --c1) {
        fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter sort_typeBstar 34\n");
        t = i - BUCKET_B(c0, c1);
        BUCKET_B(c0, c1) = i; /* end point */

        /* Move all type B* suffixes to the correct position. */
        for(i = t, j = BUCKET_BSTAR(c0, c1);
            j <= k;
            --i, --k) { 
          fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter sort_typeBstar 35\n");
          SA[i] = SA[k]; 
          // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit sort_typeBstar 35\n");
        }
        // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit sort_typeBstar 34\n");
      }
      BUCKET_BSTAR(c0, c0 + 1) = i - BUCKET_B(c0, c0) + 1; /* start point */
      BUCKET_B(c0, c0) = i; /* end point */
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit sort_typeBstar 33\n");
    }
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit sort_typeBstar 32\n");
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit sort_typeBstar 10\n");
  }

  fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter sort_typeBstar 36\n");
  return m;
  // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit sort_typeBstar 36\n");
}

/* Constructs the suffix array by using the sorted order of type B* suffixes. */
static
void
construct_SA(const sauchar_t *T, saidx_t *SA,
             saidx_t *bucket_A, saidx_t *bucket_B,
             saidx_t n, saidx_t m) {
  fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter construct_SA 1\n");
  saidx_t *i, *j, *k;
  saidx_t s;
  saint_t c0, c1, c2;

  if(0 < m) {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter construct_SA 2\n");
    /* Construct the sorted order of type B suffixes by using
       the sorted order of type B* suffixes. */
    for(c1 = ALPHABET_SIZE - 2; 0 <= c1; --c1) {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter construct_SA 3\n");
      /* Scan the suffix array from right to left. */
      for(i = SA + BUCKET_BSTAR(c1, c1 + 1),
          j = SA + BUCKET_A(c1 + 1) - 1, k = NULL, c2 = -1;
          i <= j;
          --j) {
        fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter construct_SA 4\n");
        if(0 < (s = *j)) {
          fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter construct_SA 5\n");
          assert(T[s] == c1);
          assert(((s + 1) < n) && (T[s] <= T[s + 1]));
          assert(T[s - 1] <= T[s]);
          *j = ~s;
          c0 = T[--s];
          if((0 < s) && (T[s - 1] > c0)) { s = ~s; }
          if(c0 != c2) {
            fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter construct_SA 6\n");
            if(0 <= c2) { BUCKET_B(c2, c1) = k - SA; }
            k = SA + BUCKET_B(c2 = c0, c1);
            // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit construct_SA 6\n");
          }
          assert(k < j);
          *k-- = s;
          // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit construct_SA 5\n");
        } else {
          fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter construct_SA 7\n");
          assert(((s == 0) && (T[s] == c1)) || (s < 0));
          *j = ~s;
          // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit construct_SA 7\n");
        }
        // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit construct_SA 4\n");
      }
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit construct_SA 3\n");
    }
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit construct_SA 2\n");
  }

  /* Construct the suffix array by using
     the sorted order of type B suffixes. */
  fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter construct_SA 8\n");
  k = SA + BUCKET_A(c2 = T[n - 1]);
  *k++ = (T[n - 2] < c2) ? ~(n - 1) : (n - 1);
  // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit construct_SA 8\n");
  /* Scan the suffix array from left to right. */
  fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter construct_SA 9\n");
  for(i = SA, j = SA + n; i < j; ++i) {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter construct_SA 10\n");
    if(0 < (s = *i)) {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter construct_SA 11\n");
      assert(T[s - 1] >= T[s]);
      c0 = T[--s];
      if((s == 0) || (T[s - 1] < c0)) { s = ~s; }
      if(c0 != c2) {
        fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter construct_SA 12\n");
        BUCKET_A(c2) = k - SA;
        k = SA + BUCKET_A(c2 = c0);
        // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit construct_SA 12\n");
      }
      assert(i < k);
      *k++ = s;
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit construct_SA 11\n");
    } else {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter construct_SA 13\n");
      assert(s < 0);
      *i = ~s;
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit construct_SA 13\n");
    }
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit construct_SA 10\n");
  }
  // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit construct_SA 9\n");
  // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit construct_SA 1\n");
}

/* Constructs the burrows-wheeler transformed string directly
   by using the sorted order of type B* suffixes. */
static
saidx_t
construct_BWT(const sauchar_t *T, saidx_t *SA,
              saidx_t *bucket_A, saidx_t *bucket_B,
              saidx_t n, saidx_t m) {
  fprintf(stderr, "\n");
  saidx_t *i, *j, *k, *orig;
  saidx_t s;
  saint_t c0, c1, c2;

  if(0 < m) {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter construct_BWT 2\n");
    /* Construct the sorted order of type B suffixes by using
       the sorted order of type B* suffixes. */
    for(c1 = ALPHABET_SIZE - 2; 0 <= c1; --c1) {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter construct_BWT 3\n");
      /* Scan the suffix array from right to left. */
      for(i = SA + BUCKET_BSTAR(c1, c1 + 1),
          j = SA + BUCKET_A(c1 + 1) - 1, k = NULL, c2 = -1;
          i <= j;
          --j) {
        fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter construct_BWT 4\n");
        if(0 < (s = *j)) {
          fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter construct_BWT 5\n");
          assert(T[s] == c1);
          assert(((s + 1) < n) && (T[s] <= T[s + 1]));
          assert(T[s - 1] <= T[s]);
          c0 = T[--s];
          *j = ~((saidx_t)c0);
          if((0 < s) && (T[s - 1] > c0)) { s = ~s; }
          if(c0 != c2) {
            fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter construct_BWT 6\n");
            if(0 <= c2) { BUCKET_B(c2, c1) = k - SA; }
            k = SA + BUCKET_B(c2 = c0, c1);
            // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit construct_BWT 6\n");
          }
          assert(k < j);
          *k-- = s;
          // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit construct_BWT 5\n");
        } else if(s != 0) {
          fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter construct_BWT 7\n");
          *j = ~s;
          // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit construct_BWT 7\n");
#ifndef NDEBUG
        } else {
          fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter construct_BWT 8\n");
          assert(T[s] == c1);
          // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit construct_BWT 8\n");
#endif
        }
        // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit construct_BWT 4\n");
      }
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit construct_BWT 3\n");
    }
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit construct_BWT 2\n");
  }

  /* Construct the BWTed string by using
     the sorted order of type B suffixes. */
  fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter construct_BWT 9\n");
  k = SA + BUCKET_A(c2 = T[n - 1]);
  *k++ = (T[n - 2] < c2) ? ~((saidx_t)T[n - 2]) : (n - 1);
  // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit construct_BWT 9\n");
  /* Scan the suffix array from left to right. */
  fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter construct_BWT 10\n");
  for(i = SA, j = SA + n, orig = SA; i < j; ++i) {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter construct_BWT 11\n");
    if(0 < (s = *i)) {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter construct_BWT 12\n");
      assert(T[s - 1] >= T[s]);
      c0 = T[--s];
      *i = c0;
      if((0 < s) && (T[s - 1] < c0)) { s = ~((saidx_t)T[s - 1]); }
      if(c0 != c2) {
        fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter construct_BWT 13\n");
        BUCKET_A(c2) = k - SA;
        k = SA + BUCKET_A(c2 = c0);
        // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit construct_BWT 13\n");
      }
      assert(i < k);
      *k++ = s;
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit construct_BWT 12\n");
    } else if(s != 0) {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter construct_BWT 14\n");
      *i = ~s;
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit construct_BWT 14\n");
    } else {
      fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter construct_BWT 15\n");
      orig = i;
      // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit construct_BWT 15\n");
    }
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit construct_BWT 11\n");
  }
  // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit construct_BWT 10\n");

  fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter construct_BWT 16\n");
  return orig - SA;
  // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit construct_BWT 16\n");
}


/*---------------------------------------------------------------------------*/

/*- Function -*/

saint_t
divsufsort(const sauchar_t *T, saidx_t *SA, saidx_t n) {
  fprintf(stderr, "\n");
  saidx_t *bucket_A, *bucket_B;
  saidx_t m;
  saint_t err = 0;

  /* Check arguments. */
  if((T == NULL) || (SA == NULL) || (n < 0)) { 
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter divsufsort 2\n");
    return -1; 
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit divsufsort 2\n");
  }
  else if(n == 0) { 
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter divsufsort 3\n");
    return 0; 
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit divsufsort 3\n");
  }
  else if(n == 1) { 
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter divsufsort 4\n");
    SA[0] = 0; 
    return 0; 
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit divsufsort 4\n");
  }
  else if(n == 2) { 
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter divsufsort 5\n");
    m = (T[0] < T[1]); 
    SA[m ^ 1] = 0, SA[m] = 1; 
    return 0; 
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit divsufsort 5\n");
  }

  bucket_A = (saidx_t *)malloc(BUCKET_A_SIZE * sizeof(saidx_t));
  bucket_B = (saidx_t *)malloc(BUCKET_B_SIZE * sizeof(saidx_t));

  /* Suffixsort. */
  if((bucket_A != NULL) && (bucket_B != NULL)) {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter divsufsort 6\n");
    m = sort_typeBstar(T, SA, bucket_A, bucket_B, n);
    construct_SA(T, SA, bucket_A, bucket_B, n, m);
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit divsufsort 6\n");
  } else {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter divsufsort 7\n");
    err = -2;
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit divsufsort 7\n");
  }

  free(bucket_B);
  free(bucket_A);

  fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter divsufsort 8\n");
  return err;
  // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit divsufsort 8\n");
}

saidx_t
divbwt(const sauchar_t *T, sauchar_t *U, saidx_t *A, saidx_t n) {
  fprintf(stderr, "\n");
  saidx_t *B;
  saidx_t *bucket_A, *bucket_B;
  saidx_t m, pidx, i;

  /* Check arguments. */
  if((T == NULL) || (U == NULL) || (n < 0)) { 
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter divbwt 2\n");
    return -1; 
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit divbwt 2\n");
  }
  else if(n <= 1) { 
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter divbwt 3\n");
    if(n == 1) { U[0] = T[0]; } 
    return n; 
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit divbwt 3\n");
  }

  if((B = A) == NULL) { 
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter divbwt 4\n");
    B = (saidx_t *)malloc((size_t)(n + 1) * sizeof(saidx_t)); 
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit divbwt 4\n");
  }
  bucket_A = (saidx_t *)malloc(BUCKET_A_SIZE * sizeof(saidx_t));
  bucket_B = (saidx_t *)malloc(BUCKET_B_SIZE * sizeof(saidx_t));

  /* Burrows-Wheeler Transform. */
  if((B != NULL) && (bucket_A != NULL) && (bucket_B != NULL)) {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter divbwt 5\n");
    m = sort_typeBstar(T, B, bucket_A, bucket_B, n);
    pidx = construct_BWT(T, B, bucket_A, bucket_B, n, m);

    /* Copy to output string. */
    U[0] = T[n - 1];
    for(i = 0; i < pidx; ++i) { U[i + 1] = (sauchar_t)B[i]; }
    for(i += 1; i < n; ++i) { U[i] = (sauchar_t)B[i]; }
    pidx += 1;
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit divbwt 5\n");
  } else {
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter divbwt 6\n");
    pidx = -2;
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit divbwt 6\n");
  }

  free(bucket_B);
  free(bucket_A);
  if(A == NULL) { 
    fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter divbwt 7\n");
    free(B); 
    // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit divbwt 7\n");
  }

  fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter divbwt 8\n");
  return pidx;
  // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit divbwt 8\n");
}

const char *
divsufsort_version(void) {
  fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] enter divsufsort_version 1\n");
  return PROJECT_VERSION_FULL;
  // fprintf(stderr, "[brotli/research/libdivsufsort/lib/divsufsort.c] exit divsufsort_version 1\n");
}
// Total cost: 0.908805
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 398)]
// Total instrumented cost: 0.908805, input tokens: 65198, output tokens: 49671, cache read tokens: 65174, cache write tokens: 38431
