#include "./deorummolae.h"

#include <array>
#include <cstdio>

#include "./esaxx/sais.hxx"

/* Used for quick SA-entry to file mapping. Each file is padded to size that
   is a multiple of chunk size. */
#define CHUNK_SIZE 64
/* Length of substring that is considered to be covered by dictionary string. */
#define CUT_MATCH 6
/* Minimal dictionary entry size. */
#define MIN_MATCH 24

/* Non tunable definitions. */
#define CHUNK_MASK (CHUNK_SIZE - 1)
#define COVERAGE_SIZE (1 << (DM_LOG_MAX_FILES - 6))

/* File coverage: every bit set to 1 denotes a file covered by an isle. */
typedef std::array<uint64_t, COVERAGE_SIZE> Coverage;

/* Symbol of text alphabet. */
typedef int32_t TextChar;

/* Pointer to position in text. */
typedef uint32_t TextIdx;

/* SAIS sarray_type; unfortunately, must be a signed type. */
typedef int32_t TextSaIdx;

static size_t popcount(uint64_t u) {
  fprintf(stderr, "[brotli/research/deorummolae.cc] enter popcount 1\n");
  return static_cast<size_t>(__builtin_popcountll(u));
  // fprintf(stderr, "[brotli/research/deorummolae.cc] exit popcount 1\n");
}

/* Condense terminators and pad file entries. */
static void rewriteText(std::vector<TextChar>* text) {
  fprintf(stderr, "[brotli/research/deorummolae.cc] enter rewriteText 1\n");
  TextChar terminator = text->back();
  TextChar prev = terminator;
  TextIdx to = 0;
  // fprintf(stderr, "[brotli/research/deorummolae.cc] exit rewriteText 1\n");
  
  for (TextIdx from = 0; from < text->size(); ++from) {
    fprintf(stderr, "[brotli/research/deorummolae.cc] enter rewriteText 2\n");
    TextChar next = text->at(from);
    if (next < 256 || prev < 256) {
      fprintf(stderr, "[brotli/research/deorummolae.cc] enter rewriteText 3\n");
      text->at(to++) = next;
      if (next >= 256) terminator = next;
      // fprintf(stderr, "[brotli/research/deorummolae.cc] exit rewriteText 3\n");
    }
    prev = next;
    // fprintf(stderr, "[brotli/research/deorummolae.cc] exit rewriteText 2\n");
  }
  
  fprintf(stderr, "[brotli/research/deorummolae.cc] enter rewriteText 4\n");
  text->resize(to);
  if (text->empty()) text->push_back(terminator);
  while (text->size() & CHUNK_MASK) text->push_back(terminator);
  // fprintf(stderr, "[brotli/research/deorummolae.cc] exit rewriteText 4\n");
}

/* Reenumerate terminators for smaller alphabet. */
static void remapTerminators(std::vector<TextChar>* text,
    TextChar* next_terminator) {
  fprintf(stderr, "[brotli/research/deorummolae.cc] enter remapTerminators 1\n");
  TextChar prev = -1;
  TextChar x = 256;
  // fprintf(stderr, "[brotli/research/deorummolae.cc] exit remapTerminators 1\n");
  
  for (TextIdx i = 0; i < text->size(); ++i) {
    fprintf(stderr, "[brotli/research/deorummolae.cc] enter remapTerminators 2\n");
    TextChar next = text->at(i);
    if (next < 256) {  // Char.
      // Do nothing.
    } else if (prev < 256) {  // Terminator after char.
      fprintf(stderr, "[brotli/research/deorummolae.cc] enter remapTerminators 3\n");
      next = x++;
      // fprintf(stderr, "[brotli/research/deorummolae.cc] exit remapTerminators 3\n");
    } else {  // Terminator after terminator.
      fprintf(stderr, "[brotli/research/deorummolae.cc] enter remapTerminators 4\n");
      next = prev;
      // fprintf(stderr, "[brotli/research/deorummolae.cc] exit remapTerminators 4\n");
    }
    text->at(i) = next;
    prev = next;
    // fprintf(stderr, "[brotli/research/deorummolae.cc] exit remapTerminators 2\n");
  }
  
  fprintf(stderr, "[brotli/research/deorummolae.cc] enter remapTerminators 5\n");
  *next_terminator = x;
  // fprintf(stderr, "[brotli/research/deorummolae.cc] exit remapTerminators 5\n");
}

/* Combine all file entries; create mapping position->file. */
static void buildFullText(std::vector<std::vector<TextChar>>* data,
    std::vector<TextChar>* full_text, std::vector<TextIdx>* file_map,
    std::vector<TextIdx>* file_offset, TextChar* next_terminator) {
  fprintf(stderr, "[brotli/research/deorummolae.cc] enter buildFullText 1\n");
  file_map->resize(0);
  file_offset->resize(0);
  full_text->resize(0);
  // fprintf(stderr, "[brotli/research/deorummolae.cc] exit buildFullText 1\n");
  
  for (TextIdx i = 0; i < data->size(); ++i) {
    fprintf(stderr, "[brotli/research/deorummolae.cc] enter buildFullText 2\n");
    file_offset->push_back(full_text->size());
    std::vector<TextChar>& file = data->at(i);
    rewriteText(&file);
    full_text->insert(full_text->end(), file.begin(), file.end());
    file_map->insert(file_map->end(), file.size() / CHUNK_SIZE, i);
    // fprintf(stderr, "[brotli/research/deorummolae.cc] exit buildFullText 2\n");
  }
  
  fprintf(stderr, "[brotli/research/deorummolae.cc] enter buildFullText 3\n");
  if (false) remapTerminators(full_text, next_terminator);
  // fprintf(stderr, "[brotli/research/deorummolae.cc] exit buildFullText 3\n");
}

/* Build longest-common-prefix based on suffix array and text.
   TODO: borrowed -> unknown efficiency. */
static void buildLcp(std::vector<TextChar>* text, std::vector<TextIdx>* sa,
    std::vector<TextIdx>* lcp, std::vector<TextIdx>* invese_sa) {
  fprintf(stderr, "[brotli/research/deorummolae.cc] enter buildLcp 1\n");
  TextIdx size = static_cast<TextIdx>(text->size());
  lcp->resize(size);
  TextIdx k = 0;
  lcp->at(size - 1) = 0;
  // fprintf(stderr, "[brotli/research/deorummolae.cc] exit buildLcp 1\n");
  
  for (TextIdx i = 0; i < size; ++i) {
    fprintf(stderr, "[brotli/research/deorummolae.cc] enter buildLcp 2\n");
    if (invese_sa->at(i) == size - 1) {
      fprintf(stderr, "[brotli/research/deorummolae.cc] enter buildLcp 3\n");
      k = 0;
      continue;
      // fprintf(stderr, "[brotli/research/deorummolae.cc] exit buildLcp 3\n");
    }
    // Suffix which follow i-th suffix.
    TextIdx j = sa->at(invese_sa->at(i) + 1);
    // fprintf(stderr, "[brotli/research/deorummolae.cc] exit buildLcp 2\n");
    
    while (i + k < size && j + k < size && text->at(i + k) == text->at(j + k)) {
      fprintf(stderr, "[brotli/research/deorummolae.cc] enter buildLcp 4\n");
      ++k;
      // fprintf(stderr, "[brotli/research/deorummolae.cc] exit buildLcp 4\n");
    }
    
    fprintf(stderr, "[brotli/research/deorummolae.cc] enter buildLcp 5\n");
    lcp->at(invese_sa->at(i)) = k;
    if (k > 0) --k;
    // fprintf(stderr, "[brotli/research/deorummolae.cc] exit buildLcp 5\n");
  }
}

/* Isle is a range in SA with LCP not less than some value.
   When we raise the LCP requirement, the isle sunks and smaller isles appear
   instead. */
typedef struct {
  TextIdx lcp;
  TextIdx l;
  TextIdx r;
  Coverage coverage;
} Isle;

/* Helper routine for `cutMatch`. */
static void poisonData(TextIdx pos, TextIdx length,
    std::vector<std::vector<TextChar>>* data, std::vector<TextIdx>* file_map,
    std::vector<TextIdx>* file_offset, TextChar* next_terminator) {
  fprintf(stderr, "[brotli/research/deorummolae.cc] enter poisonData 1\n");
  TextIdx f = file_map->at(pos / CHUNK_SIZE);
  pos -= file_offset->at(f);
  std::vector<TextChar>& file = data->at(f);
  TextIdx l = (length == CUT_MATCH) ? CUT_MATCH : 1;
  // fprintf(stderr, "[brotli/research/deorummolae.cc] exit poisonData 1\n");
  
  for (TextIdx j = 0; j < l; j++, pos++) {
    fprintf(stderr, "[brotli/research/deorummolae.cc] enter poisonData 2\n");
    if (file[pos] >= 256) continue;
    if (file[pos + 1] >= 256) {
      fprintf(stderr, "[brotli/research/deorummolae.cc] enter poisonData 3\n");
      file[pos] = file[pos + 1];
      // fprintf(stderr, "[brotli/research/deorummolae.cc] exit poisonData 3\n");
    } else if (pos > 0 && file[pos - 1] >= 256) {
      fprintf(stderr, "[brotli/research/deorummolae.cc] enter poisonData 4\n");
      file[pos] = file[pos - 1];
      // fprintf(stderr, "[brotli/research/deorummolae.cc] exit poisonData 4\n");
    } else {
      fprintf(stderr, "[brotli/research/deorummolae.cc] enter poisonData 5\n");
      file[pos] = (*next_terminator)++;
      // fprintf(stderr, "[brotli/research/deorummolae.cc] exit poisonData 5\n");
    }
    // fprintf(stderr, "[brotli/research/deorummolae.cc] exit poisonData 2\n");
  }
}

/* Remove substrings of a given match from files.
   Substrings are replaced with unique terminators, so next iteration SA would
   not allow to cross removed areas. */
static void cutMatch(std::vector<std::vector<TextChar>>* data, TextIdx index,
    TextIdx length, std::vector<TextIdx>* sa, std::vector<TextIdx>* lcp,
    std::vector<TextIdx>* invese_sa, TextChar* next_terminator,
    std::vector<TextIdx>* file_map, std::vector<TextIdx>* file_offset) {
  fprintf(stderr, "[brotli/research/deorummolae.cc] enter cutMatch 1\n");
  while (length >= CUT_MATCH) {
    fprintf(stderr, "[brotli/research/deorummolae.cc] enter cutMatch 2\n");
    TextIdx i = index;
    // fprintf(stderr, "[brotli/research/deorummolae.cc] exit cutMatch 2\n");
    
    while (lcp->at(i) >= length) {
      fprintf(stderr, "[brotli/research/deorummolae.cc] enter cutMatch 3\n");
      i++;
      poisonData(
          sa->at(i), length, data, file_map, file_offset, next_terminator);
      // fprintf(stderr, "[brotli/research/deorummolae.cc] exit cutMatch 3\n");
    }
    
    while (true) {
      fprintf(stderr, "[brotli/research/deorummolae.cc] enter cutMatch 4\n");
      poisonData(
          sa->at(index), length, data, file_map, file_offset, next_terminator);
      if (index == 0 || lcp->at(index - 1) < length) break;
      index--;
      // fprintf(stderr, "[brotli/research/deorummolae.cc] exit cutMatch 4\n");
    }
    
    fprintf(stderr, "[brotli/research/deorummolae.cc] enter cutMatch 5\n");
    length--;
    index = invese_sa->at(sa->at(index) + 1);
    // fprintf(stderr, "[brotli/research/deorummolae.cc] exit cutMatch 5\n");
  }
  // fprintf(stderr, "[brotli/research/deorummolae.cc] exit cutMatch 1\n");
}

std::string DM_generate(size_t dictionary_size_limit,
    const std::vector<size_t>& sample_sizes, const uint8_t* sample_data) {
  fprintf(stderr, "[brotli/research/deorummolae.cc] enter DM_generate 1\n");
  {
    TextIdx tmp = static_cast<TextIdx>(dictionary_size_limit);
    if ((tmp != dictionary_size_limit) || (tmp > 1u << 30)) {
      fprintf(stderr, "[brotli/research/deorummolae.cc] enter DM_generate 2\n");
      fprintf(stderr, "dictionary_size_limit is too large\n");
      return "";
      // fprintf(stderr, "[brotli/research/deorummolae.cc] exit DM_generate 2\n");
    }
  }

  /* Could use 256 + '0' for easier debugging. */
  TextChar next_terminator = 256;

  std::string output;
  std::vector<std::vector<TextChar>> data;

  TextIdx offset = 0;
  size_t num_samples = sample_sizes.size();
  if (num_samples > DM_MAX_FILES) num_samples = DM_MAX_FILES;
  // fprintf(stderr, "[brotli/research/deorummolae.cc] exit DM_generate 1\n");
  
  for (size_t n = 0; n < num_samples; ++n) {
    fprintf(stderr, "[brotli/research/deorummolae.cc] enter DM_generate 3\n");
    TextIdx delta = static_cast<TextIdx>(sample_sizes[n]);
    if (delta != sample_sizes[n]) {
      fprintf(stderr, "[brotli/research/deorummolae.cc] enter DM_generate 4\n");
      fprintf(stderr, "sample is too large\n");
      return "";
      // fprintf(stderr, "[brotli/research/deorummolae.cc] exit DM_generate 4\n");
    }
    if (delta == 0) {
      fprintf(stderr, "[brotli/research/deorummolae.cc] enter DM_generate 5\n");
      fprintf(stderr, "0-length samples are prohibited\n");
      return "";
      // fprintf(stderr, "[brotli/research/deorummolae.cc] exit DM_generate 5\n");
    }
    TextIdx next_offset = offset + delta;
    if (next_offset <= offset) {
      fprintf(stderr, "[brotli/research/deorummolae.cc] enter DM_generate 6\n");
      fprintf(stderr, "corpus is too large\n");
      return "";
      // fprintf(stderr, "[brotli/research/deorummolae.cc] exit DM_generate 6\n");
    }
    data.push_back(
        std::vector<TextChar>(sample_data + offset, sample_data + next_offset));
    offset = next_offset;
    data.back().push_back(next_terminator++);
    // fprintf(stderr, "[brotli/research/deorummolae.cc] exit DM_generate 3\n");
  }

  fprintf(stderr, "[brotli/research/deorummolae.cc] enter DM_generate 7\n");
  /* Most arrays are allocated once, and then just resized to smaller and
     smaller sizes. */
  std::vector<TextChar> full_text;
  std::vector<TextIdx> file_map;
  std::vector<TextIdx> file_offset;
  std::vector<TextIdx> sa;
  std::vector<TextIdx> invese_sa;
  std::vector<TextIdx> lcp;
  std::vector<Isle> isles;
  std::vector<char> output_data;
  TextIdx total = 0;
  TextIdx total_cost = 0;
  TextIdx best_cost;
  Isle best_isle;
  size_t min_count = num_samples;
  // fprintf(stderr, "[brotli/research/deorummolae.cc] exit DM_generate 7\n");

  while (true) {
    fprintf(stderr, "[brotli/research/deorummolae.cc] enter DM_generate 8\n");
    TextIdx max_match = static_cast<TextIdx>(dictionary_size_limit) - total;
    buildFullText(&data, &full_text, &file_map, &file_offset, &next_terminator);
    sa.resize(full_text.size());
    /* Hopefully, non-negative TextSaIdx is the same sa TextIdx counterpart. */
    saisxx(full_text.data(), reinterpret_cast<TextSaIdx*>(sa.data()),
        static_cast<TextChar>(full_text.size()), next_terminator);
    invese_sa.resize(full_text.size());
    // fprintf(stderr, "[brotli/research/deorummolae.cc] exit DM_generate 8\n");
    
    for (TextIdx i = 0; i < full_text.size(); ++i) {
      fprintf(stderr, "[brotli/research/deorummolae.cc] enter DM_generate 9\n");
      invese_sa[sa[i]] = i;
      // fprintf(stderr, "[brotli/research/deorummolae.cc] exit DM_generate 9\n");
    }
    
    fprintf(stderr, "[brotli/research/deorummolae.cc] enter DM_generate 10\n");
    buildLcp(&full_text, &sa, &lcp, &invese_sa);

    /* Do not rebuild SA/LCP, just use different selection. */
  retry:
    best_cost = 0;
    best_isle = {0, 0, 0, {{0}}};
    isles.resize(0);
    isles.push_back(best_isle);
    // fprintf(stderr, "[brotli/research/deorummolae.cc] exit DM_generate 10\n");

    for (TextIdx i = 0; i < lcp.size(); ++i) {
      fprintf(stderr, "[brotli/research/deorummolae.cc] enter DM_generate 11\n");
      TextIdx l = i;
      Coverage cov = {{0}};
      size_t f = file_map[sa[i] / CHUNK_SIZE];
      cov[f >> 6] = (static_cast<uint64_t>(1)) << (f & 63);
      // fprintf(stderr, "[brotli/research/deorummolae.cc] exit DM_generate 11\n");
      
      while (lcp[i] < isles.back().lcp) {
        fprintf(stderr, "[brotli/research/deorummolae.cc] enter DM_generate 12\n");
        Isle& top = isles.back();
        top.r = i;
        l = top.l;
        for (size_t x = 0; x < cov.size(); ++x) cov[x] |= top.coverage[x];
        size_t count = 0;
        // fprintf(stderr, "[brotli/research/deorummolae.cc] exit DM_generate 12\n");
        
        for (size_t x = 0; x < cov.size(); ++x) {
          fprintf(stderr, "[brotli/research/deorummolae.cc] enter DM_generate 13\n");
          count += popcount(cov[x]);
          // fprintf(stderr, "[brotli/research/deorummolae.cc] exit DM_generate 13\n");
        }
        
        fprintf(stderr, "[brotli/research/deorummolae.cc] enter DM_generate 14\n");
        TextIdx effective_lcp = top.lcp;
        /* Restrict (last) dictionary entry length. */
        if (effective_lcp > max_match) effective_lcp = max_match;
        TextIdx cost = count * effective_lcp;
        if (cost > best_cost && count >= min_count &&
            effective_lcp >= MIN_MATCH) {
          fprintf(stderr, "[brotli/research/deorummolae.cc] enter DM_generate 15\n");
          best_cost = cost;
          best_isle = top;
          best_isle.lcp = effective_lcp;
          // fprintf(stderr, "[brotli/research/deorummolae.cc] exit DM_generate 15\n");
        }
        isles.pop_back();
        // fprintf(stderr, "[brotli/research/deorummolae.cc] exit DM_generate 14\n");
        
        for (size_t x = 0; x < cov.size(); ++x) {
          fprintf(stderr, "[brotli/research/deorummolae.cc] enter DM_generate 16\n");
          isles.back().coverage[x] |= cov[x];
          // fprintf(stderr, "[brotli/research/deorummolae.cc] exit DM_generate 16\n");
        }
      }
      
      fprintf(stderr, "[brotli/research/deorummolae.cc] enter DM_generate 17\n");
      if (lcp[i] > isles.back().lcp) isles.push_back({lcp[i], l, 0, {{0}}});
      // fprintf(stderr, "[brotli/research/deorummolae.cc] exit DM_generate 17\n");
      
      for (size_t x = 0; x < cov.size(); ++x) {
        fprintf(stderr, "[brotli/research/deorummolae.cc] enter DM_generate 18\n");
        isles.back().coverage[x] |= cov[x];
        // fprintf(stderr, "[brotli/research/deorummolae.cc] exit DM_generate 18\n");
      }
    }

    fprintf(stderr, "[brotli/research/deorummolae.cc] enter DM_generate 19\n");
    /* When saturated matches do not match length restrictions, lower the
       saturation requirements. */
    if (best_cost == 0 || best_isle.lcp < MIN_MATCH) {
      fprintf(stderr, "[brotli/research/deorummolae.cc] enter DM_generate 20\n");
      if (min_count >= 8) {
        fprintf(stderr, "[brotli/research/deorummolae.cc] enter DM_generate 21\n");
        min_count = (min_count * 7) / 8;
        fprintf(stderr, "Retry: min_count=%zu\n", min_count);
        goto retry;
        // fprintf(stderr, "[brotli/research/deorummolae.cc] exit DM_generate 21\n");
      }
      break;
      // fprintf(stderr, "[brotli/research/deorummolae.cc] exit DM_generate 20\n");
    }

    /* Save the entry. */
    fprintf(stderr, "Savings: %d+%d, dictionary: %d+%d\n",
        total_cost, best_cost, total, best_isle.lcp);
    int* piece = &full_text[sa[best_isle.l]];
    output.insert(output.end(), piece, piece + best_isle.lcp);
    total += best_isle.lcp;
    total_cost += best_cost;
    cutMatch(&data, best_isle.l, best_isle.lcp, &sa, &lcp, &invese_sa,
        &next_terminator, &file_map, &file_offset);
    if (total >= dictionary_size_limit) break;
    // fprintf(stderr, "[brotli/research/deorummolae.cc] exit DM_generate 19\n");
  }

  fprintf(stderr, "[brotli/research/deorummolae.cc] enter DM_generate 22\n");
  return output;
  // fprintf(stderr, "[brotli/research/deorummolae.cc] exit DM_generate 22\n");
}
// Total cost: 0.095433
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 302)]
// Total instrumented cost: 0.095433, input tokens: 2398, output tokens: 5390, cache read tokens: 2394, cache write tokens: 3694
