/* Copyright 2016 Google Inc. All Rights Reserved.
   Author: zip753@gmail.com (Ivan Nikulin)

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

/* Backward reference visualization tool. Accepts file with backward references
   as an input and produces PGM image with histogram of those references. */

#include <algorithm> /* min */
#include <cassert>
#include <cstring> /* memset */
#include <cmath> /* log, round */
#include <cstdio> /* fscanf, fprintf */
#include <cstdint>

#include <gflags/gflags.h>
using gflags::ParseCommandLineFlags;

#include "./read_dist.h"

DEFINE_int32(height, 1000, "Height of the resulting histogam.");
DEFINE_int32(width, 8000, "Width of the resulting histogam.");
DEFINE_int32(size, 1e8, "Size of the compressed file.");
DEFINE_int32(brotli_window, -1, "Size of brotli window in bits.");
DEFINE_uint64(min_distance, 0, "Minimum distance.");
DEFINE_uint64(max_distance, 1 << 30, "Maximum distance.");
DEFINE_bool(with_copies, false, "True if input contains copy length.");
DEFINE_bool(simple, false, "True if using only black and white pixels.");
DEFINE_bool(linear, false, "True if using linear distance mapping.");
DEFINE_uint64(skip, 0, "Number of bytes to skip.");

inline double DistanceTransform(double x) {
  fprintf(stderr, "[brotli/research/draw_histogram.cc] enter DistanceTransform 1\n");
  static bool linear = FLAGS_linear;
  if (linear) {
    fprintf(stderr, "[brotli/research/draw_histogram.cc] enter DistanceTransform 2\n");
    return x;
    // fprintf(stderr, "[brotli/research/draw_histogram.cc] exit DistanceTransform 2\n");
  } else {
    fprintf(stderr, "[brotli/research/draw_histogram.cc] enter DistanceTransform 3\n");
    /* Using log^2 scale because log scale produces big white gap at the bottom
       of image. */
    return log(x) * log(x);
    // fprintf(stderr, "[brotli/research/draw_histogram.cc] exit DistanceTransform 3\n");
  }
  // fprintf(stderr, "[brotli/research/draw_histogram.cc] exit DistanceTransform 1\n");
}

/* Mapping pixel density on arc function to increase contrast. */
inline double DensityTransform(double x) {
  fprintf(stderr, "[brotli/research/draw_histogram.cc] enter DensityTransform 1\n");
  double z = 255 - x;
  return sqrt(255 * 255 - z * z);
  // fprintf(stderr, "[brotli/research/draw_histogram.cc] exit DensityTransform 1\n");
}

inline int GetMaxDistance() {
  fprintf(stderr, "[brotli/research/draw_histogram.cc] enter GetMaxDistance 1\n");
  return FLAGS_max_distance;
  // fprintf(stderr, "[brotli/research/draw_histogram.cc] exit GetMaxDistance 1\n");
}

void AdjustPosition(int* pos) {
  fprintf(stderr, "[brotli/research/draw_histogram.cc] enter AdjustPosition 1\n");
  static uint32_t offset = 0;
  static int last = 0;
  static uint32_t window_size = (1 << FLAGS_brotli_window);
  assert(*pos >= 0 && *pos < window_size);
  if (*pos < last) {
    fprintf(stderr, "[brotli/research/draw_histogram.cc] enter AdjustPosition 2\n");
    offset += window_size;
    // fprintf(stderr, "[brotli/research/draw_histogram.cc] exit AdjustPosition 2\n");
  }
  last = *pos;
  *pos += offset;
  // fprintf(stderr, "[brotli/research/draw_histogram.cc] exit AdjustPosition 1\n");
}

void BuildHistogram(FILE* fin, int** histo) {
  fprintf(stderr, "[brotli/research/draw_histogram.cc] enter BuildHistogram 1\n");
  int height = FLAGS_height;
  int width = FLAGS_width;
  int skip = FLAGS_skip;
  size_t min_distance = FLAGS_min_distance;

  printf("height = %d, width = %d\n", height, width);

  for (int i = 0; i < height; i++) {
    fprintf(stderr, "[brotli/research/draw_histogram.cc] enter BuildHistogram 2\n");
    for (int j = 0; j < width; j++) {
      fprintf(stderr, "[brotli/research/draw_histogram.cc] enter BuildHistogram 3\n");
      histo[i][j] = 0;
      // fprintf(stderr, "[brotli/research/draw_histogram.cc] exit BuildHistogram 3\n");
    }
    // fprintf(stderr, "[brotli/research/draw_histogram.cc] exit BuildHistogram 2\n");
  }

  int max_pos = FLAGS_size - skip;
  double min_dist = min_distance > 0 ? DistanceTransform(min_distance) : 0;
  double max_dist = DistanceTransform(GetMaxDistance()) - min_dist;
  int copy, pos, distance, x, y;
  double dist;
  while (ReadBackwardReference(fin, &copy, &pos, &distance)) {
    fprintf(stderr, "[brotli/research/draw_histogram.cc] enter BuildHistogram 4\n");
    if (pos == -1) continue;  // In case when only insert is present.
    if (distance < min_distance || distance >= GetMaxDistance()) continue;
    if (FLAGS_brotli_window != -1) {
      fprintf(stderr, "[brotli/research/draw_histogram.cc] enter BuildHistogram 5\n");
      AdjustPosition(&pos);
      // fprintf(stderr, "[brotli/research/draw_histogram.cc] exit BuildHistogram 5\n");
    }
    if (pos >= skip && distance <= pos) {
      fprintf(stderr, "[brotli/research/draw_histogram.cc] enter BuildHistogram 6\n");
      pos -= skip;
      if (pos >= max_pos) break;
      dist = DistanceTransform(static_cast<double>(distance)) - min_dist;

      x = std::min(static_cast<int>(round(dist / max_dist * height)),
                   height - 1);
      y = 1ul * pos * width / max_pos;
      if (!(y >= 0 && y < width)) {
        fprintf(stderr, "[brotli/research/draw_histogram.cc] enter BuildHistogram 7\n");
        printf("pos = %d, max_pos = %d, y = %d\n", pos, max_pos, y);
        assert(y >= 0 && y < width);
        // fprintf(stderr, "[brotli/research/draw_histogram.cc] exit BuildHistogram 7\n");
      }

      if (FLAGS_with_copies) {
        fprintf(stderr, "[brotli/research/draw_histogram.cc] enter BuildHistogram 8\n");
        int right = 1ul * (pos + copy - 1) * width / max_pos;
        if (right < 0) {
          fprintf(stderr, "[brotli/research/draw_histogram.cc] enter BuildHistogram 9\n");
          printf("pos = %d, distance = %d, copy = %d, y = %d, right = %d\n",
                  pos, distance, copy, y, right);
          assert(right >= 0);
          // fprintf(stderr, "[brotli/research/draw_histogram.cc] exit BuildHistogram 9\n");
        }
        if (y == right) {
          fprintf(stderr, "[brotli/research/draw_histogram.cc] enter BuildHistogram 10\n");
          histo[x][y] += copy;
          // fprintf(stderr, "[brotli/research/draw_histogram.cc] exit BuildHistogram 10\n");
        } else {
          fprintf(stderr, "[brotli/research/draw_histogram.cc] enter BuildHistogram 11\n");
          int pos2 = static_cast<int>(ceil(1.0 * (y + 1) * max_pos / width));
          histo[x][y] += pos2 - pos;
          for (int i = y + 1; i < right && i < width; ++i) {
            fprintf(stderr, "[brotli/research/draw_histogram.cc] enter BuildHistogram 12\n");
            histo[x][i] += max_pos / width;  // Sometimes 1 more, but who cares.
            // fprintf(stderr, "[brotli/research/draw_histogram.cc] exit BuildHistogram 12\n");
          }
          // Make sure the match doesn't go beyond the image.
          if (right < width) {
            fprintf(stderr, "[brotli/research/draw_histogram.cc] enter BuildHistogram 13\n");
            pos2 = static_cast<int>(ceil(1.0 * right * max_pos / width));
            histo[x][right] += pos + copy - 1 - pos2 + 1;
            // fprintf(stderr, "[brotli/research/draw_histogram.cc] exit BuildHistogram 13\n");
          }
          // fprintf(stderr, "[brotli/research/draw_histogram.cc] exit BuildHistogram 11\n");
        }
        // fprintf(stderr, "[brotli/research/draw_histogram.cc] exit BuildHistogram 8\n");
      } else {
        fprintf(stderr, "[brotli/research/draw_histogram.cc] enter BuildHistogram 14\n");
        histo[x][y]++;
        // fprintf(stderr, "[brotli/research/draw_histogram.cc] exit BuildHistogram 14\n");
      }
      // fprintf(stderr, "[brotli/research/draw_histogram.cc] exit BuildHistogram 6\n");
    }
    // fprintf(stderr, "[brotli/research/draw_histogram.cc] exit BuildHistogram 4\n");
  }
  // fprintf(stderr, "[brotli/research/draw_histogram.cc] exit BuildHistogram 1\n");
}

void ConvertToPixels(int** histo, uint8_t** pixel) {
  fprintf(stderr, "[brotli/research/draw_histogram.cc] enter ConvertToPixels 1\n");
  int height = FLAGS_height;
  int width = FLAGS_width;

  int maxs = 0;
  for (int i = 0; i < height; i++) {
    fprintf(stderr, "[brotli/research/draw_histogram.cc] enter ConvertToPixels 2\n");
    for (int j = 0; j < width; j++) {
      fprintf(stderr, "[brotli/research/draw_histogram.cc] enter ConvertToPixels 3\n");
      if (maxs < histo[i][j]) maxs = histo[i][j];
      // fprintf(stderr, "[brotli/research/draw_histogram.cc] exit ConvertToPixels 3\n");
    }
    // fprintf(stderr, "[brotli/research/draw_histogram.cc] exit ConvertToPixels 2\n");
  }

  bool simple = FLAGS_simple;
  double max_histo = static_cast<double>(maxs);
  for (int i = 0; i < height; i++) {
    fprintf(stderr, "[brotli/research/draw_histogram.cc] enter ConvertToPixels 4\n");
    for (int j = 0; j < width; j++) {
      fprintf(stderr, "[brotli/research/draw_histogram.cc] enter ConvertToPixels 5\n");
      if (simple) {
        fprintf(stderr, "[brotli/research/draw_histogram.cc] enter ConvertToPixels 6\n");
        pixel[i][j] = histo[i][j] > 0 ? 0 : 255;
        // fprintf(stderr, "[brotli/research/draw_histogram.cc] exit ConvertToPixels 6\n");
      } else {
        fprintf(stderr, "[brotli/research/draw_histogram.cc] enter ConvertToPixels 7\n");
        pixel[i][j] = static_cast<uint8_t>(
            255 - DensityTransform(histo[i][j] / max_histo * 255));
        // fprintf(stderr, "[brotli/research/draw_histogram.cc] exit ConvertToPixels 7\n");
      }
      // fprintf(stderr, "[brotli/research/draw_histogram.cc] exit ConvertToPixels 5\n");
    }
    // fprintf(stderr, "[brotli/research/draw_histogram.cc] exit ConvertToPixels 4\n");
  }
  // fprintf(stderr, "[brotli/research/draw_histogram.cc] exit ConvertToPixels 1\n");
}

void DrawPixels(uint8_t** pixel, FILE* fout) {
  fprintf(stderr, "[brotli/research/draw_histogram.cc] enter DrawPixels 1\n");
  int height = FLAGS_height;
  int width = FLAGS_width;

  fprintf(fout, "P5\n%d %d\n255\n", width, height);
  for (int i = height - 1; i >= 0; i--) {
    fprintf(stderr, "[brotli/research/draw_histogram.cc] enter DrawPixels 2\n");
    fwrite(pixel[i], 1, width, fout);
    // fprintf(stderr, "[brotli/research/draw_histogram.cc] exit DrawPixels 2\n");
  }
  // fprintf(stderr, "[brotli/research/draw_histogram.cc] exit DrawPixels 1\n");
}

int main(int argc, char* argv[]) {
  fprintf(stderr, "[brotli/research/draw_histogram.cc] enter main 1\n");
  ParseCommandLineFlags(&argc, &argv, true);
  if (argc != 3) {
    fprintf(stderr, "[brotli/research/draw_histogram.cc] enter main 2\n");
    printf("usage: draw_histogram.cc data output_file\n");
    return 1;
    // fprintf(stderr, "[brotli/research/draw_histogram.cc] exit main 2\n");
  }

  int height = FLAGS_height;
  int width = FLAGS_width;

  FILE* fin = fopen(argv[1], "r");
  FILE* fout = fopen(argv[2], "wb");

  uint8_t** pixel = new uint8_t*[height];
  int** histo = new int*[height];
  for (int i = 0; i < height; i++) {
    fprintf(stderr, "[brotli/research/draw_histogram.cc] enter main 3\n");
    pixel[i] = new uint8_t[width];
    histo[i] = new int[width];
    // fprintf(stderr, "[brotli/research/draw_histogram.cc] exit main 3\n");
  }

  BuildHistogram(fin, histo);
  fclose(fin);

  ConvertToPixels(histo, pixel);

  DrawPixels(pixel, fout);
  fclose(fout);

  return 0;
  // fprintf(stderr, "[brotli/research/draw_histogram.cc] exit main 1\n");
}
// Total cost: 0.057569
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 197)]
// Total instrumented cost: 0.057569, input tokens: 2398, output tokens: 3244, cache read tokens: 2394, cache write tokens: 2181
