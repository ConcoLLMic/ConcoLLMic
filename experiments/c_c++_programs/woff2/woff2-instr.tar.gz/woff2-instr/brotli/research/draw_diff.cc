/* Copyright 2016 Google Inc. All Rights Reserved.
   Author: zip753@gmail.com (Ivan Nikulin)

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

/* Tool for drawing diff PPM images between two input PGM images. Normally used
   with backward reference histogram drawing tool. */

#include <algorithm>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>  /* exit, EXIT_FAILURE */
#include <vector>

#ifndef CHECK
#define CHECK(X) if (!(X)) exit(EXIT_FAILURE);
#endif

typedef uint8_t* ScanLine;
typedef ScanLine* Image;

void ReadPGM(FILE* f, Image* image, size_t* height, size_t* width) {
  fprintf(stderr, "[brotli/research/draw_diff.cc] enter ReadPGM 1\n");
  int colors;
  CHECK(fscanf(f, "P5\n%lu %lu\n%d\n", width, height, &colors) == 3);
  assert(colors == 255);
  ScanLine* lines = new ScanLine[*height];
  *image = lines;
  // fprintf(stderr, "[brotli/research/draw_diff.cc] exit ReadPGM 1\n");
  
  for (int i = *height - 1; i >= 0; --i) {
    fprintf(stderr, "[brotli/research/draw_diff.cc] enter ReadPGM 2\n");
    ScanLine line = new uint8_t[*width];
    lines[i] = line;
    CHECK(fread(line, 1, *width, f) == *width);
    // fprintf(stderr, "[brotli/research/draw_diff.cc] exit ReadPGM 2\n");
  }
}

void CalculateDiff(int** diff, Image image1, Image image2,
                   size_t height, size_t width) {
  fprintf(stderr, "[brotli/research/draw_diff.cc] enter CalculateDiff 1\n");
  for (size_t i = 0; i < height; ++i) {
    fprintf(stderr, "[brotli/research/draw_diff.cc] enter CalculateDiff 2\n");
    for (size_t j = 0; j < width; ++j) {
      fprintf(stderr, "[brotli/research/draw_diff.cc] enter CalculateDiff 3\n");
      diff[i][j] = static_cast<int>(image1[i][j]) - image2[i][j];
      // fprintf(stderr, "[brotli/research/draw_diff.cc] exit CalculateDiff 3\n");
    }
    // fprintf(stderr, "[brotli/research/draw_diff.cc] exit CalculateDiff 2\n");
  }
  // fprintf(stderr, "[brotli/research/draw_diff.cc] exit CalculateDiff 1\n");
}

void DrawDiff(int** diff, Image image1, Image image2,
              size_t height, size_t width, FILE* f) {
  fprintf(stderr, "[brotli/research/draw_diff.cc] enter DrawDiff 1\n");
  int max = -1234;
  int min = +1234;
  // fprintf(stderr, "[brotli/research/draw_diff.cc] exit DrawDiff 1\n");
  
  for (size_t i = 0; i < height; ++i) {
    fprintf(stderr, "[brotli/research/draw_diff.cc] enter DrawDiff 2\n");
    for (size_t j = 0; j < width; ++j) {
      fprintf(stderr, "[brotli/research/draw_diff.cc] enter DrawDiff 3\n");
      if (max < diff[i][j]) max = diff[i][j];
      if (min > diff[i][j]) min = diff[i][j];
      int img_min = std::min(255 - image1[i][j], 255 - image2[i][j]);
      if (max < img_min) max = img_min;
      // fprintf(stderr, "[brotli/research/draw_diff.cc] exit DrawDiff 3\n");
    }
    // fprintf(stderr, "[brotli/research/draw_diff.cc] exit DrawDiff 2\n");
  }

  fprintf(stderr, "[brotli/research/draw_diff.cc] enter DrawDiff 4\n");
  int abs_max = -min;
  if (abs_max < max) abs_max = max;

  fprintf(f, "P6\n%lu %lu\n%d\n", width, height, abs_max);

  uint8_t* row = new uint8_t[3 * width];
  // fprintf(stderr, "[brotli/research/draw_diff.cc] exit DrawDiff 4\n");
  
  for (int i = height - 1; i >= 0; --i) {
    fprintf(stderr, "[brotli/research/draw_diff.cc] enter DrawDiff 5\n");
    for (int j = 0; j < width; ++j) {
      fprintf(stderr, "[brotli/research/draw_diff.cc] enter DrawDiff 6\n");
      int min_val = std::min(255 - image1[i][j], 255 - image2[i][j]);
      int max_val = std::max(min_val, abs(diff[i][j]));
      if (diff[i][j] > 0) { /* red */
        fprintf(stderr, "[brotli/research/draw_diff.cc] enter DrawDiff 7\n");
        row[3 * j + 0] = abs_max - max_val + diff[i][j];
        row[3 * j + 1] = abs_max - max_val;
        row[3 * j + 2] = abs_max - max_val + min_val;
        // fprintf(stderr, "[brotli/research/draw_diff.cc] exit DrawDiff 7\n");
      } else { /* green */
        fprintf(stderr, "[brotli/research/draw_diff.cc] enter DrawDiff 8\n");
        row[3 * j + 0] = abs_max - max_val;
        row[3 * j + 1] = abs_max - max_val - diff[i][j];
        row[3 * j + 2] = abs_max - max_val + min_val;
        // fprintf(stderr, "[brotli/research/draw_diff.cc] exit DrawDiff 8\n");
      }
      // fprintf(stderr, "[brotli/research/draw_diff.cc] exit DrawDiff 6\n");
    }
    fprintf(stderr, "[brotli/research/draw_diff.cc] enter DrawDiff 9\n");
    fwrite(row, 1, 3 * width, f);
    // fprintf(stderr, "[brotli/research/draw_diff.cc] exit DrawDiff 9\n");
    // fprintf(stderr, "[brotli/research/draw_diff.cc] exit DrawDiff 5\n");
  }
  fprintf(stderr, "[brotli/research/draw_diff.cc] enter DrawDiff 10\n");
  delete[] row;
  // fprintf(stderr, "[brotli/research/draw_diff.cc] exit DrawDiff 10\n");
}

int main(int argc, char** argv) {
  fprintf(stderr, "[brotli/research/draw_diff.cc] enter main 1\n");
  if (argc != 4) {
    fprintf(stderr, "[brotli/research/draw_diff.cc] enter main 2\n");
    printf("usage: %s pgm1 pgm2 diff_ppm_path\n", argv[0]);
    return 1;
    // fprintf(stderr, "[brotli/research/draw_diff.cc] exit main 2\n");
  }

  Image image1, image2;
  size_t h1, w1, h2, w2;

  FILE* fimage1 = fopen(argv[1], "rb");
  ReadPGM(fimage1, &image1, &h1, &w1);
  fclose(fimage1);

  FILE* fimage2 = fopen(argv[2], "rb");
  ReadPGM(fimage2, &image2, &h2, &w2);
  fclose(fimage2);

  if (!(h1 == h2 && w1 == w2)) {
    fprintf(stderr, "[brotli/research/draw_diff.cc] enter main 3\n");
    printf("Images must have the same size.\n");
    return 1;
    // fprintf(stderr, "[brotli/research/draw_diff.cc] exit main 3\n");
  }

  int** diff = new int*[h1];
  for (size_t i = 0; i < h1; ++i) {
    fprintf(stderr, "[brotli/research/draw_diff.cc] enter main 4\n");
    diff[i] = new int[w1];
    // fprintf(stderr, "[brotli/research/draw_diff.cc] exit main 4\n");
  }
  CalculateDiff(diff, image1, image2, h1, w1);

  FILE* fdiff = fopen(argv[3], "wb");
  DrawDiff(diff, image1, image2, h1, w1, fdiff);
  fclose(fdiff);

  return 0;
  // fprintf(stderr, "[brotli/research/draw_diff.cc] exit main 1\n");
}
// Total cost: 0.080236
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 117)]
// Total instrumented cost: 0.080236, input tokens: 6281, output tokens: 4298, cache read tokens: 6273, cache write tokens: 3696
