// Copyright 2016 Google Inc. All Rights Reserved.
//
// Distributed under MIT license.
// See file LICENSE for detail or copy at https://opensource.org/licenses/MIT

package cbrotli

import (
	"bytes"
	"fmt"
	"io"
	"io/ioutil"
	"math"
	"math/rand"
	"testing"
	"time"
)

func checkCompressedData(compressedData, wantOriginalData []byte) error {
	fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter checkCompressedData 1\n")
	uncompressed, err := Decode(compressedData)
	if err != nil {
		return fmt.Errorf("brotli decompress failed: %v", err)
	}
	// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit checkCompressedData 1\n")
	
	if !bytes.Equal(uncompressed, wantOriginalData) {
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter checkCompressedData 2\n")
		if len(wantOriginalData) != len(uncompressed) {
			fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter checkCompressedData 3\n")
			return fmt.Errorf(""+
				"Data doesn't uncompress to the original value.\n"+
				"Length of original: %v\n"+
				"Length of uncompressed: %v",
				len(wantOriginalData), len(uncompressed))
			// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit checkCompressedData 3\n")
		}
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit checkCompressedData 2\n")
		
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter checkCompressedData 4\n")
		for i := range wantOriginalData {
			if wantOriginalData[i] != uncompressed[i] {
				fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter checkCompressedData 5\n")
				return fmt.Errorf(""+
					"Data doesn't uncompress to the original value.\n"+
					"Original at %v is %v\n"+
					"Uncompressed at %v is %v",
					i, wantOriginalData[i], i, uncompressed[i])
				// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit checkCompressedData 5\n")
			}
		}
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit checkCompressedData 4\n")
	}
	
	fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter checkCompressedData 6\n")
	return nil
	// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit checkCompressedData 6\n")
}

func TestEncoderNoWrite(t *testing.T) {
	fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestEncoderNoWrite 1\n")
	out := bytes.Buffer{}
	e := NewWriter(&out, WriterOptions{Quality: 5})
	if err := e.Close(); err != nil {
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestEncoderNoWrite 2\n")
		t.Errorf("Close()=%v, want nil", err)
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestEncoderNoWrite 2\n")
	}
	// Check Write after close.
	if _, err := e.Write([]byte("hi")); err == nil {
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestEncoderNoWrite 3\n")
		t.Errorf("No error after Close() + Write()")
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestEncoderNoWrite 3\n")
	}
	// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestEncoderNoWrite 1\n")
}

func TestEncoderEmptyWrite(t *testing.T) {
	fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestEncoderEmptyWrite 1\n")
	out := bytes.Buffer{}
	e := NewWriter(&out, WriterOptions{Quality: 5})
	n, err := e.Write([]byte(""))
	if n != 0 || err != nil {
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestEncoderEmptyWrite 2\n")
		t.Errorf("Write()=%v,%v, want 0, nil", n, err)
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestEncoderEmptyWrite 2\n")
	}
	if err := e.Close(); err != nil {
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestEncoderEmptyWrite 3\n")
		t.Errorf("Close()=%v, want nil", err)
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestEncoderEmptyWrite 3\n")
	}
	// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestEncoderEmptyWrite 1\n")
}

func TestWriter(t *testing.T) {
	fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestWriter 1\n")
	// Test basic encoder usage.
	input := []byte("<html><body><H1>Hello world</H1></body></html>")
	out := bytes.Buffer{}
	e := NewWriter(&out, WriterOptions{Quality: 1})
	in := bytes.NewReader([]byte(input))
	n, err := io.Copy(e, in)
	if err != nil {
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestWriter 2\n")
		t.Errorf("Copy Error: %v", err)
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestWriter 2\n")
	}
	if int(n) != len(input) {
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestWriter 3\n")
		t.Errorf("Copy() n=%v, want %v", n, len(input))
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestWriter 3\n")
	}
	if err := e.Close(); err != nil {
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestWriter 4\n")
		t.Errorf("Close Error after copied %d bytes: %v", n, err)
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestWriter 4\n")
	}
	if err := checkCompressedData(out.Bytes(), input); err != nil {
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestWriter 5\n")
		t.Error(err)
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestWriter 5\n")
	}
	// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestWriter 1\n")
}

func TestEncoderStreams(t *testing.T) {
	fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestEncoderStreams 1\n")
	// Test that output is streamed.
	// Adjust window size to ensure the encoder outputs at least enough bytes
	// to fill the window.
	const lgWin = 16
	windowSize := int(math.Pow(2, lgWin))
	input := make([]byte, 8*windowSize)
	rand.Read(input)
	out := bytes.Buffer{}
	e := NewWriter(&out, WriterOptions{Quality: 11, LGWin: lgWin})
	halfInput := input[:len(input)/2]
	in := bytes.NewReader(halfInput)

	n, err := io.Copy(e, in)
	if err != nil {
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestEncoderStreams 2\n")
		t.Errorf("Copy Error: %v", err)
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestEncoderStreams 2\n")
	}

	// We've fed more data than the sliding window size. Check that some
	// compressed data has been output.
	if out.Len() == 0 {
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestEncoderStreams 3\n")
		t.Errorf("Output length is 0 after %d bytes written", n)
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestEncoderStreams 3\n")
	}
	if err := e.Close(); err != nil {
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestEncoderStreams 4\n")
		t.Errorf("Close Error after copied %d bytes: %v", n, err)
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestEncoderStreams 4\n")
	}
	if err := checkCompressedData(out.Bytes(), halfInput); err != nil {
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestEncoderStreams 5\n")
		t.Error(err)
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestEncoderStreams 5\n")
	}
	// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestEncoderStreams 1\n")
}

func TestEncoderLargeInput(t *testing.T) {
	fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestEncoderLargeInput 1\n")
	input := make([]byte, 1000000)
	rand.Read(input)
	out := bytes.Buffer{}
	e := NewWriter(&out, WriterOptions{Quality: 5})
	in := bytes.NewReader(input)

	n, err := io.Copy(e, in)
	if err != nil {
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestEncoderLargeInput 2\n")
		t.Errorf("Copy Error: %v", err)
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestEncoderLargeInput 2\n")
	}
	if int(n) != len(input) {
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestEncoderLargeInput 3\n")
		t.Errorf("Copy() n=%v, want %v", n, len(input))
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestEncoderLargeInput 3\n")
	}
	if err := e.Close(); err != nil {
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestEncoderLargeInput 4\n")
		t.Errorf("Close Error after copied %d bytes: %v", n, err)
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestEncoderLargeInput 4\n")
	}
	if err := checkCompressedData(out.Bytes(), input); err != nil {
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestEncoderLargeInput 5\n")
		t.Error(err)
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestEncoderLargeInput 5\n")
	}
	// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestEncoderLargeInput 1\n")
}

func TestEncoderFlush(t *testing.T) {
	fmt.Fprintf(io.Stderr, "\n")
	input := make([]byte, 1000)
	rand.Read(input)
	out := bytes.Buffer{}
	e := NewWriter(&out, WriterOptions{Quality: 5})
	in := bytes.NewReader(input)
	_, err := io.Copy(e, in)
	if err != nil {
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestEncoderFlush 2\n")
		t.Fatalf("Copy Error: %v", err)
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestEncoderFlush 2\n")
	}
	if err := e.Flush(); err != nil {
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestEncoderFlush 3\n")
		t.Fatalf("Flush(): %v", err)
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestEncoderFlush 3\n")
	}
	if out.Len() == 0 {
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestEncoderFlush 4\n")
		t.Fatalf("0 bytes written after Flush()")
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestEncoderFlush 4\n")
	}
	fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestEncoderFlush 5\n")
	decompressed := make([]byte, 1000)
	reader := NewReader(bytes.NewReader(out.Bytes()))
	n, err := reader.Read(decompressed)
	if n != len(decompressed) || err != nil {
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestEncoderFlush 6\n")
		t.Errorf("Expected <%v, nil>, but <%v, %v>", len(decompressed), n, err)
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestEncoderFlush 6\n")
	}
	reader.Close()
	if !bytes.Equal(decompressed, input) {
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestEncoderFlush 7\n")
		t.Errorf(""+
			"Decompress after flush: %v\n"+
			"%q\n"+
			"want:\n%q",
			err, decompressed, input)
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestEncoderFlush 7\n")
	}
	if err := e.Close(); err != nil {
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestEncoderFlush 8\n")
		t.Errorf("Close(): %v", err)
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestEncoderFlush 8\n")
	}
	// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestEncoderFlush 5\n")
}

type readerWithTimeout struct {
	io.ReadCloser
}

func (r readerWithTimeout) Read(p []byte) (int, error) {
	fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter readerWithTimeout.Read 1\n")
	type result struct {
		n   int
		err error
	}
	ch := make(chan result)
	go func() {
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter readerWithTimeout.Read.goroutine 1\n")
		n, err := r.ReadCloser.Read(p)
		ch <- result{n, err}
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit readerWithTimeout.Read.goroutine 1\n")
	}()
	select {
	case result := <-ch:
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter readerWithTimeout.Read 2\n")
		return result.n, result.err
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit readerWithTimeout.Read 2\n")
	case <-time.After(5 * time.Second):
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter readerWithTimeout.Read 3\n")
		return 0, fmt.Errorf("read timed out")
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit readerWithTimeout.Read 3\n")
	}
	// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit readerWithTimeout.Read 1\n")
}

func TestDecoderStreaming(t *testing.T) {
	fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestDecoderStreaming 1\n")
	pr, pw := io.Pipe()
	writer := NewWriter(pw, WriterOptions{Quality: 5, LGWin: 20})
	reader := readerWithTimeout{NewReader(pr)}
	defer func() {
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestDecoderStreaming.defer 1\n")
		if err := reader.Close(); err != nil {
			fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestDecoderStreaming.defer 2\n")
			t.Errorf("reader.Close: %v", err)
			// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestDecoderStreaming.defer 2\n")
		}
		go ioutil.ReadAll(pr) // swallow the "EOF" token from writer.Close
		if err := writer.Close(); err != nil {
			fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestDecoderStreaming.defer 3\n")
			t.Errorf("writer.Close: %v", err)
			// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestDecoderStreaming.defer 3\n")
		}
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestDecoderStreaming.defer 1\n")
	}()

	ch := make(chan []byte)
	errch := make(chan error)
	go func() {
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestDecoderStreaming.goroutine 1\n")
		for {
			fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestDecoderStreaming.goroutine 2\n")
			segment, ok := <-ch
			if !ok {
				fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestDecoderStreaming.goroutine 3\n")
				return
				// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestDecoderStreaming.goroutine 3\n")
			}
			if n, err := writer.Write(segment); err != nil || n != len(segment) {
				fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestDecoderStreaming.goroutine 4\n")
				errch <- fmt.Errorf("write=%v,%v, want %v,%v", n, err, len(segment), nil)
				return
				// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestDecoderStreaming.goroutine 4\n")
			}
			if err := writer.Flush(); err != nil {
				fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestDecoderStreaming.goroutine 5\n")
				errch <- fmt.Errorf("flush: %v", err)
				return
				// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestDecoderStreaming.goroutine 5\n")
			}
			// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestDecoderStreaming.goroutine 2\n")
		}
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestDecoderStreaming.goroutine 1\n")
	}()
	defer close(ch)

	segments := [...][]byte{
		[]byte("first"),
		[]byte("second"),
		[]byte("third"),
	}
	for k, segment := range segments {
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestDecoderStreaming 2\n")
		t.Run(fmt.Sprintf("Segment%d", k), func(t *testing.T) {
			fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestDecoderStreaming.Run 1\n")
			select {
			case ch <- segment:
				fmt.Fprintf(io.Stderr, "\n")
				// fmt.Fprintf(io.Stderr, "\n")
			case err := <-errch:
				fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestDecoderStreaming.Run 3\n")
				t.Fatalf("write: %v", err)
				// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestDecoderStreaming.Run 3\n")
			case <-time.After(5 * time.Second):
				fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestDecoderStreaming.Run 4\n")
				t.Fatalf("timed out")
				// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestDecoderStreaming.Run 4\n")
			}
			fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestDecoderStreaming.Run 5\n")
			wantLen := len(segment)
			got := make([]byte, wantLen)
			if n, err := reader.Read(got); err != nil || n != wantLen || !bytes.Equal(got, segment) {
				fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestDecoderStreaming.Run 6\n")
				t.Fatalf("read[%d]=%q,%v,%v, want %q,%v,%v", k, got, n, err, segment, wantLen, nil)
				// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestDecoderStreaming.Run 6\n")
			}
			// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestDecoderStreaming.Run 5\n")
			// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestDecoderStreaming.Run 1\n")
		})
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestDecoderStreaming 2\n")
	}
	// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestDecoderStreaming 1\n")
}

func TestReader(t *testing.T) {
	fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestReader 1\n")
	content := bytes.Repeat([]byte("hello world!"), 10000)
	encoded, _ := Encode(content, WriterOptions{Quality: 5})
	r := NewReader(bytes.NewReader(encoded))
	var decodedOutput bytes.Buffer
	n, err := io.Copy(&decodedOutput, r)
	if err != nil {
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestReader 2\n")
		t.Fatalf("Copy(): n=%v, err=%v", n, err)
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestReader 2\n")
	}
	if err := r.Close(); err != nil {
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestReader 3\n")
		t.Errorf("Close(): %v", err)
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestReader 3\n")
	}
	if got := decodedOutput.Bytes(); !bytes.Equal(got, content) {
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestReader 4\n")
		t.Errorf(""+
			"Reader output:\n"+
			"%q\n"+
			"want:\n"+
			"<%d bytes>",
			got, len(content))
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestReader 4\n")
	}
	// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestReader 1\n")
}

func TestDecode(t *testing.T) {
	fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestDecode 1\n")
	content := bytes.Repeat([]byte("hello world!"), 10000)
	encoded, _ := Encode(content, WriterOptions{Quality: 5})
	decoded, err := Decode(encoded)
	if err != nil {
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestDecode 2\n")
		t.Errorf("Decode: %v", err)
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestDecode 2\n")
	}
	if !bytes.Equal(decoded, content) {
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestDecode 3\n")
		t.Errorf(""+
			"Decode content:\n"+
			"%q\n"+
			"want:\n"+
			"<%d bytes>",
			decoded, len(content))
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestDecode 3\n")
	}
	// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestDecode 1\n")
}

func TestDecodeFuzz(t *testing.T) {
	fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestDecodeFuzz 1\n")
	// Test that the decoder terminates with corrupted input.
	content := bytes.Repeat([]byte("hello world!"), 100)
	src := rand.NewSource(0)
	encoded, err := Encode(content, WriterOptions{Quality: 5})
	if err != nil {
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestDecodeFuzz 2\n")
		t.Fatalf("Encode(<%d bytes>, _) = _, %s", len(content), err)
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestDecodeFuzz 2\n")
	}
	if len(encoded) == 0 {
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestDecodeFuzz 3\n")
		t.Fatalf("Encode(<%d bytes>, _) produced empty output", len(content))
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestDecodeFuzz 3\n")
	}
	for i := 0; i < 100; i++ {
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestDecodeFuzz 4\n")
		enc := append([]byte{}, encoded...)
		for j := 0; j < 5; j++ {
			fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestDecodeFuzz 5\n")
			enc[int(src.Int63())%len(enc)] = byte(src.Int63() % 256)
			// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestDecodeFuzz 5\n")
		}
		Decode(enc)
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestDecodeFuzz 4\n")
	}
	// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestDecodeFuzz 1\n")
}

func TestDecodeTrailingData(t *testing.T) {
	fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestDecodeTrailingData 1\n")
	content := bytes.Repeat([]byte("hello world!"), 100)
	encoded, _ := Encode(content, WriterOptions{Quality: 5})
	_, err := Decode(append(encoded, 0))
	if err == nil {
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestDecodeTrailingData 2\n")
		t.Errorf("Expected 'excessive input' error")
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestDecodeTrailingData 2\n")
	}
	// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestDecodeTrailingData 1\n")
}

func TestEncodeDecode(t *testing.T) {
	fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestEncodeDecode 1\n")
	for _, test := range []struct {
		data    []byte
		repeats int
	}{
		{nil, 0},
		{[]byte("A"), 1},
		{[]byte("<html><body><H1>Hello world</H1></body></html>"), 10},
		{[]byte("<html><body><H1>Hello world</H1></body></html>"), 1000},
	} {
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestEncodeDecode 2\n")
		t.Logf("case %q x %d", test.data, test.repeats)
		input := bytes.Repeat(test.data, test.repeats)
		encoded, err := Encode(input, WriterOptions{Quality: 5})
		if err != nil {
			fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestEncodeDecode 3\n")
			t.Errorf("Encode: %v", err)
			// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestEncodeDecode 3\n")
		}
		// Inputs are compressible, but may be too small to compress.
		if maxSize := len(input)/2 + 20; len(encoded) >= maxSize {
			fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestEncodeDecode 4\n")
			t.Errorf(""+
				"Encode returned %d bytes, want <%d\n"+
				"Encoded=%q",
				len(encoded), maxSize, encoded)
			// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestEncodeDecode 4\n")
		}
		decoded, err := Decode(encoded)
		if err != nil {
			fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestEncodeDecode 5\n")
			t.Errorf("Decode: %v", err)
			// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestEncodeDecode 5\n")
		}
		if !bytes.Equal(decoded, input) {
			fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestEncodeDecode 6\n")
			var want string
			if len(input) > 320 {
				fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestEncodeDecode 7\n")
				want = fmt.Sprintf("<%d bytes>", len(input))
				// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestEncodeDecode 7\n")
			} else {
				fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] enter TestEncodeDecode 8\n")
				want = fmt.Sprintf("%q", input)
				// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestEncodeDecode 8\n")
			}
			t.Errorf(""+
				"Decode content:\n"+
				"%q\n"+
				"want:\n"+
				"%s",
				decoded, want)
			// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestEncodeDecode 6\n")
		}
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestEncodeDecode 2\n")
	}
	// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/cbrotli_test.go] exit TestEncodeDecode 1\n")
}
// Total cost: 0.130443
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 367)]
// Total instrumented cost: 0.130443, input tokens: 2398, output tokens: 7683, cache read tokens: 2394, cache write tokens: 3858
