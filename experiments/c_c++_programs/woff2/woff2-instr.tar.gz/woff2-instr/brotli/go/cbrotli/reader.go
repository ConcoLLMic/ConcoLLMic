// Copyright 2016 Google Inc. All Rights Reserved.
//
// Distributed under MIT license.
// See file LICENSE for detail or copy at https://opensource.org/licenses/MIT

// Package cbrotli compresses and decompresses data with C-Brotli library.
package cbrotli

/*
#include <stddef.h>
#include <stdint.h>

#include <brotli/decode.h>

static BrotliDecoderResult DecompressStream(BrotliDecoderState* s,
                                            uint8_t* out, size_t out_len,
                                            const uint8_t* in, size_t in_len,
                                            size_t* bytes_written,
                                            size_t* bytes_consumed) {
  size_t in_remaining = in_len;
  size_t out_remaining = out_len;
  BrotliDecoderResult result = BrotliDecoderDecompressStream(
      s, &in_remaining, &in, &out_remaining, &out, NULL);
  *bytes_written = out_len - out_remaining;
  *bytes_consumed = in_len - in_remaining;
  return result;
}
*/
import "C"

import (
	"bytes"
	"errors"
	"fmt"
	"io"
	"io/ioutil"
)

type decodeError C.BrotliDecoderErrorCode

func (err decodeError) Error() string {
	fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/reader.go] enter decodeError_Error 1\n")
	return "cbrotli: " +
		C.GoString(C.BrotliDecoderErrorString(C.BrotliDecoderErrorCode(err)))
	// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/reader.go] exit decodeError_Error 1\n")
}

var errExcessiveInput = errors.New("cbrotli: excessive input")
var errInvalidState = errors.New("cbrotli: invalid state")
var errReaderClosed = errors.New("cbrotli: Reader is closed")

// Reader implements io.ReadCloser by reading Brotli-encoded data from an
// underlying Reader.
type Reader struct {
	src   io.Reader
	state *C.BrotliDecoderState
	buf   []byte // scratch space for reading from src
	in    []byte // current chunk to decode; usually aliases buf
}

// readBufSize is a "good" buffer size that avoids excessive round-trips
// between C and Go but doesn't waste too much memory on buffering.
// It is arbitrarily chosen to be equal to the constant used in io.Copy.
const readBufSize = 32 * 1024

// NewReader initializes new Reader instance.
// Close MUST be called to free resources.
func NewReader(src io.Reader) *Reader {
	fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/reader.go] enter NewReader 1\n")
	return &Reader{
		src:   src,
		state: C.BrotliDecoderCreateInstance(nil, nil, nil),
		buf:   make([]byte, readBufSize),
	}
	// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/reader.go] exit NewReader 1\n")
}

// Close implements io.Closer. Close MUST be invoked to free native resources.
func (r *Reader) Close() error {
	fmt.Fprintf(io.Stderr, "\n")
	if r.state == nil {
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/reader.go] enter Reader_Close 2\n")
		return errReaderClosed
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/reader.go] exit Reader_Close 2\n")
	}
	// Close despite the state; i.e. there might be some unread decoded data.
	fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/reader.go] enter Reader_Close 3\n")
	C.BrotliDecoderDestroyInstance(r.state)
	r.state = nil
	return nil
	// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/reader.go] exit Reader_Close 3\n")
}

func (r *Reader) Read(p []byte) (n int, err error) {
	fmt.Fprintf(io.Stderr, "\n")
	if int(C.BrotliDecoderHasMoreOutput(r.state)) == 0 && len(r.in) == 0 {
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/reader.go] enter Reader_Read 2\n")
		m, readErr := r.src.Read(r.buf)
		if m == 0 {
			fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/reader.go] enter Reader_Read 3\n")
			// If readErr is `nil`, we just proxy underlying stream behavior.
			return 0, readErr
			// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/reader.go] exit Reader_Read 3\n")
		}
		r.in = r.buf[:m]
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/reader.go] exit Reader_Read 2\n")
	}

	if len(p) == 0 {
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/reader.go] enter Reader_Read 4\n")
		return 0, nil
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/reader.go] exit Reader_Read 4\n")
	}

	for {
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/reader.go] enter Reader_Read 5\n")
		var written, consumed C.size_t
		var data *C.uint8_t
		if len(r.in) != 0 {
			fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/reader.go] enter Reader_Read 6\n")
			data = (*C.uint8_t)(&r.in[0])
			// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/reader.go] exit Reader_Read 6\n")
		}
		result := C.DecompressStream(r.state,
			(*C.uint8_t)(&p[0]), C.size_t(len(p)),
			data, C.size_t(len(r.in)),
			&written, &consumed)
		r.in = r.in[int(consumed):]
		n = int(written)

		switch result {
		case C.BROTLI_DECODER_RESULT_SUCCESS:
			fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/reader.go] enter Reader_Read 7\n")
			if len(r.in) > 0 {
				fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/reader.go] enter Reader_Read 8\n")
				return n, errExcessiveInput
				// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/reader.go] exit Reader_Read 8\n")
			}
			return n, nil
			// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/reader.go] exit Reader_Read 7\n")
		case C.BROTLI_DECODER_RESULT_ERROR:
			fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/reader.go] enter Reader_Read 9\n")
			return n, decodeError(C.BrotliDecoderGetErrorCode(r.state))
			// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/reader.go] exit Reader_Read 9\n")
		case C.BROTLI_DECODER_RESULT_NEEDS_MORE_OUTPUT:
			fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/reader.go] enter Reader_Read 10\n")
			if n == 0 {
				fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/reader.go] enter Reader_Read 11\n")
				return 0, io.ErrShortBuffer
				// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/reader.go] exit Reader_Read 11\n")
			}
			return n, nil
			// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/reader.go] exit Reader_Read 10\n")
		case C.BROTLI_DECODER_NEEDS_MORE_INPUT:
			fmt.Fprintf(io.Stderr, "\n")
			// fmt.Fprintf(io.Stderr, "\n")
		}

		if len(r.in) != 0 {
			fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/reader.go] enter Reader_Read 13\n")
			return 0, errInvalidState
			// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/reader.go] exit Reader_Read 13\n")
		}

		// Calling r.src.Read may block. Don't block if we have data to return.
		if n > 0 {
			fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/reader.go] enter Reader_Read 14\n")
			return n, nil
			// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/reader.go] exit Reader_Read 14\n")
		}

		// Top off the buffer.
		fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/reader.go] enter Reader_Read 15\n")
		encN, err := r.src.Read(r.buf)
		if encN == 0 {
			fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/reader.go] enter Reader_Read 16\n")
			// Not enough data to complete decoding.
			if err == io.EOF {
				fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/reader.go] enter Reader_Read 17\n")
				return 0, io.ErrUnexpectedEOF
				// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/reader.go] exit Reader_Read 17\n")
			}
			return 0, err
			// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/reader.go] exit Reader_Read 16\n")
		}
		r.in = r.buf[:encN]
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/reader.go] exit Reader_Read 15\n")
		// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/reader.go] exit Reader_Read 5\n")
	}

	fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/reader.go] enter Reader_Read 18\n")
	return n, nil
	// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/reader.go] exit Reader_Read 18\n")
}

// Decode decodes Brotli encoded data.
func Decode(encodedData []byte) ([]byte, error) {
	fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/reader.go] enter Decode 1\n")
	r := &Reader{
		src:   bytes.NewReader(nil),
		state: C.BrotliDecoderCreateInstance(nil, nil, nil),
		buf:   make([]byte, 4), // arbitrarily small but nonzero so that r.src.Read returns io.EOF
		in:    encodedData,
	}
	defer r.Close()
	return ioutil.ReadAll(r)
	// fmt.Fprintf(io.Stderr, "[brotli/go/cbrotli/reader.go] exit Decode 1\n")
}
// Total cost: 0.046705
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 161)]
// Total instrumented cost: 0.046705, input tokens: 2398, output tokens: 2647, cache read tokens: 2394, cache write tokens: 1672
