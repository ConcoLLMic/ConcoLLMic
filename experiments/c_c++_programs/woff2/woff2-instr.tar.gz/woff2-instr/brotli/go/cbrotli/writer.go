// Copyright 2016 Google Inc. All Rights Reserved.
//
// Distributed under MIT license.
// See file LICENSE for detail or copy at https://opensource.org/licenses/MIT

package cbrotli

/*
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include <brotli/encode.h>

struct CompressStreamResult {
  size_t bytes_consumed;
  const uint8_t* output_data;
  size_t output_data_size;
  int success;
  int has_more;
};

static struct CompressStreamResult CompressStream(
    BrotliEncoderState* s, BrotliEncoderOperation op,
    const uint8_t* data, size_t data_size) {
  struct CompressStreamResult result;
  size_t available_in = data_size;
  const uint8_t* next_in = data;
  size_t available_out = 0;
  result.success = BrotliEncoderCompressStream(s, op,
      &available_in, &next_in, &available_out, 0, 0) ? 1 : 0;
  result.bytes_consumed = data_size - available_in;
  result.output_data = 0;
  result.output_data_size = 0;
  if (result.success) {
    result.output_data = BrotliEncoderTakeOutput(s, &result.output_data_size);
  }
  result.has_more = BrotliEncoderHasMoreOutput(s) ? 1 : 0;
  return result;
}
*/
import "C"

import (
	"bytes"
	"errors"
	"fmt"
	"io"
	"os"
	"unsafe"
)

// WriterOptions configures Writer.
type WriterOptions struct {
	// Quality controls the compression-speed vs compression-density trade-offs.
	// The higher the quality, the slower the compression. Range is 0 to 11.
	Quality int
	// LGWin is the base 2 logarithm of the sliding window size.
	// Range is 10 to 24. 0 indicates automatic configuration based on Quality.
	LGWin int
}

// Writer implements io.WriteCloser by writing Brotli-encoded data to an
// underlying Writer.
type Writer struct {
	dst          io.Writer
	state        *C.BrotliEncoderState
	buf, encoded []byte
}

var (
	errEncode       = errors.New("cbrotli: encode error")
	errWriterClosed = errors.New("cbrotli: Writer is closed")
)

// NewWriter initializes new Writer instance.
// Close MUST be called to free resources.
func NewWriter(dst io.Writer, options WriterOptions) *Writer {
	fmt.Fprintf(os.Stderr, "[brotli/go/cbrotli/writer.go] enter NewWriter 1\n")
	state := C.BrotliEncoderCreateInstance(nil, nil, nil)
	C.BrotliEncoderSetParameter(
		state, C.BROTLI_PARAM_QUALITY, (C.uint32_t)(options.Quality))
	if options.LGWin > 0 {
		fmt.Fprintf(os.Stderr, "[brotli/go/cbrotli/writer.go] enter NewWriter 2\n")
		C.BrotliEncoderSetParameter(
			state, C.BROTLI_PARAM_LGWIN, (C.uint32_t)(options.LGWin))
		// fmt.Fprintf(os.Stderr, "[brotli/go/cbrotli/writer.go] exit NewWriter 2\n")
	}
	return &Writer{
		dst:   dst,
		state: state,
	}
	// fmt.Fprintf(os.Stderr, "[brotli/go/cbrotli/writer.go] exit NewWriter 1\n")
}

func (w *Writer) writeChunk(p []byte, op C.BrotliEncoderOperation) (n int, err error) {
	fmt.Fprintf(os.Stderr, "[brotli/go/cbrotli/writer.go] enter writeChunk 1\n")
	if w.state == nil {
		fmt.Fprintf(os.Stderr, "[brotli/go/cbrotli/writer.go] enter writeChunk 2\n")
		return 0, errWriterClosed
		// fmt.Fprintf(os.Stderr, "[brotli/go/cbrotli/writer.go] exit writeChunk 2\n")
	}

	for {
		fmt.Fprintf(os.Stderr, "[brotli/go/cbrotli/writer.go] enter writeChunk 3\n")
		var data *C.uint8_t
		if len(p) != 0 {
			fmt.Fprintf(os.Stderr, "[brotli/go/cbrotli/writer.go] enter writeChunk 4\n")
			data = (*C.uint8_t)(&p[0])
			// fmt.Fprintf(os.Stderr, "[brotli/go/cbrotli/writer.go] exit writeChunk 4\n")
		}
		result := C.CompressStream(w.state, op, data, C.size_t(len(p)))
		if result.success == 0 {
			fmt.Fprintf(os.Stderr, "[brotli/go/cbrotli/writer.go] enter writeChunk 5\n")
			return n, errEncode
			// fmt.Fprintf(os.Stderr, "[brotli/go/cbrotli/writer.go] exit writeChunk 5\n")
		}
		p = p[int(result.bytes_consumed):]
		n += int(result.bytes_consumed)

		length := int(result.output_data_size)
		if length != 0 {
			fmt.Fprintf(os.Stderr, "[brotli/go/cbrotli/writer.go] enter writeChunk 6\n")
			// It is a workaround for non-copying-wrapping of native memory.
			// C-encoder never pushes output block longer than ((2 << 25) + 502).
			// TODO: use natural wrapper, when it becomes available, see
			//               https://golang.org/issue/13656.
			output := (*[1 << 30]byte)(unsafe.Pointer(result.output_data))[:length:length]
			_, err = w.dst.Write(output)
			if err != nil {
				fmt.Fprintf(os.Stderr, "[brotli/go/cbrotli/writer.go] enter writeChunk 7\n")
				return n, err
				// fmt.Fprintf(os.Stderr, "[brotli/go/cbrotli/writer.go] exit writeChunk 7\n")
			}
			// fmt.Fprintf(os.Stderr, "[brotli/go/cbrotli/writer.go] exit writeChunk 6\n")
		}
		if len(p) == 0 && result.has_more == 0 {
			fmt.Fprintf(os.Stderr, "[brotli/go/cbrotli/writer.go] enter writeChunk 8\n")
			return n, nil
			// fmt.Fprintf(os.Stderr, "[brotli/go/cbrotli/writer.go] exit writeChunk 8\n")
		}
		// fmt.Fprintf(os.Stderr, "[brotli/go/cbrotli/writer.go] exit writeChunk 3\n")
	}
	// fmt.Fprintf(os.Stderr, "[brotli/go/cbrotli/writer.go] exit writeChunk 1\n")
}

// Flush outputs encoded data for all input provided to Write. The resulting
// output can be decoded to match all input before Flush, but the stream is
// not yet complete until after Close.
// Flush has a negative impact on compression.
func (w *Writer) Flush() error {
	fmt.Fprintf(os.Stderr, "[brotli/go/cbrotli/writer.go] enter Flush 1\n")
	_, err := w.writeChunk(nil, C.BROTLI_OPERATION_FLUSH)
	return err
	// fmt.Fprintf(os.Stderr, "[brotli/go/cbrotli/writer.go] exit Flush 1\n")
}

// Close flushes remaining data to the decorated writer and frees C resources.
func (w *Writer) Close() error {
	fmt.Fprintf(os.Stderr, "[brotli/go/cbrotli/writer.go] enter Close 1\n")
	// If stream is already closed, it is reported by `writeChunk`.
	_, err := w.writeChunk(nil, C.BROTLI_OPERATION_FINISH)
	// C-Brotli tolerates `nil` pointer here.
	C.BrotliEncoderDestroyInstance(w.state)
	w.state = nil
	return err
	// fmt.Fprintf(os.Stderr, "[brotli/go/cbrotli/writer.go] exit Close 1\n")
}

// Write implements io.Writer. Flush or Close must be called to ensure that the
// encoded bytes are actually flushed to the underlying Writer.
func (w *Writer) Write(p []byte) (n int, err error) {
	fmt.Fprintf(os.Stderr, "[brotli/go/cbrotli/writer.go] enter Write 1\n")
	return w.writeChunk(p, C.BROTLI_OPERATION_PROCESS)
	// fmt.Fprintf(os.Stderr, "[brotli/go/cbrotli/writer.go] exit Write 1\n")
}

// Encode returns content encoded with Brotli.
func Encode(content []byte, options WriterOptions) ([]byte, error) {
	fmt.Fprintf(os.Stderr, "[brotli/go/cbrotli/writer.go] enter Encode 1\n")
	var buf bytes.Buffer
	writer := NewWriter(&buf, options)
	_, err := writer.Write(content)
	if closeErr := writer.Close(); err == nil {
		fmt.Fprintf(os.Stderr, "[brotli/go/cbrotli/writer.go] enter Encode 2\n")
		err = closeErr
		// fmt.Fprintf(os.Stderr, "[brotli/go/cbrotli/writer.go] exit Encode 2\n")
	}
	return buf.Bytes(), err
	// fmt.Fprintf(os.Stderr, "[brotli/go/cbrotli/writer.go] exit Encode 1\n")
}
// Total cost: 0.041706
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 159)]
// Total instrumented cost: 0.041706, input tokens: 2398, output tokens: 2306, cache read tokens: 2394, cache write tokens: 1703
