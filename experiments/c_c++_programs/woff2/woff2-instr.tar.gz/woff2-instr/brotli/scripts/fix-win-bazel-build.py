import fnmatch
import os
import os.path
from shutil import copyfile
import sys

sys.stderr.write("[brotli/scripts/fix-win-bazel-build.py] enter module 1\n")
matches = []
for root, dirnames, filenames in os.walk('bazel-bin\\java\\org\\brotli'):
  sys.stderr.write("[brotli/scripts/fix-win-bazel-build.py] enter module 2\n")
  for filename in fnmatch.filter(filenames, '*.runfiles_manifest'):
    sys.stderr.write("[brotli/scripts/fix-win-bazel-build.py] enter module 3\n")
    matches.append(os.path.join(root, filename))
    # sys.stderr.write("[brotli/scripts/fix-win-bazel-build.py] exit module 3\n")
  # sys.stderr.write("[brotli/scripts/fix-win-bazel-build.py] exit module 2\n")
# sys.stderr.write("[brotli/scripts/fix-win-bazel-build.py] exit module 1\n")

sys.stderr.write("[brotli/scripts/fix-win-bazel-build.py] enter module 4\n")
for match in matches:
  sys.stderr.write("[brotli/scripts/fix-win-bazel-build.py] enter module 5\n")
  runfiles = match[:-len('_manifest')]
  with open(match) as manifest:
    sys.stderr.write("[brotli/scripts/fix-win-bazel-build.py] enter module 6\n")
    for entry in manifest:
      sys.stderr.write("[brotli/scripts/fix-win-bazel-build.py] enter module 7\n")
      entry = entry.strip()
      if not entry.startswith("org_brotli"):
        sys.stderr.write("[brotli/scripts/fix-win-bazel-build.py] enter module 8\n")
        continue
        # sys.stderr.write("[brotli/scripts/fix-win-bazel-build.py] exit module 8\n")
      # sys.stderr.write("[brotli/scripts/fix-win-bazel-build.py] exit module 7\n")
      
      sys.stderr.write("[brotli/scripts/fix-win-bazel-build.py] enter module 9\n")
      if entry.startswith('org_brotli/external'):
        sys.stderr.write("[brotli/scripts/fix-win-bazel-build.py] enter module 10\n")
        continue
        # sys.stderr.write("[brotli/scripts/fix-win-bazel-build.py] exit module 10\n")
      # sys.stderr.write("[brotli/scripts/fix-win-bazel-build.py] exit module 9\n")
      
      sys.stderr.write("[brotli/scripts/fix-win-bazel-build.py] enter module 11\n")
      (alias, space, link) = entry.partition(' ')
      if alias.endswith('.jar') or alias.endswith('.exe'):
        sys.stderr.write("[brotli/scripts/fix-win-bazel-build.py] enter module 12\n")
        continue
        # sys.stderr.write("[brotli/scripts/fix-win-bazel-build.py] exit module 12\n")
      # sys.stderr.write("[brotli/scripts/fix-win-bazel-build.py] exit module 11\n")
      
      sys.stderr.write("[brotli/scripts/fix-win-bazel-build.py] enter module 13\n")
      link = link.replace('/', '\\')
      alias = alias.replace('/', '\\')
      dst = os.path.join(runfiles, alias)
      if not os.path.exists(dst):
        sys.stderr.write("[brotli/scripts/fix-win-bazel-build.py] enter module 14\n")
        print(link + ' -> ' + dst)
        parent = os.path.dirname(dst)
        if not os.path.exists(parent):
          sys.stderr.write("[brotli/scripts/fix-win-bazel-build.py] enter module 15\n")
          os.makedirs(parent)
          # sys.stderr.write("[brotli/scripts/fix-win-bazel-build.py] exit module 15\n")
        sys.stderr.write("[brotli/scripts/fix-win-bazel-build.py] enter module 16\n")
        copyfile(link, dst)
        # sys.stderr.write("[brotli/scripts/fix-win-bazel-build.py] exit module 16\n")
        # sys.stderr.write("[brotli/scripts/fix-win-bazel-build.py] exit module 14\n")
      # sys.stderr.write("[brotli/scripts/fix-win-bazel-build.py] exit module 13\n")
    # sys.stderr.write("[brotli/scripts/fix-win-bazel-build.py] exit module 6\n")
  # sys.stderr.write("[brotli/scripts/fix-win-bazel-build.py] exit module 5\n")
# sys.stderr.write("[brotli/scripts/fix-win-bazel-build.py] exit module 4\n")
# Total cost: 0.014703
# Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 31)]
# Total instrumented cost: 0.014703, input tokens: 2398, output tokens: 832, cache read tokens: 2394, cache write tokens: 398
