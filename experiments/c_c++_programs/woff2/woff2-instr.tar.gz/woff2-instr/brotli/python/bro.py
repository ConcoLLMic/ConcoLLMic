#! /usr/bin/env python
"""Compression/decompression utility using the Brotli algorithm."""

from __future__ import print_function
import argparse
import sys
import os
import platform

import brotli

# default values of encoder parameters
DEFAULT_PARAMS = {
    'mode': brotli.MODE_GENERIC,
    'quality': 11,
    'lgwin': 22,
    'lgblock': 0,
}


def get_binary_stdio(stream):
    """ Return the specified standard input, output or errors stream as a
    'raw' buffer object suitable for reading/writing binary data from/to it.
    """
    sys.stderr.write("[brotli/python/bro.py] enter get_binary_stdio 1\n")
    assert stream in ['stdin', 'stdout', 'stderr'], 'invalid stream name'
    stdio = getattr(sys, stream)
    if sys.version_info[0] < 3:
        sys.stderr.write("[brotli/python/bro.py] enter get_binary_stdio 2\n")
        if sys.platform == 'win32':
            sys.stderr.write("[brotli/python/bro.py] enter get_binary_stdio 3\n")
            # set I/O stream binary flag on python2.x (Windows)
            runtime = platform.python_implementation()
            if runtime == 'PyPy':
                sys.stderr.write("[brotli/python/bro.py] enter get_binary_stdio 4\n")
                # the msvcrt trick doesn't work in pypy, so I use fdopen
                mode = 'rb' if stream == 'stdin' else 'wb'
                stdio = os.fdopen(stdio.fileno(), mode, 0)
                # sys.stderr.write("[brotli/python/bro.py] exit get_binary_stdio 4\n")
            else:
                sys.stderr.write("[brotli/python/bro.py] enter get_binary_stdio 5\n")
                # this works with CPython -- untested on other implementations
                import msvcrt
                msvcrt.setmode(stdio.fileno(), os.O_BINARY)
                # sys.stderr.write("[brotli/python/bro.py] exit get_binary_stdio 5\n")
            # sys.stderr.write("[brotli/python/bro.py] exit get_binary_stdio 3\n")
        return stdio
        # sys.stderr.write("[brotli/python/bro.py] exit get_binary_stdio 2\n")
    else:
        sys.stderr.write("[brotli/python/bro.py] enter get_binary_stdio 6\n")
        # get 'buffer' attribute to read/write binary data on python3.x
        if hasattr(stdio, 'buffer'):
            sys.stderr.write("[brotli/python/bro.py] enter get_binary_stdio 7\n")
            return stdio.buffer
            # sys.stderr.write("[brotli/python/bro.py] exit get_binary_stdio 7\n")
        else:
            sys.stderr.write("[brotli/python/bro.py] enter get_binary_stdio 8\n")
            orig_stdio = getattr(sys, '__%s__' % stream)
            return orig_stdio.buffer
            # sys.stderr.write("[brotli/python/bro.py] exit get_binary_stdio 8\n")
        # sys.stderr.write("[brotli/python/bro.py] exit get_binary_stdio 6\n")
    # sys.stderr.write("[brotli/python/bro.py] exit get_binary_stdio 1\n")


def main(args=None):
    sys.stderr.write("[brotli/python/bro.py] enter main 1\n")
    parser = argparse.ArgumentParser(
        prog=os.path.basename(__file__), description=__doc__)
    parser.add_argument(
        '--version', action='version', version=brotli.__version__)
    parser.add_argument(
        '-i',
        '--input',
        metavar='FILE',
        type=str,
        dest='infile',
        help='Input file',
        default=None)
    parser.add_argument(
        '-o',
        '--output',
        metavar='FILE',
        type=str,
        dest='outfile',
        help='Output file',
        default=None)
    parser.add_argument(
        '-f',
        '--force',
        action='store_true',
        help='Overwrite existing output file',
        default=False)
    parser.add_argument(
        '-d',
        '--decompress',
        action='store_true',
        help='Decompress input file',
        default=False)
    params = parser.add_argument_group('optional encoder parameters')
    params.add_argument(
        '-m',
        '--mode',
        metavar='MODE',
        type=int,
        choices=[0, 1, 2],
        help='The compression mode can be 0 for generic input, '
        '1 for UTF-8 encoded text, or 2 for WOFF 2.0 font data. '
        'Defaults to 0.')
    params.add_argument(
        '-q',
        '--quality',
        metavar='QUALITY',
        type=int,
        choices=list(range(0, 12)),
        help='Controls the compression-speed vs compression-density '
        'tradeoff. The higher the quality, the slower the '
        'compression. Range is 0 to 11. Defaults to 11.')
    params.add_argument(
        '--lgwin',
        metavar='LGWIN',
        type=int,
        choices=list(range(10, 25)),
        help='Base 2 logarithm of the sliding window size. Range is '
        '10 to 24. Defaults to 22.')
    params.add_argument(
        '--lgblock',
        metavar='LGBLOCK',
        type=int,
        choices=[0] + list(range(16, 25)),
        help='Base 2 logarithm of the maximum input block size. '
        'Range is 16 to 24. If set to 0, the value will be set based '
        'on the quality. Defaults to 0.')
    # set default values using global DEFAULT_PARAMS dictionary
    parser.set_defaults(**DEFAULT_PARAMS)

    options = parser.parse_args(args=args)

    if options.infile:
        sys.stderr.write("[brotli/python/bro.py] enter main 2\n")
        if not os.path.isfile(options.infile):
            sys.stderr.write("[brotli/python/bro.py] enter main 3\n")
            parser.error('file "%s" not found' % options.infile)
            # sys.stderr.write("[brotli/python/bro.py] exit main 3\n")
        with open(options.infile, 'rb') as infile:
            sys.stderr.write("[brotli/python/bro.py] enter main 4\n")
            data = infile.read()
            # sys.stderr.write("[brotli/python/bro.py] exit main 4\n")
        # sys.stderr.write("[brotli/python/bro.py] exit main 2\n")
    else:
        sys.stderr.write("[brotli/python/bro.py] enter main 5\n")
        if sys.stdin.isatty():
            sys.stderr.write("[brotli/python/bro.py] enter main 6\n")
            # interactive console, just quit
            parser.error('no input')
            # sys.stderr.write("[brotli/python/bro.py] exit main 6\n")
        infile = get_binary_stdio('stdin')
        data = infile.read()
        # sys.stderr.write("[brotli/python/bro.py] exit main 5\n")

    if options.outfile:
        sys.stderr.write("[brotli/python/bro.py] enter main 7\n")
        if os.path.isfile(options.outfile) and not options.force:
            sys.stderr.write("[brotli/python/bro.py] enter main 8\n")
            parser.error('output file exists')
            # sys.stderr.write("[brotli/python/bro.py] exit main 8\n")
        outfile = open(options.outfile, 'wb')
        # sys.stderr.write("[brotli/python/bro.py] exit main 7\n")
    else:
        sys.stderr.write("[brotli/python/bro.py] enter main 9\n")
        outfile = get_binary_stdio('stdout')
        # sys.stderr.write("[brotli/python/bro.py] exit main 9\n")

    try:
        sys.stderr.write("[brotli/python/bro.py] enter main 10\n")
        if options.decompress:
            sys.stderr.write("[brotli/python/bro.py] enter main 11\n")
            data = brotli.decompress(data)
            # sys.stderr.write("[brotli/python/bro.py] exit main 11\n")
        else:
            sys.stderr.write("[brotli/python/bro.py] enter main 12\n")
            data = brotli.compress(
                data,
                mode=options.mode,
                quality=options.quality,
                lgwin=options.lgwin,
                lgblock=options.lgblock)
            # sys.stderr.write("[brotli/python/bro.py] exit main 12\n")
        # sys.stderr.write("[brotli/python/bro.py] exit main 10\n")
    except brotli.error as e:
        sys.stderr.write("[brotli/python/bro.py] enter main 13\n")
        parser.exit(1,
                    'bro: error: %s: %s' % (e, options.infile or 'sys.stdin'))
        # sys.stderr.write("[brotli/python/bro.py] exit main 13\n")

    sys.stderr.write("[brotli/python/bro.py] enter main 14\n")
    outfile.write(data)
    outfile.close()
    # sys.stderr.write("[brotli/python/bro.py] exit main 14\n")
    # sys.stderr.write("[brotli/python/bro.py] exit main 1\n")


if __name__ == '__main__':
    sys.stderr.write("[brotli/python/bro.py] enter module 1\n")
    main()
    # sys.stderr.write("[brotli/python/bro.py] exit module 1\n")
# Total cost: 0.040551
# Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 160)]
# Total instrumented cost: 0.040551, input tokens: 2398, output tokens: 2267, cache read tokens: 2394, cache write tokens: 1551
