# Copyright 2016 The Brotli Authors. All rights reserved.
#
# Distributed under MIT license.
# See file LICENSE for detail or copy at https://opensource.org/licenses/MIT

import functools
import unittest
import sys

from . import _test_utils
import brotli


# Do not inherit from TestCase here to ensure that test methods
# are not run automatically and instead are run as part of a specific
# configuration below.
class _TestCompressor(object):

    CHUNK_SIZE = 2048

    def _check_decompression(self, test_data):
        sys.stderr.write("[brotli/python/tests/compressor_test.py] enter _check_decompression 1\n")
        # Write decompression to temp file and verify it matches the original.
        temp_uncompressed = _test_utils.get_temp_uncompressed_name(test_data)
        temp_compressed = _test_utils.get_temp_compressed_name(test_data)
        original = test_data
        with open(temp_uncompressed, 'wb') as out_file:
            with open(temp_compressed, 'rb') as in_file:
                out_file.write(brotli.decompress(in_file.read()))
        self.assertFilesMatch(temp_uncompressed, original)
        # sys.stderr.write("[brotli/python/tests/compressor_test.py] exit _check_decompression 1\n")

    def _test_single_process(self, test_data):
        sys.stderr.write("[brotli/python/tests/compressor_test.py] enter _test_single_process 1\n")
        # Write single-shot compression to temp file.
        temp_compressed = _test_utils.get_temp_compressed_name(test_data)
        with open(temp_compressed, 'wb') as out_file:
            with open(test_data, 'rb') as in_file:
                out_file.write(self.compressor.process(in_file.read()))
            out_file.write(self.compressor.finish())
        self._check_decompression(test_data)
        # sys.stderr.write("[brotli/python/tests/compressor_test.py] exit _test_single_process 1\n")

    def _test_multiple_process(self, test_data):
        sys.stderr.write("[brotli/python/tests/compressor_test.py] enter _test_multiple_process 1\n")
        # Write chunked compression to temp file.
        temp_compressed = _test_utils.get_temp_compressed_name(test_data)
        with open(temp_compressed, 'wb') as out_file:
            with open(test_data, 'rb') as in_file:
                read_chunk = functools.partial(in_file.read, self.CHUNK_SIZE)
                for data in iter(read_chunk, b''):
                    sys.stderr.write("[brotli/python/tests/compressor_test.py] enter _test_multiple_process 2\n")
                    out_file.write(self.compressor.process(data))
                    # sys.stderr.write("[brotli/python/tests/compressor_test.py] exit _test_multiple_process 2\n")
            out_file.write(self.compressor.finish())
        self._check_decompression(test_data)
        # sys.stderr.write("[brotli/python/tests/compressor_test.py] exit _test_multiple_process 1\n")

    def _test_multiple_process_and_flush(self, test_data):
        sys.stderr.write("[brotli/python/tests/compressor_test.py] enter _test_multiple_process_and_flush 1\n")
        # Write chunked and flushed compression to temp file.
        temp_compressed = _test_utils.get_temp_compressed_name(test_data)
        with open(temp_compressed, 'wb') as out_file:
            with open(test_data, 'rb') as in_file:
                read_chunk = functools.partial(in_file.read, self.CHUNK_SIZE)
                for data in iter(read_chunk, b''):
                    sys.stderr.write("[brotli/python/tests/compressor_test.py] enter _test_multiple_process_and_flush 2\n")
                    out_file.write(self.compressor.process(data))
                    out_file.write(self.compressor.flush())
                    # sys.stderr.write("[brotli/python/tests/compressor_test.py] exit _test_multiple_process_and_flush 2\n")
            out_file.write(self.compressor.finish())
        self._check_decompression(test_data)
        # sys.stderr.write("[brotli/python/tests/compressor_test.py] exit _test_multiple_process_and_flush 1\n")


_test_utils.generate_test_methods(_TestCompressor)


class TestCompressorQuality1(_TestCompressor, _test_utils.TestCase):

    def setUp(self):
        sys.stderr.write("[brotli/python/tests/compressor_test.py] enter TestCompressorQuality1.setUp 1\n")
        self.compressor = brotli.Compressor(quality=1)
        # sys.stderr.write("[brotli/python/tests/compressor_test.py] exit TestCompressorQuality1.setUp 1\n")


class TestCompressorQuality6(_TestCompressor, _test_utils.TestCase):

    def setUp(self):
        sys.stderr.write("[brotli/python/tests/compressor_test.py] enter TestCompressorQuality6.setUp 1\n")
        self.compressor = brotli.Compressor(quality=6)
        # sys.stderr.write("[brotli/python/tests/compressor_test.py] exit TestCompressorQuality6.setUp 1\n")


class TestCompressorQuality9(_TestCompressor, _test_utils.TestCase):

    def setUp(self):
        sys.stderr.write("[brotli/python/tests/compressor_test.py] enter TestCompressorQuality9.setUp 1\n")
        self.compressor = brotli.Compressor(quality=9)
        # sys.stderr.write("[brotli/python/tests/compressor_test.py] exit TestCompressorQuality9.setUp 1\n")


class TestCompressorQuality11(_TestCompressor, _test_utils.TestCase):

    def setUp(self):
        sys.stderr.write("[brotli/python/tests/compressor_test.py] enter TestCompressorQuality11.setUp 1\n")
        self.compressor = brotli.Compressor(quality=11)
        # sys.stderr.write("[brotli/python/tests/compressor_test.py] exit TestCompressorQuality11.setUp 1\n")


if __name__ == '__main__':
    sys.stderr.write("[brotli/python/tests/compressor_test.py] enter module 1\n")
    unittest.main()
    # sys.stderr.write("[brotli/python/tests/compressor_test.py] exit module 1\n")
# Total cost: 0.027681
# Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 91)]
# Total instrumented cost: 0.027681, input tokens: 2398, output tokens: 1522, cache read tokens: 2394, cache write tokens: 1099
