# Copyright 2016 The Brotli Authors. All rights reserved.
#
# Distributed under MIT license.
# See file LICENSE for detail or copy at https://opensource.org/licenses/MIT

import unittest
import sys

from . import _test_utils
import brotli


def _get_original_name(test_data):
    sys.stderr.write("[brotli/python/tests/decompress_test.py] enter _get_original_name 1\n")
    return test_data.split('.compressed')[0]
    # sys.stderr.write("[brotli/python/tests/decompress_test.py] exit _get_original_name 1\n")


class TestDecompress(_test_utils.TestCase):

    def _check_decompression(self, test_data):
        sys.stderr.write("[brotli/python/tests/decompress_test.py] enter _check_decompression 1\n")
        # Verify decompression matches the original.
        temp_uncompressed = _test_utils.get_temp_uncompressed_name(test_data)
        original = _get_original_name(test_data)
        self.assertFilesMatch(temp_uncompressed, original)
        # sys.stderr.write("[brotli/python/tests/decompress_test.py] exit _check_decompression 1\n")

    def _decompress(self, test_data):
        sys.stderr.write("[brotli/python/tests/decompress_test.py] enter _decompress 1\n")
        temp_uncompressed = _test_utils.get_temp_uncompressed_name(test_data)
        with open(temp_uncompressed, 'wb') as out_file:
            sys.stderr.write("[brotli/python/tests/decompress_test.py] enter _decompress 2\n")
            with open(test_data, 'rb') as in_file:
                sys.stderr.write("[brotli/python/tests/decompress_test.py] enter _decompress 3\n")
                out_file.write(brotli.decompress(in_file.read()))
                # sys.stderr.write("[brotli/python/tests/decompress_test.py] exit _decompress 3\n")
            # sys.stderr.write("[brotli/python/tests/decompress_test.py] exit _decompress 2\n")
        # sys.stderr.write("[brotli/python/tests/decompress_test.py] exit _decompress 1\n")

    def _test_decompress(self, test_data):
        sys.stderr.write("[brotli/python/tests/decompress_test.py] enter _test_decompress 1\n")
        self._decompress(test_data)
        self._check_decompression(test_data)
        # sys.stderr.write("[brotli/python/tests/decompress_test.py] exit _test_decompress 1\n")


_test_utils.generate_test_methods(TestDecompress, for_decompression=True)

if __name__ == '__main__':
    sys.stderr.write("[brotli/python/tests/decompress_test.py] enter module 1\n")
    unittest.main()
    # sys.stderr.write("[brotli/python/tests/decompress_test.py] exit module 1\n")
# Total cost: 0.012205
# Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 38)]
# Total instrumented cost: 0.012205, input tokens: 2398, output tokens: 651, cache read tokens: 2394, cache write tokens: 456
