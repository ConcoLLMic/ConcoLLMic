from __future__ import print_function
import filecmp
import glob
import itertools
import os
import sys
import sysconfig
import tempfile
import unittest


sys.stderr.write("[brotli/python/tests/_test_utils.py] enter module 1\n")
project_dir = os.path.abspath(os.path.join(__file__, '..', '..', '..'))
src_dir = os.path.join(project_dir, 'python')
test_dir = os.path.join(project_dir, 'tests')

python_exe = sys.executable or 'python'
bro_path = os.path.join(src_dir, 'bro.py')
BRO_ARGS = [python_exe, bro_path]

# Get the platform/version-specific build folder.
# By default, the distutils build base is in the same location as setup.py.
platform_lib_name = 'lib.{platform}-{version[0]}.{version[1]}'.format(
    platform=sysconfig.get_platform(), version=sys.version_info)
build_dir = os.path.join(project_dir, 'bin', platform_lib_name)

# Prepend the build folder to sys.path and the PYTHONPATH environment variable.
if build_dir not in sys.path:
    sys.stderr.write("[brotli/python/tests/_test_utils.py] enter module 2\n")
    sys.path.insert(0, build_dir)
    # sys.stderr.write("[brotli/python/tests/_test_utils.py] exit module 2\n")

TEST_ENV = os.environ.copy()
if 'PYTHONPATH' not in TEST_ENV:
    sys.stderr.write("[brotli/python/tests/_test_utils.py] enter module 3\n")
    TEST_ENV['PYTHONPATH'] = build_dir
    # sys.stderr.write("[brotli/python/tests/_test_utils.py] exit module 3\n")
else:
    sys.stderr.write("[brotli/python/tests/_test_utils.py] enter module 4\n")
    TEST_ENV['PYTHONPATH'] = build_dir + os.pathsep + TEST_ENV['PYTHONPATH']
    # sys.stderr.write("[brotli/python/tests/_test_utils.py] exit module 4\n")

TESTDATA_DIR = os.path.join(test_dir, 'testdata')

TESTDATA_FILES = [
    'empty',  # Empty file
    '10x10y',  # Small text
    'alice29.txt',  # Large text
    'random_org_10k.bin',  # Small data
    'mapsdatazrh',  # Large data
]

TESTDATA_PATHS = [os.path.join(TESTDATA_DIR, f) for f in TESTDATA_FILES]

TESTDATA_PATHS_FOR_DECOMPRESSION = glob.glob(
    os.path.join(TESTDATA_DIR, '*.compressed'))

TEMP_DIR = tempfile.mkdtemp()
# sys.stderr.write("[brotli/python/tests/_test_utils.py] exit module 1\n")


def get_temp_compressed_name(filename):
    sys.stderr.write("[brotli/python/tests/_test_utils.py] enter get_temp_compressed_name 1\n")
    return os.path.join(TEMP_DIR, os.path.basename(filename + '.bro'))
    # sys.stderr.write("[brotli/python/tests/_test_utils.py] exit get_temp_compressed_name 1\n")


def get_temp_uncompressed_name(filename):
    sys.stderr.write("[brotli/python/tests/_test_utils.py] enter get_temp_uncompressed_name 1\n")
    return os.path.join(TEMP_DIR, os.path.basename(filename + '.unbro'))
    # sys.stderr.write("[brotli/python/tests/_test_utils.py] exit get_temp_uncompressed_name 1\n")


def bind_method_args(method, *args, **kwargs):
    sys.stderr.write("[brotli/python/tests/_test_utils.py] enter bind_method_args 1\n")
    return lambda self: method(self, *args, **kwargs)
    # sys.stderr.write("[brotli/python/tests/_test_utils.py] exit bind_method_args 1\n")


def generate_test_methods(test_case_class,
                          for_decompression=False,
                          variants=None):
    sys.stderr.write("[brotli/python/tests/_test_utils.py] enter generate_test_methods 1\n")
    # Add test methods for each test data file.  This makes identifying problems
    # with specific compression scenarios easier.
    if for_decompression:
        sys.stderr.write("[brotli/python/tests/_test_utils.py] enter generate_test_methods 2\n")
        paths = TESTDATA_PATHS_FOR_DECOMPRESSION
        # sys.stderr.write("[brotli/python/tests/_test_utils.py] exit generate_test_methods 2\n")
    else:
        sys.stderr.write("[brotli/python/tests/_test_utils.py] enter generate_test_methods 3\n")
        paths = TESTDATA_PATHS
        # sys.stderr.write("[brotli/python/tests/_test_utils.py] exit generate_test_methods 3\n")
    opts = []
    if variants:
        sys.stderr.write("[brotli/python/tests/_test_utils.py] enter generate_test_methods 4\n")
        opts_list = []
        for k, v in variants.items():
            sys.stderr.write("[brotli/python/tests/_test_utils.py] enter generate_test_methods 5\n")
            opts_list.append([r for r in itertools.product([k], v)])
            # sys.stderr.write("[brotli/python/tests/_test_utils.py] exit generate_test_methods 5\n")
        for o in itertools.product(*opts_list):
            sys.stderr.write("[brotli/python/tests/_test_utils.py] enter generate_test_methods 6\n")
            opts_name = '_'.join([str(i) for i in itertools.chain(*o)])
            opts_dict = dict(o)
            opts.append([opts_name, opts_dict])
            # sys.stderr.write("[brotli/python/tests/_test_utils.py] exit generate_test_methods 6\n")
        # sys.stderr.write("[brotli/python/tests/_test_utils.py] exit generate_test_methods 4\n")
    else:
        sys.stderr.write("[brotli/python/tests/_test_utils.py] enter generate_test_methods 7\n")
        opts.append(['', {}])
        # sys.stderr.write("[brotli/python/tests/_test_utils.py] exit generate_test_methods 7\n")
    for method in [m for m in dir(test_case_class) if m.startswith('_test')]:
        sys.stderr.write("[brotli/python/tests/_test_utils.py] enter generate_test_methods 8\n")
        for testdata in paths:
            sys.stderr.write("[brotli/python/tests/_test_utils.py] enter generate_test_methods 9\n")
            for (opts_name, opts_dict) in opts:
                sys.stderr.write("[brotli/python/tests/_test_utils.py] enter generate_test_methods 10\n")
                f = os.path.splitext(os.path.basename(testdata))[0]
                name = 'test_{method}_{options}_{file}'.format(
                    method=method, options=opts_name, file=f)
                func = bind_method_args(
                    getattr(test_case_class, method), testdata, **opts_dict)
                setattr(test_case_class, name, func)
                # sys.stderr.write("[brotli/python/tests/_test_utils.py] exit generate_test_methods 10\n")
            # sys.stderr.write("[brotli/python/tests/_test_utils.py] exit generate_test_methods 9\n")
        # sys.stderr.write("[brotli/python/tests/_test_utils.py] exit generate_test_methods 8\n")
    # sys.stderr.write("[brotli/python/tests/_test_utils.py] exit generate_test_methods 1\n")


class TestCase(unittest.TestCase):

    def tearDown(self):
        sys.stderr.write("[brotli/python/tests/_test_utils.py] enter tearDown 1\n")
        for f in TESTDATA_PATHS:
            sys.stderr.write("[brotli/python/tests/_test_utils.py] enter tearDown 2\n")
            try:
                sys.stderr.write("[brotli/python/tests/_test_utils.py] enter tearDown 3\n")
                os.unlink(get_temp_compressed_name(f))
                # sys.stderr.write("[brotli/python/tests/_test_utils.py] exit tearDown 3\n")
            except OSError:
                sys.stderr.write("[brotli/python/tests/_test_utils.py] enter tearDown 4\n")
                pass
                # sys.stderr.write("[brotli/python/tests/_test_utils.py] exit tearDown 4\n")
            try:
                sys.stderr.write("[brotli/python/tests/_test_utils.py] enter tearDown 5\n")
                os.unlink(get_temp_uncompressed_name(f))
                # sys.stderr.write("[brotli/python/tests/_test_utils.py] exit tearDown 5\n")
            except OSError:
                sys.stderr.write("[brotli/python/tests/_test_utils.py] enter tearDown 6\n")
                pass
                # sys.stderr.write("[brotli/python/tests/_test_utils.py] exit tearDown 6\n")
            # sys.stderr.write("[brotli/python/tests/_test_utils.py] exit tearDown 2\n")
        # sys.stderr.write("[brotli/python/tests/_test_utils.py] exit tearDown 1\n")

    def assertFilesMatch(self, first, second):
        sys.stderr.write("[brotli/python/tests/_test_utils.py] enter assertFilesMatch 1\n")
        self.assertTrue(
            filecmp.cmp(first, second, shallow=False),
            'File {} differs from {}'.format(first, second))
        # sys.stderr.write("[brotli/python/tests/_test_utils.py] exit assertFilesMatch 1\n")
# Total cost: 0.036929
# Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 112)]
# Total instrumented cost: 0.036929, input tokens: 2398, output tokens: 2093, cache read tokens: 2394, cache write tokens: 1281
