# Copyright 2016 The Brotli Authors. All rights reserved.
#
# Distributed under MIT license.
# See file LICENSE for detail or copy at https://opensource.org/licenses/MIT

import subprocess
import unittest
import sys

from . import _test_utils
import brotli

BRO_ARGS = _test_utils.BRO_ARGS
TEST_ENV = _test_utils.TEST_ENV


def _get_original_name(test_data):
    sys.stderr.write("[brotli/python/tests/bro_test.py] enter _get_original_name 1\n")
    return test_data.split('.compressed')[0]
    # sys.stderr.write("[brotli/python/tests/bro_test.py] exit _get_original_name 1\n")


class TestBroDecompress(_test_utils.TestCase):

    def _check_decompression(self, test_data):
        sys.stderr.write("[brotli/python/tests/bro_test.py] enter _check_decompression 1\n")
        # Verify decompression matches the original.
        temp_uncompressed = _test_utils.get_temp_uncompressed_name(test_data)
        original = _get_original_name(test_data)
        self.assertFilesMatch(temp_uncompressed, original)
        # sys.stderr.write("[brotli/python/tests/bro_test.py] exit _check_decompression 1\n")

    def _decompress_file(self, test_data):
        sys.stderr.write("[brotli/python/tests/bro_test.py] enter _decompress_file 1\n")
        temp_uncompressed = _test_utils.get_temp_uncompressed_name(test_data)
        args = BRO_ARGS + ['-f', '-d', '-i', test_data, '-o', temp_uncompressed]
        subprocess.check_call(args, env=TEST_ENV)
        # sys.stderr.write("[brotli/python/tests/bro_test.py] exit _decompress_file 1\n")

    def _decompress_pipe(self, test_data):
        sys.stderr.write("[brotli/python/tests/bro_test.py] enter _decompress_pipe 1\n")
        temp_uncompressed = _test_utils.get_temp_uncompressed_name(test_data)
        args = BRO_ARGS + ['-d']
        with open(temp_uncompressed, 'wb') as out_file:
            sys.stderr.write("[brotli/python/tests/bro_test.py] enter _decompress_pipe 2\n")
            with open(test_data, 'rb') as in_file:
                sys.stderr.write("[brotli/python/tests/bro_test.py] enter _decompress_pipe 3\n")
                subprocess.check_call(
                    args, stdin=in_file, stdout=out_file, env=TEST_ENV)
                # sys.stderr.write("[brotli/python/tests/bro_test.py] exit _decompress_pipe 3\n")
            # sys.stderr.write("[brotli/python/tests/bro_test.py] exit _decompress_pipe 2\n")
        # sys.stderr.write("[brotli/python/tests/bro_test.py] exit _decompress_pipe 1\n")

    def _test_decompress_file(self, test_data):
        sys.stderr.write("[brotli/python/tests/bro_test.py] enter _test_decompress_file 1\n")
        self._decompress_file(test_data)
        self._check_decompression(test_data)
        # sys.stderr.write("[brotli/python/tests/bro_test.py] exit _test_decompress_file 1\n")

    def _test_decompress_pipe(self, test_data):
        sys.stderr.write("[brotli/python/tests/bro_test.py] enter _test_decompress_pipe 1\n")
        self._decompress_pipe(test_data)
        self._check_decompression(test_data)
        # sys.stderr.write("[brotli/python/tests/bro_test.py] exit _test_decompress_pipe 1\n")


_test_utils.generate_test_methods(TestBroDecompress, for_decompression=True)


class TestBroCompress(_test_utils.TestCase):

    VARIANTS = {'quality': (1, 6, 9, 11), 'lgwin': (10, 15, 20, 24)}

    def _check_decompression(self, test_data, **kwargs):
        sys.stderr.write("[brotli/python/tests/bro_test.py] enter _check_decompression 1208\n")
        # Write decompression to temp file and verify it matches the original.
        temp_uncompressed = _test_utils.get_temp_uncompressed_name(test_data)
        temp_compressed = _test_utils.get_temp_compressed_name(test_data)
        original = test_data
        args = BRO_ARGS + ['-f', '-d']
        args.extend(['-i', temp_compressed, '-o', temp_uncompressed])
        subprocess.check_call(args, env=TEST_ENV)
        self.assertFilesMatch(temp_uncompressed, original)
        # sys.stderr.write("[brotli/python/tests/bro_test.py] exit _check_decompression 1208\n")

    def _compress_file(self, test_data, **kwargs):
        sys.stderr.write("[brotli/python/tests/bro_test.py] enter _compress_file 1\n")
        temp_compressed = _test_utils.get_temp_compressed_name(test_data)
        args = BRO_ARGS + ['-f']
        if 'quality' in kwargs:
            sys.stderr.write("[brotli/python/tests/bro_test.py] enter _compress_file 2\n")
            args.extend(['-q', str(kwargs['quality'])])
            # sys.stderr.write("[brotli/python/tests/bro_test.py] exit _compress_file 2\n")
        if 'lgwin' in kwargs:
            sys.stderr.write("[brotli/python/tests/bro_test.py] enter _compress_file 3\n")
            args.extend(['--lgwin', str(kwargs['lgwin'])])
            # sys.stderr.write("[brotli/python/tests/bro_test.py] exit _compress_file 3\n")
        args.extend(['-i', test_data, '-o', temp_compressed])
        subprocess.check_call(args, env=TEST_ENV)
        # sys.stderr.write("[brotli/python/tests/bro_test.py] exit _compress_file 1\n")

    def _compress_pipe(self, test_data, **kwargs):
        sys.stderr.write("[brotli/python/tests/bro_test.py] enter _compress_pipe 1\n")
        temp_compressed = _test_utils.get_temp_compressed_name(test_data)
        args = BRO_ARGS
        if 'quality' in kwargs:
            sys.stderr.write("[brotli/python/tests/bro_test.py] enter _compress_pipe 2\n")
            args.extend(['-q', str(kwargs['quality'])])
            # sys.stderr.write("[brotli/python/tests/bro_test.py] exit _compress_pipe 2\n")
        if 'lgwin' in kwargs:
            sys.stderr.write("[brotli/python/tests/bro_test.py] enter _compress_pipe 3\n")
            args.extend(['--lgwin', str(kwargs['lgwin'])])
            # sys.stderr.write("[brotli/python/tests/bro_test.py] exit _compress_pipe 3\n")
        with open(temp_compressed, 'wb') as out_file:
            sys.stderr.write("[brotli/python/tests/bro_test.py] enter _compress_pipe 4\n")
            with open(test_data, 'rb') as in_file:
                sys.stderr.write("[brotli/python/tests/bro_test.py] enter _compress_pipe 5\n")
                subprocess.check_call(
                    args, stdin=in_file, stdout=out_file, env=TEST_ENV)
                # sys.stderr.write("[brotli/python/tests/bro_test.py] exit _compress_pipe 5\n")
            # sys.stderr.write("[brotli/python/tests/bro_test.py] exit _compress_pipe 4\n")
        # sys.stderr.write("[brotli/python/tests/bro_test.py] exit _compress_pipe 1\n")

    def _test_compress_file(self, test_data, **kwargs):
        sys.stderr.write("[brotli/python/tests/bro_test.py] enter _test_compress_file 1\n")
        self._compress_file(test_data, **kwargs)
        self._check_decompression(test_data)
        # sys.stderr.write("[brotli/python/tests/bro_test.py] exit _test_compress_file 1\n")

    def _test_compress_pipe(self, test_data, **kwargs):
        sys.stderr.write("[brotli/python/tests/bro_test.py] enter _test_compress_pipe 1\n")
        self._compress_pipe(test_data, **kwargs)
        self._check_decompression(test_data)
        # sys.stderr.write("[brotli/python/tests/bro_test.py] exit _test_compress_pipe 1\n")


_test_utils.generate_test_methods(
    TestBroCompress, variants=TestBroCompress.VARIANTS)

if __name__ == '__main__':
    sys.stderr.write("[brotli/python/tests/bro_test.py] enter module 1\n")
    unittest.main()
    # sys.stderr.write("[brotli/python/tests/bro_test.py] exit module 1\n")
# Total cost: 0.036254
# Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 102)]
# Total instrumented cost: 0.036254, input tokens: 2398, output tokens: 2037, cache read tokens: 2394, cache write tokens: 1325
