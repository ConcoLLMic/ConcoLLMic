# Copyright 2016 The Brotli Authors. All rights reserved.
#
# Distributed under MIT license.
# See file LICENSE for detail or copy at https://opensource.org/licenses/MIT

import unittest
import sys

from . import _test_utils
import brotli


class TestCompress(_test_utils.TestCase):

    VARIANTS = {'quality': (1, 6, 9, 11), 'lgwin': (10, 15, 20, 24)}

    def _check_decompression(self, test_data, **kwargs):
        sys.stderr.write("[brotli/python/tests/compress_test.py] enter _check_decompression 1\n")
        kwargs = {}
        # Write decompression to temp file and verify it matches the original.
        temp_uncompressed = _test_utils.get_temp_uncompressed_name(test_data)
        temp_compressed = _test_utils.get_temp_compressed_name(test_data)
        original = test_data
        with open(temp_uncompressed, 'wb') as out_file:
            sys.stderr.write("[brotli/python/tests/compress_test.py] enter _check_decompression 2\n")
            with open(temp_compressed, 'rb') as in_file:
                sys.stderr.write("[brotli/python/tests/compress_test.py] enter _check_decompression 3\n")
                out_file.write(brotli.decompress(in_file.read(), **kwargs))
                # sys.stderr.write("[brotli/python/tests/compress_test.py] exit _check_decompression 3\n")
            # sys.stderr.write("[brotli/python/tests/compress_test.py] exit _check_decompression 2\n")
        self.assertFilesMatch(temp_uncompressed, original)
        # sys.stderr.write("[brotli/python/tests/compress_test.py] exit _check_decompression 1\n")

    def _compress(self, test_data, **kwargs):
        sys.stderr.write("[brotli/python/tests/compress_test.py] enter _compress 1\n")
        temp_compressed = _test_utils.get_temp_compressed_name(test_data)
        with open(temp_compressed, 'wb') as out_file:
            sys.stderr.write("[brotli/python/tests/compress_test.py] enter _compress 2\n")
            with open(test_data, 'rb') as in_file:
                sys.stderr.write("[brotli/python/tests/compress_test.py] enter _compress 3\n")
                out_file.write(brotli.compress(in_file.read(), **kwargs))
                # sys.stderr.write("[brotli/python/tests/compress_test.py] exit _compress 3\n")
            # sys.stderr.write("[brotli/python/tests/compress_test.py] exit _compress 2\n")
        # sys.stderr.write("[brotli/python/tests/compress_test.py] exit _compress 1\n")

    def _test_compress(self, test_data, **kwargs):
        sys.stderr.write("[brotli/python/tests/compress_test.py] enter _test_compress 1\n")
        self._compress(test_data, **kwargs)
        self._check_decompression(test_data, **kwargs)
        # sys.stderr.write("[brotli/python/tests/compress_test.py] exit _test_compress 1\n")


_test_utils.generate_test_methods(TestCompress, variants=TestCompress.VARIANTS)

if __name__ == '__main__':
    sys.stderr.write("[brotli/python/tests/compress_test.py] enter module 1\n")
    unittest.main()
    # sys.stderr.write("[brotli/python/tests/compress_test.py] exit module 1\n")
# Total cost: 0.014665
# Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 41)]
# Total instrumented cost: 0.014665, input tokens: 2398, output tokens: 789, cache read tokens: 2394, cache write tokens: 560
