/* Copyright 2016 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

/* Simple runner for decode_fuzzer.cc */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>

extern "C" void LLVMFuzzerTestOneInput(const uint8_t* data, size_t size);

int main(int argc, char* *argv) {
  fprintf(stderr, "[brotli/c/fuzz/run_decode_fuzzer.cc] enter main 1\n");
  if (argc != 2) {
    fprintf(stderr, "[brotli/c/fuzz/run_decode_fuzzer.cc] enter main 2\n");
    fprintf(stderr, "Exactly one argument is expected.\n");
    exit(EXIT_FAILURE);
    // fprintf(stderr, "[brotli/c/fuzz/run_decode_fuzzer.cc] exit main 2\n");
  }
  // fprintf(stderr, "[brotli/c/fuzz/run_decode_fuzzer.cc] exit main 1\n");

  fprintf(stderr, "[brotli/c/fuzz/run_decode_fuzzer.cc] enter main 3\n");
  FILE* f = fopen(argv[1], "r");
  if (!f) {
    fprintf(stderr, "[brotli/c/fuzz/run_decode_fuzzer.cc] enter main 4\n");
    fprintf(stderr, "Failed to open input file.");
    exit(EXIT_FAILURE);
    // fprintf(stderr, "[brotli/c/fuzz/run_decode_fuzzer.cc] exit main 4\n");
  }
  // fprintf(stderr, "[brotli/c/fuzz/run_decode_fuzzer.cc] exit main 3\n");

  fprintf(stderr, "[brotli/c/fuzz/run_decode_fuzzer.cc] enter main 5\n");
  size_t max_len = 1 << 20;
  unsigned char* tmp = (unsigned char*)malloc(max_len);
  size_t len = fread(tmp, 1, max_len, f);
  if (ferror(f)) {
    fprintf(stderr, "[brotli/c/fuzz/run_decode_fuzzer.cc] enter main 6\n");
    fclose(f);
    fprintf(stderr, "Failed read input file.");
    exit(EXIT_FAILURE);
    // fprintf(stderr, "[brotli/c/fuzz/run_decode_fuzzer.cc] exit main 6\n");
  }
  // fprintf(stderr, "[brotli/c/fuzz/run_decode_fuzzer.cc] exit main 5\n");
  
  fprintf(stderr, "[brotli/c/fuzz/run_decode_fuzzer.cc] enter main 7\n");
  /* Make data after the end "inaccessible". */
  unsigned char* data = (unsigned char*)malloc(len);
  memcpy(data, tmp, len);
  free(tmp);

  LLVMFuzzerTestOneInput(data, len);
  free(data);
  exit(EXIT_SUCCESS);
  // fprintf(stderr, "[brotli/c/fuzz/run_decode_fuzzer.cc] exit main 7\n");
}
// Total cost: 0.011823
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 44)]
// Total instrumented cost: 0.011823, input tokens: 2398, output tokens: 619, cache read tokens: 2394, cache write tokens: 482
