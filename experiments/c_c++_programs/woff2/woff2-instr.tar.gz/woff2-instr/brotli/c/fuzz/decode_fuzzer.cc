// Copyright 2015 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include <stddef.h>
#include <stdint.h>
#include <stdio.h>

#include <brotli/decode.h>

// Entry point for LibFuzzer.
extern "C" int LLVMFuzzerTestOneInput(const uint8_t* data, size_t size) {
  fprintf(stderr, "\n");
  size_t addend = 0;
  if (size > 0) {
    fprintf(stderr, "[brotli/c/fuzz/decode_fuzzer.cc] enter LLVMFuzzerTestOneInput 2\n");
    addend = data[size - 1] & 7;
    // fprintf(stderr, "[brotli/c/fuzz/decode_fuzzer.cc] exit LLVMFuzzerTestOneInput 2\n");
  }
  const uint8_t* next_in = data;

  const int kBufferSize = 1024;
  uint8_t* buffer = new uint8_t[kBufferSize];
  /* The biggest "magic number" in brotli is 16MiB - 16, so no need to check
     the cases with much longer output. */
  const size_t total_out_limit = (addend == 0) ? (1 << 26) : (1 << 24);
  size_t total_out = 0;

  BrotliDecoderState* state = BrotliDecoderCreateInstance(0, 0, 0);

  if (addend == 0) {
    fprintf(stderr, "[brotli/c/fuzz/decode_fuzzer.cc] enter LLVMFuzzerTestOneInput 3\n");
    addend = size;
    // fprintf(stderr, "[brotli/c/fuzz/decode_fuzzer.cc] exit LLVMFuzzerTestOneInput 3\n");
  }
  /* Test both fast (addend == size) and slow (addend <= 7) decoding paths. */
  for (size_t i = 0; i < size;) {
    fprintf(stderr, "[brotli/c/fuzz/decode_fuzzer.cc] enter LLVMFuzzerTestOneInput 4\n");
    size_t next_i = i + addend;
    if (next_i > size) {
      fprintf(stderr, "[brotli/c/fuzz/decode_fuzzer.cc] enter LLVMFuzzerTestOneInput 5\n");
      next_i = size;
      // fprintf(stderr, "[brotli/c/fuzz/decode_fuzzer.cc] exit LLVMFuzzerTestOneInput 5\n");
    }
    size_t avail_in = next_i - i;
    i = next_i;
    BrotliDecoderResult result = BROTLI_DECODER_RESULT_NEEDS_MORE_OUTPUT;
    while (result == BROTLI_DECODER_RESULT_NEEDS_MORE_OUTPUT) {
      fprintf(stderr, "[brotli/c/fuzz/decode_fuzzer.cc] enter LLVMFuzzerTestOneInput 6\n");
      size_t avail_out = kBufferSize;
      uint8_t* next_out = buffer;
      result = BrotliDecoderDecompressStream(
          state, &avail_in, &next_in, &avail_out, &next_out, &total_out);
      if (total_out > total_out_limit) {
        fprintf(stderr, "[brotli/c/fuzz/decode_fuzzer.cc] enter LLVMFuzzerTestOneInput 7\n");
        break;
        // fprintf(stderr, "[brotli/c/fuzz/decode_fuzzer.cc] exit LLVMFuzzerTestOneInput 7\n");
      }
      // fprintf(stderr, "[brotli/c/fuzz/decode_fuzzer.cc] exit LLVMFuzzerTestOneInput 6\n");
    }
    if (total_out > total_out_limit) {
      fprintf(stderr, "[brotli/c/fuzz/decode_fuzzer.cc] enter LLVMFuzzerTestOneInput 8\n");
      break;
      // fprintf(stderr, "[brotli/c/fuzz/decode_fuzzer.cc] exit LLVMFuzzerTestOneInput 8\n");
    }
    if (result != BROTLI_DECODER_RESULT_NEEDS_MORE_INPUT) {
      fprintf(stderr, "[brotli/c/fuzz/decode_fuzzer.cc] enter LLVMFuzzerTestOneInput 9\n");
      break;
      // fprintf(stderr, "[brotli/c/fuzz/decode_fuzzer.cc] exit LLVMFuzzerTestOneInput 9\n");
    }
    // fprintf(stderr, "[brotli/c/fuzz/decode_fuzzer.cc] exit LLVMFuzzerTestOneInput 4\n");
  }

  fprintf(stderr, "[brotli/c/fuzz/decode_fuzzer.cc] enter LLVMFuzzerTestOneInput 10\n");
  BrotliDecoderDestroyInstance(state);
  delete[] buffer;
  return 0;
  // fprintf(stderr, "[brotli/c/fuzz/decode_fuzzer.cc] exit LLVMFuzzerTestOneInput 10\n");
}
// Total cost: 0.020823
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 53)]
// Total instrumented cost: 0.020823, input tokens: 2398, output tokens: 1154, cache read tokens: 2394, cache write tokens: 742
