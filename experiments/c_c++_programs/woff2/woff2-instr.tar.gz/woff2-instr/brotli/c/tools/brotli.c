/* Copyright 2014 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

/* Command line interface for Brotli library. */

#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>

#include "../common/constants.h"
#include "../common/version.h"
#include <brotli/decode.h>
#include <brotli/encode.h>

#if !defined(_WIN32)
#include <unistd.h>
#include <utime.h>
#define MAKE_BINARY(FILENO) (FILENO)
#else
#include <io.h>
#include <share.h>
#include <sys/utime.h>

#define MAKE_BINARY(FILENO) (_setmode((FILENO), _O_BINARY), (FILENO))

#if !defined(__MINGW32__)
#define STDIN_FILENO _fileno(stdin)
#define STDOUT_FILENO _fileno(stdout)
#define S_IRUSR S_IREAD
#define S_IWUSR S_IWRITE
#endif

#define fdopen _fdopen
#define isatty _isatty
#define unlink _unlink
#define utimbuf _utimbuf
#define utime _utime

#define fopen ms_fopen
#define open ms_open

#define chmod(F, P) (0)
#define chown(F, O, G) (0)

#if defined(_MSC_VER) && (_MSC_VER >= 1400)
#define fseek _fseeki64
#define ftell _ftelli64
#endif

static FILE* ms_fopen(const char* filename, const char* mode) {
  fprintf(stderr, "[brotli/c/tools/brotli.c] enter ms_fopen 1\n");
  FILE* result = 0;
  fopen_s(&result, filename, mode);
  return result;
  // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ms_fopen 1\n");
}

static int ms_open(const char* filename, int oflag, int pmode) {
  fprintf(stderr, "[brotli/c/tools/brotli.c] enter ms_open 1\n");
  int result = -1;
  _sopen_s(&result, filename, oflag | O_BINARY, _SH_DENYNO, pmode);
  return result;
  // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ms_open 1\n");
}
#endif  /* WIN32 */

typedef enum {
  COMMAND_COMPRESS,
  COMMAND_DECOMPRESS,
  COMMAND_HELP,
  COMMAND_INVALID,
  COMMAND_TEST_INTEGRITY,
  COMMAND_NOOP,
  COMMAND_VERSION
} Command;

#define DEFAULT_LGWIN 22
#define DEFAULT_SUFFIX ".br"
#define MAX_OPTIONS 20

typedef struct {
  /* Parameters */
  int quality;
  int lgwin;
  BROTLI_BOOL force_overwrite;
  BROTLI_BOOL junk_source;
  BROTLI_BOOL copy_stat;
  BROTLI_BOOL verbose;
  BROTLI_BOOL write_to_stdout;
  BROTLI_BOOL test_integrity;
  BROTLI_BOOL decompress;
  const char* output_path;
  const char* suffix;
  int not_input_indices[MAX_OPTIONS];
  size_t longest_path_len;
  size_t input_count;

  /* Inner state */
  int argc;
  char** argv;
  char* modified_path;  /* Storage for path with appended / cut suffix */
  int iterator;
  int ignore;
  BROTLI_BOOL iterator_error;
  uint8_t* buffer;
  uint8_t* input;
  uint8_t* output;
  const char* current_input_path;
  const char* current_output_path;
  int64_t input_file_length;  /* -1, if impossible to calculate */
  FILE* fin;
  FILE* fout;

  /* I/O buffers */
  size_t available_in;
  const uint8_t* next_in;
  size_t available_out;
  uint8_t* next_out;
} Context;

/* Parse up to 5 decimal digits. */
static BROTLI_BOOL ParseInt(const char* s, int low, int high, int* result) {
  fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseInt 1\n");
  int value = 0;
  int i;
  for (i = 0; i < 5; ++i) {
    char c = s[i];
    if (c == 0) break;
    if (s[i] < '0' || s[i] > '9') return BROTLI_FALSE;
    value = (10 * value) + (c - '0');
  }
  if (i == 0) return BROTLI_FALSE;
  if (i > 1 && s[0] == '0') return BROTLI_FALSE;
  if (s[i] != 0) return BROTLI_FALSE;
  if (value < low || value > high) return BROTLI_FALSE;
  *result = value;
  return BROTLI_TRUE;
  // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseInt 1\n");
}

/* Returns "base file name" or its tail, if it contains '/' or '\'. */
static const char* FileName(const char* path) {
  fprintf(stderr, "[brotli/c/tools/brotli.c] enter FileName 1\n");
  const char* separator_position = strrchr(path, '/');
  if (separator_position) path = separator_position + 1;
  separator_position = strrchr(path, '\\');
  if (separator_position) path = separator_position + 1;
  return path;
  // fprintf(stderr, "[brotli/c/tools/brotli.c] exit FileName 1\n");
}

/* Detect if the program name is a special alias that infers a command type. */
static Command ParseAlias(const char* name) {
  fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseAlias 1\n");
  /* TODO: cast name to lower case? */
  const char* unbrotli = "unbrotli";
  size_t unbrotli_len = strlen(unbrotli);
  name = FileName(name);
  /* Partial comparison. On Windows there could be ".exe" suffix. */
  if (strncmp(name, unbrotli, unbrotli_len) == 0) {
    fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseAlias 2\n");
    char terminator = name[unbrotli_len];
    if (terminator == 0 || terminator == '.') return COMMAND_DECOMPRESS;
    // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseAlias 2\n");
  }
  return COMMAND_COMPRESS;
  // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseAlias 1\n");
}

static Command ParseParams(Context* params) {
  fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 1\n");
  int argc = params->argc;
  char** argv = params->argv;
  int i;
  int next_option_index = 0;
  size_t input_count = 0;
  size_t longest_path_len = 1;
  BROTLI_BOOL command_set = BROTLI_FALSE;
  BROTLI_BOOL quality_set = BROTLI_FALSE;
  BROTLI_BOOL output_set = BROTLI_FALSE;
  BROTLI_BOOL keep_set = BROTLI_FALSE;
  BROTLI_BOOL lgwin_set = BROTLI_FALSE;
  BROTLI_BOOL suffix_set = BROTLI_FALSE;
  BROTLI_BOOL after_dash_dash = BROTLI_FALSE;
  Command command = ParseAlias(argv[0]);
  // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 1\n");

  for (i = 1; i < argc; ++i) {
    fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 2\n");
    const char* arg = argv[i];
    /* C99 5.1.2.2.1: "members argv[0] through argv[argc-1] inclusive shall
       contain pointers to strings"; NULL and 0-length are not forbidden. */
    size_t arg_len = arg ? strlen(arg) : 0;

    if (arg_len == 0) {
      fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 3\n");
      params->not_input_indices[next_option_index++] = i;
      // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 3\n");
      continue;
    }

    /* Too many options. The expected longest option list is:
       "-q 0 -w 10 -o f -D d -S b -d -f -k -n -v --", i.e. 16 items in total.
       This check is an additional guard that is never triggered, but provides
       a guard for future changes. */
    if (next_option_index > (MAX_OPTIONS - 2)) {
      fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 4\n");
      return COMMAND_INVALID;
      // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 4\n");
    }

    /* Input file entry. */
    if (after_dash_dash || arg[0] != '-' || arg_len == 1) {
      fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 5\n");
      input_count++;
      if (longest_path_len < arg_len) longest_path_len = arg_len;
      // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 5\n");
      continue;
    }

    /* Not a file entry. */
    params->not_input_indices[next_option_index++] = i;

    /* '--' entry stop parsing arguments. */
    if (arg_len == 2 && arg[1] == '-') {
      fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 6\n");
      after_dash_dash = BROTLI_TRUE;
      // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 6\n");
      continue;
    }

    /* Simple / coalesced options. */
    if (arg[1] != '-') {
      fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 7\n");
      size_t j;
      for (j = 1; j < arg_len; ++j) {
        fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 8\n");
        char c = arg[j];
        if (c >= '0' && c <= '9') {
          fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 9\n");
          if (quality_set) return COMMAND_INVALID;
          quality_set = BROTLI_TRUE;
          params->quality = c - '0';
          // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 9\n");
          continue;
        } else if (c == 'c') {
          fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 10\n");
          if (output_set) return COMMAND_INVALID;
          output_set = BROTLI_TRUE;
          params->write_to_stdout = BROTLI_TRUE;
          // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 10\n");
          continue;
        } else if (c == 'd') {
          fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 11\n");
          if (command_set) return COMMAND_INVALID;
          command_set = BROTLI_TRUE;
          command = COMMAND_DECOMPRESS;
          // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 11\n");
          continue;
        } else if (c == 'f') {
          fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 12\n");
          if (params->force_overwrite) return COMMAND_INVALID;
          params->force_overwrite = BROTLI_TRUE;
          // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 12\n");
          continue;
        } else if (c == 'h') {
          fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 13\n");
          /* Don't parse further. */
          return COMMAND_HELP;
          // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 13\n");
        } else if (c == 'j' || c == 'k') {
          fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 14\n");
          if (keep_set) return COMMAND_INVALID;
          keep_set = BROTLI_TRUE;
          params->junk_source = TO_BROTLI_BOOL(c == 'j');
          // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 14\n");
          continue;
        } else if (c == 'n') {
          fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 15\n");
          if (!params->copy_stat) return COMMAND_INVALID;
          params->copy_stat = BROTLI_FALSE;
          // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 15\n");
          continue;
        } else if (c == 't') {
          fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 16\n");
          if (command_set) return COMMAND_INVALID;
          command_set = BROTLI_TRUE;
          command = COMMAND_TEST_INTEGRITY;
          // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 16\n");
          continue;
        } else if (c == 'v') {
          fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 17\n");
          if (params->verbose) return COMMAND_INVALID;
          params->verbose = BROTLI_TRUE;
          // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 17\n");
          continue;
        } else if (c == 'V') {
          fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 18\n");
          /* Don't parse further. */
          return COMMAND_VERSION;
          // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 18\n");
        } else if (c == 'Z') {
          fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 19\n");
          if (quality_set) return COMMAND_INVALID;
          quality_set = BROTLI_TRUE;
          params->quality = 11;
          // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 19\n");
          continue;
        }
        /* o/q/w/D/S with parameter is expected */
        if (c != 'o' && c != 'q' && c != 'w' && c != 'D' && c != 'S') {
          fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 20\n");
          return COMMAND_INVALID;
          // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 20\n");
        }
        if (j + 1 != arg_len) return COMMAND_INVALID;
        i++;
        if (i == argc || !argv[i] || argv[i][0] == 0) return COMMAND_INVALID;
        params->not_input_indices[next_option_index++] = i;
        if (c == 'o') {
          fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 21\n");
          if (output_set) return COMMAND_INVALID;
          params->output_path = argv[i];
          // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 21\n");
        } else if (c == 'q') {
          fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 22\n");
          if (quality_set) return COMMAND_INVALID;
          quality_set = ParseInt(argv[i], BROTLI_MIN_QUALITY,
                                 BROTLI_MAX_QUALITY, &params->quality);
          if (!quality_set) return COMMAND_INVALID;
          // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 22\n");
        } else if (c == 'w') {
          fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 23\n");
          if (lgwin_set) return COMMAND_INVALID;
          lgwin_set = ParseInt(argv[i], 0,
                               BROTLI_MAX_WINDOW_BITS, &params->lgwin);
          if (!lgwin_set) return COMMAND_INVALID;
          if (params->lgwin != 0 && params->lgwin < BROTLI_MIN_WINDOW_BITS) {
            return COMMAND_INVALID;
          }
          // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 23\n");
        } else if (c == 'S') {
          fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 24\n");
          if (suffix_set) return COMMAND_INVALID;
          suffix_set = BROTLI_TRUE;
          params->suffix = argv[i];
          // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 24\n");
        }
        // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 8\n");
      }
      // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 7\n");
    } else {  /* Double-dash. */
      fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 25\n");
      arg = &arg[2];
      if (strcmp("best", arg) == 0) {
        fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 26\n");
        if (quality_set) return COMMAND_INVALID;
        quality_set = BROTLI_TRUE;
        params->quality = 11;
        // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 26\n");
      } else if (strcmp("decompress", arg) == 0) {
        fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 27\n");
        if (command_set) return COMMAND_INVALID;
        command_set = BROTLI_TRUE;
        command = COMMAND_DECOMPRESS;
        // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 27\n");
      } else if (strcmp("force", arg) == 0) {
        fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 28\n");
        if (params->force_overwrite) return COMMAND_INVALID;
        params->force_overwrite = BROTLI_TRUE;
        // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 28\n");
      } else if (strcmp("help", arg) == 0) {
        fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 29\n");
        /* Don't parse further. */
        return COMMAND_HELP;
        // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 29\n");
      } else if (strcmp("keep", arg) == 0) {
        fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 30\n");
        if (keep_set) return COMMAND_INVALID;
        keep_set = BROTLI_TRUE;
        params->junk_source = BROTLI_FALSE;
        // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 30\n");
      } else if (strcmp("no-copy-stat", arg) == 0) {
        fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 31\n");
        if (!params->copy_stat) return COMMAND_INVALID;
        params->copy_stat = BROTLI_FALSE;
        // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 31\n");
      } else if (strcmp("rm", arg) == 0) {
        fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 32\n");
        if (keep_set) return COMMAND_INVALID;
        keep_set = BROTLI_TRUE;
        params->junk_source = BROTLI_TRUE;
        // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 32\n");
      } else if (strcmp("stdout", arg) == 0) {
        fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 33\n");
        if (output_set) return COMMAND_INVALID;
        output_set = BROTLI_TRUE;
        params->write_to_stdout = BROTLI_TRUE;
        // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 33\n");
      } else if (strcmp("test", arg) == 0) {
        fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 34\n");
        if (command_set) return COMMAND_INVALID;
        command_set = BROTLI_TRUE;
        command = COMMAND_TEST_INTEGRITY;
        // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 34\n");
      } else if (strcmp("verbose", arg) == 0) {
        fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 35\n");
        if (params->verbose) return COMMAND_INVALID;
        params->verbose = BROTLI_TRUE;
        // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 35\n");
      } else if (strcmp("version", arg) == 0) {
        fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 36\n");
        /* Don't parse further. */
        return COMMAND_VERSION;
        // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 36\n");
      } else {
        fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 37\n");
        /* key=value */
        const char* value = strrchr(arg, '=');
        size_t key_len;
        if (!value || value[1] == 0) return COMMAND_INVALID;
        key_len = (size_t)(value - arg);
        value++;
        if (strncmp("lgwin", arg, key_len) == 0) {
          fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 38\n");
          if (lgwin_set) return COMMAND_INVALID;
          lgwin_set = ParseInt(value, 0,
                               BROTLI_MAX_WINDOW_BITS, &params->lgwin);
          if (!lgwin_set) return COMMAND_INVALID;
          if (params->lgwin != 0 && params->lgwin < BROTLI_MIN_WINDOW_BITS) {
            return COMMAND_INVALID;
          }
          // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 38\n");
        } else if (strncmp("output", arg, key_len) == 0) {
          fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 39\n");
          if (output_set) return COMMAND_INVALID;
          params->output_path = value;
          // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 39\n");
        } else if (strncmp("quality", arg, key_len) == 0) {
          fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 40\n");
          if (quality_set) return COMMAND_INVALID;
          quality_set = ParseInt(value, BROTLI_MIN_QUALITY,
                                 BROTLI_MAX_QUALITY, &params->quality);
          if (!quality_set) return COMMAND_INVALID;
          // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 40\n");
        } else if (strncmp("suffix", arg, key_len) == 0) {
          fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 41\n");
          if (suffix_set) return COMMAND_INVALID;
          suffix_set = BROTLI_TRUE;
          params->suffix = value;
          // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 41\n");
        } else {
          fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 42\n");
          return COMMAND_INVALID;
          // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 42\n");
        }
        // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 37\n");
      }
      // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 25\n");
    }
    // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 2\n");
  }

  fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 43\n");
  params->input_count = input_count;
  params->longest_path_len = longest_path_len;
  params->decompress = (command == COMMAND_DECOMPRESS);
  params->test_integrity = (command == COMMAND_TEST_INTEGRITY);

  if (input_count > 1 && output_set) return COMMAND_INVALID;
  if (params->test_integrity) {
    fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 44\n");
    if (params->output_path) return COMMAND_INVALID;
    if (params->write_to_stdout) return COMMAND_INVALID;
    // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 44\n");
  }
  if (strchr(params->suffix, '/') || strchr(params->suffix, '\\')) {
    fprintf(stderr, "[brotli/c/tools/brotli.c] enter ParseParams 45\n");
    return COMMAND_INVALID;
    // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 45\n");
  }

  return command;
  // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ParseParams 43\n");
}

static void PrintVersion(void) {
  fprintf(stderr, "[brotli/c/tools/brotli.c] enter PrintVersion 1\n");
  int major = BROTLI_VERSION >> 24;
  int minor = (BROTLI_VERSION >> 12) & 0xFFF;
  int patch = BROTLI_VERSION & 0xFFF;
  fprintf(stdout, "brotli %d.%d.%d\n", major, minor, patch);
  // fprintf(stderr, "[brotli/c/tools/brotli.c] exit PrintVersion 1\n");
}

static void PrintHelp(const char* name) {
  fprintf(stderr, "[brotli/c/tools/brotli.c] enter PrintHelp 1\n");
  /* String is cut to pieces with length less than 509, to conform C90 spec. */
  fprintf(stdout,
"Usage: %s [OPTION]... [FILE]...\n",
          name);
  fprintf(stdout,
"Options:\n"
"  -#                          compression level (0-9)\n"
"  -c, --stdout                write on standard output\n"
"  -d, --decompress            decompress\n"
"  -f, --force                 force output file overwrite\n"
"  -h, --help                  display this help and exit\n");
  fprintf(stdout,
"  -j, --rm                    remove source file(s)\n"
"  -k, --keep                  keep source file(s) (default)\n"
"  -n, --no-copy-stat          do not copy source file(s) attributes\n"
"  -o FILE, --output=FILE      output file (only if 1 input file)\n");
  fprintf(stdout,
"  -q NUM, --quality=NUM       compression level (%d-%d)\n",
          BROTLI_MIN_QUALITY, BROTLI_MAX_QUALITY);
  fprintf(stdout,
"  -t, --test                  test compressed file integrity\n"
"  -v, --verbose               verbose mode\n");
  fprintf(stdout,
"  -w NUM, --lgwin=NUM         set LZ77 window size (0, %d-%d)\n",
          BROTLI_MIN_WINDOW_BITS, BROTLI_MAX_WINDOW_BITS);
  fprintf(stdout,
"                              window size = 2**NUM - 16\n"
"                              0 lets compressor choose the optimal value\n");
  fprintf(stdout,
"  -S SUF, --suffix=SUF        output file suffix (default:'%s')\n",
          DEFAULT_SUFFIX);
  fprintf(stdout,
"  -V, --version               display version and exit\n"
"  -Z, --best                  use best compression level (11) (default)\n"
"Simple options could be coalesced, i.e. '-9kf' is equivalent to '-9 -k -f'.\n"
"With no FILE, or when FILE is -, read standard input.\n"
"All arguments after '--' are treated as files.\n");
  // fprintf(stderr, "[brotli/c/tools/brotli.c] exit PrintHelp 1\n");
}

static const char* PrintablePath(const char* path) {
  fprintf(stderr, "[brotli/c/tools/brotli.c] enter PrintablePath 1\n");
  return path ? path : "con";
  // fprintf(stderr, "[brotli/c/tools/brotli.c] exit PrintablePath 1\n");
}

static BROTLI_BOOL OpenInputFile(const char* input_path, FILE** f) {
  fprintf(stderr, "[brotli/c/tools/brotli.c] enter OpenInputFile 1\n");
  *f = NULL;
  if (!input_path) {
    fprintf(stderr, "[brotli/c/tools/brotli.c] enter OpenInputFile 2\n");
    *f = fdopen(MAKE_BINARY(STDIN_FILENO), "rb");
    return BROTLI_TRUE;
    // fprintf(stderr, "[brotli/c/tools/brotli.c] exit OpenInputFile 2\n");
  }
  *f = fopen(input_path, "rb");
  if (!*f) {
    fprintf(stderr, "[brotli/c/tools/brotli.c] enter OpenInputFile 3\n");
    fprintf(stderr, "failed to open input file [%s]: %s\n",
            PrintablePath(input_path), strerror(errno));
    return BROTLI_FALSE;
    // fprintf(stderr, "[brotli/c/tools/brotli.c] exit OpenInputFile 3\n");
  }
  return BROTLI_TRUE;
  // fprintf(stderr, "[brotli/c/tools/brotli.c] exit OpenInputFile 1\n");
}

static BROTLI_BOOL OpenOutputFile(const char* output_path, FILE** f,
                                  BROTLI_BOOL force) {
  fprintf(stderr, "[brotli/c/tools/brotli.c] enter OpenOutputFile 1\n");
  int fd;
  *f = NULL;
  if (!output_path) {
    fprintf(stderr, "[brotli/c/tools/brotli.c] enter OpenOutputFile 2\n");
    *f = fdopen(MAKE_BINARY(STDOUT_FILENO), "wb");
    return BROTLI_TRUE;
    // fprintf(stderr, "[brotli/c/tools/brotli.c] exit OpenOutputFile 2\n");
  }
  fd = open(output_path, O_CREAT | (force ? 0 : O_EXCL) | O_WRONLY | O_TRUNC,
            S_IRUSR | S_IWUSR);
  if (fd < 0) {
    fprintf(stderr, "[brotli/c/tools/brotli.c] enter OpenOutputFile 3\n");
    fprintf(stderr, "failed to open output file [%s]: %s\n",
            PrintablePath(output_path), strerror(errno));
    return BROTLI_FALSE;
    // fprintf(stderr, "[brotli/c/tools/brotli.c] exit OpenOutputFile 3\n");
  }
  *f = fdopen(fd, "wb");
  if (!*f) {
    fprintf(stderr, "[brotli/c/tools/brotli.c] enter OpenOutputFile 4\n");
    fprintf(stderr, "failed to open output file [%s]: %s\n",
            PrintablePath(output_path), strerror(errno));
    return BROTLI_FALSE;
    // fprintf(stderr, "[brotli/c/tools/brotli.c] exit OpenOutputFile 4\n");
  }
  return BROTLI_TRUE;
  // fprintf(stderr, "[brotli/c/tools/brotli.c] exit OpenOutputFile 1\n");
}

static int64_t FileSize(const char* path) {
  fprintf(stderr, "[brotli/c/tools/brotli.c] enter FileSize 1\n");
  FILE* f = fopen(path, "rb");
  int64_t retval;
  if (f == NULL) {
    fprintf(stderr, "[brotli/c/tools/brotli.c] enter FileSize 2\n");
    return -1;
    // fprintf(stderr, "[brotli/c/tools/brotli.c] exit FileSize 2\n");
  }
  if (fseek(f, 0L, SEEK_END) != 0) {
    fprintf(stderr, "[brotli/c/tools/brotli.c] enter FileSize 3\n");
    fclose(f);
    return -1;
    // fprintf(stderr, "[brotli/c/tools/brotli.c] exit FileSize 3\n");
  }
  retval = ftell(f);
  if (fclose(f) != 0) {
    fprintf(stderr, "[brotli/c/tools/brotli.c] enter FileSize 4\n");
    return -1;
    // fprintf(stderr, "[brotli/c/tools/brotli.c] exit FileSize 4\n");
  }
  return retval;
  // fprintf(stderr, "[brotli/c/tools/brotli.c] exit FileSize 1\n");
}

/* Copy file times and permissions.
   TODO: this is a "best effort" implementation; honest cross-platform
   fully featured implementation is way too hacky; add more hacks by request. */
static void CopyStat(const char* input_path, const char* output_path) {
  fprintf(stderr, "[brotli/c/tools/brotli.c] enter CopyStat 1\n");
  struct stat statbuf;
  struct utimbuf times;
  int res;
  if (input_path == 0 || output_path == 0) {
    fprintf(stderr, "[brotli/c/tools/brotli.c] enter CopyStat 2\n");
    return;
    // fprintf(stderr, "[brotli/c/tools/brotli.c] exit CopyStat 2\n");
  }
  if (stat(input_path, &statbuf) != 0) {
    fprintf(stderr, "[brotli/c/tools/brotli.c] enter CopyStat 3\n");
    return;
    // fprintf(stderr, "[brotli/c/tools/brotli.c] exit CopyStat 3\n");
  }
  times.actime = statbuf.st_atime;
  times.modtime = statbuf.st_mtime;
  utime(output_path, &times);
  res = chmod(output_path, statbuf.st_mode & (S_IRWXU | S_IRWXG | S_IRWXO));
  if (res != 0) {
    fprintf(stderr, "[brotli/c/tools/brotli.c] enter CopyStat 4\n");
    fprintf(stderr, "setting access bits failed for [%s]: %s\n",
            PrintablePath(output_path), strerror(errno));
    // fprintf(stderr, "[brotli/c/tools/brotli.c] exit CopyStat 4\n");
  }
  res = chown(output_path, (uid_t)-1, statbuf.st_gid);
  if (res != 0) {
    fprintf(stderr, "[brotli/c/tools/brotli.c] enter CopyStat 5\n");
    fprintf(stderr, "setting group failed for [%s]: %s\n",
            PrintablePath(output_path), strerror(errno));
    // fprintf(stderr, "[brotli/c/tools/brotli.c] exit CopyStat 5\n");
  }
  res = chown(output_path, statbuf.st_uid, (gid_t)-1);
  if (res != 0) {
    fprintf(stderr, "[brotli/c/tools/brotli.c] enter CopyStat 6\n");
    fprintf(stderr, "setting user failed for [%s]: %s\n",
            PrintablePath(output_path), strerror(errno));
    // fprintf(stderr, "[brotli/c/tools/brotli.c] exit CopyStat 6\n");
  }
  // fprintf(stderr, "[brotli/c/tools/brotli.c] exit CopyStat 1\n");
}

static BROTLI_BOOL NextFile(Context* context) {
  fprintf(stderr, "[brotli/c/tools/brotli.c] enter NextFile 1\n");
  const char* arg;
  size_t arg_len;

  /* Iterator points to last used arg; increment to search for the next one. */
  context->iterator++;

  context->input_file_length = -1;

  /* No input path; read from console. */
  if (context->input_count == 0) {
    fprintf(stderr, "[brotli/c/tools/brotli.c] enter NextFile 2\n");
    if (context->iterator > 1) return BROTLI_FALSE;
    context->current_input_path = NULL;
    /* Either write to the specified path, or to console. */
    context->current_output_path = context->output_path;
    return BROTLI_TRUE;
    // fprintf(stderr, "[brotli/c/tools/brotli.c] exit NextFile 2\n");
  }

  /* Skip option arguments. */
  while (context->iterator == context->not_input_indices[context->ignore]) {
    fprintf(stderr, "[brotli/c/tools/brotli.c] enter NextFile 3\n");
    context->iterator++;
    context->ignore++;
    // fprintf(stderr, "[brotli/c/tools/brotli.c] exit NextFile 3\n");
  }

  /* All args are scanned already. */
  if (context->iterator >= context->argc) {
    fprintf(stderr, "[brotli/c/tools/brotli.c] enter NextFile 4\n");
    return BROTLI_FALSE;
    // fprintf(stderr, "[brotli/c/tools/brotli.c] exit NextFile 4\n");
  }

  /* Iterator now points to the input file name. */
  arg = context->argv[context->iterator];
  arg_len = strlen(arg);
  /* Read from console. */
  if (arg_len == 1 && arg[0] == '-') {
    fprintf(stderr, "[brotli/c/tools/brotli.c] enter NextFile 5\n");
    context->current_input_path = NULL;
    context->current_output_path = context->output_path;
    return BROTLI_TRUE;
    // fprintf(stderr, "[brotli/c/tools/brotli.c] exit NextFile 5\n");
  }

  context->current_input_path = arg;
  context->input_file_length = FileSize(arg);
  context->current_output_path = context->output_path;

  if (context->output_path) {
    fprintf(stderr, "[brotli/c/tools/brotli.c] enter NextFile 6\n");
    return BROTLI_TRUE;
    // fprintf(stderr, "[brotli/c/tools/brotli.c] exit NextFile 6\n");
  }
  if (context->write_to_stdout) {
    fprintf(stderr, "[brotli/c/tools/brotli.c] enter NextFile 7\n");
    return BROTLI_TRUE;
    // fprintf(stderr, "[brotli/c/tools/brotli.c] exit NextFile 7\n");
  }

  strcpy(context->modified_path, arg);
  context->current_output_path = context->modified_path;
  /* If output is not specified, input path suffix should match. */
  if (context->decompress) {
    fprintf(stderr, "[brotli/c/tools/brotli.c] enter NextFile 8\n");
    size_t suffix_len = strlen(context->suffix);
    char* name = (char*)FileName(context->modified_path);
    char* name_suffix;
    size_t name_len = strlen(name);
    if (name_len < suffix_len + 1) {
      fprintf(stderr, "[brotli/c/tools/brotli.c] enter NextFile 9\n");
      fprintf(stderr, "empty output file name for [%s] input file\n",
              PrintablePath(arg));
      context->iterator_error = BROTLI_TRUE;
      return BROTLI_FALSE;
      // fprintf(stderr, "[brotli/c/tools/brotli.c] exit NextFile 9\n");
    }
    name_suffix = name + name_len - suffix_len;
    if (strcmp(context->suffix, name_suffix) != 0) {
      fprintf(stderr, "[brotli/c/tools/brotli.c] enter NextFile 10\n");
      fprintf(stderr, "input file [%s] suffix mismatch\n",
              PrintablePath(arg));
      context->iterator_error = BROTLI_TRUE;
      return BROTLI_FALSE;
      // fprintf(stderr, "[brotli/c/tools/brotli.c] exit NextFile 10\n");
    }
    name_suffix[0] = 0;
    return BROTLI_TRUE;
    // fprintf(stderr, "[brotli/c/tools/brotli.c] exit NextFile 8\n");
  } else {
    fprintf(stderr, "[brotli/c/tools/brotli.c] enter NextFile 11\n");
    strcpy(context->modified_path + arg_len, context->suffix);
    return BROTLI_TRUE;
    // fprintf(stderr, "[brotli/c/tools/brotli.c] exit NextFile 11\n");
  }
  // fprintf(stderr, "[brotli/c/tools/brotli.c] exit NextFile 1\n");
}

static BROTLI_BOOL OpenFiles(Context* context) {
  fprintf(stderr, "[brotli/c/tools/brotli.c] enter OpenFiles 1\n");
  BROTLI_BOOL is_ok = OpenInputFile(context->current_input_path, &context->fin);
  if (!context->test_integrity && is_ok) {
    fprintf(stderr, "[brotli/c/tools/brotli.c] enter OpenFiles 2\n");
    is_ok = OpenOutputFile(
        context->current_output_path, &context->fout, context->force_overwrite);
    // fprintf(stderr, "[brotli/c/tools/brotli.c] exit OpenFiles 2\n");
  }
  return is_ok;
  // fprintf(stderr, "[brotli/c/tools/brotli.c] exit OpenFiles 1\n");
}

static BROTLI_BOOL CloseFiles(Context* context, BROTLI_BOOL success) {
  fprintf(stderr, "[brotli/c/tools/brotli.c] enter CloseFiles 1\n");
  BROTLI_BOOL is_ok = BROTLI_TRUE;
  if (!context->test_integrity && context->fout) {
    fprintf(stderr, "[brotli/c/tools/brotli.c] enter CloseFiles 2\n");
    if (!success && context->current_output_path) {
      fprintf(stderr, "[brotli/c/tools/brotli.c] enter CloseFiles 3\n");
      unlink(context->current_output_path);
      // fprintf(stderr, "[brotli/c/tools/brotli.c] exit CloseFiles 3\n");
    }
    if (fclose(context->fout) != 0) {
      fprintf(stderr, "[brotli/c/tools/brotli.c] enter CloseFiles 4\n");
      if (success) {
        fprintf(stderr, "[brotli/c/tools/brotli.c] enter CloseFiles 5\n");
        fprintf(stderr, "fclose failed [%s]: %s\n",
                PrintablePath(context->current_output_path), strerror(errno));
        // fprintf(stderr, "[brotli/c/tools/brotli.c] exit CloseFiles 5\n");
      }
      is_ok = BROTLI_FALSE;
      // fprintf(stderr, "[brotli/c/tools/brotli.c] exit CloseFiles 4\n");
    }

    /* TOCTOU violation, but otherwise it is impossible to set file times. */
    if (success && is_ok && context->copy_stat) {
      fprintf(stderr, "[brotli/c/tools/brotli.c] enter CloseFiles 6\n");
      CopyStat(context->current_input_path, context->current_output_path);
      // fprintf(stderr, "[brotli/c/tools/brotli.c] exit CloseFiles 6\n");
    }
    // fprintf(stderr, "[brotli/c/tools/brotli.c] exit CloseFiles 2\n");
  }

  if (context->fin) {
    fprintf(stderr, "[brotli/c/tools/brotli.c] enter CloseFiles 7\n");
    if (fclose(context->fin) != 0) {
      fprintf(stderr, "[brotli/c/tools/brotli.c] enter CloseFiles 8\n");
      if (is_ok) {
        fprintf(stderr, "[brotli/c/tools/brotli.c] enter CloseFiles 9\n");
        fprintf(stderr, "fclose failed [%s]: %s\n",
                PrintablePath(context->current_input_path), strerror(errno));
        // fprintf(stderr, "[brotli/c/tools/brotli.c] exit CloseFiles 9\n");
      }
      is_ok = BROTLI_FALSE;
      // fprintf(stderr, "[brotli/c/tools/brotli.c] exit CloseFiles 8\n");
    }
    // fprintf(stderr, "[brotli/c/tools/brotli.c] exit CloseFiles 7\n");
  }
  if (success && context->junk_source && context->current_input_path) {
    fprintf(stderr, "[brotli/c/tools/brotli.c] enter CloseFiles 10\n");
    unlink(context->current_input_path);
    // fprintf(stderr, "[brotli/c/tools/brotli.c] exit CloseFiles 10\n");
  }

  context->fin = NULL;
  context->fout = NULL;

  return is_ok;
  // fprintf(stderr, "[brotli/c/tools/brotli.c] exit CloseFiles 1\n");
}

static const size_t kFileBufferSize = 1 << 16;

static void InitializeBuffers(Context* context) {
  fprintf(stderr, "[brotli/c/tools/brotli.c] enter InitializeBuffers 1\n");
  context->available_in = 0;
  context->next_in = NULL;
  context->available_out = kFileBufferSize;
  context->next_out = context->output;
  // fprintf(stderr, "[brotli/c/tools/brotli.c] exit InitializeBuffers 1\n");
}

static BROTLI_BOOL HasMoreInput(Context* context) {
  fprintf(stderr, "[brotli/c/tools/brotli.c] enter HasMoreInput 1\n");
  return feof(context->fin) ? BROTLI_FALSE : BROTLI_TRUE;
  // fprintf(stderr, "[brotli/c/tools/brotli.c] exit HasMoreInput 1\n");
}

static BROTLI_BOOL ProvideInput(Context* context) {
  fprintf(stderr, "[brotli/c/tools/brotli.c] enter ProvideInput 1\n");
  context->available_in =
      fread(context->input, 1, kFileBufferSize, context->fin);
  context->next_in = context->input;
  if (ferror(context->fin)) {
    fprintf(stderr, "[brotli/c/tools/brotli.c] enter ProvideInput 2\n");
    fprintf(stderr, "failed to read input [%s]: %s\n",
            PrintablePath(context->current_input_path), strerror(errno));
    return BROTLI_FALSE;
    // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ProvideInput 2\n");
  }
  return BROTLI_TRUE;
  // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ProvideInput 1\n");
}

/* Internal: should be used only in Provide-/Flush-Output. */
static BROTLI_BOOL WriteOutput(Context* context) {
  fprintf(stderr, "[brotli/c/tools/brotli.c] enter WriteOutput 1\n");
  size_t out_size = (size_t)(context->next_out - context->output);
  if (out_size == 0) {
    fprintf(stderr, "[brotli/c/tools/brotli.c] enter WriteOutput 2\n");
    return BROTLI_TRUE;
    // fprintf(stderr, "[brotli/c/tools/brotli.c] exit WriteOutput 2\n");
  }
  if (context->test_integrity) {
    fprintf(stderr, "[brotli/c/tools/brotli.c] enter WriteOutput 3\n");
    return BROTLI_TRUE;
    // fprintf(stderr, "[brotli/c/tools/brotli.c] exit WriteOutput 3\n");
  }

  fwrite(context->output, 1, out_size, context->fout);
  if (ferror(context->fout)) {
    fprintf(stderr, "[brotli/c/tools/brotli.c] enter WriteOutput 4\n");
    fprintf(stderr, "failed to write output [%s]: %s\n",
            PrintablePath(context->current_output_path), strerror(errno));
    return BROTLI_FALSE;
    // fprintf(stderr, "[brotli/c/tools/brotli.c] exit WriteOutput 4\n");
  }
  return BROTLI_TRUE;
  // fprintf(stderr, "[brotli/c/tools/brotli.c] exit WriteOutput 1\n");
}

static BROTLI_BOOL ProvideOutput(Context* context) {
  fprintf(stderr, "[brotli/c/tools/brotli.c] enter ProvideOutput 1\n");
  if (!WriteOutput(context)) return BROTLI_FALSE;
  context->available_out = kFileBufferSize;
  context->next_out = context->output;
  return BROTLI_TRUE;
  // fprintf(stderr, "[brotli/c/tools/brotli.c] exit ProvideOutput 1\n");
}

static BROTLI_BOOL FlushOutput(Context* context) {
  fprintf(stderr, "[brotli/c/tools/brotli.c] enter FlushOutput 1\n");
  if (!WriteOutput(context)) return BROTLI_FALSE;
  context->available_out = 0;
  return BROTLI_TRUE;
  // fprintf(stderr, "[brotli/c/tools/brotli.c] exit FlushOutput 1\n");
}

static BROTLI_BOOL DecompressFile(Context* context, BrotliDecoderState* s) {
  fprintf(stderr, "[brotli/c/tools/brotli.c] enter DecompressFile 1\n");
  BrotliDecoderResult result = BROTLI_DECODER_RESULT_NEEDS_MORE_INPUT;
  InitializeBuffers(context);
  for (;;) {
    fprintf(stderr, "[brotli/c/tools/brotli.c] enter DecompressFile 2\n");
    if (result == BROTLI_DECODER_RESULT_NEEDS_MORE_INPUT) {
      fprintf(stderr, "[brotli/c/tools/brotli.c] enter DecompressFile 3\n");
      if (!HasMoreInput(context)) {
        fprintf(stderr, "[brotli/c/tools/brotli.c] enter DecompressFile 4\n");
        fprintf(stderr, "corrupt input [%s]\n",
                PrintablePath(context->current_input_path));
        return BROTLI_FALSE;
        // fprintf(stderr, "[brotli/c/tools/brotli.c] exit DecompressFile 4\n");
      }
      if (!ProvideInput(context)) return BROTLI_FALSE;
      // fprintf(stderr, "[brotli/c/tools/brotli.c] exit DecompressFile 3\n");
    } else if (result == BROTLI_DECODER_RESULT_NEEDS_MORE_OUTPUT) {
      fprintf(stderr, "[brotli/c/tools/brotli.c] enter DecompressFile 5\n");
      if (!ProvideOutput(context)) return BROTLI_FALSE;
      // fprintf(stderr, "[brotli/c/tools/brotli.c] exit DecompressFile 5\n");
    } else if (result == BROTLI_DECODER_RESULT_SUCCESS) {
      fprintf(stderr, "[brotli/c/tools/brotli.c] enter DecompressFile 6\n");
      if (!FlushOutput(context)) return BROTLI_FALSE;
      if (context->available_in != 0 || HasMoreInput(context)) {
        fprintf(stderr, "[brotli/c/tools/brotli.c] enter DecompressFile 7\n");
        fprintf(stderr, "corrupt input [%s]\n",
                PrintablePath(context->current_input_path));
        return BROTLI_FALSE;
        // fprintf(stderr, "[brotli/c/tools/brotli.c] exit DecompressFile 7\n");
      }
      return BROTLI_TRUE;
      // fprintf(stderr, "[brotli/c/tools/brotli.c] exit DecompressFile 6\n");
    } else {
      fprintf(stderr, "[brotli/c/tools/brotli.c] enter DecompressFile 8\n");
      fprintf(stderr, "corrupt input [%s]\n",
              PrintablePath(context->current_input_path));
      return BROTLI_FALSE;
      // fprintf(stderr, "[brotli/c/tools/brotli.c] exit DecompressFile 8\n");
    }

    result = BrotliDecoderDecompressStream(s, &context->available_in,
        &context->next_in, &context->available_out, &context->next_out, 0);
    // fprintf(stderr, "[brotli/c/tools/brotli.c] exit DecompressFile 2\n");
  }
  // fprintf(stderr, "[brotli/c/tools/brotli.c] exit DecompressFile 1\n");
}

static BROTLI_BOOL DecompressFiles(Context* context) {
  fprintf(stderr, "[brotli/c/tools/brotli.c] enter DecompressFiles 1\n");
  while (NextFile(context)) {
    fprintf(stderr, "[brotli/c/tools/brotli.c] enter DecompressFiles 2\n");
    BROTLI_BOOL is_ok = BROTLI_TRUE;
    BrotliDecoderState* s = BrotliDecoderCreateInstance(NULL, NULL, NULL);
    if (!s) {
      fprintf(stderr, "[brotli/c/tools/brotli.c] enter DecompressFiles 3\n");
      fprintf(stderr, "out of memory\n");
      return BROTLI_FALSE;
      // fprintf(stderr, "[brotli/c/tools/brotli.c] exit DecompressFiles 3\n");
    }
    is_ok = OpenFiles(context);
    if (is_ok && !context->current_input_path &&
        !context->force_overwrite && isatty(STDIN_FILENO)) {
      fprintf(stderr, "[brotli/c/tools/brotli.c] enter DecompressFiles 4\n");
      fprintf(stderr, "Use -h help. Use -f to force input from a terminal.\n");
      is_ok = BROTLI_FALSE;
      // fprintf(stderr, "[brotli/c/tools/brotli.c] exit DecompressFiles 4\n");
    }
    if (is_ok) is_ok = DecompressFile(context, s);
    BrotliDecoderDestroyInstance(s);
    if (!CloseFiles(context, is_ok)) is_ok = BROTLI_FALSE;
    if (!is_ok) return BROTLI_FALSE;
    // fprintf(stderr, "[brotli/c/tools/brotli.c] exit DecompressFiles 2\n");
  }
  return BROTLI_TRUE;
  // fprintf(stderr, "[brotli/c/tools/brotli.c] exit DecompressFiles 1\n");
}

static BROTLI_BOOL CompressFile(Context* context, BrotliEncoderState* s) {
  fprintf(stderr, "[brotli/c/tools/brotli.c] enter CompressFile 1\n");
  BROTLI_BOOL is_eof = BROTLI_FALSE;
  InitializeBuffers(context);
  for (;;) {
    fprintf(stderr, "[brotli/c/tools/brotli.c] enter CompressFile 2\n");
    if (context->available_in == 0 && !is_eof) {
      fprintf(stderr, "[brotli/c/tools/brotli.c] enter CompressFile 3\n");
      if (!ProvideInput(context)) return BROTLI_FALSE;
      is_eof = !HasMoreInput(context);
      // fprintf(stderr, "[brotli/c/tools/brotli.c] exit CompressFile 3\n");
    }

    if (!BrotliEncoderCompressStream(s,
        is_eof ? BROTLI_OPERATION_FINISH : BROTLI_OPERATION_PROCESS,
        &context->available_in, &context->next_in,
        &context->available_out, &context->next_out, NULL)) {
      fprintf(stderr, "[brotli/c/tools/brotli.c] enter CompressFile 4\n");
      /* Should detect OOM? */
      fprintf(stderr, "failed to compress data [%s]\n",
              PrintablePath(context->current_input_path));
      return BROTLI_FALSE;
      // fprintf(stderr, "[brotli/c/tools/brotli.c] exit CompressFile 4\n");
    }

    if (context->available_out == 0) {
      fprintf(stderr, "[brotli/c/tools/brotli.c] enter CompressFile 5\n");
      if (!ProvideOutput(context)) return BROTLI_FALSE;
      // fprintf(stderr, "[brotli/c/tools/brotli.c] exit CompressFile 5\n");
    }

    if (BrotliEncoderIsFinished(s)) {
      fprintf(stderr, "[brotli/c/tools/brotli.c] enter CompressFile 6\n");
      return FlushOutput(context);
      // fprintf(stderr, "[brotli/c/tools/brotli.c] exit CompressFile 6\n");
    }
    // fprintf(stderr, "[brotli/c/tools/brotli.c] exit CompressFile 2\n");
  }
  // fprintf(stderr, "[brotli/c/tools/brotli.c] exit CompressFile 1\n");
}
static BROTLI_BOOL CompressFiles(Context* context) {
  fprintf(stderr, "[brotli/c/tools/brotli.c] enter CompressFiles 1\n");
  while (NextFile(context)) {
    fprintf(stderr, "[brotli/c/tools/brotli.c] enter CompressFiles 2\n");
    BROTLI_BOOL is_ok = BROTLI_TRUE;
    BrotliEncoderState* s = BrotliEncoderCreateInstance(NULL, NULL, NULL);
    if (!s) {
      fprintf(stderr, "[brotli/c/tools/brotli.c] enter CompressFiles 3\n");
      fprintf(stderr, "out of memory\n");
      return BROTLI_FALSE;
      // fprintf(stderr, "[brotli/c/tools/brotli.c] exit CompressFiles 3\n");
    }
    fprintf(stderr, "[brotli/c/tools/brotli.c] enter CompressFiles 4\n");
    BrotliEncoderSetParameter(s,
        BROTLI_PARAM_QUALITY, (uint32_t)context->quality);
    if (context->lgwin > 0) {
      fprintf(stderr, "[brotli/c/tools/brotli.c] enter CompressFiles 5\n");
      /* Specified by user. */
      BrotliEncoderSetParameter(s,
          BROTLI_PARAM_LGWIN, (uint32_t)context->lgwin);
      // fprintf(stderr, "[brotli/c/tools/brotli.c] exit CompressFiles 5\n");
    } else {
      fprintf(stderr, "[brotli/c/tools/brotli.c] enter CompressFiles 6\n");
      /* 0, or not specified by user; could be chosen by compressor. */
      uint32_t lgwin = DEFAULT_LGWIN;
      /* Use file size to limit lgwin. */
      if (context->input_file_length >= 0) {
        fprintf(stderr, "[brotli/c/tools/brotli.c] enter CompressFiles 7\n");
        int32_t size = 1 << BROTLI_MIN_WINDOW_BITS;
        lgwin = BROTLI_MIN_WINDOW_BITS;
        // fprintf(stderr, "[brotli/c/tools/brotli.c] exit CompressFiles 7\n");
        while (size < context->input_file_length) {
          fprintf(stderr, "[brotli/c/tools/brotli.c] enter CompressFiles 8\n");
          size <<= 1;
          lgwin++;
          if (lgwin == BROTLI_MAX_WINDOW_BITS) break;
          // fprintf(stderr, "[brotli/c/tools/brotli.c] exit CompressFiles 8\n");
        }
      }
      fprintf(stderr, "[brotli/c/tools/brotli.c] enter CompressFiles 9\n");
      BrotliEncoderSetParameter(s, BROTLI_PARAM_LGWIN, lgwin);
      // fprintf(stderr, "[brotli/c/tools/brotli.c] exit CompressFiles 9\n");
    }
    fprintf(stderr, "[brotli/c/tools/brotli.c] enter CompressFiles 10\n");
    if (context->input_file_length > 0) {
      fprintf(stderr, "[brotli/c/tools/brotli.c] enter CompressFiles 11\n");
      uint32_t size_hint = context->input_file_length < (1 << 30) ?
          (uint32_t)context->input_file_length : (1u << 30);
      BrotliEncoderSetParameter(s, BROTLI_PARAM_SIZE_HINT, size_hint);
      // fprintf(stderr, "[brotli/c/tools/brotli.c] exit CompressFiles 11\n");
    }
    fprintf(stderr, "[brotli/c/tools/brotli.c] enter CompressFiles 12\n");
    is_ok = OpenFiles(context);
    if (is_ok && !context->current_output_path &&
        !context->force_overwrite && isatty(STDOUT_FILENO)) {
      fprintf(stderr, "[brotli/c/tools/brotli.c] enter CompressFiles 13\n");
      fprintf(stderr, "Use -h help. Use -f to force output to a terminal.\n");
      is_ok = BROTLI_FALSE;
      // fprintf(stderr, "[brotli/c/tools/brotli.c] exit CompressFiles 13\n");
    }
    fprintf(stderr, "[brotli/c/tools/brotli.c] enter CompressFiles 14\n");
    if (is_ok) is_ok = CompressFile(context, s);
    BrotliEncoderDestroyInstance(s);
    if (!CloseFiles(context, is_ok)) is_ok = BROTLI_FALSE;
    if (!is_ok) return BROTLI_FALSE;
    // fprintf(stderr, "[brotli/c/tools/brotli.c] exit CompressFiles 14\n");
    // fprintf(stderr, "[brotli/c/tools/brotli.c] exit CompressFiles 12\n");
    // fprintf(stderr, "[brotli/c/tools/brotli.c] exit CompressFiles 10\n");
    // fprintf(stderr, "[brotli/c/tools/brotli.c] exit CompressFiles 6\n");
    // fprintf(stderr, "[brotli/c/tools/brotli.c] exit CompressFiles 4\n");
    // fprintf(stderr, "[brotli/c/tools/brotli.c] exit CompressFiles 2\n");
  }
  fprintf(stderr, "[brotli/c/tools/brotli.c] enter CompressFiles 15\n");
  return BROTLI_TRUE;
  // fprintf(stderr, "[brotli/c/tools/brotli.c] exit CompressFiles 15\n");
  // fprintf(stderr, "[brotli/c/tools/brotli.c] exit CompressFiles 1\n");
}

int main(int argc, char** argv) {
  fprintf(stderr, "[brotli/c/tools/brotli.c] enter main 1\n");
  Command command;
  Context context;
  BROTLI_BOOL is_ok = BROTLI_TRUE;
  int i;

  context.quality = 11;
  context.lgwin = -1;
  context.force_overwrite = BROTLI_FALSE;
  context.junk_source = BROTLI_FALSE;
  context.copy_stat = BROTLI_TRUE;
  context.test_integrity = BROTLI_FALSE;
  context.verbose = BROTLI_FALSE;
  context.write_to_stdout = BROTLI_FALSE;
  context.decompress = BROTLI_FALSE;
  context.output_path = NULL;
  context.suffix = DEFAULT_SUFFIX;
  for (i = 0; i < MAX_OPTIONS; ++i) context.not_input_indices[i] = 0;
  context.longest_path_len = 1;
  context.input_count = 0;

  context.argc = argc;
  context.argv = argv;
  context.modified_path = NULL;
  context.iterator = 0;
  context.ignore = 0;
  context.iterator_error = BROTLI_FALSE;
  context.buffer = NULL;
  context.current_input_path = NULL;
  context.current_output_path = NULL;
  context.fin = NULL;
  context.fout = NULL;

  command = ParseParams(&context);
  // fprintf(stderr, "[brotli/c/tools/brotli.c] exit main 1\n");

  if (command == COMMAND_COMPRESS || command == COMMAND_DECOMPRESS ||
      command == COMMAND_TEST_INTEGRITY) {
    fprintf(stderr, "[brotli/c/tools/brotli.c] enter main 2\n");
    if (is_ok) {
      fprintf(stderr, "[brotli/c/tools/brotli.c] enter main 3\n");
      size_t modified_path_len =
          context.longest_path_len + strlen(context.suffix) + 1;
      context.modified_path = (char*)malloc(modified_path_len);
      context.buffer = (uint8_t*)malloc(kFileBufferSize * 2);
      if (!context.modified_path || !context.buffer) {
        fprintf(stderr, "[brotli/c/tools/brotli.c] enter main 4\n");
        fprintf(stderr, "out of memory\n");
        is_ok = BROTLI_FALSE;
        // fprintf(stderr, "[brotli/c/tools/brotli.c] exit main 4\n");
      } else {
        fprintf(stderr, "[brotli/c/tools/brotli.c] enter main 5\n");
        context.input = context.buffer;
        context.output = context.buffer + kFileBufferSize;
        // fprintf(stderr, "[brotli/c/tools/brotli.c] exit main 5\n");
      }
      // fprintf(stderr, "[brotli/c/tools/brotli.c] exit main 3\n");
    }
    // fprintf(stderr, "[brotli/c/tools/brotli.c] exit main 2\n");
  }

  fprintf(stderr, "[brotli/c/tools/brotli.c] enter main 6\n");
  if (!is_ok) command = COMMAND_NOOP;
  // fprintf(stderr, "[brotli/c/tools/brotli.c] exit main 6\n");

  switch (command) {
    case COMMAND_NOOP:
      fprintf(stderr, "[brotli/c/tools/brotli.c] enter main 7\n");
      break;
      // fprintf(stderr, "[brotli/c/tools/brotli.c] exit main 7\n");

    case COMMAND_VERSION:
      fprintf(stderr, "[brotli/c/tools/brotli.c] enter main 8\n");
      PrintVersion();
      break;
      // fprintf(stderr, "[brotli/c/tools/brotli.c] exit main 8\n");

    case COMMAND_COMPRESS:
      fprintf(stderr, "[brotli/c/tools/brotli.c] enter main 9\n");
      is_ok = CompressFiles(&context);
      break;
      // fprintf(stderr, "[brotli/c/tools/brotli.c] exit main 9\n");

    case COMMAND_DECOMPRESS:
    case COMMAND_TEST_INTEGRITY:
      fprintf(stderr, "[brotli/c/tools/brotli.c] enter main 10\n");
      is_ok = DecompressFiles(&context);
      break;
      // fprintf(stderr, "[brotli/c/tools/brotli.c] exit main 10\n");

    case COMMAND_HELP:
    case COMMAND_INVALID:
    default:
      fprintf(stderr, "[brotli/c/tools/brotli.c] enter main 11\n");
      PrintHelp(FileName(argv[0]));
      is_ok = (command == COMMAND_HELP);
      break;
      // fprintf(stderr, "[brotli/c/tools/brotli.c] exit main 11\n");
  }

  fprintf(stderr, "[brotli/c/tools/brotli.c] enter main 12\n");
  if (context.iterator_error) is_ok = BROTLI_FALSE;

  free(context.modified_path);
  free(context.buffer);

  if (!is_ok) exit(1);
  return 0;
  // fprintf(stderr, "[brotli/c/tools/brotli.c] exit main 12\n");
}
// Total cost: 0.560733
// Total split cost: 0.057016, input tokens: 13510, output tokens: 672, cache read tokens: 13501, cache write tokens: 11429, split chunks: [(0, 789), (789, 924)]
// Total instrumented cost: 0.503717, input tokens: 31793, output tokens: 27686, cache read tokens: 31765, cache write tokens: 21017
