#include <stdio.h>
/* NOLINT(build/header_guard) */
/* Copyright 2010 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

/* template parameters: FN */

/* A (forgetful) hash table to the data seen by the compressor, to
   help create backward references to previous data.

   This is a hash map of fixed size (bucket_size_) to a ring buffer of
   fixed size (block_size_). The ring buffer contains the last block_size_
   index positions of the given hash key in the compressed data. */

#define HashLongestMatch HASHER()

static BROTLI_INLINE size_t FN(HashTypeLength)(void) { return 4; }
static BROTLI_INLINE size_t FN(StoreLookahead)(void) { return 4; }

/* HashBytes is the function that chooses the bucket to place the address in. */
static uint32_t FN(HashBytes)(const uint8_t* data, const int shift) {
  fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] enter FN(HashBytes) 1\n");
  uint32_t h = BROTLI_UNALIGNED_LOAD32LE(data) * kHashMul32;
  /* The higher bits contain more mixture from the multiplication,
     so we take our results from there. */
  return (uint32_t)(h >> shift);
  // fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] exit FN(HashBytes) 1\n");
}

typedef struct HashLongestMatch {
  /* Number of hash buckets. */
  size_t bucket_size_;
  /* Only block_size_ newest backward references are kept,
     and the older are forgotten. */
  size_t block_size_;
  /* Left-shift for computing hash bucket index from hash value. */
  int hash_shift_;
  /* Mask for accessing entries in a block (in a ring-buffer manner). */
  uint32_t block_mask_;

  /* --- Dynamic size members --- */

  /* Number of entries in a particular bucket. */
  /* uint16_t num[bucket_size]; */

  /* Buckets containing block_size_ of backward references. */
  /* uint32_t* buckets[bucket_size * block_size]; */
} HashLongestMatch;

static BROTLI_INLINE HashLongestMatch* FN(Self)(HasherHandle handle) {
  fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] enter FN(Self) 1\n");
  return (HashLongestMatch*)&(GetHasherCommon(handle)[1]);
  // fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] exit FN(Self) 1\n");
}

static BROTLI_INLINE uint16_t* FN(Num)(HashLongestMatch* self) {
  fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] enter FN(Num) 1\n");
  return (uint16_t*)(&self[1]);
  // fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] exit FN(Num) 1\n");
}

static BROTLI_INLINE uint32_t* FN(Buckets)(HashLongestMatch* self) {
  fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] enter FN(Buckets) 1\n");
  return (uint32_t*)(&FN(Num)(self)[self->bucket_size_]);
  // fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] exit FN(Buckets) 1\n");
}

static void FN(Initialize)(
    HasherHandle handle, const BrotliEncoderParams* params) {
  fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] enter FN(Initialize) 1\n");
  HasherCommon* common = GetHasherCommon(handle);
  HashLongestMatch* self = FN(Self)(handle);
  BROTLI_UNUSED(params);
  self->hash_shift_ = 32 - common->params.bucket_bits;
  self->bucket_size_ = (size_t)1 << common->params.bucket_bits;
  self->block_size_ = (size_t)1 << common->params.block_bits;
  self->block_mask_ = (uint32_t)(self->block_size_ - 1);
  // fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] exit FN(Initialize) 1\n");
}

static void FN(Prepare)(HasherHandle handle, BROTLI_BOOL one_shot,
    size_t input_size, const uint8_t* data) {
  fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] enter FN(Prepare) 1\n");
  HashLongestMatch* self = FN(Self)(handle);
  uint16_t* num = FN(Num)(self);
  /* Partial preparation is 100 times slower (per socket). */
  size_t partial_prepare_threshold = self->bucket_size_ >> 6;
  // fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] exit FN(Prepare) 1\n");
  if (one_shot && input_size <= partial_prepare_threshold) {
    fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] enter FN(Prepare) 2\n");
    size_t i;
    for (i = 0; i < input_size; ++i) {
      fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] enter FN(Prepare) 3\n");
      const uint32_t key = FN(HashBytes)(&data[i], self->hash_shift_);
      num[key] = 0;
      // fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] exit FN(Prepare) 3\n");
    }
    // fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] exit FN(Prepare) 2\n");
  } else {
    fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] enter FN(Prepare) 4\n");
    memset(num, 0, self->bucket_size_ * sizeof(num[0]));
    // fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] exit FN(Prepare) 4\n");
  }
}

static BROTLI_INLINE size_t FN(HashMemAllocInBytes)(
    const BrotliEncoderParams* params, BROTLI_BOOL one_shot,
    size_t input_size) {
  fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] enter FN(HashMemAllocInBytes) 1\n");
  size_t bucket_size = (size_t)1 << params->hasher.bucket_bits;
  size_t block_size = (size_t)1 << params->hasher.block_bits;
  BROTLI_UNUSED(one_shot);
  BROTLI_UNUSED(input_size);
  return sizeof(HashLongestMatch) + bucket_size * (2 + 4 * block_size);
  // fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] exit FN(HashMemAllocInBytes) 1\n");
}

/* Look at 4 bytes at &data[ix & mask].
   Compute a hash from these, and store the value of ix at that position. */
static BROTLI_INLINE void FN(Store)(HasherHandle handle, const uint8_t* data,
    const size_t mask, const size_t ix) {
  fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] enter FN(Store) 1\n");
  HashLongestMatch* self = FN(Self)(handle);
  uint16_t* num = FN(Num)(self);
  const uint32_t key = FN(HashBytes)(&data[ix & mask], self->hash_shift_);
  const size_t minor_ix = num[key] & self->block_mask_;
  const size_t offset =
      minor_ix + (key << GetHasherCommon(handle)->params.block_bits);
  FN(Buckets)(self)[offset] = (uint32_t)ix;
  ++num[key];
  // fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] exit FN(Store) 1\n");
}

static BROTLI_INLINE void FN(StoreRange)(HasherHandle handle,
    const uint8_t* data, const size_t mask, const size_t ix_start,
    const size_t ix_end) {
  fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] enter FN(StoreRange) 1\n");
  size_t i;
  for (i = ix_start; i < ix_end; ++i) {
    fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] enter FN(StoreRange) 2\n");
    FN(Store)(handle, data, mask, i);
    // fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] exit FN(StoreRange) 2\n");
  }
  // fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] exit FN(StoreRange) 1\n");
}

static BROTLI_INLINE void FN(StitchToPreviousBlock)(HasherHandle handle,
    size_t num_bytes, size_t position, const uint8_t* ringbuffer,
    size_t ringbuffer_mask) {
  fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] enter FN(StitchToPreviousBlock) 1\n");
  if (num_bytes >= FN(HashTypeLength)() - 1 && position >= 3) {
    fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] enter FN(StitchToPreviousBlock) 2\n");
    /* Prepare the hashes for three last bytes of the last write.
       These could not be calculated before, since they require knowledge
       of both the previous and the current block. */
    FN(Store)(handle, ringbuffer, ringbuffer_mask, position - 3);
    FN(Store)(handle, ringbuffer, ringbuffer_mask, position - 2);
    FN(Store)(handle, ringbuffer, ringbuffer_mask, position - 1);
    // fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] exit FN(StitchToPreviousBlock) 2\n");
  }
  // fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] exit FN(StitchToPreviousBlock) 1\n");
}

static BROTLI_INLINE void FN(PrepareDistanceCache)(
    HasherHandle handle, int* BROTLI_RESTRICT distance_cache) {
  fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] enter FN(PrepareDistanceCache) 1\n");
  PrepareDistanceCache(distance_cache,
      GetHasherCommon(handle)->params.num_last_distances_to_check);
  // fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] exit FN(PrepareDistanceCache) 1\n");
}

/* Find a longest backward match of &data[cur_ix] up to the length of
   max_length and stores the position cur_ix in the hash table.

   REQUIRES: FN(PrepareDistanceCache) must be invoked for current distance cache
             values; if this method is invoked repeatedly with the same distance
             cache values, it is enough to invoke FN(PrepareDistanceCache) once.

   Does not look for matches longer than max_length.
   Does not look for matches further away than max_backward.
   Writes the best match into |out|.
   |out|->score is updated only if a better match is found. */
static BROTLI_INLINE void FN(FindLongestMatch)(HasherHandle handle,
    const BrotliEncoderDictionary* dictionary,
    const uint8_t* BROTLI_RESTRICT data, const size_t ring_buffer_mask,
    const int* BROTLI_RESTRICT distance_cache, const size_t cur_ix,
    const size_t max_length, const size_t max_backward, const size_t gap,
    const size_t max_distance, HasherSearchResult* BROTLI_RESTRICT out) {
  fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] enter FN(FindLongestMatch) 1\n");
  HasherCommon* common = GetHasherCommon(handle);
  HashLongestMatch* self = FN(Self)(handle);
  uint16_t* num = FN(Num)(self);
  uint32_t* buckets = FN(Buckets)(self);
  const size_t cur_ix_masked = cur_ix & ring_buffer_mask;
  /* Don't accept a short copy from far away. */
  score_t min_score = out->score;
  score_t best_score = out->score;
  size_t best_len = out->len;
  size_t i;
  out->len = 0;
  out->len_code_delta = 0;
  // fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] exit FN(FindLongestMatch) 1\n");
  /* Try last distance first. */
  for (i = 0; i < (size_t)common->params.num_last_distances_to_check; ++i) {
    fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] enter FN(FindLongestMatch) 2\n");
    const size_t backward = (size_t)distance_cache[i];
    size_t prev_ix = (size_t)(cur_ix - backward);
    // fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] exit FN(FindLongestMatch) 2\n");
    if (prev_ix >= cur_ix) {
      fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] enter FN(FindLongestMatch) 3\n");
      continue;
      // fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] exit FN(FindLongestMatch) 3\n");
    }
    if (BROTLI_PREDICT_FALSE(backward > max_backward)) {
      fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] enter FN(FindLongestMatch) 4\n");
      continue;
      // fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] exit FN(FindLongestMatch) 4\n");
    }
    prev_ix &= ring_buffer_mask;

    if (cur_ix_masked + best_len > ring_buffer_mask ||
        prev_ix + best_len > ring_buffer_mask ||
        data[cur_ix_masked + best_len] != data[prev_ix + best_len]) {
      fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] enter FN(FindLongestMatch) 5\n");
      continue;
      // fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] exit FN(FindLongestMatch) 5\n");
    }
    {
      fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] enter FN(FindLongestMatch) 6\n");
      const size_t len = FindMatchLengthWithLimit(&data[prev_ix],
                                                  &data[cur_ix_masked],
                                                  max_length);
      // fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] exit FN(FindLongestMatch) 6\n");
      if (len >= 3 || (len == 2 && i < 2)) {
        fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] enter FN(FindLongestMatch) 7\n");
        /* Comparing for >= 2 does not change the semantics, but just saves for
           a few unnecessary binary logarithms in backward reference score,
           since we are not interested in such short matches. */
        score_t score = BackwardReferenceScoreUsingLastDistance(len);
        // fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] exit FN(FindLongestMatch) 7\n");
        if (best_score < score) {
          fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] enter FN(FindLongestMatch) 8\n");
          if (i != 0) score -= BackwardReferencePenaltyUsingLastDistance(i);
          // fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] exit FN(FindLongestMatch) 8\n");
          if (best_score < score) {
            fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] enter FN(FindLongestMatch) 9\n");
            best_score = score;
            best_len = len;
            out->len = best_len;
            out->distance = backward;
            out->score = best_score;
            // fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] exit FN(FindLongestMatch) 9\n");
          }
        }
      }
    }
  }
  {
    fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] enter FN(FindLongestMatch) 10\n");
    const uint32_t key =
        FN(HashBytes)(&data[cur_ix_masked], self->hash_shift_);
    uint32_t* BROTLI_RESTRICT bucket =
        &buckets[key << common->params.block_bits];
    const size_t down =
        (num[key] > self->block_size_) ? (num[key] - self->block_size_) : 0u;
    // fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] exit FN(FindLongestMatch) 10\n");
    for (i = num[key]; i > down;) {
      fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] enter FN(FindLongestMatch) 11\n");
      size_t prev_ix = bucket[--i & self->block_mask_];
      const size_t backward = cur_ix - prev_ix;
      // fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] exit FN(FindLongestMatch) 11\n");
      if (BROTLI_PREDICT_FALSE(backward > max_backward)) {
        fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] enter FN(FindLongestMatch) 12\n");
        break;
        // fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] exit FN(FindLongestMatch) 12\n");
      }
      prev_ix &= ring_buffer_mask;
      if (cur_ix_masked + best_len > ring_buffer_mask ||
          prev_ix + best_len > ring_buffer_mask ||
          data[cur_ix_masked + best_len] != data[prev_ix + best_len]) {
        fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] enter FN(FindLongestMatch) 13\n");
        continue;
        // fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] exit FN(FindLongestMatch) 13\n");
      }
      {
        fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] enter FN(FindLongestMatch) 14\n");
        const size_t len = FindMatchLengthWithLimit(&data[prev_ix],
                                                    &data[cur_ix_masked],
                                                    max_length);
        // fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] exit FN(FindLongestMatch) 14\n");
        if (len >= 4) {
          fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] enter FN(FindLongestMatch) 15\n");
          /* Comparing for >= 3 does not change the semantics, but just saves
             for a few unnecessary binary logarithms in backward reference
             score, since we are not interested in such short matches. */
          score_t score = BackwardReferenceScore(len, backward);
          // fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] exit FN(FindLongestMatch) 15\n");
          if (best_score < score) {
            fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] enter FN(FindLongestMatch) 16\n");
            best_score = score;
            best_len = len;
            out->len = best_len;
            out->distance = backward;
            out->score = best_score;
            // fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] exit FN(FindLongestMatch) 16\n");
          }
        }
      }
    }
    fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] enter FN(FindLongestMatch) 17\n");
    bucket[num[key] & self->block_mask_] = (uint32_t)cur_ix;
    ++num[key];
    // fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] exit FN(FindLongestMatch) 17\n");
  }
  if (min_score == out->score) {
    fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] enter FN(FindLongestMatch) 18\n");
    SearchInStaticDictionary(dictionary,
        handle, &data[cur_ix_masked], max_length, max_backward + gap,
        max_distance, out, BROTLI_FALSE);
    // fprintf(stderr, "[brotli/c/enc/hash_longest_match_inc.h] exit FN(FindLongestMatch) 18\n");
  }
}

#undef HashLongestMatch
// Total cost: 0.086616
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 258)]
// Total instrumented cost: 0.086616, input tokens: 2398, output tokens: 4862, cache read tokens: 2394, cache write tokens: 3455
