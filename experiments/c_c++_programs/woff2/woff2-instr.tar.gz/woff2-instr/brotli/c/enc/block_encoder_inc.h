/* NOLINT(build/header_guard) */
/* Copyright 2014 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

/* template parameters: FN */

#define HistogramType FN(Histogram)

/* Creates entropy codes for all block types and stores them to the bit
   stream. */
static void FN(BuildAndStoreEntropyCodes)(MemoryManager* m, BlockEncoder* self,
    const HistogramType* histograms, const size_t histograms_size,
    const size_t alphabet_size, HuffmanTree* tree,
    size_t* storage_ix, uint8_t* storage) {
  fprintf(stderr, "[brotli/c/enc/block_encoder_inc.h] enter FN(BuildAndStoreEntropyCodes) 1\n");
  const size_t table_size = histograms_size * self->histogram_length_;
  self->depths_ = BROTLI_ALLOC(m, uint8_t, table_size);
  self->bits_ = BROTLI_ALLOC(m, uint16_t, table_size);
  if (BROTLI_IS_OOM(m)) {
    fprintf(stderr, "[brotli/c/enc/block_encoder_inc.h] enter FN(BuildAndStoreEntropyCodes) 2\n");
    return;
    // fprintf(stderr, "[brotli/c/enc/block_encoder_inc.h] exit FN(BuildAndStoreEntropyCodes) 2\n");
  }

  {
    fprintf(stderr, "[brotli/c/enc/block_encoder_inc.h] enter FN(BuildAndStoreEntropyCodes) 3\n");
    size_t i;
    for (i = 0; i < histograms_size; ++i) {
      fprintf(stderr, "[brotli/c/enc/block_encoder_inc.h] enter FN(BuildAndStoreEntropyCodes) 4\n");
      size_t ix = i * self->histogram_length_;
      BuildAndStoreHuffmanTree(&histograms[i].data_[0], self->histogram_length_,
          alphabet_size, tree, &self->depths_[ix], &self->bits_[ix],
          storage_ix, storage);
      // fprintf(stderr, "[brotli/c/enc/block_encoder_inc.h] exit FN(BuildAndStoreEntropyCodes) 4\n");
    }
    // fprintf(stderr, "[brotli/c/enc/block_encoder_inc.h] exit FN(BuildAndStoreEntropyCodes) 3\n");
  }
  // fprintf(stderr, "[brotli/c/enc/block_encoder_inc.h] exit FN(BuildAndStoreEntropyCodes) 1\n");
}

#undef HistogramType
// Total cost: 0.012003
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 34)]
// Total instrumented cost: 0.012003, input tokens: 2398, output tokens: 630, cache read tokens: 2394, cache write tokens: 486
