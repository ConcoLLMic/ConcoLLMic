/* NOLINT(build/header_guard) */
/* Copyright 2015 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

/* template parameters: FN */

#include <stdio.h>

#define HistogramType FN(Histogram)

/* Greedy block splitter for one block category (literal, command or distance).
*/
typedef struct FN(BlockSplitter) {
  /* Alphabet size of particular block category. */
  size_t alphabet_size_;
  /* We collect at least this many symbols for each block. */
  size_t min_block_size_;
  /* We merge histograms A and B if
       entropy(A+B) < entropy(A) + entropy(B) + split_threshold_,
     where A is the current histogram and B is the histogram of the last or the
     second last block type. */
  double split_threshold_;

  size_t num_blocks_;
  BlockSplit* split_;  /* not owned */
  HistogramType* histograms_;  /* not owned */
  size_t* histograms_size_;  /* not owned */

  /* The number of symbols that we want to collect before deciding on whether
     or not to merge the block with a previous one or emit a new block. */
  size_t target_block_size_;
  /* The number of symbols in the current histogram. */
  size_t block_size_;
  /* Offset of the current histogram. */
  size_t curr_histogram_ix_;
  /* Offset of the histograms of the previous two block types. */
  size_t last_histogram_ix_[2];
  /* Entropy of the previous two block types. */
  double last_entropy_[2];
  /* The number of times we merged the current block with the last one. */
  size_t merge_last_count_;
} FN(BlockSplitter);

static void FN(InitBlockSplitter)(
    MemoryManager* m, FN(BlockSplitter)* self, size_t alphabet_size,
    size_t min_block_size, double split_threshold, size_t num_symbols,
    BlockSplit* split, HistogramType** histograms, size_t* histograms_size) {
  fprintf(stderr, "[brotli/c/enc/metablock_inc.h] enter FN(InitBlockSplitter) 1\n");
  size_t max_num_blocks = num_symbols / min_block_size + 1;
  /* We have to allocate one more histogram than the maximum number of block
     types for the current histogram when the meta-block is too big. */
  size_t max_num_types =
      BROTLI_MIN(size_t, max_num_blocks, BROTLI_MAX_NUMBER_OF_BLOCK_TYPES + 1);
  self->alphabet_size_ = alphabet_size;
  self->min_block_size_ = min_block_size;
  self->split_threshold_ = split_threshold;
  self->num_blocks_ = 0;
  self->split_ = split;
  self->histograms_size_ = histograms_size;
  self->target_block_size_ = min_block_size;
  self->block_size_ = 0;
  self->curr_histogram_ix_ = 0;
  self->merge_last_count_ = 0;
  BROTLI_ENSURE_CAPACITY(m, uint8_t,
      split->types, split->types_alloc_size, max_num_blocks);
  BROTLI_ENSURE_CAPACITY(m, uint32_t,
      split->lengths, split->lengths_alloc_size, max_num_blocks);
  if (BROTLI_IS_OOM(m)) return;
  // fprintf(stderr, "[brotli/c/enc/metablock_inc.h] exit FN(InitBlockSplitter) 1\n");
  
  fprintf(stderr, "[brotli/c/enc/metablock_inc.h] enter FN(InitBlockSplitter) 2\n");
  self->split_->num_blocks = max_num_blocks;
  BROTLI_DCHECK(*histograms == 0);
  *histograms_size = max_num_types;
  *histograms = BROTLI_ALLOC(m, HistogramType, *histograms_size);
  self->histograms_ = *histograms;
  if (BROTLI_IS_OOM(m)) return;
  // fprintf(stderr, "[brotli/c/enc/metablock_inc.h] exit FN(InitBlockSplitter) 2\n");
  
  fprintf(stderr, "[brotli/c/enc/metablock_inc.h] enter FN(InitBlockSplitter) 3\n");
  /* Clear only current histogram. */
  FN(HistogramClear)(&self->histograms_[0]);
  self->last_histogram_ix_[0] = self->last_histogram_ix_[1] = 0;
  // fprintf(stderr, "[brotli/c/enc/metablock_inc.h] exit FN(InitBlockSplitter) 3\n");
}

/* Does either of three things:
     (1) emits the current block with a new block type;
     (2) emits the current block with the type of the second last block;
     (3) merges the current block with the last block. */
static void FN(BlockSplitterFinishBlock)(
    FN(BlockSplitter)* self, BROTLI_BOOL is_final) {
  fprintf(stderr, "[brotli/c/enc/metablock_inc.h] enter FN(BlockSplitterFinishBlock) 1\n");
  BlockSplit* split = self->split_;
  double* last_entropy = self->last_entropy_;
  HistogramType* histograms = self->histograms_;
  self->block_size_ =
      BROTLI_MAX(size_t, self->block_size_, self->min_block_size_);
  // fprintf(stderr, "[brotli/c/enc/metablock_inc.h] exit FN(BlockSplitterFinishBlock) 1\n");
  
  if (self->num_blocks_ == 0) {
    fprintf(stderr, "[brotli/c/enc/metablock_inc.h] enter FN(BlockSplitterFinishBlock) 2\n");
    /* Create first block. */
    split->lengths[0] = (uint32_t)self->block_size_;
    split->types[0] = 0;
    last_entropy[0] =
        BitsEntropy(histograms[0].data_, self->alphabet_size_);
    last_entropy[1] = last_entropy[0];
    ++self->num_blocks_;
    ++split->num_types;
    ++self->curr_histogram_ix_;
    if (self->curr_histogram_ix_ < *self->histograms_size_)
      FN(HistogramClear)(&histograms[self->curr_histogram_ix_]);
    self->block_size_ = 0;
    // fprintf(stderr, "[brotli/c/enc/metablock_inc.h] exit FN(BlockSplitterFinishBlock) 2\n");
  } else if (self->block_size_ > 0) {
    fprintf(stderr, "[brotli/c/enc/metablock_inc.h] enter FN(BlockSplitterFinishBlock) 3\n");
    double entropy = BitsEntropy(histograms[self->curr_histogram_ix_].data_,
                                 self->alphabet_size_);
    HistogramType combined_histo[2];
    double combined_entropy[2];
    double diff[2];
    size_t j;
    // fprintf(stderr, "[brotli/c/enc/metablock_inc.h] exit FN(BlockSplitterFinishBlock) 3\n");
    
    for (j = 0; j < 2; ++j) {
      fprintf(stderr, "[brotli/c/enc/metablock_inc.h] enter FN(BlockSplitterFinishBlock) 4\n");
      size_t last_histogram_ix = self->last_histogram_ix_[j];
      combined_histo[j] = histograms[self->curr_histogram_ix_];
      FN(HistogramAddHistogram)(&combined_histo[j],
          &histograms[last_histogram_ix]);
      combined_entropy[j] = BitsEntropy(
          &combined_histo[j].data_[0], self->alphabet_size_);
      diff[j] = combined_entropy[j] - entropy - last_entropy[j];
      // fprintf(stderr, "[brotli/c/enc/metablock_inc.h] exit FN(BlockSplitterFinishBlock) 4\n");
    }

    if (split->num_types < BROTLI_MAX_NUMBER_OF_BLOCK_TYPES &&
        diff[0] > self->split_threshold_ &&
        diff[1] > self->split_threshold_) {
      fprintf(stderr, "[brotli/c/enc/metablock_inc.h] enter FN(BlockSplitterFinishBlock) 5\n");
      /* Create new block. */
      split->lengths[self->num_blocks_] = (uint32_t)self->block_size_;
      split->types[self->num_blocks_] = (uint8_t)split->num_types;
      self->last_histogram_ix_[1] = self->last_histogram_ix_[0];
      self->last_histogram_ix_[0] = (uint8_t)split->num_types;
      last_entropy[1] = last_entropy[0];
      last_entropy[0] = entropy;
      ++self->num_blocks_;
      ++split->num_types;
      ++self->curr_histogram_ix_;
      if (self->curr_histogram_ix_ < *self->histograms_size_)
        FN(HistogramClear)(&histograms[self->curr_histogram_ix_]);
      self->block_size_ = 0;
      self->merge_last_count_ = 0;
      self->target_block_size_ = self->min_block_size_;
      // fprintf(stderr, "[brotli/c/enc/metablock_inc.h] exit FN(BlockSplitterFinishBlock) 5\n");
    } else if (diff[1] < diff[0] - 20.0) {
      fprintf(stderr, "[brotli/c/enc/metablock_inc.h] enter FN(BlockSplitterFinishBlock) 6\n");
      /* Combine this block with second last block. */
      split->lengths[self->num_blocks_] = (uint32_t)self->block_size_;
      split->types[self->num_blocks_] = split->types[self->num_blocks_ - 2];
      BROTLI_SWAP(size_t, self->last_histogram_ix_, 0, 1);
      histograms[self->last_histogram_ix_[0]] = combined_histo[1];
      last_entropy[1] = last_entropy[0];
      last_entropy[0] = combined_entropy[1];
      ++self->num_blocks_;
      self->block_size_ = 0;
      FN(HistogramClear)(&histograms[self->curr_histogram_ix_]);
      self->merge_last_count_ = 0;
      self->target_block_size_ = self->min_block_size_;
      // fprintf(stderr, "[brotli/c/enc/metablock_inc.h] exit FN(BlockSplitterFinishBlock) 6\n");
    } else {
      fprintf(stderr, "[brotli/c/enc/metablock_inc.h] enter FN(BlockSplitterFinishBlock) 7\n");
      /* Combine this block with last block. */
      split->lengths[self->num_blocks_ - 1] += (uint32_t)self->block_size_;
      histograms[self->last_histogram_ix_[0]] = combined_histo[0];
      last_entropy[0] = combined_entropy[0];
      if (split->num_types == 1) {
        last_entropy[1] = last_entropy[0];
      }
      self->block_size_ = 0;
      FN(HistogramClear)(&histograms[self->curr_histogram_ix_]);
      if (++self->merge_last_count_ > 1) {
        self->target_block_size_ += self->min_block_size_;
      }
      // fprintf(stderr, "[brotli/c/enc/metablock_inc.h] exit FN(BlockSplitterFinishBlock) 7\n");
    }
  }
  
  if (is_final) {
    fprintf(stderr, "[brotli/c/enc/metablock_inc.h] enter FN(BlockSplitterFinishBlock) 8\n");
    *self->histograms_size_ = split->num_types;
    split->num_blocks = self->num_blocks_;
    // fprintf(stderr, "[brotli/c/enc/metablock_inc.h] exit FN(BlockSplitterFinishBlock) 8\n");
  }
}

/* Adds the next symbol to the current histogram. When the current histogram
   reaches the target size, decides on merging the block. */
static void FN(BlockSplitterAddSymbol)(FN(BlockSplitter)* self, size_t symbol) {
  fprintf(stderr, "[brotli/c/enc/metablock_inc.h] enter FN(BlockSplitterAddSymbol) 1\n");
  FN(HistogramAdd)(&self->histograms_[self->curr_histogram_ix_], symbol);
  ++self->block_size_;
  if (self->block_size_ == self->target_block_size_) {
    FN(BlockSplitterFinishBlock)(self, /* is_final = */ BROTLI_FALSE);
  }
  // fprintf(stderr, "[brotli/c/enc/metablock_inc.h] exit FN(BlockSplitterAddSymbol) 1\n");
}

#undef HistogramType
// Total cost: 0.060269
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 183)]
// Total instrumented cost: 0.060269, input tokens: 2398, output tokens: 3281, cache read tokens: 2394, cache write tokens: 2753
