/* NOLINT(build/header_guard) */
/* Copyright 2013 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

/* template parameters: FN */

#include <stdio.h>

#define HistogramType FN(Histogram)

double FN(BrotliPopulationCost)(const HistogramType* histogram) {
  fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] enter BrotliPopulationCost 1\n");
  static const double kOneSymbolHistogramCost = 12;
  static const double kTwoSymbolHistogramCost = 20;
  static const double kThreeSymbolHistogramCost = 28;
  static const double kFourSymbolHistogramCost = 37;
  const size_t data_size = FN(HistogramDataSize)();
  int count = 0;
  size_t s[5];
  double bits = 0.0;
  size_t i;
  // fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] exit BrotliPopulationCost 1\n");
  
  if (histogram->total_count_ == 0) {
    fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] enter BrotliPopulationCost 2\n");
    return kOneSymbolHistogramCost;
    // fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] exit BrotliPopulationCost 2\n");
  }
  
  fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] enter BrotliPopulationCost 3\n");
  for (i = 0; i < data_size; ++i) {
    fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] enter BrotliPopulationCost 4\n");
    if (histogram->data_[i] > 0) {
      fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] enter BrotliPopulationCost 5\n");
      s[count] = i;
      ++count;
      if (count > 4) break;
      // fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] exit BrotliPopulationCost 5\n");
    }
    // fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] exit BrotliPopulationCost 4\n");
  }
  // fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] exit BrotliPopulationCost 3\n");
  
  if (count == 1) {
    fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] enter BrotliPopulationCost 6\n");
    return kOneSymbolHistogramCost;
    // fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] exit BrotliPopulationCost 6\n");
  }
  
  if (count == 2) {
    fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] enter BrotliPopulationCost 7\n");
    return (kTwoSymbolHistogramCost + (double)histogram->total_count_);
    // fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] exit BrotliPopulationCost 7\n");
  }
  
  if (count == 3) {
    fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] enter BrotliPopulationCost 8\n");
    const uint32_t histo0 = histogram->data_[s[0]];
    const uint32_t histo1 = histogram->data_[s[1]];
    const uint32_t histo2 = histogram->data_[s[2]];
    const uint32_t histomax =
        BROTLI_MAX(uint32_t, histo0, BROTLI_MAX(uint32_t, histo1, histo2));
    return (kThreeSymbolHistogramCost +
            2 * (histo0 + histo1 + histo2) - histomax);
    // fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] exit BrotliPopulationCost 8\n");
  }
  
  if (count == 4) {
    fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] enter BrotliPopulationCost 9\n");
    uint32_t histo[4];
    uint32_t h23;
    uint32_t histomax;
    for (i = 0; i < 4; ++i) {
      fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] enter BrotliPopulationCost 10\n");
      histo[i] = histogram->data_[s[i]];
      // fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] exit BrotliPopulationCost 10\n");
    }
    /* Sort */
    for (i = 0; i < 4; ++i) {
      fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] enter BrotliPopulationCost 11\n");
      size_t j;
      for (j = i + 1; j < 4; ++j) {
        fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] enter BrotliPopulationCost 12\n");
        if (histo[j] > histo[i]) {
          fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] enter BrotliPopulationCost 13\n");
          BROTLI_SWAP(uint32_t, histo, j, i);
          // fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] exit BrotliPopulationCost 13\n");
        }
        // fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] exit BrotliPopulationCost 12\n");
      }
      // fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] exit BrotliPopulationCost 11\n");
    }
    h23 = histo[2] + histo[3];
    histomax = BROTLI_MAX(uint32_t, h23, histo[0]);
    return (kFourSymbolHistogramCost +
            3 * h23 + 2 * (histo[0] + histo[1]) - histomax);
    // fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] exit BrotliPopulationCost 9\n");
  }

  {
    fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] enter BrotliPopulationCost 14\n");
    /* In this loop we compute the entropy of the histogram and simultaneously
       build a simplified histogram of the code length codes where we use the
       zero repeat code 17, but we don't use the non-zero repeat code 16. */
    size_t max_depth = 1;
    uint32_t depth_histo[BROTLI_CODE_LENGTH_CODES] = { 0 };
    const double log2total = FastLog2(histogram->total_count_);
    for (i = 0; i < data_size;) {
      fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] enter BrotliPopulationCost 15\n");
      if (histogram->data_[i] > 0) {
        fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] enter BrotliPopulationCost 16\n");
        /* Compute -log2(P(symbol)) = -log2(count(symbol)/total_count) =
                                    = log2(total_count) - log2(count(symbol)) */
        double log2p = log2total - FastLog2(histogram->data_[i]);
        /* Approximate the bit depth by round(-log2(P(symbol))) */
        size_t depth = (size_t)(log2p + 0.5);
        bits += histogram->data_[i] * log2p;
        if (depth > 15) {
          fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] enter BrotliPopulationCost 17\n");
          depth = 15;
          // fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] exit BrotliPopulationCost 17\n");
        }
        if (depth > max_depth) {
          fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] enter BrotliPopulationCost 18\n");
          max_depth = depth;
          // fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] exit BrotliPopulationCost 18\n");
        }
        ++depth_histo[depth];
        ++i;
        // fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] exit BrotliPopulationCost 16\n");
      } else {
        fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] enter BrotliPopulationCost 19\n");
        /* Compute the run length of zeros and add the appropriate number of 0
           and 17 code length codes to the code length code histogram. */
        uint32_t reps = 1;
        size_t k;
        for (k = i + 1; k < data_size && histogram->data_[k] == 0; ++k) {
          fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] enter BrotliPopulationCost 20\n");
          ++reps;
          // fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] exit BrotliPopulationCost 20\n");
        }
        i += reps;
        if (i == data_size) {
          fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] enter BrotliPopulationCost 21\n");
          /* Don't add any cost for the last zero run, since these are encoded
             only implicitly. */
          break;
          // fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] exit BrotliPopulationCost 21\n");
        }
        if (reps < 3) {
          fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] enter BrotliPopulationCost 22\n");
          depth_histo[0] += reps;
          // fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] exit BrotliPopulationCost 22\n");
        } else {
          fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] enter BrotliPopulationCost 23\n");
          reps -= 2;
          while (reps > 0) {
            fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] enter BrotliPopulationCost 24\n");
            ++depth_histo[BROTLI_REPEAT_ZERO_CODE_LENGTH];
            /* Add the 3 extra bits for the 17 code length code. */
            bits += 3;
            reps >>= 3;
            // fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] exit BrotliPopulationCost 24\n");
          }
          // fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] exit BrotliPopulationCost 23\n");
        }
        // fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] exit BrotliPopulationCost 19\n");
      }
      // fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] exit BrotliPopulationCost 15\n");
    }
    /* Add the estimated encoding cost of the code length code histogram. */
    bits += (double)(18 + 2 * max_depth);
    /* Add the entropy of the code length code histogram. */
    bits += BitsEntropy(depth_histo, BROTLI_CODE_LENGTH_CODES);
    // fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] exit BrotliPopulationCost 14\n");
  }
  
  fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] enter BrotliPopulationCost 25\n");
  return bits;
  // fprintf(stderr, "[brotli/c/enc/bit_cost_inc.h] exit BrotliPopulationCost 25\n");
}

#undef HistogramType
// Total cost: 0.046139
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 127)]
// Total instrumented cost: 0.046139, input tokens: 2398, output tokens: 2628, cache read tokens: 2394, cache write tokens: 1597
