#include <stdio.h>
/* NOLINT(build/header_guard) */
/* Copyright 2016 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

/* template parameters: FN, BUCKET_BITS, NUM_BANKS, BANK_BITS,
                        NUM_LAST_DISTANCES_TO_CHECK */

/* A (forgetful) hash table to the data seen by the compressor, to
   help create backward references to previous data.

   Hashes are stored in chains which are bucketed to groups. Group of chains
   share a storage "bank". When more than "bank size" chain nodes are added,
   oldest nodes are replaced; this way several chains may share a tail. */

#define HashForgetfulChain HASHER()

#define BANK_SIZE (1 << BANK_BITS)

/* Number of hash buckets. */
#define BUCKET_SIZE (1 << BUCKET_BITS)

#define CAPPED_CHAINS 0

static BROTLI_INLINE size_t FN(HashTypeLength)(void) { 
  fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] enter FN(HashTypeLength) 1\n");
  return 4; 
  // fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] exit FN(HashTypeLength) 1\n");
}

static BROTLI_INLINE size_t FN(StoreLookahead)(void) { 
  fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] enter FN(StoreLookahead) 1\n");
  return 4; 
  // fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] exit FN(StoreLookahead) 1\n");
}

/* HashBytes is the function that chooses the bucket to place the address in.*/
static BROTLI_INLINE size_t FN(HashBytes)(const uint8_t* data) {
  fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] enter FN(HashBytes) 1\n");
  const uint32_t h = BROTLI_UNALIGNED_LOAD32LE(data) * kHashMul32;
  /* The higher bits contain more mixture from the multiplication,
     so we take our results from there. */
  return h >> (32 - BUCKET_BITS);
  // fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] exit FN(HashBytes) 1\n");
}

typedef struct FN(Slot) {
  uint16_t delta;
  uint16_t next;
} FN(Slot);

typedef struct FN(Bank) {
  FN(Slot) slots[BANK_SIZE];
} FN(Bank);

typedef struct HashForgetfulChain {
  uint32_t addr[BUCKET_SIZE];
  uint16_t head[BUCKET_SIZE];
  /* Truncated hash used for quick rejection of "distance cache" candidates. */
  uint8_t tiny_hash[65536];
  FN(Bank) banks[NUM_BANKS];
  uint16_t free_slot_idx[NUM_BANKS];
  size_t max_hops;
} HashForgetfulChain;

static BROTLI_INLINE HashForgetfulChain* FN(Self)(HasherHandle handle) {
  fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] enter FN(Self) 1\n");
  return (HashForgetfulChain*)&(GetHasherCommon(handle)[1]);
  // fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] exit FN(Self) 1\n");
}

static void FN(Initialize)(
    HasherHandle handle, const BrotliEncoderParams* params) {
  fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] enter FN(Initialize) 1\n");
  FN(Self)(handle)->max_hops =
      (params->quality > 6 ? 7u : 8u) << (params->quality - 4);
  // fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] exit FN(Initialize) 1\n");
}

static void FN(Prepare)(HasherHandle handle, BROTLI_BOOL one_shot,
    size_t input_size, const uint8_t* data) {
  fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] enter FN(Prepare) 1\n");
  HashForgetfulChain* self = FN(Self)(handle);
  /* Partial preparation is 100 times slower (per socket). */
  size_t partial_prepare_threshold = BUCKET_SIZE >> 6;
  // fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] exit FN(Prepare) 1\n");
  
  if (one_shot && input_size <= partial_prepare_threshold) {
    fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] enter FN(Prepare) 2\n");
    size_t i;
    for (i = 0; i < input_size; ++i) {
      fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] enter FN(Prepare) 3\n");
      size_t bucket = FN(HashBytes)(&data[i]);
      /* See InitEmpty comment. */
      self->addr[bucket] = 0xCCCCCCCC;
      self->head[bucket] = 0xCCCC;
      // fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] exit FN(Prepare) 3\n");
    }
    // fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] exit FN(Prepare) 2\n");
  } else {
    fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] enter FN(Prepare) 4\n");
    /* Fill |addr| array with 0xCCCCCCCC value. Because of wrapping, position
       processed by hasher never reaches 3GB + 64M; this makes all new chains
       to be terminated after the first node. */
    memset(self->addr, 0xCC, sizeof(self->addr));
    memset(self->head, 0, sizeof(self->head));
    // fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] exit FN(Prepare) 4\n");
  }
  
  fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] enter FN(Prepare) 5\n");
  memset(self->tiny_hash, 0, sizeof(self->tiny_hash));
  memset(self->free_slot_idx, 0, sizeof(self->free_slot_idx));
  // fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] exit FN(Prepare) 5\n");
}

static BROTLI_INLINE size_t FN(HashMemAllocInBytes)(
    const BrotliEncoderParams* params, BROTLI_BOOL one_shot,
    size_t input_size) {
  fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] enter FN(HashMemAllocInBytes) 1\n");
  BROTLI_UNUSED(params);
  BROTLI_UNUSED(one_shot);
  BROTLI_UNUSED(input_size);
  return sizeof(HashForgetfulChain);
  // fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] exit FN(HashMemAllocInBytes) 1\n");
}

/* Look at 4 bytes at &data[ix & mask]. Compute a hash from these, and prepend
   node to corresponding chain; also update tiny_hash for current position. */
static BROTLI_INLINE void FN(Store)(HasherHandle BROTLI_RESTRICT handle,
    const uint8_t* BROTLI_RESTRICT data, const size_t mask, const size_t ix) {
  fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] enter FN(Store) 1\n");
  HashForgetfulChain* self = FN(Self)(handle);
  const size_t key = FN(HashBytes)(&data[ix & mask]);
  const size_t bank = key & (NUM_BANKS - 1);
  const size_t idx = self->free_slot_idx[bank]++ & (BANK_SIZE - 1);
  size_t delta = ix - self->addr[key];
  self->tiny_hash[(uint16_t)ix] = (uint8_t)key;
  // fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] exit FN(Store) 1\n");
  
  if (delta > 0xFFFF) {
    fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] enter FN(Store) 2\n");
    delta = CAPPED_CHAINS ? 0 : 0xFFFF;
    // fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] exit FN(Store) 2\n");
  }
  
  fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] enter FN(Store) 3\n");
  self->banks[bank].slots[idx].delta = (uint16_t)delta;
  self->banks[bank].slots[idx].next = self->head[key];
  self->addr[key] = (uint32_t)ix;
  self->head[key] = (uint16_t)idx;
  // fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] exit FN(Store) 3\n");
}

static BROTLI_INLINE void FN(StoreRange)(HasherHandle handle,
    const uint8_t* data, const size_t mask, const size_t ix_start,
    const size_t ix_end) {
  fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] enter FN(StoreRange) 1\n");
  size_t i;
  for (i = ix_start; i < ix_end; ++i) {
    fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] enter FN(StoreRange) 2\n");
    FN(Store)(handle, data, mask, i);
    // fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] exit FN(StoreRange) 2\n");
  }
  // fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] exit FN(StoreRange) 1\n");
}

static BROTLI_INLINE void FN(StitchToPreviousBlock)(HasherHandle handle,
    size_t num_bytes, size_t position, const uint8_t* ringbuffer,
    size_t ring_buffer_mask) {
  fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] enter FN(StitchToPreviousBlock) 1\n");
  if (num_bytes >= FN(HashTypeLength)() - 1 && position >= 3) {
    fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] enter FN(StitchToPreviousBlock) 2\n");
    /* Prepare the hashes for three last bytes of the last write.
       These could not be calculated before, since they require knowledge
       of both the previous and the current block. */
    FN(Store)(handle, ringbuffer, ring_buffer_mask, position - 3);
    FN(Store)(handle, ringbuffer, ring_buffer_mask, position - 2);
    FN(Store)(handle, ringbuffer, ring_buffer_mask, position - 1);
    // fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] exit FN(StitchToPreviousBlock) 2\n");
  }
  // fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] exit FN(StitchToPreviousBlock) 1\n");
}

static BROTLI_INLINE void FN(PrepareDistanceCache)(
    HasherHandle handle, int* BROTLI_RESTRICT distance_cache) {
  fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] enter FN(PrepareDistanceCache) 1\n");
  BROTLI_UNUSED(handle);
  PrepareDistanceCache(distance_cache, NUM_LAST_DISTANCES_TO_CHECK);
  // fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] exit FN(PrepareDistanceCache) 1\n");
}

/* Find a longest backward match of &data[cur_ix] up to the length of
   max_length and stores the position cur_ix in the hash table.

   REQUIRES: FN(PrepareDistanceCache) must be invoked for current distance cache
             values; if this method is invoked repeatedly with the same distance
             cache values, it is enough to invoke FN(PrepareDistanceCache) once.

   Does not look for matches longer than max_length.
   Does not look for matches further away than max_backward.
   Writes the best match into |out|.
   |out|->score is updated only if a better match is found. */
static BROTLI_INLINE void FN(FindLongestMatch)(HasherHandle handle,
    const BrotliEncoderDictionary* dictionary,
    const uint8_t* BROTLI_RESTRICT data, const size_t ring_buffer_mask,
    const int* BROTLI_RESTRICT distance_cache,
    const size_t cur_ix, const size_t max_length, const size_t max_backward,
    const size_t gap, const size_t max_distance,
    HasherSearchResult* BROTLI_RESTRICT out) {
  fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] enter FN(FindLongestMatch) 1\n");
  HashForgetfulChain* self = FN(Self)(handle);
  const size_t cur_ix_masked = cur_ix & ring_buffer_mask;
  /* Don't accept a short copy from far away. */
  score_t min_score = out->score;
  score_t best_score = out->score;
  size_t best_len = out->len;
  size_t i;
  const size_t key = FN(HashBytes)(&data[cur_ix_masked]);
  const uint8_t tiny_hash = (uint8_t)(key);
  out->len = 0;
  out->len_code_delta = 0;
  // fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] exit FN(FindLongestMatch) 1\n");
  
  /* Try last distance first. */
  for (i = 0; i < NUM_LAST_DISTANCES_TO_CHECK; ++i) {
    fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] enter FN(FindLongestMatch) 2\n");
    const size_t backward = (size_t)distance_cache[i];
    size_t prev_ix = (cur_ix - backward);
    // fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] exit FN(FindLongestMatch) 2\n");
    
    /* For distance code 0 we want to consider 2-byte matches. */
    if (i > 0 && self->tiny_hash[(uint16_t)prev_ix] != tiny_hash) {
      fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] enter FN(FindLongestMatch) 3\n");
      continue;
      // fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] exit FN(FindLongestMatch) 3\n");
    }
    
    if (prev_ix >= cur_ix || backward > max_backward) {
      fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] enter FN(FindLongestMatch) 4\n");
      continue;
      // fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] exit FN(FindLongestMatch) 4\n");
    }
    
    fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] enter FN(FindLongestMatch) 5\n");
    prev_ix &= ring_buffer_mask;
    {
      const size_t len = FindMatchLengthWithLimit(&data[prev_ix],
                                                  &data[cur_ix_masked],
                                                  max_length);
      if (len >= 2) {
        fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] enter FN(FindLongestMatch) 6\n");
        score_t score = BackwardReferenceScoreUsingLastDistance(len);
        // fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] exit FN(FindLongestMatch) 6\n");
        if (best_score < score) {
          fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] enter FN(FindLongestMatch) 7\n");
          if (i != 0) score -= BackwardReferencePenaltyUsingLastDistance(i);
          // fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] exit FN(FindLongestMatch) 7\n");
          if (best_score < score) {
            fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] enter FN(FindLongestMatch) 8\n");
            best_score = score;
            best_len = len;
            out->len = best_len;
            out->distance = backward;
            out->score = best_score;
            // fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] exit FN(FindLongestMatch) 8\n");
          }
        }
      }
    }
    // fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] exit FN(FindLongestMatch) 5\n");
  }
  
  fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] enter FN(FindLongestMatch) 9\n");
  {
    const size_t bank = key & (NUM_BANKS - 1);
    size_t backward = 0;
    size_t hops = self->max_hops;
    size_t delta = cur_ix - self->addr[key];
    size_t slot = self->head[key];
    // fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] exit FN(FindLongestMatch) 9\n");
    
    while (hops--) {
      fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] enter FN(FindLongestMatch) 10\n");
      size_t prev_ix;
      size_t last = slot;
      backward += delta;
      // fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] exit FN(FindLongestMatch) 10\n");
      
      if (backward > max_backward || (CAPPED_CHAINS && !delta)) {
        fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] enter FN(FindLongestMatch) 11\n");
        break;
        // fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] exit FN(FindLongestMatch) 11\n");
      }
      
      fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] enter FN(FindLongestMatch) 12\n");
      prev_ix = (cur_ix - backward) & ring_buffer_mask;
      slot = self->banks[bank].slots[last].next;
      delta = self->banks[bank].slots[last].delta;
      // fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] exit FN(FindLongestMatch) 12\n");
      
      if (cur_ix_masked + best_len > ring_buffer_mask ||
          prev_ix + best_len > ring_buffer_mask ||
          data[cur_ix_masked + best_len] != data[prev_ix + best_len]) {
        fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] enter FN(FindLongestMatch) 13\n");
        continue;
        // fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] exit FN(FindLongestMatch) 13\n");
      }
      
      fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] enter FN(FindLongestMatch) 14\n");
      {
        const size_t len = FindMatchLengthWithLimit(&data[prev_ix],
                                                    &data[cur_ix_masked],
                                                    max_length);
        if (len >= 4) {
          fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] enter FN(FindLongestMatch) 15\n");
          /* Comparing for >= 3 does not change the semantics, but just saves
             for a few unnecessary binary logarithms in backward reference
             score, since we are not interested in such short matches. */
          score_t score = BackwardReferenceScore(len, backward);
          // fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] exit FN(FindLongestMatch) 15\n");
          
          if (best_score < score) {
            fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] enter FN(FindLongestMatch) 16\n");
            best_score = score;
            best_len = len;
            out->len = best_len;
            out->distance = backward;
            out->score = best_score;
            // fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] exit FN(FindLongestMatch) 16\n");
          }
        }
      }
      // fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] exit FN(FindLongestMatch) 14\n");
    }
    
    fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] enter FN(FindLongestMatch) 17\n");
    FN(Store)(handle, data, ring_buffer_mask, cur_ix);
    // fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] exit FN(FindLongestMatch) 17\n");
  }
  
  if (out->score == min_score) {
    fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] enter FN(FindLongestMatch) 18\n");
    SearchInStaticDictionary(dictionary,
        handle, &data[cur_ix_masked], max_length, max_backward + gap,
        max_distance, out, BROTLI_FALSE);
    // fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] exit FN(FindLongestMatch) 18\n");
  }
  
  fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] enter FN(FindLongestMatch) 19\n");
  // Final block at the end of the function
  // fprintf(stderr, "[brotli/c/enc/hash_forgetful_chain_inc.h] exit FN(FindLongestMatch) 19\n");
}

#undef BANK_SIZE
#undef BUCKET_SIZE
#undef CAPPED_CHAINS

#undef HashForgetfulChain
// Total cost: 0.290338
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 254)]
// Total instrumented cost: 0.290338, input tokens: 19147, output tokens: 15494, cache read tokens: 19135, cache write tokens: 13907
