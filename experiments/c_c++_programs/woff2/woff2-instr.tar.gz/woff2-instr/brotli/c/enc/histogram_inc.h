/* NOLINT(build/header_guard) */
/* Copyright 2013 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

/* template parameters: Histogram, DATA_SIZE, DataType */

/* A simple container for histograms of data in blocks. */

#include <stdio.h>

typedef struct FN(Histogram) {
  uint32_t data_[DATA_SIZE];
  size_t total_count_;
  double bit_cost_;
} FN(Histogram);

static BROTLI_INLINE void FN(HistogramClear)(FN(Histogram)* self) {
  fprintf(stderr, "[brotli/c/enc/histogram_inc.h] enter HistogramClear 1\n");
  memset(self->data_, 0, sizeof(self->data_));
  self->total_count_ = 0;
  self->bit_cost_ = HUGE_VAL;
  // fprintf(stderr, "[brotli/c/enc/histogram_inc.h] exit HistogramClear 1\n");
}

static BROTLI_INLINE void FN(ClearHistograms)(
    FN(Histogram)* array, size_t length) {
  fprintf(stderr, "[brotli/c/enc/histogram_inc.h] enter ClearHistograms 1\n");
  size_t i;
  for (i = 0; i < length; ++i) {
    fprintf(stderr, "[brotli/c/enc/histogram_inc.h] enter ClearHistograms 2\n");
    FN(HistogramClear)(array + i);
    // fprintf(stderr, "[brotli/c/enc/histogram_inc.h] exit ClearHistograms 2\n");
  }
  // fprintf(stderr, "[brotli/c/enc/histogram_inc.h] exit ClearHistograms 1\n");
}

static BROTLI_INLINE void FN(HistogramAdd)(FN(Histogram)* self, size_t val) {
  fprintf(stderr, "[brotli/c/enc/histogram_inc.h] enter HistogramAdd 1\n");
  ++self->data_[val];
  ++self->total_count_;
  // fprintf(stderr, "[brotli/c/enc/histogram_inc.h] exit HistogramAdd 1\n");
}

static BROTLI_INLINE void FN(HistogramAddVector)(FN(Histogram)* self,
    const DataType* p, size_t n) {
  fprintf(stderr, "[brotli/c/enc/histogram_inc.h] enter HistogramAddVector 1\n");
  self->total_count_ += n;
  n += 1;
  while (--n) {
    fprintf(stderr, "[brotli/c/enc/histogram_inc.h] enter HistogramAddVector 2\n");
    ++self->data_[*p++];
    // fprintf(stderr, "[brotli/c/enc/histogram_inc.h] exit HistogramAddVector 2\n");
  }
  // fprintf(stderr, "[brotli/c/enc/histogram_inc.h] exit HistogramAddVector 1\n");
}

static BROTLI_INLINE void FN(HistogramAddHistogram)(FN(Histogram)* self,
    const FN(Histogram)* v) {
  fprintf(stderr, "[brotli/c/enc/histogram_inc.h] enter HistogramAddHistogram 1\n");
  size_t i;
  self->total_count_ += v->total_count_;
  for (i = 0; i < DATA_SIZE; ++i) {
    fprintf(stderr, "[brotli/c/enc/histogram_inc.h] enter HistogramAddHistogram 2\n");
    self->data_[i] += v->data_[i];
    // fprintf(stderr, "[brotli/c/enc/histogram_inc.h] exit HistogramAddHistogram 2\n");
  }
  // fprintf(stderr, "[brotli/c/enc/histogram_inc.h] exit HistogramAddHistogram 1\n");
}

static BROTLI_INLINE size_t FN(HistogramDataSize)(void) { 
  fprintf(stderr, "[brotli/c/enc/histogram_inc.h] enter HistogramDataSize 1\n");
  return DATA_SIZE; 
  // fprintf(stderr, "[brotli/c/enc/histogram_inc.h] exit HistogramDataSize 1\n");
}
// Total cost: 0.017133
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 51)]
// Total instrumented cost: 0.017133, input tokens: 2398, output tokens: 934, cache read tokens: 2394, cache write tokens: 638
