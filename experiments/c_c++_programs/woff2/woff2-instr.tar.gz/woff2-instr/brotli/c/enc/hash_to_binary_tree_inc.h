/* NOLINT(build/header_guard) */
/* Copyright 2016 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

/* template parameters: FN, BUCKET_BITS, MAX_TREE_COMP_LENGTH,
                        MAX_TREE_SEARCH_DEPTH */

/* A (forgetful) hash table where each hash bucket contains a binary tree of
   sequences whose first 4 bytes share the same hash code.
   Each sequence is MAX_TREE_COMP_LENGTH long and is identified by its starting
   position in the input data. The binary tree is sorted by the lexicographic
   order of the sequences, and it is also a max-heap with respect to the
   starting positions. */

#include <stdio.h>

#define HashToBinaryTree HASHER()

#define BUCKET_SIZE (1 << BUCKET_BITS)

static BROTLI_INLINE size_t FN(HashTypeLength)(void) { 
  fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(HashTypeLength) 1\n");
  return 4; 
  // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(HashTypeLength) 1\n");
}

static BROTLI_INLINE size_t FN(StoreLookahead)(void) {
  fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(StoreLookahead) 1\n");
  return MAX_TREE_COMP_LENGTH;
  // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(StoreLookahead) 1\n");
}

static uint32_t FN(HashBytes)(const uint8_t* data) {
  fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(HashBytes) 1\n");
  uint32_t h = BROTLI_UNALIGNED_LOAD32LE(data) * kHashMul32;
  /* The higher bits contain more mixture from the multiplication,
     so we take our results from there. */
  return h >> (32 - BUCKET_BITS);
  // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(HashBytes) 1\n");
}

typedef struct HashToBinaryTree {
  /* The window size minus 1 */
  size_t window_mask_;

  /* Hash table that maps the 4-byte hashes of the sequence to the last
     position where this hash was found, which is the root of the binary
     tree of sequences that share this hash bucket. */
  uint32_t buckets_[BUCKET_SIZE];

  /* A position used to mark a non-existent sequence, i.e. a tree is empty if
     its root is at invalid_pos_ and a node is a leaf if both its children
     are at invalid_pos_. */
  uint32_t invalid_pos_;

  /* --- Dynamic size members --- */

  /* The union of the binary trees of each hash bucket. The root of the tree
     corresponding to a hash is a sequence starting at buckets_[hash] and
     the left and right children of a sequence starting at pos are
     forest_[2 * pos] and forest_[2 * pos + 1]. */
  /* uint32_t forest[2 * num_nodes] */
} HashToBinaryTree;

static BROTLI_INLINE HashToBinaryTree* FN(Self)(HasherHandle handle) {
  fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(Self) 1\n");
  return (HashToBinaryTree*)&(GetHasherCommon(handle)[1]);
  // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(Self) 1\n");
}

static BROTLI_INLINE uint32_t* FN(Forest)(HashToBinaryTree* self) {
  fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(Forest) 1\n");
  return (uint32_t*)(&self[1]);
  // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(Forest) 1\n");
}

static void FN(Initialize)(
    HasherHandle handle, const BrotliEncoderParams* params) {
  fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(Initialize) 1\n");
  HashToBinaryTree* self = FN(Self)(handle);
  self->window_mask_ = (1u << params->lgwin) - 1u;
  self->invalid_pos_ = (uint32_t)(0 - self->window_mask_);
  // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(Initialize) 1\n");
}

static void FN(Prepare)(HasherHandle handle, BROTLI_BOOL one_shot,
    size_t input_size, const uint8_t* data) {
  fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(Prepare) 1\n");
  HashToBinaryTree* self = FN(Self)(handle);
  uint32_t invalid_pos = self->invalid_pos_;
  uint32_t i;
  BROTLI_UNUSED(data);
  BROTLI_UNUSED(one_shot);
  BROTLI_UNUSED(input_size);
  // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(Prepare) 1\n");
  
  for (i = 0; i < BUCKET_SIZE; i++) {
    fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(Prepare) 2\n");
    self->buckets_[i] = invalid_pos;
    // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(Prepare) 2\n");
  }
}

static BROTLI_INLINE size_t FN(HashMemAllocInBytes)(
    const BrotliEncoderParams* params, BROTLI_BOOL one_shot,
    size_t input_size) {
  fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(HashMemAllocInBytes) 1\n");
  size_t num_nodes = (size_t)1 << params->lgwin;
  // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(HashMemAllocInBytes) 1\n");
  
  if (one_shot && input_size < num_nodes) {
    fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(HashMemAllocInBytes) 2\n");
    num_nodes = input_size;
    // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(HashMemAllocInBytes) 2\n");
  }
  
  fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(HashMemAllocInBytes) 3\n");
  return sizeof(HashToBinaryTree) + 2 * sizeof(uint32_t) * num_nodes;
  // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(HashMemAllocInBytes) 3\n");
}

static BROTLI_INLINE size_t FN(LeftChildIndex)(HashToBinaryTree* self,
    const size_t pos) {
  fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(LeftChildIndex) 1\n");
  return 2 * (pos & self->window_mask_);
  // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(LeftChildIndex) 1\n");
}

static BROTLI_INLINE size_t FN(RightChildIndex)(HashToBinaryTree* self,
    const size_t pos) {
  fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(RightChildIndex) 1\n");
  return 2 * (pos & self->window_mask_) + 1;
  // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(RightChildIndex) 1\n");
}

/* Stores the hash of the next 4 bytes and in a single tree-traversal, the
   hash bucket's binary tree is searched for matches and is re-rooted at the
   current position.

   If less than MAX_TREE_COMP_LENGTH data is available, the hash bucket of the
   current position is searched for matches, but the state of the hash table
   is not changed, since we can not know the final sorting order of the
   current (incomplete) sequence.

   This function must be called with increasing cur_ix positions. */
static BROTLI_INLINE BackwardMatch* FN(StoreAndFindMatches)(
    HashToBinaryTree* self, const uint8_t* const BROTLI_RESTRICT data,
    const size_t cur_ix, const size_t ring_buffer_mask, const size_t max_length,
    const size_t max_backward, size_t* const BROTLI_RESTRICT best_len,
    BackwardMatch* BROTLI_RESTRICT matches) {
  fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(StoreAndFindMatches) 1\n");
  const size_t cur_ix_masked = cur_ix & ring_buffer_mask;
  const size_t max_comp_len =
      BROTLI_MIN(size_t, max_length, MAX_TREE_COMP_LENGTH);
  const BROTLI_BOOL should_reroot_tree =
      TO_BROTLI_BOOL(max_length >= MAX_TREE_COMP_LENGTH);
  const uint32_t key = FN(HashBytes)(&data[cur_ix_masked]);
  uint32_t* forest = FN(Forest)(self);
  size_t prev_ix = self->buckets_[key];
  /* The forest index of the rightmost node of the left subtree of the new
     root, updated as we traverse and re-root the tree of the hash bucket. */
  size_t node_left = FN(LeftChildIndex)(self, cur_ix);
  /* The forest index of the leftmost node of the right subtree of the new
     root, updated as we traverse and re-root the tree of the hash bucket. */
  size_t node_right = FN(RightChildIndex)(self, cur_ix);
  /* The match length of the rightmost node of the left subtree of the new
     root, updated as we traverse and re-root the tree of the hash bucket. */
  size_t best_len_left = 0;
  /* The match length of the leftmost node of the right subtree of the new
     root, updated as we traverse and re-root the tree of the hash bucket. */
  size_t best_len_right = 0;
  size_t depth_remaining;
  // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(StoreAndFindMatches) 1\n");
  
  if (should_reroot_tree) {
    fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(StoreAndFindMatches) 2\n");
    self->buckets_[key] = (uint32_t)cur_ix;
    // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(StoreAndFindMatches) 2\n");
  }
  
  for (depth_remaining = MAX_TREE_SEARCH_DEPTH; ; --depth_remaining) {
    fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(StoreAndFindMatches) 3\n");
    const size_t backward = cur_ix - prev_ix;
    const size_t prev_ix_masked = prev_ix & ring_buffer_mask;
    // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(StoreAndFindMatches) 3\n");
    
    if (backward == 0 || backward > max_backward || depth_remaining == 0) {
      fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(StoreAndFindMatches) 4\n");
      if (should_reroot_tree) {
        fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(StoreAndFindMatches) 5\n");
        forest[node_left] = self->invalid_pos_;
        forest[node_right] = self->invalid_pos_;
        // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(StoreAndFindMatches) 5\n");
      }
      break;
      // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(StoreAndFindMatches) 4\n");
    }
    
    {
      fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(StoreAndFindMatches) 6\n");
      const size_t cur_len = BROTLI_MIN(size_t, best_len_left, best_len_right);
      size_t len;
      BROTLI_DCHECK(cur_len <= MAX_TREE_COMP_LENGTH);
      len = cur_len +
          FindMatchLengthWithLimit(&data[cur_ix_masked + cur_len],
                                   &data[prev_ix_masked + cur_len],
                                   max_length - cur_len);
      BROTLI_DCHECK(
          0 == memcmp(&data[cur_ix_masked], &data[prev_ix_masked], len));
      // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(StoreAndFindMatches) 6\n");
      
      if (matches && len > *best_len) {
        fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(StoreAndFindMatches) 7\n");
        *best_len = len;
        InitBackwardMatch(matches++, backward, len);
        // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(StoreAndFindMatches) 7\n");
      }
      
      if (len >= max_comp_len) {
        fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(StoreAndFindMatches) 8\n");
        if (should_reroot_tree) {
          fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(StoreAndFindMatches) 9\n");
          forest[node_left] = forest[FN(LeftChildIndex)(self, prev_ix)];
          forest[node_right] = forest[FN(RightChildIndex)(self, prev_ix)];
          // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(StoreAndFindMatches) 9\n");
        }
        break;
        // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(StoreAndFindMatches) 8\n");
      }
      
      if (data[cur_ix_masked + len] > data[prev_ix_masked + len]) {
        fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(StoreAndFindMatches) 10\n");
        best_len_left = len;
        if (should_reroot_tree) {
          fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(StoreAndFindMatches) 11\n");
          forest[node_left] = (uint32_t)prev_ix;
          // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(StoreAndFindMatches) 11\n");
        }
        node_left = FN(RightChildIndex)(self, prev_ix);
        prev_ix = forest[node_left];
        // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(StoreAndFindMatches) 10\n");
      } else {
        fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(StoreAndFindMatches) 12\n");
        best_len_right = len;
        if (should_reroot_tree) {
          fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(StoreAndFindMatches) 13\n");
          forest[node_right] = (uint32_t)prev_ix;
          // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(StoreAndFindMatches) 13\n");
        }
        node_right = FN(LeftChildIndex)(self, prev_ix);
        prev_ix = forest[node_right];
        // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(StoreAndFindMatches) 12\n");
      }
    }
  }
  
  fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(StoreAndFindMatches) 14\n");
  return matches;
  // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(StoreAndFindMatches) 14\n");
}

/* Finds all backward matches of &data[cur_ix & ring_buffer_mask] up to the
   length of max_length and stores the position cur_ix in the hash table.

   Sets *num_matches to the number of matches found, and stores the found
   matches in matches[0] to matches[*num_matches - 1]. The matches will be
   sorted by strictly increasing length and (non-strictly) increasing
   distance. */
static BROTLI_INLINE size_t FN(FindAllMatches)(HasherHandle handle,
    const BrotliEncoderDictionary* dictionary, const uint8_t* data,
    const size_t ring_buffer_mask, const size_t cur_ix,
    const size_t max_length, const size_t max_backward, const size_t gap,
    const BrotliEncoderParams* params, BackwardMatch* matches) {
  fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(FindAllMatches) 1\n");
  BackwardMatch* const orig_matches = matches;
  const size_t cur_ix_masked = cur_ix & ring_buffer_mask;
  size_t best_len = 1;
  const size_t short_match_max_backward =
      params->quality != HQ_ZOPFLIFICATION_QUALITY ? 16 : 64;
  size_t stop = cur_ix - short_match_max_backward;
  uint32_t dict_matches[BROTLI_MAX_STATIC_DICTIONARY_MATCH_LEN + 1];
  size_t i;
  // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(FindAllMatches) 1\n");
  
  if (cur_ix < short_match_max_backward) { 
    fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(FindAllMatches) 2\n");
    stop = 0; 
    // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(FindAllMatches) 2\n");
  }
  
  for (i = cur_ix - 1; i > stop && best_len <= 2; --i) {
    fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(FindAllMatches) 3\n");
    size_t prev_ix = i;
    const size_t backward = cur_ix - prev_ix;
    // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(FindAllMatches) 3\n");
    
    if (BROTLI_PREDICT_FALSE(backward > max_backward)) {
      fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(FindAllMatches) 4\n");
      break;
      // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(FindAllMatches) 4\n");
    }
    
    fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(FindAllMatches) 5\n");
    prev_ix &= ring_buffer_mask;
    // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(FindAllMatches) 5\n");
    
    if (data[cur_ix_masked] != data[prev_ix] ||
        data[cur_ix_masked + 1] != data[prev_ix + 1]) {
      fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(FindAllMatches) 6\n");
      continue;
      // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(FindAllMatches) 6\n");
    }
    
    {
      fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(FindAllMatches) 7\n");
      const size_t len =
          FindMatchLengthWithLimit(&data[prev_ix], &data[cur_ix_masked],
                                   max_length);
      // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(FindAllMatches) 7\n");
      
      if (len > best_len) {
        fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(FindAllMatches) 8\n");
        best_len = len;
        InitBackwardMatch(matches++, backward, len);
        // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(FindAllMatches) 8\n");
      }
    }
  }
  
  if (best_len < max_length) {
    fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(FindAllMatches) 9\n");
    matches = FN(StoreAndFindMatches)(FN(Self)(handle), data, cur_ix,
        ring_buffer_mask, max_length, max_backward, &best_len, matches);
    // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(FindAllMatches) 9\n");
  }
  
  for (i = 0; i <= BROTLI_MAX_STATIC_DICTIONARY_MATCH_LEN; ++i) {
    fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(FindAllMatches) 10\n");
    dict_matches[i] = kInvalidMatch;
    // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(FindAllMatches) 10\n");
  }
  
  {
    fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(FindAllMatches) 11\n");
    size_t minlen = BROTLI_MAX(size_t, 4, best_len + 1);
    // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(FindAllMatches) 11\n");
    
    if (BrotliFindAllStaticDictionaryMatches(dictionary,
        &data[cur_ix_masked], minlen, max_length, &dict_matches[0])) {
      fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(FindAllMatches) 12\n");
      size_t maxlen = BROTLI_MIN(
          size_t, BROTLI_MAX_STATIC_DICTIONARY_MATCH_LEN, max_length);
      size_t l;
      // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(FindAllMatches) 12\n");
      
      for (l = minlen; l <= maxlen; ++l) {
        fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(FindAllMatches) 13\n");
        uint32_t dict_id = dict_matches[l];
        // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(FindAllMatches) 13\n");
        
        if (dict_id < kInvalidMatch) {
          fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(FindAllMatches) 14\n");
          size_t distance = max_backward + gap + (dict_id >> 5) + 1;
          // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(FindAllMatches) 14\n");
          
          if (distance <= params->dist.max_distance) {
            fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(FindAllMatches) 15\n");
            InitDictionaryBackwardMatch(matches++, distance, l, dict_id & 31);
            // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(FindAllMatches) 15\n");
          }
        }
      }
    }
  }
  
  fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(FindAllMatches) 16\n");
  return (size_t)(matches - orig_matches);
  // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(FindAllMatches) 16\n");
}

/* Stores the hash of the next 4 bytes and re-roots the binary tree at the
   current sequence, without returning any matches.
   REQUIRES: ix + MAX_TREE_COMP_LENGTH <= end-of-current-block */
static BROTLI_INLINE void FN(Store)(HasherHandle handle, const uint8_t* data,
    const size_t mask, const size_t ix) {
  fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(Store) 1\n");
  HashToBinaryTree* self = FN(Self)(handle);
  /* Maximum distance is window size - 16, see section 9.1. of the spec. */
  const size_t max_backward = self->window_mask_ - BROTLI_WINDOW_GAP + 1;
  FN(StoreAndFindMatches)(self, data, ix, mask, MAX_TREE_COMP_LENGTH,
      max_backward, NULL, NULL);
  // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(Store) 1\n");
}

static BROTLI_INLINE void FN(StoreRange)(HasherHandle handle,
    const uint8_t* data, const size_t mask, const size_t ix_start,
    const size_t ix_end) {
  fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(StoreRange) 1\n");
  size_t i = ix_start;
  size_t j = ix_start;
  // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(StoreRange) 1\n");
  
  if (ix_start + 63 <= ix_end) {
    fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(StoreRange) 2\n");
    i = ix_end - 63;
    // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(StoreRange) 2\n");
  }
  
  if (ix_start + 512 <= i) {
    fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(StoreRange) 3\n");
    for (; j < i; j += 8) {
      fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(StoreRange) 4\n");
      FN(Store)(handle, data, mask, j);
      // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(StoreRange) 4\n");
    }
    // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(StoreRange) 3\n");
  }
  
  for (; i < ix_end; ++i) {
    fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(StoreRange) 5\n");
    FN(Store)(handle, data, mask, i);
    // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(StoreRange) 5\n");
  }
}

static BROTLI_INLINE void FN(StitchToPreviousBlock)(HasherHandle handle,
    size_t num_bytes, size_t position, const uint8_t* ringbuffer,
    size_t ringbuffer_mask) {
  fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(StitchToPreviousBlock) 1\n");
  HashToBinaryTree* self = FN(Self)(handle);
  // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(StitchToPreviousBlock) 1\n");
  
  if (num_bytes >= FN(HashTypeLength)() - 1 &&
      position >= MAX_TREE_COMP_LENGTH) {
    fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(StitchToPreviousBlock) 2\n");
    /* Store the last `MAX_TREE_COMP_LENGTH - 1` positions in the hasher.
       These could not be calculated before, since they require knowledge
       of both the previous and the current block. */
    const size_t i_start = position - MAX_TREE_COMP_LENGTH + 1;
    const size_t i_end = BROTLI_MIN(size_t, position, i_start + num_bytes);
    size_t i;
    // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(StitchToPreviousBlock) 2\n");
    
    for (i = i_start; i < i_end; ++i) {
      fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] enter FN(StitchToPreviousBlock) 3\n");
      /* Maximum distance is window size - 16, see section 9.1. of the spec.
         Furthermore, we have to make sure that we don't look further back
         from the start of the next block than the window size, otherwise we
         could access already overwritten areas of the ring-buffer. */
      const size_t max_backward =
          self->window_mask_ - BROTLI_MAX(size_t,
                                          BROTLI_WINDOW_GAP - 1,
                                          position - i);
      /* We know that i + MAX_TREE_COMP_LENGTH <= position + num_bytes, i.e. the
         end of the current block and that we have at least
         MAX_TREE_COMP_LENGTH tail in the ring-buffer. */
      FN(StoreAndFindMatches)(self, ringbuffer, i, ringbuffer_mask,
          MAX_TREE_COMP_LENGTH, max_backward, NULL, NULL);
      // fprintf(stderr, "[brotli/c/enc/hash_to_binary_tree_inc.h] exit FN(StitchToPreviousBlock) 3\n");
    }
  }
}

#undef BUCKET_SIZE

#undef HashToBinaryTree
// Total cost: 0.121439
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 327)]
// Total instrumented cost: 0.121439, input tokens: 2398, output tokens: 6902, cache read tokens: 2394, cache write tokens: 4581
