/* Copyright 2015 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

/* Algorithms for distributing the literals and commands of a metablock between
   block types and contexts. */

#include "./memory.h"

#include <stdlib.h>  /* exit, free, malloc */
#include <string.h>  /* memcpy */

#include "../common/platform.h"
#include <brotli/types.h>

#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

#define MAX_PERM_ALLOCATED 128
#define MAX_NEW_ALLOCATED 64
#define MAX_NEW_FREED 64

#define PERM_ALLOCATED_OFFSET 0
#define NEW_ALLOCATED_OFFSET MAX_PERM_ALLOCATED
#define NEW_FREED_OFFSET (MAX_PERM_ALLOCATED + MAX_NEW_ALLOCATED)

void BrotliInitMemoryManager(
    MemoryManager* m, brotli_alloc_func alloc_func, brotli_free_func free_func,
    void* opaque) {
  fprintf(stderr, "[brotli/c/enc/memory.c] enter BrotliInitMemoryManager 1\n");
  if (!alloc_func) {
    fprintf(stderr, "[brotli/c/enc/memory.c] enter BrotliInitMemoryManager 2\n");
    m->alloc_func = BrotliDefaultAllocFunc;
    m->free_func = BrotliDefaultFreeFunc;
    m->opaque = 0;
    // fprintf(stderr, "[brotli/c/enc/memory.c] exit BrotliInitMemoryManager 2\n");
  } else {
    fprintf(stderr, "[brotli/c/enc/memory.c] enter BrotliInitMemoryManager 3\n");
    m->alloc_func = alloc_func;
    m->free_func = free_func;
    m->opaque = opaque;
    // fprintf(stderr, "[brotli/c/enc/memory.c] exit BrotliInitMemoryManager 3\n");
  }
#if !defined(BROTLI_ENCODER_EXIT_ON_OOM)
  fprintf(stderr, "[brotli/c/enc/memory.c] enter BrotliInitMemoryManager 4\n");
  m->is_oom = BROTLI_FALSE;
  m->perm_allocated = 0;
  m->new_allocated = 0;
  m->new_freed = 0;
  // fprintf(stderr, "[brotli/c/enc/memory.c] exit BrotliInitMemoryManager 4\n");
#endif  /* BROTLI_ENCODER_EXIT_ON_OOM */
  // fprintf(stderr, "[brotli/c/enc/memory.c] exit BrotliInitMemoryManager 1\n");
}

#if defined(BROTLI_ENCODER_EXIT_ON_OOM)

void* BrotliAllocate(MemoryManager* m, size_t n) {
  fprintf(stderr, "[brotli/c/enc/memory.c] enter BrotliAllocate 1\n");
  void* result = m->alloc_func(m->opaque, n);
  if (!result) exit(EXIT_FAILURE);
  return result;
  // fprintf(stderr, "[brotli/c/enc/memory.c] exit BrotliAllocate 1\n");
}

void BrotliFree(MemoryManager* m, void* p) {
  fprintf(stderr, "[brotli/c/enc/memory.c] enter BrotliFree 1\n");
  m->free_func(m->opaque, p);
  // fprintf(stderr, "[brotli/c/enc/memory.c] exit BrotliFree 1\n");
}

void BrotliWipeOutMemoryManager(MemoryManager* m) {
  fprintf(stderr, "[brotli/c/enc/memory.c] enter BrotliWipeOutMemoryManager 1\n");
  BROTLI_UNUSED(m);
  // fprintf(stderr, "[brotli/c/enc/memory.c] exit BrotliWipeOutMemoryManager 1\n");
}

#else  /* BROTLI_ENCODER_EXIT_ON_OOM */

static void SortPointers(void** items, const size_t n) {
  fprintf(stderr, "[brotli/c/enc/memory.c] enter SortPointers 1\n");
  /* Shell sort. */
  static const size_t gaps[] = {23, 10, 4, 1};
  int g = 0;
  for (; g < 4; ++g) {
    size_t gap = gaps[g];
    size_t i;
    for (i = gap; i < n; ++i) {
      fprintf(stderr, "[brotli/c/enc/memory.c] enter SortPointers 2\n");
      size_t j = i;
      void* tmp = items[i];
      for (; j >= gap && tmp < items[j - gap]; j -= gap) {
        fprintf(stderr, "[brotli/c/enc/memory.c] enter SortPointers 3\n");
        items[j] = items[j - gap];
        // fprintf(stderr, "[brotli/c/enc/memory.c] exit SortPointers 3\n");
      }
      items[j] = tmp;
      // fprintf(stderr, "[brotli/c/enc/memory.c] exit SortPointers 2\n");
    }
  }
  // fprintf(stderr, "[brotli/c/enc/memory.c] exit SortPointers 1\n");
}

static size_t Annihilate(void** a, size_t a_len, void** b, size_t b_len) {
  fprintf(stderr, "\n");
  size_t a_read_index = 0;
  size_t b_read_index = 0;
  size_t a_write_index = 0;
  size_t b_write_index = 0;
  size_t annihilated = 0;
  while (a_read_index < a_len && b_read_index < b_len) {
    fprintf(stderr, "[brotli/c/enc/memory.c] enter Annihilate 2\n");
    if (a[a_read_index] == b[b_read_index]) {
      fprintf(stderr, "[brotli/c/enc/memory.c] enter Annihilate 3\n");
      a_read_index++;
      b_read_index++;
      annihilated++;
      // fprintf(stderr, "[brotli/c/enc/memory.c] exit Annihilate 3\n");
    } else if (a[a_read_index] < b[b_read_index]) {
      fprintf(stderr, "[brotli/c/enc/memory.c] enter Annihilate 4\n");
      a[a_write_index++] = a[a_read_index++];
      // fprintf(stderr, "[brotli/c/enc/memory.c] exit Annihilate 4\n");
    } else {
      fprintf(stderr, "[brotli/c/enc/memory.c] enter Annihilate 5\n");
      b[b_write_index++] = b[b_read_index++];
      // fprintf(stderr, "[brotli/c/enc/memory.c] exit Annihilate 5\n");
    }
    // fprintf(stderr, "[brotli/c/enc/memory.c] exit Annihilate 2\n");
  }
  fprintf(stderr, "[brotli/c/enc/memory.c] enter Annihilate 6\n");
  while (a_read_index < a_len) a[a_write_index++] = a[a_read_index++];
  while (b_read_index < b_len) b[b_write_index++] = b[b_read_index++];
  return annihilated;
  // fprintf(stderr, "[brotli/c/enc/memory.c] exit Annihilate 6\n");
}

static void CollectGarbagePointers(MemoryManager* m) {
  fprintf(stderr, "[brotli/c/enc/memory.c] enter CollectGarbagePointers 1\n");
  size_t annihilated;
  SortPointers(m->pointers + NEW_ALLOCATED_OFFSET, m->new_allocated);
  SortPointers(m->pointers + NEW_FREED_OFFSET, m->new_freed);
  annihilated = Annihilate(
      m->pointers + NEW_ALLOCATED_OFFSET, m->new_allocated,
      m->pointers + NEW_FREED_OFFSET, m->new_freed);
  m->new_allocated -= annihilated;
  m->new_freed -= annihilated;

  if (m->new_freed != 0) {
    fprintf(stderr, "[brotli/c/enc/memory.c] enter CollectGarbagePointers 2\n");
    annihilated = Annihilate(
        m->pointers + PERM_ALLOCATED_OFFSET, m->perm_allocated,
        m->pointers + NEW_FREED_OFFSET, m->new_freed);
    m->perm_allocated -= annihilated;
    m->new_freed -= annihilated;
    BROTLI_DCHECK(m->new_freed == 0);
    // fprintf(stderr, "[brotli/c/enc/memory.c] exit CollectGarbagePointers 2\n");
  }

  if (m->new_allocated != 0) {
    fprintf(stderr, "[brotli/c/enc/memory.c] enter CollectGarbagePointers 3\n");
    BROTLI_DCHECK(m->perm_allocated + m->new_allocated <= MAX_PERM_ALLOCATED);
    memcpy(m->pointers + PERM_ALLOCATED_OFFSET + m->perm_allocated,
           m->pointers + NEW_ALLOCATED_OFFSET,
           sizeof(void*) * m->new_allocated);
    m->perm_allocated += m->new_allocated;
    m->new_allocated = 0;
    SortPointers(m->pointers + PERM_ALLOCATED_OFFSET, m->perm_allocated);
    // fprintf(stderr, "[brotli/c/enc/memory.c] exit CollectGarbagePointers 3\n");
  }
  // fprintf(stderr, "[brotli/c/enc/memory.c] exit CollectGarbagePointers 1\n");
}

void* BrotliAllocate(MemoryManager* m, size_t n) {
  fprintf(stderr, "[brotli/c/enc/memory.c] enter BrotliAllocate 987\n");
  void* result = m->alloc_func(m->opaque, n);
  if (!result) {
    fprintf(stderr, "[brotli/c/enc/memory.c] enter BrotliAllocate 2\n");
    m->is_oom = BROTLI_TRUE;
    return NULL;
    // fprintf(stderr, "[brotli/c/enc/memory.c] exit BrotliAllocate 2\n");
  }
  if (m->new_allocated == MAX_NEW_ALLOCATED) CollectGarbagePointers(m);
  m->pointers[NEW_ALLOCATED_OFFSET + (m->new_allocated++)] = result;
  return result;
  // fprintf(stderr, "[brotli/c/enc/memory.c] exit BrotliAllocate 987\n");
}

void BrotliFree(MemoryManager* m, void* p) {
  fprintf(stderr, "[brotli/c/enc/memory.c] enter BrotliFree 3383\n");
  if (!p) return;
  m->free_func(m->opaque, p);
  if (m->new_freed == MAX_NEW_FREED) CollectGarbagePointers(m);
  m->pointers[NEW_FREED_OFFSET + (m->new_freed++)] = p;
  // fprintf(stderr, "[brotli/c/enc/memory.c] exit BrotliFree 3383\n");
}

void BrotliWipeOutMemoryManager(MemoryManager* m) {
  fprintf(stderr, "[brotli/c/enc/memory.c] enter BrotliWipeOutMemoryManager 3908\n");
  size_t i;
  CollectGarbagePointers(m);
  /* Now all unfreed pointers are in perm-allocated list. */
  for (i = 0; i < m->perm_allocated; ++i) {
    fprintf(stderr, "[brotli/c/enc/memory.c] enter BrotliWipeOutMemoryManager 2\n");
    m->free_func(m->opaque, m->pointers[PERM_ALLOCATED_OFFSET + i]);
    // fprintf(stderr, "[brotli/c/enc/memory.c] exit BrotliWipeOutMemoryManager 2\n");
  }
  m->perm_allocated = 0;
  // fprintf(stderr, "[brotli/c/enc/memory.c] exit BrotliWipeOutMemoryManager 3908\n");
}

#endif  /* BROTLI_ENCODER_EXIT_ON_OOM */

#if defined(__cplusplus) || defined(c_plusplus)
}  /* extern "C" */
#endif
// Total cost: 0.122300
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 170)]
// Total instrumented cost: 0.122300, input tokens: 4506, output tokens: 6129, cache read tokens: 4498, cache write tokens: 7731
