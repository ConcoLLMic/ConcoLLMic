/* Copyright 2017 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

#include "./encoder_dict.h"

#include "../common/dictionary.h"
#include "../common/transform.h"
#include "./dictionary_hash.h"
#include "./hash.h"
#include <stdio.h>

#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

void BrotliInitEncoderDictionary(BrotliEncoderDictionary* dict) {
  fprintf(stderr, "[brotli/c/enc/encoder_dict.c] enter BrotliInitEncoderDictionary 1\n");
  dict->words = BrotliGetDictionary();

  dict->hash_table = kStaticDictionaryHash;
  dict->buckets = kStaticDictionaryBuckets;
  dict->dict_words = kStaticDictionaryWords;

  dict->cutoffTransformsCount = kCutoffTransformsCount;
  dict->cutoffTransforms = kCutoffTransforms;
  // fprintf(stderr, "[brotli/c/enc/encoder_dict.c] exit BrotliInitEncoderDictionary 1\n");
}

#if defined(__cplusplus) || defined(c_plusplus)
}  /* extern "C" */
#endif
// Total cost: 0.007308
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 32)]
// Total instrumented cost: 0.007308, input tokens: 2398, output tokens: 349, cache read tokens: 2394, cache write tokens: 358
