/* Copyright 2013 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

/* Function to find backward reference copies. */

#include "./backward_references.h"

#include "../common/constants.h"
#include "../common/dictionary.h"
#include "../common/platform.h"
#include <brotli/types.h>
#include "./command.h"
#include "./dictionary_hash.h"
#include "./memory.h"
#include "./quality.h"
#include <stdio.h>

#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

static BROTLI_INLINE size_t ComputeDistanceCode(size_t distance,
                                                size_t max_distance,
                                                const int* dist_cache) {
  fprintf(stderr, "[brotli/c/enc/backward_references.c] enter ComputeDistanceCode 1\n");
  if (distance <= max_distance) {
    fprintf(stderr, "[brotli/c/enc/backward_references.c] enter ComputeDistanceCode 2\n");
    size_t distance_plus_3 = distance + 3;
    size_t offset0 = distance_plus_3 - (size_t)dist_cache[0];
    size_t offset1 = distance_plus_3 - (size_t)dist_cache[1];
    // fprintf(stderr, "[brotli/c/enc/backward_references.c] exit ComputeDistanceCode 2\n");
    if (distance == (size_t)dist_cache[0]) {
      fprintf(stderr, "[brotli/c/enc/backward_references.c] enter ComputeDistanceCode 3\n");
      return 0;
      // fprintf(stderr, "[brotli/c/enc/backward_references.c] exit ComputeDistanceCode 3\n");
    } else if (distance == (size_t)dist_cache[1]) {
      fprintf(stderr, "[brotli/c/enc/backward_references.c] enter ComputeDistanceCode 4\n");
      return 1;
      // fprintf(stderr, "[brotli/c/enc/backward_references.c] exit ComputeDistanceCode 4\n");
    } else if (offset0 < 7) {
      fprintf(stderr, "[brotli/c/enc/backward_references.c] enter ComputeDistanceCode 5\n");
      return (0x9750468 >> (4 * offset0)) & 0xF;
      // fprintf(stderr, "[brotli/c/enc/backward_references.c] exit ComputeDistanceCode 5\n");
    } else if (offset1 < 7) {
      fprintf(stderr, "[brotli/c/enc/backward_references.c] enter ComputeDistanceCode 6\n");
      return (0xFDB1ACE >> (4 * offset1)) & 0xF;
      // fprintf(stderr, "[brotli/c/enc/backward_references.c] exit ComputeDistanceCode 6\n");
    } else if (distance == (size_t)dist_cache[2]) {
      fprintf(stderr, "[brotli/c/enc/backward_references.c] enter ComputeDistanceCode 7\n");
      return 2;
      // fprintf(stderr, "[brotli/c/enc/backward_references.c] exit ComputeDistanceCode 7\n");
    } else if (distance == (size_t)dist_cache[3]) {
      fprintf(stderr, "[brotli/c/enc/backward_references.c] enter ComputeDistanceCode 8\n");
      return 3;
      // fprintf(stderr, "[brotli/c/enc/backward_references.c] exit ComputeDistanceCode 8\n");
    }
    // fprintf(stderr, "[brotli/c/enc/backward_references.c] exit ComputeDistanceCode 1\n");
  }
  fprintf(stderr, "[brotli/c/enc/backward_references.c] enter ComputeDistanceCode 9\n");
  return distance + BROTLI_NUM_DISTANCE_SHORT_CODES - 1;
  // fprintf(stderr, "[brotli/c/enc/backward_references.c] exit ComputeDistanceCode 9\n");
}

#define EXPAND_CAT(a, b) CAT(a, b)
#define CAT(a, b) a ## b
#define FN(X) EXPAND_CAT(X, HASHER())
#define EXPORT_FN(X) EXPAND_CAT(X, EXPAND_CAT(PREFIX(), HASHER()))
#define PREFIX() N

#define HASHER() H2
/* NOLINTNEXTLINE(build/include) */
#include "./backward_references_inc.h"
#undef HASHER

#define HASHER() H3
/* NOLINTNEXTLINE(build/include) */
#include "./backward_references_inc.h"
#undef HASHER

#define HASHER() H4
/* NOLINTNEXTLINE(build/include) */
#include "./backward_references_inc.h"
#undef HASHER

#define HASHER() H5
/* NOLINTNEXTLINE(build/include) */
#include "./backward_references_inc.h"
#undef HASHER

#define HASHER() H6
/* NOLINTNEXTLINE(build/include) */
#include "./backward_references_inc.h"
#undef HASHER

#define HASHER() H40
/* NOLINTNEXTLINE(build/include) */
#include "./backward_references_inc.h"
#undef HASHER

#define HASHER() H41
/* NOLINTNEXTLINE(build/include) */
#include "./backward_references_inc.h"
#undef HASHER

#define HASHER() H42
/* NOLINTNEXTLINE(build/include) */
#include "./backward_references_inc.h"
#undef HASHER

#define HASHER() H54
/* NOLINTNEXTLINE(build/include) */
#include "./backward_references_inc.h"
#undef HASHER

#undef PREFIX
#undef EXPORT_FN
#undef FN
#undef CAT
#undef EXPAND_CAT

void BrotliCreateBackwardReferences(
    size_t num_bytes, size_t position, const uint8_t* ringbuffer,
    size_t ringbuffer_mask, const BrotliEncoderParams* params,
    HasherHandle hasher, int* dist_cache, size_t* last_insert_len,
    Command* commands, size_t* num_commands, size_t* num_literals) {
  fprintf(stderr, "[brotli/c/enc/backward_references.c] enter BrotliCreateBackwardReferences 1\n");
  switch (params->hasher.type) {
#define CASE_(N)                                                  \
    case N:                                                       \
      fprintf(stderr, "[brotli/c/enc/backward_references.c] enter BrotliCreateBackwardReferences 2\n"); \
      CreateBackwardReferencesNH ## N(                            \
          num_bytes, position, ringbuffer,                        \
          ringbuffer_mask, params, hasher, dist_cache,            \
          last_insert_len, commands, num_commands, num_literals); \
      return;                                                     \
      // fprintf(stderr, "[brotli/c/enc/backward_references.c] exit BrotliCreateBackwardReferences 2\n");
    FOR_GENERIC_HASHERS(CASE_)
#undef CASE_
    default:
      fprintf(stderr, "[brotli/c/enc/backward_references.c] enter BrotliCreateBackwardReferences 3\n");
      break;
      // fprintf(stderr, "[brotli/c/enc/backward_references.c] exit BrotliCreateBackwardReferences 3\n");
  }
  // fprintf(stderr, "[brotli/c/enc/backward_references.c] exit BrotliCreateBackwardReferences 1\n");
}

#if defined(__cplusplus) || defined(c_plusplus)
}  /* extern "C" */
#endif
// Total cost: 0.032830
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 127)]
// Total instrumented cost: 0.032830, input tokens: 2398, output tokens: 1798, cache read tokens: 2394, cache write tokens: 1368
