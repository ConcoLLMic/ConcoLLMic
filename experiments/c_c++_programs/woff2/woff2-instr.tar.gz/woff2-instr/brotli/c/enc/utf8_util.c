/* Copyright 2013 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

/* Heuristics for deciding about the UTF8-ness of strings. */

#include "./utf8_util.h"
#include <stdio.h>

#include <brotli/types.h>

#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

static size_t BrotliParseAsUTF8(
    int* symbol, const uint8_t* input, size_t size) {
  fprintf(stderr, "[brotli/c/enc/utf8_util.c] enter BrotliParseAsUTF8 1\n");
  /* ASCII */
  if ((input[0] & 0x80) == 0) {
    fprintf(stderr, "[brotli/c/enc/utf8_util.c] enter BrotliParseAsUTF8 2\n");
    *symbol = input[0];
    if (*symbol > 0) {
      fprintf(stderr, "[brotli/c/enc/utf8_util.c] enter BrotliParseAsUTF8 3\n");
      return 1;
      // fprintf(stderr, "[brotli/c/enc/utf8_util.c] exit BrotliParseAsUTF8 3\n");
    }
    // fprintf(stderr, "[brotli/c/enc/utf8_util.c] exit BrotliParseAsUTF8 2\n");
  }
  /* 2-byte UTF8 */
  if (size > 1u &&
      (input[0] & 0xE0) == 0xC0 &&
      (input[1] & 0xC0) == 0x80) {
    fprintf(stderr, "[brotli/c/enc/utf8_util.c] enter BrotliParseAsUTF8 4\n");
    *symbol = (((input[0] & 0x1F) << 6) |
               (input[1] & 0x3F));
    if (*symbol > 0x7F) {
      fprintf(stderr, "[brotli/c/enc/utf8_util.c] enter BrotliParseAsUTF8 5\n");
      return 2;
      // fprintf(stderr, "[brotli/c/enc/utf8_util.c] exit BrotliParseAsUTF8 5\n");
    }
    // fprintf(stderr, "[brotli/c/enc/utf8_util.c] exit BrotliParseAsUTF8 4\n");
  }
  /* 3-byte UFT8 */
  if (size > 2u &&
      (input[0] & 0xF0) == 0xE0 &&
      (input[1] & 0xC0) == 0x80 &&
      (input[2] & 0xC0) == 0x80) {
    fprintf(stderr, "[brotli/c/enc/utf8_util.c] enter BrotliParseAsUTF8 6\n");
    *symbol = (((input[0] & 0x0F) << 12) |
               ((input[1] & 0x3F) << 6) |
               (input[2] & 0x3F));
    if (*symbol > 0x7FF) {
      fprintf(stderr, "[brotli/c/enc/utf8_util.c] enter BrotliParseAsUTF8 7\n");
      return 3;
      // fprintf(stderr, "[brotli/c/enc/utf8_util.c] exit BrotliParseAsUTF8 7\n");
    }
    // fprintf(stderr, "[brotli/c/enc/utf8_util.c] exit BrotliParseAsUTF8 6\n");
  }
  /* 4-byte UFT8 */
  if (size > 3u &&
      (input[0] & 0xF8) == 0xF0 &&
      (input[1] & 0xC0) == 0x80 &&
      (input[2] & 0xC0) == 0x80 &&
      (input[3] & 0xC0) == 0x80) {
    fprintf(stderr, "[brotli/c/enc/utf8_util.c] enter BrotliParseAsUTF8 8\n");
    *symbol = (((input[0] & 0x07) << 18) |
               ((input[1] & 0x3F) << 12) |
               ((input[2] & 0x3F) << 6) |
               (input[3] & 0x3F));
    if (*symbol > 0xFFFF && *symbol <= 0x10FFFF) {
      fprintf(stderr, "[brotli/c/enc/utf8_util.c] enter BrotliParseAsUTF8 9\n");
      return 4;
      // fprintf(stderr, "[brotli/c/enc/utf8_util.c] exit BrotliParseAsUTF8 9\n");
    }
    // fprintf(stderr, "[brotli/c/enc/utf8_util.c] exit BrotliParseAsUTF8 8\n");
  }
  /* Not UTF8, emit a special symbol above the UTF8-code space */
  fprintf(stderr, "[brotli/c/enc/utf8_util.c] enter BrotliParseAsUTF8 10\n");
  *symbol = 0x110000 | input[0];
  return 1;
  // fprintf(stderr, "[brotli/c/enc/utf8_util.c] exit BrotliParseAsUTF8 10\n");
  // fprintf(stderr, "[brotli/c/enc/utf8_util.c] exit BrotliParseAsUTF8 1\n");
}

/* Returns 1 if at least min_fraction of the data is UTF8-encoded.*/
BROTLI_BOOL BrotliIsMostlyUTF8(
    const uint8_t* data, const size_t pos, const size_t mask,
    const size_t length, const double min_fraction) {
  fprintf(stderr, "[brotli/c/enc/utf8_util.c] enter BrotliIsMostlyUTF8 1\n");
  size_t size_utf8 = 0;
  size_t i = 0;
  // fprintf(stderr, "[brotli/c/enc/utf8_util.c] exit BrotliIsMostlyUTF8 1\n");
  while (i < length) {
    fprintf(stderr, "[brotli/c/enc/utf8_util.c] enter BrotliIsMostlyUTF8 2\n");
    int symbol;
    size_t bytes_read =
        BrotliParseAsUTF8(&symbol, &data[(pos + i) & mask], length - i);
    i += bytes_read;
    if (symbol < 0x110000) {
      fprintf(stderr, "[brotli/c/enc/utf8_util.c] enter BrotliIsMostlyUTF8 3\n");
      size_utf8 += bytes_read;
      // fprintf(stderr, "[brotli/c/enc/utf8_util.c] exit BrotliIsMostlyUTF8 3\n");
    }
    // fprintf(stderr, "[brotli/c/enc/utf8_util.c] exit BrotliIsMostlyUTF8 2\n");
  }
  fprintf(stderr, "[brotli/c/enc/utf8_util.c] enter BrotliIsMostlyUTF8 4\n");
  return TO_BROTLI_BOOL(size_utf8 > min_fraction * (double)length);
  // fprintf(stderr, "[brotli/c/enc/utf8_util.c] exit BrotliIsMostlyUTF8 4\n");
}

#if defined(__cplusplus) || defined(c_plusplus)
}  /* extern "C" */
#endif
// Total cost: 0.030355
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 85)]
// Total instrumented cost: 0.030355, input tokens: 2398, output tokens: 1703, cache read tokens: 2394, cache write tokens: 1088
