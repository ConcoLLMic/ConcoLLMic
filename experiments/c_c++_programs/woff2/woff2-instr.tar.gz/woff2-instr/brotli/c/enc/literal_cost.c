/* Copyright 2013 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

/* Literal cost model to allow backward reference replacement to be efficient.
*/

#include "./literal_cost.h"

#include "../common/platform.h"
#include <brotli/types.h>
#include "./fast_log.h"
#include "./utf8_util.h"
#include <stdio.h>

#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

static size_t UTF8Position(size_t last, size_t c, size_t clamp) {
  fprintf(stderr, "[brotli/c/enc/literal_cost.c] enter UTF8Position 1\n");
  if (c < 128) {
    fprintf(stderr, "[brotli/c/enc/literal_cost.c] enter UTF8Position 2\n");
    return 0;  /* Next one is the 'Byte 1' again. */
    // fprintf(stderr, "[brotli/c/enc/literal_cost.c] exit UTF8Position 2\n");
  } else if (c >= 192) {  /* Next one is the 'Byte 2' of utf-8 encoding. */
    fprintf(stderr, "[brotli/c/enc/literal_cost.c] enter UTF8Position 3\n");
    return BROTLI_MIN(size_t, 1, clamp);
    // fprintf(stderr, "[brotli/c/enc/literal_cost.c] exit UTF8Position 3\n");
  } else {
    fprintf(stderr, "[brotli/c/enc/literal_cost.c] enter UTF8Position 4\n");
    /* Let's decide over the last byte if this ends the sequence. */
    if (last < 0xE0) {
      fprintf(stderr, "[brotli/c/enc/literal_cost.c] enter UTF8Position 5\n");
      return 0;  /* Completed two or three byte coding. */
      // fprintf(stderr, "[brotli/c/enc/literal_cost.c] exit UTF8Position 5\n");
    } else {  /* Next one is the 'Byte 3' of utf-8 encoding. */
      fprintf(stderr, "[brotli/c/enc/literal_cost.c] enter UTF8Position 6\n");
      return BROTLI_MIN(size_t, 2, clamp);
      // fprintf(stderr, "[brotli/c/enc/literal_cost.c] exit UTF8Position 6\n");
    }
    // fprintf(stderr, "[brotli/c/enc/literal_cost.c] exit UTF8Position 4\n");
  }
  // fprintf(stderr, "[brotli/c/enc/literal_cost.c] exit UTF8Position 1\n");
}

static size_t DecideMultiByteStatsLevel(size_t pos, size_t len, size_t mask,
                                        const uint8_t* data) {
  fprintf(stderr, "[brotli/c/enc/literal_cost.c] enter DecideMultiByteStatsLevel 1\n");
  size_t counts[3] = { 0 };
  size_t max_utf8 = 1;  /* should be 2, but 1 compresses better. */
  size_t last_c = 0;
  size_t i;
  for (i = 0; i < len; ++i) {
    fprintf(stderr, "[brotli/c/enc/literal_cost.c] enter DecideMultiByteStatsLevel 2\n");
    size_t c = data[(pos + i) & mask];
    ++counts[UTF8Position(last_c, c, 2)];
    last_c = c;
    // fprintf(stderr, "[brotli/c/enc/literal_cost.c] exit DecideMultiByteStatsLevel 2\n");
  }
  if (counts[2] < 500) {
    fprintf(stderr, "[brotli/c/enc/literal_cost.c] enter DecideMultiByteStatsLevel 3\n");
    max_utf8 = 1;
    // fprintf(stderr, "[brotli/c/enc/literal_cost.c] exit DecideMultiByteStatsLevel 3\n");
  }
  if (counts[1] + counts[2] < 25) {
    fprintf(stderr, "[brotli/c/enc/literal_cost.c] enter DecideMultiByteStatsLevel 4\n");
    max_utf8 = 0;
    // fprintf(stderr, "[brotli/c/enc/literal_cost.c] exit DecideMultiByteStatsLevel 4\n");
  }
  return max_utf8;
  // fprintf(stderr, "[brotli/c/enc/literal_cost.c] exit DecideMultiByteStatsLevel 1\n");
}

static void EstimateBitCostsForLiteralsUTF8(size_t pos, size_t len, size_t mask,
                                            const uint8_t* data, float* cost) {
  fprintf(stderr, "[brotli/c/enc/literal_cost.c] enter EstimateBitCostsForLiteralsUTF8 1\n");
  /* max_utf8 is 0 (normal ASCII single byte modeling),
     1 (for 2-byte UTF-8 modeling), or 2 (for 3-byte UTF-8 modeling). */
  const size_t max_utf8 = DecideMultiByteStatsLevel(pos, len, mask, data);
  size_t histogram[3][256] = { { 0 } };
  size_t window_half = 495;
  size_t in_window = BROTLI_MIN(size_t, window_half, len);
  size_t in_window_utf8[3] = { 0 };

  size_t i;
  {  /* Bootstrap histograms. */
    fprintf(stderr, "[brotli/c/enc/literal_cost.c] enter EstimateBitCostsForLiteralsUTF8 2\n");
    size_t last_c = 0;
    size_t utf8_pos = 0;
    for (i = 0; i < in_window; ++i) {
      fprintf(stderr, "[brotli/c/enc/literal_cost.c] enter EstimateBitCostsForLiteralsUTF8 3\n");
      size_t c = data[(pos + i) & mask];
      ++histogram[utf8_pos][c];
      ++in_window_utf8[utf8_pos];
      utf8_pos = UTF8Position(last_c, c, max_utf8);
      last_c = c;
      // fprintf(stderr, "[brotli/c/enc/literal_cost.c] exit EstimateBitCostsForLiteralsUTF8 3\n");
    }
    // fprintf(stderr, "[brotli/c/enc/literal_cost.c] exit EstimateBitCostsForLiteralsUTF8 2\n");
  }

  /* Compute bit costs with sliding window. */
  for (i = 0; i < len; ++i) {
    fprintf(stderr, "[brotli/c/enc/literal_cost.c] enter EstimateBitCostsForLiteralsUTF8 4\n");
    if (i >= window_half) {
      fprintf(stderr, "[brotli/c/enc/literal_cost.c] enter EstimateBitCostsForLiteralsUTF8 5\n");
      /* Remove a byte in the past. */
      size_t c =
          i < window_half + 1 ? 0 : data[(pos + i - window_half - 1) & mask];
      size_t last_c =
          i < window_half + 2 ? 0 : data[(pos + i - window_half - 2) & mask];
      size_t utf8_pos2 = UTF8Position(last_c, c, max_utf8);
      --histogram[utf8_pos2][data[(pos + i - window_half) & mask]];
      --in_window_utf8[utf8_pos2];
      // fprintf(stderr, "[brotli/c/enc/literal_cost.c] exit EstimateBitCostsForLiteralsUTF8 5\n");
    }
    if (i + window_half < len) {
      fprintf(stderr, "[brotli/c/enc/literal_cost.c] enter EstimateBitCostsForLiteralsUTF8 6\n");
      /* Add a byte in the future. */
      size_t c = data[(pos + i + window_half - 1) & mask];
      size_t last_c = data[(pos + i + window_half - 2) & mask];
      size_t utf8_pos2 = UTF8Position(last_c, c, max_utf8);
      ++histogram[utf8_pos2][data[(pos + i + window_half) & mask]];
      ++in_window_utf8[utf8_pos2];
      // fprintf(stderr, "[brotli/c/enc/literal_cost.c] exit EstimateBitCostsForLiteralsUTF8 6\n");
    }
    {
      fprintf(stderr, "[brotli/c/enc/literal_cost.c] enter EstimateBitCostsForLiteralsUTF8 7\n");
      size_t c = i < 1 ? 0 : data[(pos + i - 1) & mask];
      size_t last_c = i < 2 ? 0 : data[(pos + i - 2) & mask];
      size_t utf8_pos = UTF8Position(last_c, c, max_utf8);
      size_t masked_pos = (pos + i) & mask;
      size_t histo = histogram[utf8_pos][data[masked_pos]];
      double lit_cost;
      if (histo == 0) {
        fprintf(stderr, "[brotli/c/enc/literal_cost.c] enter EstimateBitCostsForLiteralsUTF8 8\n");
        histo = 1;
        // fprintf(stderr, "[brotli/c/enc/literal_cost.c] exit EstimateBitCostsForLiteralsUTF8 8\n");
      }
      lit_cost = FastLog2(in_window_utf8[utf8_pos]) - FastLog2(histo);
      lit_cost += 0.02905;
      if (lit_cost < 1.0) {
        fprintf(stderr, "[brotli/c/enc/literal_cost.c] enter EstimateBitCostsForLiteralsUTF8 9\n");
        lit_cost *= 0.5;
        lit_cost += 0.5;
        // fprintf(stderr, "[brotli/c/enc/literal_cost.c] exit EstimateBitCostsForLiteralsUTF8 9\n");
      }
      /* Make the first bytes more expensive -- seems to help, not sure why.
         Perhaps because the entropy source is changing its properties
         rapidly in the beginning of the file, perhaps because the beginning
         of the data is a statistical "anomaly". */
      if (i < 2000) {
        fprintf(stderr, "[brotli/c/enc/literal_cost.c] enter EstimateBitCostsForLiteralsUTF8 10\n");
        lit_cost += 0.7 - ((double)(2000 - i) / 2000.0 * 0.35);
        // fprintf(stderr, "[brotli/c/enc/literal_cost.c] exit EstimateBitCostsForLiteralsUTF8 10\n");
      }
      cost[i] = (float)lit_cost;
      // fprintf(stderr, "[brotli/c/enc/literal_cost.c] exit EstimateBitCostsForLiteralsUTF8 7\n");
    }
    // fprintf(stderr, "[brotli/c/enc/literal_cost.c] exit EstimateBitCostsForLiteralsUTF8 4\n");
  }
  // fprintf(stderr, "[brotli/c/enc/literal_cost.c] exit EstimateBitCostsForLiteralsUTF8 1\n");
}

void BrotliEstimateBitCostsForLiterals(size_t pos, size_t len, size_t mask,
                                       const uint8_t* data, float* cost) {
  fprintf(stderr, "[brotli/c/enc/literal_cost.c] enter BrotliEstimateBitCostsForLiterals 1\n");
  if (BrotliIsMostlyUTF8(data, pos, mask, len, kMinUTF8Ratio)) {
    fprintf(stderr, "[brotli/c/enc/literal_cost.c] enter BrotliEstimateBitCostsForLiterals 2\n");
    EstimateBitCostsForLiteralsUTF8(pos, len, mask, data, cost);
    return;
    // fprintf(stderr, "[brotli/c/enc/literal_cost.c] exit BrotliEstimateBitCostsForLiterals 2\n");
  } else {
    fprintf(stderr, "[brotli/c/enc/literal_cost.c] enter BrotliEstimateBitCostsForLiterals 3\n");
    size_t histogram[256] = { 0 };
    size_t window_half = 2000;
    size_t in_window = BROTLI_MIN(size_t, window_half, len);

    /* Bootstrap histogram. */
    size_t i;
    for (i = 0; i < in_window; ++i) {
      fprintf(stderr, "[brotli/c/enc/literal_cost.c] enter BrotliEstimateBitCostsForLiterals 4\n");
      ++histogram[data[(pos + i) & mask]];
      // fprintf(stderr, "[brotli/c/enc/literal_cost.c] exit BrotliEstimateBitCostsForLiterals 4\n");
    }

    /* Compute bit costs with sliding window. */
    for (i = 0; i < len; ++i) {
      fprintf(stderr, "[brotli/c/enc/literal_cost.c] enter BrotliEstimateBitCostsForLiterals 5\n");
      size_t histo;
      if (i >= window_half) {
        fprintf(stderr, "[brotli/c/enc/literal_cost.c] enter BrotliEstimateBitCostsForLiterals 6\n");
        /* Remove a byte in the past. */
        --histogram[data[(pos + i - window_half) & mask]];
        --in_window;
        // fprintf(stderr, "[brotli/c/enc/literal_cost.c] exit BrotliEstimateBitCostsForLiterals 6\n");
      }
      if (i + window_half < len) {
        fprintf(stderr, "[brotli/c/enc/literal_cost.c] enter BrotliEstimateBitCostsForLiterals 7\n");
        /* Add a byte in the future. */
        ++histogram[data[(pos + i + window_half) & mask]];
        ++in_window;
        // fprintf(stderr, "[brotli/c/enc/literal_cost.c] exit BrotliEstimateBitCostsForLiterals 7\n");
      }
      histo = histogram[data[(pos + i) & mask]];
      if (histo == 0) {
        fprintf(stderr, "[brotli/c/enc/literal_cost.c] enter BrotliEstimateBitCostsForLiterals 8\n");
        histo = 1;
        // fprintf(stderr, "[brotli/c/enc/literal_cost.c] exit BrotliEstimateBitCostsForLiterals 8\n");
      }
      {
        fprintf(stderr, "[brotli/c/enc/literal_cost.c] enter BrotliEstimateBitCostsForLiterals 9\n");
        double lit_cost = FastLog2(in_window) - FastLog2(histo);
        lit_cost += 0.029;
        if (lit_cost < 1.0) {
          fprintf(stderr, "[brotli/c/enc/literal_cost.c] enter BrotliEstimateBitCostsForLiterals 10\n");
          lit_cost *= 0.5;
          lit_cost += 0.5;
          // fprintf(stderr, "[brotli/c/enc/literal_cost.c] exit BrotliEstimateBitCostsForLiterals 10\n");
        }
        cost[i] = (float)lit_cost;
        // fprintf(stderr, "[brotli/c/enc/literal_cost.c] exit BrotliEstimateBitCostsForLiterals 9\n");
      }
      // fprintf(stderr, "[brotli/c/enc/literal_cost.c] exit BrotliEstimateBitCostsForLiterals 5\n");
    }
    // fprintf(stderr, "[brotli/c/enc/literal_cost.c] exit BrotliEstimateBitCostsForLiterals 3\n");
  }
  // fprintf(stderr, "[brotli/c/enc/literal_cost.c] exit BrotliEstimateBitCostsForLiterals 1\n");
}

#if defined(__cplusplus) || defined(c_plusplus)
}  /* extern "C" */
#endif
// Total cost: 0.140788
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 175)]
// Total instrumented cost: 0.140788, input tokens: 7073, output tokens: 7703, cache read tokens: 7065, cache write tokens: 6160
