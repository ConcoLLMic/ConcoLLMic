/* Copyright 2013 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

/* Function to find backward reference copies. */

#include "./backward_references_hq.h"

#include <stdio.h>  /* for fprintf */
#include <string.h>  /* memcpy, memset */

#include "../common/constants.h"
#include "../common/platform.h"
#include <brotli/types.h>
#include "./command.h"
#include "./fast_log.h"
#include "./find_match_length.h"
#include "./literal_cost.h"
#include "./memory.h"
#include "./params.h"
#include "./prefix.h"
#include "./quality.h"

#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

#define BROTLI_MAX_EFFECTIVE_DISTANCE_ALPHABET_SIZE 544

static const float kInfinity = 1.7e38f;  /* ~= 2 ^ 127 */

static const uint32_t kDistanceCacheIndex[] = {
  0, 1, 2, 3, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1,
};
static const int kDistanceCacheOffset[] = {
  0, 0, 0, 0, -1, 1, -2, 2, -3, 3, -1, 1, -2, 2, -3, 3
};

void BrotliInitZopfliNodes(ZopfliNode* array, size_t length) {
  fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter BrotliInitZopfliNodes 1\n");
  ZopfliNode stub;
  size_t i;
  stub.length = 1;
  stub.distance = 0;
  stub.dcode_insert_length = 0;
  stub.u.cost = kInfinity;
  for (i = 0; i < length; ++i) array[i] = stub;
  // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit BrotliInitZopfliNodes 1\n");
}

static BROTLI_INLINE uint32_t ZopfliNodeCopyLength(const ZopfliNode* self) {
  fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter ZopfliNodeCopyLength 1\n");
  return self->length & 0x1FFFFFF;
  // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit ZopfliNodeCopyLength 1\n");
}

static BROTLI_INLINE uint32_t ZopfliNodeLengthCode(const ZopfliNode* self) {
  fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter ZopfliNodeLengthCode 1\n");
  const uint32_t modifier = self->length >> 25;
  return ZopfliNodeCopyLength(self) + 9u - modifier;
  // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit ZopfliNodeLengthCode 1\n");
}

static BROTLI_INLINE uint32_t ZopfliNodeCopyDistance(const ZopfliNode* self) {
  fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter ZopfliNodeCopyDistance 1\n");
  return self->distance;
  // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit ZopfliNodeCopyDistance 1\n");
}

static BROTLI_INLINE uint32_t ZopfliNodeDistanceCode(const ZopfliNode* self) {
  fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter ZopfliNodeDistanceCode 1\n");
  const uint32_t short_code = self->dcode_insert_length >> 27;
  return short_code == 0 ?
      ZopfliNodeCopyDistance(self) + BROTLI_NUM_DISTANCE_SHORT_CODES - 1 :
      short_code - 1;
  // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit ZopfliNodeDistanceCode 1\n");
}

static BROTLI_INLINE uint32_t ZopfliNodeCommandLength(const ZopfliNode* self) {
  fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter ZopfliNodeCommandLength 1\n");
  return ZopfliNodeCopyLength(self) + (self->dcode_insert_length & 0x7FFFFFF);
  // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit ZopfliNodeCommandLength 1\n");
}

/* Histogram based cost model for zopflification. */
typedef struct ZopfliCostModel {
  /* The insert and copy length symbols. */
  float cost_cmd_[BROTLI_NUM_COMMAND_SYMBOLS];
  float* cost_dist_;
  uint32_t distance_alphabet_size;
  /* Cumulative costs of literals per position in the stream. */
  float* literal_costs_;
  float min_cost_cmd_;
  size_t num_bytes_;
} ZopfliCostModel;

static void InitZopfliCostModel(
    MemoryManager* m, ZopfliCostModel* self, const BrotliDistanceParams* dist,
    size_t num_bytes) {
  fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter InitZopfliCostModel 1\n");
  self->num_bytes_ = num_bytes;
  self->literal_costs_ = BROTLI_ALLOC(m, float, num_bytes + 2);
  self->cost_dist_ = BROTLI_ALLOC(m, float, dist->alphabet_size);
  self->distance_alphabet_size = dist->alphabet_size;
  if (BROTLI_IS_OOM(m)) return;
  // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit InitZopfliCostModel 1\n");
}

static void CleanupZopfliCostModel(MemoryManager* m, ZopfliCostModel* self) {
  fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter CleanupZopfliCostModel 1\n");
  BROTLI_FREE(m, self->literal_costs_);
  BROTLI_FREE(m, self->cost_dist_);
  // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit CleanupZopfliCostModel 1\n");
}

static void SetCost(const uint32_t* histogram, size_t histogram_size,
                    BROTLI_BOOL literal_histogram, float* cost) {
  fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter SetCost 1\n");
  size_t sum = 0;
  size_t missing_symbol_sum;
  float log2sum;
  float missing_symbol_cost;
  size_t i;
  for (i = 0; i < histogram_size; i++) {
    sum += histogram[i];
  }
  log2sum = (float)FastLog2(sum);
  missing_symbol_sum = sum;
  if (!literal_histogram) {
    fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter SetCost 2\n");
    for (i = 0; i < histogram_size; i++) {
      if (histogram[i] == 0) missing_symbol_sum++;
    }
    // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit SetCost 2\n");
  }
  missing_symbol_cost = (float)FastLog2(missing_symbol_sum) + 2;
  for (i = 0; i < histogram_size; i++) {
    fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter SetCost 3\n");
    if (histogram[i] == 0) {
      fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter SetCost 4\n");
      cost[i] = missing_symbol_cost;
      // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit SetCost 4\n");
      continue;
    }

    /* Shannon bits for this symbol. */
    cost[i] = log2sum - (float)FastLog2(histogram[i]);

    /* Cannot be coded with less than 1 bit */
    if (cost[i] < 1) cost[i] = 1;
    // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit SetCost 3\n");
  }
  // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit SetCost 1\n");
}

static void ZopfliCostModelSetFromCommands(ZopfliCostModel* self,
                                           size_t position,
                                           const uint8_t* ringbuffer,
                                           size_t ringbuffer_mask,
                                           const Command* commands,
                                           size_t num_commands,
                                           size_t last_insert_len) {
  fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter ZopfliCostModelSetFromCommands 1\n");
  uint32_t histogram_literal[BROTLI_NUM_LITERAL_SYMBOLS];
  uint32_t histogram_cmd[BROTLI_NUM_COMMAND_SYMBOLS];
  uint32_t histogram_dist[BROTLI_MAX_EFFECTIVE_DISTANCE_ALPHABET_SIZE];
  float cost_literal[BROTLI_NUM_LITERAL_SYMBOLS];
  size_t pos = position - last_insert_len;
  float min_cost_cmd = kInfinity;
  size_t i;
  float* cost_cmd = self->cost_cmd_;

  memset(histogram_literal, 0, sizeof(histogram_literal));
  memset(histogram_cmd, 0, sizeof(histogram_cmd));
  memset(histogram_dist, 0, sizeof(histogram_dist));

  for (i = 0; i < num_commands; i++) {
    fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter ZopfliCostModelSetFromCommands 2\n");
    size_t inslength = commands[i].insert_len_;
    size_t copylength = CommandCopyLen(&commands[i]);
    size_t distcode = commands[i].dist_prefix_ & 0x3FF;
    size_t cmdcode = commands[i].cmd_prefix_;
    size_t j;

    histogram_cmd[cmdcode]++;
    if (cmdcode >= 128) histogram_dist[distcode]++;

    for (j = 0; j < inslength; j++) {
      fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter ZopfliCostModelSetFromCommands 3\n");
      histogram_literal[ringbuffer[(pos + j) & ringbuffer_mask]]++;
      // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit ZopfliCostModelSetFromCommands 3\n");
    }

    pos += inslength + copylength;
    // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit ZopfliCostModelSetFromCommands 2\n");
  }

  SetCost(histogram_literal, BROTLI_NUM_LITERAL_SYMBOLS, BROTLI_TRUE,
          cost_literal);
  SetCost(histogram_cmd, BROTLI_NUM_COMMAND_SYMBOLS, BROTLI_FALSE,
          cost_cmd);
  SetCost(histogram_dist, self->distance_alphabet_size, BROTLI_FALSE,
          self->cost_dist_);

  for (i = 0; i < BROTLI_NUM_COMMAND_SYMBOLS; ++i) {
    fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter ZopfliCostModelSetFromCommands 4\n");
    min_cost_cmd = BROTLI_MIN(float, min_cost_cmd, cost_cmd[i]);
    // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit ZopfliCostModelSetFromCommands 4\n");
  }
  self->min_cost_cmd_ = min_cost_cmd;

  {
    fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter ZopfliCostModelSetFromCommands 5\n");
    float* literal_costs = self->literal_costs_;
    float literal_carry = 0.0;
    size_t num_bytes = self->num_bytes_;
    literal_costs[0] = 0.0;
    for (i = 0; i < num_bytes; ++i) {
      fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter ZopfliCostModelSetFromCommands 6\n");
      literal_carry +=
          cost_literal[ringbuffer[(position + i) & ringbuffer_mask]];
      literal_costs[i + 1] = literal_costs[i] + literal_carry;
      literal_carry -= literal_costs[i + 1] - literal_costs[i];
      // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit ZopfliCostModelSetFromCommands 6\n");
    }
    // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit ZopfliCostModelSetFromCommands 5\n");
  }
  // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit ZopfliCostModelSetFromCommands 1\n");
}

static void ZopfliCostModelSetFromLiteralCosts(ZopfliCostModel* self,
                                               size_t position,
                                               const uint8_t* ringbuffer,
                                               size_t ringbuffer_mask) {
  fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter ZopfliCostModelSetFromLiteralCosts 1\n");
  float* literal_costs = self->literal_costs_;
  float literal_carry = 0.0;
  float* cost_dist = self->cost_dist_;
  float* cost_cmd = self->cost_cmd_;
  size_t num_bytes = self->num_bytes_;
  size_t i;
  BrotliEstimateBitCostsForLiterals(position, num_bytes, ringbuffer_mask,
                                    ringbuffer, &literal_costs[1]);
  literal_costs[0] = 0.0;
  for (i = 0; i < num_bytes; ++i) {
    fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter ZopfliCostModelSetFromLiteralCosts 2\n");
    literal_carry += literal_costs[i + 1];
    literal_costs[i + 1] = literal_costs[i] + literal_carry;
    literal_carry -= literal_costs[i + 1] - literal_costs[i];
    // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit ZopfliCostModelSetFromLiteralCosts 2\n");
  }
  for (i = 0; i < BROTLI_NUM_COMMAND_SYMBOLS; ++i) {
    fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter ZopfliCostModelSetFromLiteralCosts 3\n");
    cost_cmd[i] = (float)FastLog2(11 + (uint32_t)i);
    // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit ZopfliCostModelSetFromLiteralCosts 3\n");
  }
  for (i = 0; i < self->distance_alphabet_size; ++i) {
    fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter ZopfliCostModelSetFromLiteralCosts 4\n");
    cost_dist[i] = (float)FastLog2(20 + (uint32_t)i);
    // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit ZopfliCostModelSetFromLiteralCosts 4\n");
  }
  self->min_cost_cmd_ = (float)FastLog2(11);
  // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit ZopfliCostModelSetFromLiteralCosts 1\n");
}

static BROTLI_INLINE float ZopfliCostModelGetCommandCost(
    const ZopfliCostModel* self, uint16_t cmdcode) {
  fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter ZopfliCostModelGetCommandCost 1\n");
  return self->cost_cmd_[cmdcode];
  // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit ZopfliCostModelGetCommandCost 1\n");
}

static BROTLI_INLINE float ZopfliCostModelGetDistanceCost(
    const ZopfliCostModel* self, size_t distcode) {
  fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter ZopfliCostModelGetDistanceCost 1\n");
  return self->cost_dist_[distcode];
  // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit ZopfliCostModelGetDistanceCost 1\n");
}

static BROTLI_INLINE float ZopfliCostModelGetLiteralCosts(
    const ZopfliCostModel* self, size_t from, size_t to) {
  fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter ZopfliCostModelGetLiteralCosts 1\n");
  return self->literal_costs_[to] - self->literal_costs_[from];
  // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit ZopfliCostModelGetLiteralCosts 1\n");
}

static BROTLI_INLINE float ZopfliCostModelGetMinCostCmd(
    const ZopfliCostModel* self) {
  fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter ZopfliCostModelGetMinCostCmd 1\n");
  return self->min_cost_cmd_;
  // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit ZopfliCostModelGetMinCostCmd 1\n");
}

/* REQUIRES: len >= 2, start_pos <= pos */
/* REQUIRES: cost < kInfinity, nodes[start_pos].cost < kInfinity */
/* Maintains the "ZopfliNode array invariant". */
static BROTLI_INLINE void UpdateZopfliNode(ZopfliNode* nodes, size_t pos,
    size_t start_pos, size_t len, size_t len_code, size_t dist,
    size_t short_code, float cost) {
  fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter UpdateZopfliNode 1\n");
  ZopfliNode* next = &nodes[pos + len];
  next->length = (uint32_t)(len | ((len + 9u - len_code) << 25));
  next->distance = (uint32_t)dist;
  next->dcode_insert_length = (uint32_t)(
      (short_code << 27) | (pos - start_pos));
  next->u.cost = cost;
  // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit UpdateZopfliNode 1\n");
}

typedef struct PosData {
  size_t pos;
  int distance_cache[4];
  float costdiff;
  float cost;
} PosData;

/* Maintains the smallest 8 cost difference together with their positions */
typedef struct StartPosQueue {
  PosData q_[8];
  size_t idx_;
} StartPosQueue;

static BROTLI_INLINE void InitStartPosQueue(StartPosQueue* self) {
  fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter InitStartPosQueue 1\n");
  self->idx_ = 0;
  // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit InitStartPosQueue 1\n");
}

static size_t StartPosQueueSize(const StartPosQueue* self) {
  fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter StartPosQueueSize 1\n");
  return BROTLI_MIN(size_t, self->idx_, 8);
  // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit StartPosQueueSize 1\n");
}

static void StartPosQueuePush(StartPosQueue* self, const PosData* posdata) {
  fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter StartPosQueuePush 1\n");
  size_t offset = ~(self->idx_++) & 7;
  size_t len = StartPosQueueSize(self);
  size_t i;
  PosData* q = self->q_;
  q[offset] = *posdata;
  /* Restore the sorted order. In the list of |len| items at most |len - 1|
     adjacent element comparisons / swaps are required. */
  for (i = 1; i < len; ++i) {
    fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter StartPosQueuePush 2\n");
    if (q[offset & 7].costdiff > q[(offset + 1) & 7].costdiff) {
      fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter StartPosQueuePush 3\n");
      BROTLI_SWAP(PosData, q, offset & 7, (offset + 1) & 7);
      // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit StartPosQueuePush 3\n");
    }
    ++offset;
    // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit StartPosQueuePush 2\n");
  }
  // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit StartPosQueuePush 1\n");
}

static const PosData* StartPosQueueAt(const StartPosQueue* self, size_t k) {
  fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter StartPosQueueAt 1\n");
  return &self->q_[(k - self->idx_) & 7];
  // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit StartPosQueueAt 1\n");
}

/* Returns the minimum possible copy length that can improve the cost of any */
/* future position. */
static size_t ComputeMinimumCopyLength(const float start_cost,
                                       const ZopfliNode* nodes,
                                       const size_t num_bytes,
                                       const size_t pos) {
  fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter ComputeMinimumCopyLength 1\n");
  /* Compute the minimum possible cost of reaching any future position. */
  float min_cost = start_cost;
  size_t len = 2;
  size_t next_len_bucket = 4;
  size_t next_len_offset = 10;
  while (pos + len <= num_bytes && nodes[pos + len].u.cost <= min_cost) {
    fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter ComputeMinimumCopyLength 2\n");
    /* We already reached (pos + len) with no more cost than the minimum
       possible cost of reaching anything from this pos, so there is no point in
       looking for lengths <= len. */
    ++len;
    if (len == next_len_offset) {
      fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter ComputeMinimumCopyLength 3\n");
      /* We reached the next copy length code bucket, so we add one more
         extra bit to the minimum cost. */
      min_cost += 1.0f;
      next_len_offset += next_len_bucket;
      next_len_bucket *= 2;
      // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit ComputeMinimumCopyLength 3\n");
    }
    // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit ComputeMinimumCopyLength 2\n");
  }
  return len;
  // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit ComputeMinimumCopyLength 1\n");
}

/* REQUIRES: nodes[pos].cost < kInfinity
   REQUIRES: nodes[0..pos] satisfies that "ZopfliNode array invariant". */
static uint32_t ComputeDistanceShortcut(const size_t block_start,
                                        const size_t pos,
                                        const size_t max_backward,
                                        const size_t gap,
                                        const ZopfliNode* nodes) {
  fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter ComputeDistanceShortcut 1\n");
  const size_t clen = ZopfliNodeCopyLength(&nodes[pos]);
  const size_t ilen = nodes[pos].dcode_insert_length & 0x7FFFFFF;
  const size_t dist = ZopfliNodeCopyDistance(&nodes[pos]);
  /* Since |block_start + pos| is the end position of the command, the copy part
     starts from |block_start + pos - clen|. Distances that are greater than
     this or greater than |max_backward| are static dictionary references, and
     do not update the last distances. Also distance code 0 (last distance)
     does not update the last distances. */
  if (pos == 0) {
    fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter ComputeDistanceShortcut 2\n");
    return 0;
    // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit ComputeDistanceShortcut 2\n");
  } else if (dist + clen <= block_start + pos + gap &&
             dist <= max_backward + gap &&
             ZopfliNodeDistanceCode(&nodes[pos]) > 0) {
    fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter ComputeDistanceShortcut 3\n");
    return (uint32_t)pos;
    // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit ComputeDistanceShortcut 3\n");
  } else {
    fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter ComputeDistanceShortcut 4\n");
    return nodes[pos - clen - ilen].u.shortcut;
    // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit ComputeDistanceShortcut 4\n");
  }
  // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit ComputeDistanceShortcut 1\n");
}

/* Fills in dist_cache[0..3] with the last four distances (as defined by
   Section 4. of the Spec) that would be used at (block_start + pos) if we
   used the shortest path of commands from block_start, computed from
   nodes[0..pos]. The last four distances at block_start are in
   starting_dist_cache[0..3].
   REQUIRES: nodes[pos].cost < kInfinity
   REQUIRES: nodes[0..pos] satisfies that "ZopfliNode array invariant". */
static void ComputeDistanceCache(const size_t pos,
                                 const int* starting_dist_cache,
                                 const ZopfliNode* nodes,
                                 int* dist_cache) {
  fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter ComputeDistanceCache 1\n");
  int idx = 0;
  size_t p = nodes[pos].u.shortcut;
  while (idx < 4 && p > 0) {
    fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter ComputeDistanceCache 2\n");
    const size_t ilen = nodes[p].dcode_insert_length & 0x7FFFFFF;
    const size_t clen = ZopfliNodeCopyLength(&nodes[p]);
    const size_t dist = ZopfliNodeCopyDistance(&nodes[p]);
    dist_cache[idx++] = (int)dist;
    /* Because of prerequisite, p >= clen + ilen >= 2. */
    p = nodes[p - clen - ilen].u.shortcut;
    // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit ComputeDistanceCache 2\n");
  }
  for (; idx < 4; ++idx) {
    fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter ComputeDistanceCache 3\n");
    dist_cache[idx] = *starting_dist_cache++;
    // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit ComputeDistanceCache 3\n");
  }
  // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit ComputeDistanceCache 1\n");
}

/* Maintains "ZopfliNode array invariant" and pushes node to the queue, if it
   is eligible. */
static void EvaluateNode(
    const size_t block_start, const size_t pos, const size_t max_backward_limit,
    const size_t gap, const int* starting_dist_cache,
    const ZopfliCostModel* model, StartPosQueue* queue, ZopfliNode* nodes) {
  fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter EvaluateNode 1\n");
  /* Save cost, because ComputeDistanceCache invalidates it. */
  float node_cost = nodes[pos].u.cost;
  nodes[pos].u.shortcut = ComputeDistanceShortcut(
      block_start, pos, max_backward_limit, gap, nodes);
  if (node_cost <= ZopfliCostModelGetLiteralCosts(model, 0, pos)) {
    fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter EvaluateNode 2\n");
    PosData posdata;
    posdata.pos = pos;
    posdata.cost = node_cost;
    posdata.costdiff = node_cost -
        ZopfliCostModelGetLiteralCosts(model, 0, pos);
    ComputeDistanceCache(
        pos, starting_dist_cache, nodes, posdata.distance_cache);
    StartPosQueuePush(queue, &posdata);
    // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit EvaluateNode 2\n");
  }
  // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit EvaluateNode 1\n");
}

/* Returns longest copy length. */
static size_t UpdateNodes(
    const size_t num_bytes, const size_t block_start, const size_t pos,
    const uint8_t* ringbuffer, const size_t ringbuffer_mask,
    const BrotliEncoderParams* params, const size_t max_backward_limit,
    const int* starting_dist_cache, const size_t num_matches,
    const BackwardMatch* matches, const ZopfliCostModel* model,
    StartPosQueue* queue, ZopfliNode* nodes) {
  fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter UpdateNodes 1\n");
  const size_t cur_ix = block_start + pos;
  const size_t cur_ix_masked = cur_ix & ringbuffer_mask;
  const size_t max_distance = BROTLI_MIN(size_t, cur_ix, max_backward_limit);
  const size_t max_len = num_bytes - pos;
  const size_t max_zopfli_len = MaxZopfliLen(params);
  const size_t max_iters = MaxZopfliCandidates(params);
  size_t min_len;
  size_t result = 0;
  size_t k;
  size_t gap = 0;

  EvaluateNode(block_start, pos, max_backward_limit, gap, starting_dist_cache,
      model, queue, nodes);

  {
    fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter UpdateNodes 2\n");
    const PosData* posdata = StartPosQueueAt(queue, 0);
    float min_cost = (posdata->cost + ZopfliCostModelGetMinCostCmd(model) +
        ZopfliCostModelGetLiteralCosts(model, posdata->pos, pos));
    min_len = ComputeMinimumCopyLength(min_cost, nodes, num_bytes, pos);
    // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit UpdateNodes 2\n");
  }

  /* Go over the command starting positions in order of increasing cost
     difference. */
  for (k = 0; k < max_iters && k < StartPosQueueSize(queue); ++k) {
    fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter UpdateNodes 3\n");
    const PosData* posdata = StartPosQueueAt(queue, k);
    const size_t start = posdata->pos;
    const uint16_t inscode = GetInsertLengthCode(pos - start);
    const float start_costdiff = posdata->costdiff;
    const float base_cost = start_costdiff + (float)GetInsertExtra(inscode) +
        ZopfliCostModelGetLiteralCosts(model, 0, pos);

    /* Look for last distance matches using the distance cache from this
       starting position. */
    size_t best_len = min_len - 1;
    size_t j = 0;
    for (; j < BROTLI_NUM_DISTANCE_SHORT_CODES && best_len < max_len; ++j) {
      fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter UpdateNodes 4\n");
      const size_t idx = kDistanceCacheIndex[j];
      const size_t backward =
          (size_t)(posdata->distance_cache[idx] + kDistanceCacheOffset[j]);
      size_t prev_ix = cur_ix - backward;
      size_t len = 0;
      uint8_t continuation = ringbuffer[cur_ix_masked + best_len];
      if (cur_ix_masked + best_len > ringbuffer_mask) {
        fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter UpdateNodes 5\n");
        break;
        // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit UpdateNodes 5\n");
      }
      if (BROTLI_PREDICT_FALSE(backward > max_distance + gap)) {
        fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter UpdateNodes 6\n");
        continue;
        // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit UpdateNodes 6\n");
      }
      if (backward <= max_distance) {
        fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter UpdateNodes 7\n");
        if (prev_ix >= cur_ix) {
          fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter UpdateNodes 8\n");
          continue;
          // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit UpdateNodes 8\n");
        }

        prev_ix &= ringbuffer_mask;
        if (prev_ix + best_len > ringbuffer_mask ||
            continuation != ringbuffer[prev_ix + best_len]) {
          fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter UpdateNodes 9\n");
          continue;
          // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit UpdateNodes 9\n");
        }
        len = FindMatchLengthWithLimit(&ringbuffer[prev_ix],
                                       &ringbuffer[cur_ix_masked],
                                       max_len);
        // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit UpdateNodes 7\n");
      } else {
        fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter UpdateNodes 10\n");
        continue;
        // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit UpdateNodes 10\n");
      }
      {
        fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter UpdateNodes 11\n");
        const float dist_cost = base_cost +
            ZopfliCostModelGetDistanceCost(model, j);
        size_t l;
        for (l = best_len + 1; l <= len; ++l) {
          fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter UpdateNodes 12\n");
          const uint16_t copycode = GetCopyLengthCode(l);
          const uint16_t cmdcode =
              CombineLengthCodes(inscode, copycode, j == 0);
          const float cost = (cmdcode < 128 ? base_cost : dist_cost) +
              (float)GetCopyExtra(copycode) +
              ZopfliCostModelGetCommandCost(model, cmdcode);
          if (cost < nodes[pos + l].u.cost) {
            fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter UpdateNodes 13\n");
            UpdateZopfliNode(nodes, pos, start, l, l, backward, j + 1, cost);
            result = BROTLI_MAX(size_t, result, l);
            // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit UpdateNodes 13\n");
          }
          best_len = l;
          // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit UpdateNodes 12\n");
        }
        // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit UpdateNodes 11\n");
      }
      // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit UpdateNodes 4\n");
    }

    /* At higher iterations look only for new last distance matches, since
       looking only for new command start positions with the same distances
       does not help much. */
    if (k >= 2) continue;

    {
      fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter UpdateNodes 14\n");
      /* Loop through all possible copy lengths at this position. */
      size_t len = min_len;
      for (j = 0; j < num_matches; ++j) {
        fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter UpdateNodes 15\n");
        BackwardMatch match = matches[j];
        size_t dist = match.distance;
        BROTLI_BOOL is_dictionary_match =
            TO_BROTLI_BOOL(dist > max_distance + gap);
        /* We already tried all possible last distance matches, so we can use
           normal distance code here. */
        size_t dist_code = dist + BROTLI_NUM_DISTANCE_SHORT_CODES - 1;
        uint16_t dist_symbol;
        uint32_t distextra;
        uint32_t distnumextra;
        float dist_cost;
        size_t max_match_len;
        PrefixEncodeCopyDistance(
            dist_code, params->dist.num_direct_distance_codes,
            params->dist.distance_postfix_bits, &dist_symbol, &distextra);
        distnumextra = dist_symbol >> 10;
        dist_cost = base_cost + (float)distnumextra +
            ZopfliCostModelGetDistanceCost(model, dist_symbol & 0x3FF);

        /* Try all copy lengths up until the maximum copy length corresponding
           to this distance. If the distance refers to the static dictionary, or
           the maximum length is long enough, try only one maximum length. */
        max_match_len = BackwardMatchLength(&match);
        if (len < max_match_len &&
            (is_dictionary_match || max_match_len > max_zopfli_len)) {
          fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter UpdateNodes 16\n");
          len = max_match_len;
          // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit UpdateNodes 16\n");
        }
        for (; len <= max_match_len; ++len) {
          fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter UpdateNodes 17\n");
          const size_t len_code =
              is_dictionary_match ? BackwardMatchLengthCode(&match) : len;
          const uint16_t copycode = GetCopyLengthCode(len_code);
          const uint16_t cmdcode = CombineLengthCodes(inscode, copycode, 0);
          const float cost = dist_cost + (float)GetCopyExtra(copycode) +
              ZopfliCostModelGetCommandCost(model, cmdcode);
          if (cost < nodes[pos + len].u.cost) {
            fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter UpdateNodes 18\n");
            UpdateZopfliNode(nodes, pos, start, len, len_code, dist, 0, cost);
            result = BROTLI_MAX(size_t, result, len);
            // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit UpdateNodes 18\n");
          }
          // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit UpdateNodes 17\n");
        }
        // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit UpdateNodes 15\n");
      }
      // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit UpdateNodes 14\n");
    }
    // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit UpdateNodes 3\n");
  }
  return result;
  // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit UpdateNodes 1\n");
}

static size_t ComputeShortestPathFromNodes(size_t num_bytes,
    ZopfliNode* nodes) {
  fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter ComputeShortestPathFromNodes 1\n");
  size_t index = num_bytes;
  size_t num_commands = 0;
  while ((nodes[index].dcode_insert_length & 0x7FFFFFF) == 0 &&
      nodes[index].length == 1) --index;
  nodes[index].u.next = BROTLI_UINT32_MAX;
  while (index != 0) {
    fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter ComputeShortestPathFromNodes 2\n");
    size_t len = ZopfliNodeCommandLength(&nodes[index]);
    index -= len;
    nodes[index].u.next = (uint32_t)len;
    num_commands++;
    // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit ComputeShortestPathFromNodes 2\n");
  }
  return num_commands;
  // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit ComputeShortestPathFromNodes 1\n");
}

/* REQUIRES: nodes != NULL and len(nodes) >= num_bytes + 1 */
void BrotliZopfliCreateCommands(const size_t num_bytes,
                                const size_t block_start,
                                const size_t max_backward_limit,
                                const ZopfliNode* nodes,
                                int* dist_cache,
                                size_t* last_insert_len,
                                const BrotliEncoderParams* params,
                                Command* commands,
                                size_t* num_literals) {
  fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter BrotliZopfliCreateCommands 1\n");
  size_t pos = 0;
  uint32_t offset = nodes[0].u.next;
  size_t i;
  size_t gap = 0;
  for (i = 0; offset != BROTLI_UINT32_MAX; i++) {
    fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter BrotliZopfliCreateCommands 2\n");
    const ZopfliNode* next = &nodes[pos + offset];
    size_t copy_length = ZopfliNodeCopyLength(next);
    size_t insert_length = next->dcode_insert_length & 0x7FFFFFF;
    pos += insert_length;
    offset = next->u.next;
    if (i == 0) {
      fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter BrotliZopfliCreateCommands 3\n");
      insert_length += *last_insert_len;
      *last_insert_len = 0;
      // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit BrotliZopfliCreateCommands 3\n");
    }
    {
      fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter BrotliZopfliCreateCommands 4\n");
      size_t distance = ZopfliNodeCopyDistance(next);
      size_t len_code = ZopfliNodeLengthCode(next);
      size_t max_distance =
          BROTLI_MIN(size_t, block_start + pos, max_backward_limit);
      BROTLI_BOOL is_dictionary = TO_BROTLI_BOOL(distance > max_distance + gap);
      size_t dist_code = ZopfliNodeDistanceCode(next);
      InitCommand(&commands[i], &params->dist, insert_length,
          copy_length, (int)len_code - (int)copy_length, dist_code);

      if (!is_dictionary && dist_code > 0) {
        fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter BrotliZopfliCreateCommands 5\n");
        dist_cache[3] = dist_cache[2];
        dist_cache[2] = dist_cache[1];
        dist_cache[1] = dist_cache[0];
        dist_cache[0] = (int)distance;
        // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit BrotliZopfliCreateCommands 5\n");
      }
      // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit BrotliZopfliCreateCommands 4\n");
    }

    *num_literals += insert_length;
    pos += copy_length;
    // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit BrotliZopfliCreateCommands 2\n");
  }
  *last_insert_len += num_bytes - pos;
  // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit BrotliZopfliCreateCommands 1\n");
}

static size_t ZopfliIterate(size_t num_bytes,
                            size_t position,
                            const uint8_t* ringbuffer,
                            size_t ringbuffer_mask,
                            const BrotliEncoderParams* params,
                            const size_t max_backward_limit,
                            const size_t gap,
                            const int* dist_cache,
                            const ZopfliCostModel* model,
                            const uint32_t* num_matches,
                            const BackwardMatch* matches,
                            ZopfliNode* nodes) {
  fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter ZopfliIterate 1\n");
  const size_t max_zopfli_len = MaxZopfliLen(params);
  StartPosQueue queue;
  size_t cur_match_pos = 0;
  size_t i;
  nodes[0].length = 0;
  nodes[0].u.cost = 0;
  InitStartPosQueue(&queue);
  for (i = 0; i + 3 < num_bytes; i++) {
    fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter ZopfliIterate 2\n");
    size_t skip = UpdateNodes(num_bytes, position, i, ringbuffer,
        ringbuffer_mask, params, max_backward_limit, dist_cache,
        num_matches[i], &matches[cur_match_pos], model, &queue, nodes);
    if (skip < BROTLI_LONG_COPY_QUICK_STEP) skip = 0;
    cur_match_pos += num_matches[i];
    if (num_matches[i] == 1 &&
        BackwardMatchLength(&matches[cur_match_pos - 1]) > max_zopfli_len) {
      fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter ZopfliIterate 3\n");
      skip = BROTLI_MAX(size_t,
          BackwardMatchLength(&matches[cur_match_pos - 1]), skip);
      // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit ZopfliIterate 3\n");
    }
    if (skip > 1) {
      fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter ZopfliIterate 4\n");
      skip--;
      while (skip) {
        fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter ZopfliIterate 5\n");
        i++;
        if (i + 3 >= num_bytes) break;
        EvaluateNode(position, i, max_backward_limit, gap, dist_cache, model,
            &queue, nodes);
        cur_match_pos += num_matches[i];
        skip--;
        // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit ZopfliIterate 5\n");
      }
      // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit ZopfliIterate 4\n");
    }
    // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit ZopfliIterate 2\n");
  }
  return ComputeShortestPathFromNodes(num_bytes, nodes);
  // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit ZopfliIterate 1\n");
}

/* REQUIRES: nodes != NULL and len(nodes) >= num_bytes + 1 */
size_t BrotliZopfliComputeShortestPath(MemoryManager* m,
    size_t num_bytes, size_t position, const uint8_t* ringbuffer,
    size_t ringbuffer_mask, const BrotliEncoderParams* params,
    const size_t max_backward_limit, const int* dist_cache, HasherHandle hasher,
    ZopfliNode* nodes) {
  fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter BrotliZopfliComputeShortestPath 1\n");
  const size_t max_zopfli_len = MaxZopfliLen(params);
  ZopfliCostModel model;
  StartPosQueue queue;
  BackwardMatch matches[2 * (MAX_NUM_MATCHES_H10 + 64)];
  const size_t store_end = num_bytes >= StoreLookaheadH10() ?
      position + num_bytes - StoreLookaheadH10() + 1 : position;
  size_t i;
  size_t gap = 0;
  size_t lz_matches_offset = 0;
  nodes[0].length = 0;
  nodes[0].u.cost = 0;
  InitZopfliCostModel(m, &model, &params->dist, num_bytes);
  if (BROTLI_IS_OOM(m)) return 0;
  ZopfliCostModelSetFromLiteralCosts(
      &model, position, ringbuffer, ringbuffer_mask);
  InitStartPosQueue(&queue);
  for (i = 0; i + HashTypeLengthH10() - 1 < num_bytes; i++) {
    fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter BrotliZopfliComputeShortestPath 2\n");
    const size_t pos = position + i;
    const size_t max_distance = BROTLI_MIN(size_t, pos, max_backward_limit);
    size_t skip;
    size_t num_matches = FindAllMatchesH10(hasher, &params->dictionary,
        ringbuffer, ringbuffer_mask, pos, num_bytes - i, max_distance, gap,
        params, &matches[lz_matches_offset]);
    if (num_matches > 0 &&
        BackwardMatchLength(&matches[num_matches - 1]) > max_zopfli_len) {
      fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter BrotliZopfliComputeShortestPath 3\n");
      matches[0] = matches[num_matches - 1];
      num_matches = 1;
      // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit BrotliZopfliComputeShortestPath 3\n");
    }
    skip = UpdateNodes(num_bytes, position, i, ringbuffer, ringbuffer_mask,
        params, max_backward_limit, dist_cache, num_matches, matches, &model,
        &queue, nodes);
    if (skip < BROTLI_LONG_COPY_QUICK_STEP) skip = 0;
    if (num_matches == 1 && BackwardMatchLength(&matches[0]) > max_zopfli_len) {
      fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter BrotliZopfliComputeShortestPath 4\n");
      skip = BROTLI_MAX(size_t, BackwardMatchLength(&matches[0]), skip);
      // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit BrotliZopfliComputeShortestPath 4\n");
    }
    if (skip > 1) {
      fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter BrotliZopfliComputeShortestPath 5\n");
      /* Add the tail of the copy to the hasher. */
      StoreRangeH10(hasher, ringbuffer, ringbuffer_mask, pos + 1, BROTLI_MIN(
          size_t, pos + skip, store_end));
      skip--;
      while (skip) {
        fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter BrotliZopfliComputeShortestPath 6\n");
        i++;
        if (i + HashTypeLengthH10() - 1 >= num_bytes) break;
        EvaluateNode(position, i, max_backward_limit, gap, dist_cache, &model,
            &queue, nodes);
        skip--;
        // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit BrotliZopfliComputeShortestPath 6\n");
      }
      // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit BrotliZopfliComputeShortestPath 5\n");
    }
    // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit BrotliZopfliComputeShortestPath 2\n");
  }
  CleanupZopfliCostModel(m, &model);
  return ComputeShortestPathFromNodes(num_bytes, nodes);
  // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit BrotliZopfliComputeShortestPath 1\n");
}

void BrotliCreateZopfliBackwardReferences(MemoryManager* m,
    size_t num_bytes, size_t position, const uint8_t* ringbuffer,
    size_t ringbuffer_mask, const BrotliEncoderParams* params,
    HasherHandle hasher, int* dist_cache, size_t* last_insert_len,
    Command* commands, size_t* num_commands, size_t* num_literals) {
  fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter BrotliCreateZopfliBackwardReferences 1\n");
  const size_t max_backward_limit = BROTLI_MAX_BACKWARD_LIMIT(params->lgwin);
  ZopfliNode* nodes;
  nodes = BROTLI_ALLOC(m, ZopfliNode, num_bytes + 1);
  if (BROTLI_IS_OOM(m)) return;
  BrotliInitZopfliNodes(nodes, num_bytes + 1);
  *num_commands += BrotliZopfliComputeShortestPath(m,
      num_bytes, position, ringbuffer, ringbuffer_mask,
      params, max_backward_limit, dist_cache, hasher, nodes);
  if (BROTLI_IS_OOM(m)) return;
  BrotliZopfliCreateCommands(num_bytes, position, max_backward_limit, nodes,
      dist_cache, last_insert_len, params, commands, num_literals);
  BROTLI_FREE(m, nodes);
  // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit BrotliCreateZopfliBackwardReferences 1\n");
}

#if defined(__cplusplus) || defined(c_plusplus)
}  /* extern "C" */
#endif
void BrotliCreateHqZopfliBackwardReferences(MemoryManager* m,
    size_t num_bytes, size_t position, const uint8_t* ringbuffer,
    size_t ringbuffer_mask, const BrotliEncoderParams* params,
    HasherHandle hasher, int* dist_cache, size_t* last_insert_len,
    Command* commands, size_t* num_commands, size_t* num_literals) {
  fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter BrotliCreateHqZopfliBackwardReferences 1\n");
  const size_t max_backward_limit = BROTLI_MAX_BACKWARD_LIMIT(params->lgwin);
  uint32_t* num_matches = BROTLI_ALLOC(m, uint32_t, num_bytes);
  size_t matches_size = 4 * num_bytes;
  const size_t store_end = num_bytes >= StoreLookaheadH10() ?
      position + num_bytes - StoreLookaheadH10() + 1 : position;
  size_t cur_match_pos = 0;
  size_t i;
  size_t orig_num_literals;
  size_t orig_last_insert_len;
  int orig_dist_cache[4];
  size_t orig_num_commands;
  ZopfliCostModel model;
  ZopfliNode* nodes;
  BackwardMatch* matches = BROTLI_ALLOC(m, BackwardMatch, matches_size);
  size_t gap = 0;
  size_t shadow_matches = 0;
  if (BROTLI_IS_OOM(m)) return;
  // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit BrotliCreateHqZopfliBackwardReferences 1\n");
  
  for (i = 0; i + HashTypeLengthH10() - 1 < num_bytes; ++i) {
    fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter BrotliCreateHqZopfliBackwardReferences 2\n");
    const size_t pos = position + i;
    size_t max_distance = BROTLI_MIN(size_t, pos, max_backward_limit);
    size_t max_length = num_bytes - i;
    size_t num_found_matches;
    size_t cur_match_end;
    size_t j;
    /* Ensure that we have enough free slots. */
    BROTLI_ENSURE_CAPACITY(m, BackwardMatch, matches, matches_size,
        cur_match_pos + MAX_NUM_MATCHES_H10 + shadow_matches);
    if (BROTLI_IS_OOM(m)) return;
    // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit BrotliCreateHqZopfliBackwardReferences 2\n");
    
    fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter BrotliCreateHqZopfliBackwardReferences 3\n");
    num_found_matches = FindAllMatchesH10(hasher,
        &params->dictionary, ringbuffer, ringbuffer_mask, pos, max_length,
        max_distance, gap, params, &matches[cur_match_pos + shadow_matches]);
    cur_match_end = cur_match_pos + num_found_matches;
    // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit BrotliCreateHqZopfliBackwardReferences 3\n");
    
    for (j = cur_match_pos; j + 1 < cur_match_end; ++j) {
      fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter BrotliCreateHqZopfliBackwardReferences 4\n");
      BROTLI_DCHECK(BackwardMatchLength(&matches[j]) <=
          BackwardMatchLength(&matches[j + 1]));
      // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit BrotliCreateHqZopfliBackwardReferences 4\n");
    }
    
    fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter BrotliCreateHqZopfliBackwardReferences 5\n");
    num_matches[i] = (uint32_t)num_found_matches;
    // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit BrotliCreateHqZopfliBackwardReferences 5\n");
    
    if (num_found_matches > 0) {
      fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter BrotliCreateHqZopfliBackwardReferences 6\n");
      const size_t match_len = BackwardMatchLength(&matches[cur_match_end - 1]);
      // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit BrotliCreateHqZopfliBackwardReferences 6\n");
      
      if (match_len > MAX_ZOPFLI_LEN_QUALITY_11) {
        fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter BrotliCreateHqZopfliBackwardReferences 7\n");
        const size_t skip = match_len - 1;
        matches[cur_match_pos++] = matches[cur_match_end - 1];
        num_matches[i] = 1;
        /* Add the tail of the copy to the hasher. */
        StoreRangeH10(hasher, ringbuffer, ringbuffer_mask, pos + 1,
                      BROTLI_MIN(size_t, pos + match_len, store_end));
        memset(&num_matches[i + 1], 0, skip * sizeof(num_matches[0]));
        i += skip;
        // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit BrotliCreateHqZopfliBackwardReferences 7\n");
      } else {
        fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter BrotliCreateHqZopfliBackwardReferences 8\n");
        cur_match_pos = cur_match_end;
        // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit BrotliCreateHqZopfliBackwardReferences 8\n");
      }
    }
  }
  
  fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter BrotliCreateHqZopfliBackwardReferences 9\n");
  orig_num_literals = *num_literals;
  orig_last_insert_len = *last_insert_len;
  memcpy(orig_dist_cache, dist_cache, 4 * sizeof(dist_cache[0]));
  orig_num_commands = *num_commands;
  nodes = BROTLI_ALLOC(m, ZopfliNode, num_bytes + 1);
  if (BROTLI_IS_OOM(m)) return;
  // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit BrotliCreateHqZopfliBackwardReferences 9\n");
  
  fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter BrotliCreateHqZopfliBackwardReferences 10\n");
  InitZopfliCostModel(m, &model, &params->dist, num_bytes);
  if (BROTLI_IS_OOM(m)) return;
  // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit BrotliCreateHqZopfliBackwardReferences 10\n");
  
  for (i = 0; i < 2; i++) {
    fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter BrotliCreateHqZopfliBackwardReferences 11\n");
    BrotliInitZopfliNodes(nodes, num_bytes + 1);
    // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit BrotliCreateHqZopfliBackwardReferences 11\n");
    
    if (i == 0) {
      fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter BrotliCreateHqZopfliBackwardReferences 12\n");
      ZopfliCostModelSetFromLiteralCosts(
          &model, position, ringbuffer, ringbuffer_mask);
      // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit BrotliCreateHqZopfliBackwardReferences 12\n");
    } else {
      fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter BrotliCreateHqZopfliBackwardReferences 13\n");
      ZopfliCostModelSetFromCommands(&model, position, ringbuffer,
          ringbuffer_mask, commands, *num_commands - orig_num_commands,
          orig_last_insert_len);
      // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit BrotliCreateHqZopfliBackwardReferences 13\n");
    }
    
    fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter BrotliCreateHqZopfliBackwardReferences 14\n");
    *num_commands = orig_num_commands;
    *num_literals = orig_num_literals;
    *last_insert_len = orig_last_insert_len;
    memcpy(dist_cache, orig_dist_cache, 4 * sizeof(dist_cache[0]));
    *num_commands += ZopfliIterate(num_bytes, position, ringbuffer,
        ringbuffer_mask, params, max_backward_limit, gap, dist_cache,
        &model, num_matches, matches, nodes);
    BrotliZopfliCreateCommands(num_bytes, position, max_backward_limit,
        nodes, dist_cache, last_insert_len, params, commands, num_literals);
    // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit BrotliCreateHqZopfliBackwardReferences 14\n");
  }
  
  fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] enter BrotliCreateHqZopfliBackwardReferences 15\n");
  CleanupZopfliCostModel(m, &model);
  BROTLI_FREE(m, nodes);
  BROTLI_FREE(m, matches);
  BROTLI_FREE(m, num_matches);
  // fprintf(stderr, "[brotli/c/enc/backward_references_hq.c] exit BrotliCreateHqZopfliBackwardReferences 15\n");
}

#if defined(__cplusplus) || defined(c_plusplus)
}  /* extern "C" */
#endif
// Total cost: 0.384635
// Total split cost: 0.105245, input tokens: 70590, output tokens: 2146, cache read tokens: 70569, cache write tokens: 13819, split chunks: [(0, 731), (731, 826)]
// Total instrumented cost: 0.279390, input tokens: 4741, output tokens: 15662, cache read tokens: 4733, cache write tokens: 11471
