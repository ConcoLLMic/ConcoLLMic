/* Copyright 2010 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

/* Entropy encoding (Huffman) utilities. */

#include "./entropy_encode.h"

#include <string.h>  /* memset */
#include <stdio.h>   /* for fprintf */

#include "../common/constants.h"
#include "../common/platform.h"
#include <brotli/types.h>

#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

BROTLI_BOOL BrotliSetDepth(
    int p0, HuffmanTree* pool, uint8_t* depth, int max_depth) {
  fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliSetDepth 1\n");
  int stack[16];
  int level = 0;
  int p = p0;
  BROTLI_DCHECK(max_depth <= 15);
  stack[0] = -1;
  // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliSetDepth 1\n");
  
  while (BROTLI_TRUE) {
    fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliSetDepth 2\n");
    if (pool[p].index_left_ >= 0) {
      fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliSetDepth 3\n");
      level++;
      if (level > max_depth) return BROTLI_FALSE;
      stack[level] = pool[p].index_right_or_value_;
      p = pool[p].index_left_;
      // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliSetDepth 3\n");
      continue;
    } else {
      fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliSetDepth 4\n");
      depth[pool[p].index_right_or_value_] = (uint8_t)level;
      // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliSetDepth 4\n");
    }
    // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliSetDepth 2\n");
    
    while (level >= 0 && stack[level] == -1) {
      fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliSetDepth 5\n");
      level--;
      // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliSetDepth 5\n");
    }
    
    fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliSetDepth 6\n");
    if (level < 0) return BROTLI_TRUE;
    p = stack[level];
    stack[level] = -1;
    // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliSetDepth 6\n");
  }
}

/* Sort the root nodes, least popular first. */
static BROTLI_INLINE BROTLI_BOOL SortHuffmanTree(
    const HuffmanTree* v0, const HuffmanTree* v1) {
  fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter SortHuffmanTree 1\n");
  if (v0->total_count_ != v1->total_count_) {
    fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter SortHuffmanTree 2\n");
    return TO_BROTLI_BOOL(v0->total_count_ < v1->total_count_);
    // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit SortHuffmanTree 2\n");
  }
  fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter SortHuffmanTree 3\n");
  return TO_BROTLI_BOOL(v0->index_right_or_value_ > v1->index_right_or_value_);
  // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit SortHuffmanTree 3\n");
  // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit SortHuffmanTree 1\n");
}

/* This function will create a Huffman tree.

   The catch here is that the tree cannot be arbitrarily deep.
   Brotli specifies a maximum depth of 15 bits for "code trees"
   and 7 bits for "code length code trees."

   count_limit is the value that is to be faked as the minimum value
   and this minimum value is raised until the tree matches the
   maximum length requirement.

   This algorithm is not of excellent performance for very long data blocks,
   especially when population counts are longer than 2**tree_limit, but
   we are not planning to use this with extremely long blocks.

   See http://en.wikipedia.org/wiki/Huffman_coding */
void BrotliCreateHuffmanTree(const uint32_t* data,
                             const size_t length,
                             const int tree_limit,
                             HuffmanTree* tree,
                             uint8_t* depth) {
  fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliCreateHuffmanTree 1\n");
  uint32_t count_limit;
  HuffmanTree sentinel;
  InitHuffmanTree(&sentinel, BROTLI_UINT32_MAX, -1, -1);
  // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliCreateHuffmanTree 1\n");
  
  /* For block sizes below 64 kB, we never need to do a second iteration
     of this loop. Probably all of our block sizes will be smaller than
     that, so this loop is mostly of academic interest. If we actually
     would need this, we would be better off with the Katajainen algorithm. */
  for (count_limit = 1; ; count_limit *= 2) {
    fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliCreateHuffmanTree 2\n");
    size_t n = 0;
    size_t i;
    size_t j;
    size_t k;
    // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliCreateHuffmanTree 2\n");
    
    for (i = length; i != 0;) {
      fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliCreateHuffmanTree 3\n");
      --i;
      if (data[i]) {
        fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliCreateHuffmanTree 4\n");
        const uint32_t count = BROTLI_MAX(uint32_t, data[i], count_limit);
        InitHuffmanTree(&tree[n++], count, -1, (int16_t)i);
        // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliCreateHuffmanTree 4\n");
      }
      // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliCreateHuffmanTree 3\n");
    }

    fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliCreateHuffmanTree 5\n");
    if (n == 1) {
      fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliCreateHuffmanTree 6\n");
      depth[tree[0].index_right_or_value_] = 1;  /* Only one element. */
      break;
      // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliCreateHuffmanTree 6\n");
    }
    // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliCreateHuffmanTree 5\n");

    fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliCreateHuffmanTree 7\n");
    SortHuffmanTreeItems(tree, n, SortHuffmanTree);

    /* The nodes are:
       [0, n): the sorted leaf nodes that we start with.
       [n]: we add a sentinel here.
       [n + 1, 2n): new parent nodes are added here, starting from
                    (n+1). These are naturally in ascending order.
       [2n]: we add a sentinel at the end as well.
       There will be (2n+1) elements at the end. */
    tree[n] = sentinel;
    tree[n + 1] = sentinel;
    // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliCreateHuffmanTree 7\n");

    fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliCreateHuffmanTree 8\n");
    i = 0;      /* Points to the next leaf node. */
    j = n + 1;  /* Points to the next non-leaf node. */
    // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliCreateHuffmanTree 8\n");
    
    for (k = n - 1; k != 0; --k) {
      fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliCreateHuffmanTree 9\n");
      size_t left, right;
      if (tree[i].total_count_ <= tree[j].total_count_) {
        fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliCreateHuffmanTree 10\n");
        left = i;
        ++i;
        // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliCreateHuffmanTree 10\n");
      } else {
        fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliCreateHuffmanTree 11\n");
        left = j;
        ++j;
        // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliCreateHuffmanTree 11\n");
      }
      
      if (tree[i].total_count_ <= tree[j].total_count_) {
        fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliCreateHuffmanTree 12\n");
        right = i;
        ++i;
        // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliCreateHuffmanTree 12\n");
      } else {
        fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliCreateHuffmanTree 13\n");
        right = j;
        ++j;
        // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliCreateHuffmanTree 13\n");
      }

      fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliCreateHuffmanTree 14\n");
      {
        /* The sentinel node becomes the parent node. */
        size_t j_end = 2 * n - k;
        tree[j_end].total_count_ =
            tree[left].total_count_ + tree[right].total_count_;
        tree[j_end].index_left_ = (int16_t)left;
        tree[j_end].index_right_or_value_ = (int16_t)right;

        /* Add back the last sentinel node. */
        tree[j_end + 1] = sentinel;
      }
      // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliCreateHuffmanTree 14\n");
      // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliCreateHuffmanTree 9\n");
    }
    
    fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliCreateHuffmanTree 15\n");
    if (BrotliSetDepth((int)(2 * n - 1), &tree[0], depth, tree_limit)) {
      fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliCreateHuffmanTree 16\n");
      /* We need to pack the Huffman tree in tree_limit bits. If this was not
         successful, add fake entities to the lowest values and retry. */
      break;
      // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliCreateHuffmanTree 16\n");
    }
    // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliCreateHuffmanTree 15\n");
  }
}

static void Reverse(uint8_t* v, size_t start, size_t end) {
  fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter Reverse 1\n");
  --end;
  // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit Reverse 1\n");
  
  while (start < end) {
    fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter Reverse 2\n");
    uint8_t tmp = v[start];
    v[start] = v[end];
    v[end] = tmp;
    ++start;
    --end;
    // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit Reverse 2\n");
  }
}

static void BrotliWriteHuffmanTreeRepetitions(
    const uint8_t previous_value,
    const uint8_t value,
    size_t repetitions,
    size_t* tree_size,
    uint8_t* tree,
    uint8_t* extra_bits_data) {
  fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliWriteHuffmanTreeRepetitions 1\n");
  BROTLI_DCHECK(repetitions > 0);
  if (previous_value != value) {
    fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliWriteHuffmanTreeRepetitions 2\n");
    tree[*tree_size] = value;
    extra_bits_data[*tree_size] = 0;
    ++(*tree_size);
    --repetitions;
    // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliWriteHuffmanTreeRepetitions 2\n");
  }
  // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliWriteHuffmanTreeRepetitions 1\n");
  
  fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliWriteHuffmanTreeRepetitions 3\n");
  if (repetitions == 7) {
    fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliWriteHuffmanTreeRepetitions 4\n");
    tree[*tree_size] = value;
    extra_bits_data[*tree_size] = 0;
    ++(*tree_size);
    --repetitions;
    // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliWriteHuffmanTreeRepetitions 4\n");
  }
  // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliWriteHuffmanTreeRepetitions 3\n");
  
  fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliWriteHuffmanTreeRepetitions 5\n");
  if (repetitions < 3) {
    fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliWriteHuffmanTreeRepetitions 6\n");
    size_t i;
    for (i = 0; i < repetitions; ++i) {
      fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliWriteHuffmanTreeRepetitions 7\n");
      tree[*tree_size] = value;
      extra_bits_data[*tree_size] = 0;
      ++(*tree_size);
      // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliWriteHuffmanTreeRepetitions 7\n");
    }
    // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliWriteHuffmanTreeRepetitions 6\n");
  } else {
    fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliWriteHuffmanTreeRepetitions 8\n");
    size_t start = *tree_size;
    repetitions -= 3;
    // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliWriteHuffmanTreeRepetitions 8\n");
    
    while (BROTLI_TRUE) {
      fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliWriteHuffmanTreeRepetitions 9\n");
      tree[*tree_size] = BROTLI_REPEAT_PREVIOUS_CODE_LENGTH;
      extra_bits_data[*tree_size] = repetitions & 0x3;
      ++(*tree_size);
      repetitions >>= 2;
      // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliWriteHuffmanTreeRepetitions 9\n");
      
      if (repetitions == 0) {
        fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliWriteHuffmanTreeRepetitions 10\n");
        break;
        // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliWriteHuffmanTreeRepetitions 10\n");
      }
      
      fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliWriteHuffmanTreeRepetitions 11\n");
      --repetitions;
      // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliWriteHuffmanTreeRepetitions 11\n");
    }
    
    fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliWriteHuffmanTreeRepetitions 12\n");
    Reverse(tree, start, *tree_size);
    Reverse(extra_bits_data, start, *tree_size);
    // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliWriteHuffmanTreeRepetitions 12\n");
  }
  // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliWriteHuffmanTreeRepetitions 5\n");
}

static void BrotliWriteHuffmanTreeRepetitionsZeros(
    size_t repetitions,
    size_t* tree_size,
    uint8_t* tree,
    uint8_t* extra_bits_data) {
  fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliWriteHuffmanTreeRepetitionsZeros 1\n");
  if (repetitions == 11) {
    fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliWriteHuffmanTreeRepetitionsZeros 2\n");
    tree[*tree_size] = 0;
    extra_bits_data[*tree_size] = 0;
    ++(*tree_size);
    --repetitions;
    // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliWriteHuffmanTreeRepetitionsZeros 2\n");
  }
  // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliWriteHuffmanTreeRepetitionsZeros 1\n");
  
  fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliWriteHuffmanTreeRepetitionsZeros 3\n");
  if (repetitions < 3) {
    fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliWriteHuffmanTreeRepetitionsZeros 4\n");
    size_t i;
    for (i = 0; i < repetitions; ++i) {
      fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliWriteHuffmanTreeRepetitionsZeros 5\n");
      tree[*tree_size] = 0;
      extra_bits_data[*tree_size] = 0;
      ++(*tree_size);
      // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliWriteHuffmanTreeRepetitionsZeros 5\n");
    }
    // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliWriteHuffmanTreeRepetitionsZeros 4\n");
  } else {
    fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliWriteHuffmanTreeRepetitionsZeros 6\n");
    size_t start = *tree_size;
    repetitions -= 3;
    // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliWriteHuffmanTreeRepetitionsZeros 6\n");
    
    while (BROTLI_TRUE) {
      fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliWriteHuffmanTreeRepetitionsZeros 7\n");
      tree[*tree_size] = BROTLI_REPEAT_ZERO_CODE_LENGTH;
      extra_bits_data[*tree_size] = repetitions & 0x7;
      ++(*tree_size);
      repetitions >>= 3;
      // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliWriteHuffmanTreeRepetitionsZeros 7\n");
      
      if (repetitions == 0) {
        fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliWriteHuffmanTreeRepetitionsZeros 8\n");
        break;
        // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliWriteHuffmanTreeRepetitionsZeros 8\n");
      }
      
      fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliWriteHuffmanTreeRepetitionsZeros 9\n");
      --repetitions;
      // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliWriteHuffmanTreeRepetitionsZeros 9\n");
    }
    
    fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliWriteHuffmanTreeRepetitionsZeros 10\n");
    Reverse(tree, start, *tree_size);
    Reverse(extra_bits_data, start, *tree_size);
    // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliWriteHuffmanTreeRepetitionsZeros 10\n");
  }
  // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliWriteHuffmanTreeRepetitionsZeros 3\n");
}

void BrotliOptimizeHuffmanCountsForRle(size_t length, uint32_t* counts,
                                       uint8_t* good_for_rle) {
  fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 1\n");
  size_t nonzero_count = 0;
  size_t stride;
  size_t limit;
  size_t sum;
  const size_t streak_limit = 1240;
  /* Let's make the Huffman code more compatible with RLE encoding. */
  size_t i;
  // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 1\n");
  
  for (i = 0; i < length; i++) {
    fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 2\n");
    if (counts[i]) {
      fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 3\n");
      ++nonzero_count;
      // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 3\n");
    }
    // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 2\n");
  }
  
  fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 4\n");
  if (nonzero_count < 16) {
    fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 5\n");
    return;
    // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 5\n");
  }
  // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 4\n");
  
  fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 6\n");
  while (length != 0 && counts[length - 1] == 0) {
    fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 7\n");
    --length;
    // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 7\n");
  }
  // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 6\n");
  
  fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 8\n");
  if (length == 0) {
    fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 9\n");
    return;  /* All zeros. */
    // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 9\n");
  }
  // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 8\n");
  
  /* Now counts[0..length - 1] does not have trailing zeros. */
  fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 10\n");
  {
    size_t nonzeros = 0;
    uint32_t smallest_nonzero = 1 << 30;
    for (i = 0; i < length; ++i) {
      fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 11\n");
      if (counts[i] != 0) {
        fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 12\n");
        ++nonzeros;
        if (smallest_nonzero > counts[i]) {
          fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 13\n");
          smallest_nonzero = counts[i];
          // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 13\n");
        }
        // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 12\n");
      }
      // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 11\n");
    }
    
    fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 14\n");
    if (nonzeros < 5) {
      fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 15\n");
      /* Small histogram will model it well. */
      return;
      // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 15\n");
    }
    // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 14\n");
    
    fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 16\n");
    if (smallest_nonzero < 4) {
      fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 17\n");
      size_t zeros = length - nonzeros;
      if (zeros < 6) {
        fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 18\n");
        for (i = 1; i < length - 1; ++i) {
          fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 19\n");
          if (counts[i - 1] != 0 && counts[i] == 0 && counts[i + 1] != 0) {
            fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 20\n");
            counts[i] = 1;
            // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 20\n");
          }
          // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 19\n");
        }
        // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 18\n");
      }
      // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 17\n");
    }
    // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 16\n");
    
    fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 21\n");
    if (nonzeros < 28) {
      fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 22\n");
      return;
      // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 22\n");
    }
    // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 21\n");
  }
  // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 10\n");
  
  /* 2) Let's mark all population counts that already can be encoded
     with an RLE code. */
  fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 23\n");
  memset(good_for_rle, 0, length);
  // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 23\n");
  
  fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 24\n");
  {
    /* Let's not spoil any of the existing good RLE codes.
       Mark any seq of 0's that is longer as 5 as a good_for_rle.
       Mark any seq of non-0's that is longer as 7 as a good_for_rle. */
    uint32_t symbol = counts[0];
    size_t step = 0;
    for (i = 0; i <= length; ++i) {
      fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 25\n");
      if (i == length || counts[i] != symbol) {
        fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 26\n");
        if ((symbol == 0 && step >= 5) ||
            (symbol != 0 && step >= 7)) {
          fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 27\n");
          size_t k;
          for (k = 0; k < step; ++k) {
            fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 28\n");
            good_for_rle[i - k - 1] = 1;
            // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 28\n");
          }
          // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 27\n");
        }
        
        fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 29\n");
        step = 1;
        if (i != length) {
          fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 30\n");
          symbol = counts[i];
          // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 30\n");
        }
        // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 29\n");
        // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 26\n");
      } else {
        fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 31\n");
        ++step;
        // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 31\n");
      }
      // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 25\n");
    }
  }
  // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 24\n");
  
  /* 3) Let's replace those population counts that lead to more RLE codes.
     Math here is in 24.8 fixed point representation. */
  fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 32\n");
  stride = 0;
  limit = 256 * (counts[0] + counts[1] + counts[2]) / 3 + 420;
  sum = 0;
  // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 32\n");
  
  for (i = 0; i <= length; ++i) {
    fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 33\n");
    if (i == length || good_for_rle[i] ||
        (i != 0 && good_for_rle[i - 1]) ||
        (256 * counts[i] - limit + streak_limit) >= 2 * streak_limit) {
      fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 34\n");
      if (stride >= 4 || (stride >= 3 && sum == 0)) {
        fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 35\n");
        size_t k;
        /* The stride must end, collapse what we have, if we have enough (4). */
        size_t count = (sum + stride / 2) / stride;
        if (count == 0) {
          fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 36\n");
          count = 1;
          // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 36\n");
        }
        
        fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 37\n");
        if (sum == 0) {
          fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 38\n");
          /* Don't make an all zeros stride to be upgraded to ones. */
          count = 0;
          // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 38\n");
        }
        // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 37\n");
        
        fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 39\n");
        for (k = 0; k < stride; ++k) {
          fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 40\n");
          /* We don't want to change value at counts[i],
             that is already belonging to the next stride. Thus - 1. */
          counts[i - k - 1] = (uint32_t)count;
          // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 40\n");
        }
        // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 39\n");
        // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 35\n");
      }
      
      fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 41\n");
      stride = 0;
      sum = 0;
      if (i < length - 2) {
        fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 42\n");
        /* All interesting strides have a count of at least 4, */
        /* at least when non-zeros. */
        limit = 256 * (counts[i] + counts[i + 1] + counts[i + 2]) / 3 + 420;
        // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 42\n");
      } else if (i < length) {
        fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 43\n");
        limit = 256 * counts[i];
        // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 43\n");
      } else {
        fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 44\n");
        limit = 0;
        // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 44\n");
      }
      // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 41\n");
      // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 34\n");
    }
    
    fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 45\n");
    ++stride;
    if (i != length) {
      fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 46\n");
      sum += counts[i];
      if (stride >= 4) {
        fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 47\n");
        limit = (256 * sum + stride / 2) / stride;
        // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 47\n");
      }
      
      fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 48\n");
      if (stride == 4) {
        fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliOptimizeHuffmanCountsForRle 49\n");
        limit += 120;
        // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 49\n");
      }
      // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 48\n");
      // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 46\n");
    }
    // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 45\n");
    // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliOptimizeHuffmanCountsForRle 33\n");
  }
}

static void DecideOverRleUse(const uint8_t* depth, const size_t length,
                             BROTLI_BOOL* use_rle_for_non_zero,
                             BROTLI_BOOL* use_rle_for_zero) {
  fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter DecideOverRleUse 1\n");
  size_t total_reps_zero = 0;
  size_t total_reps_non_zero = 0;
  size_t count_reps_zero = 1;
  size_t count_reps_non_zero = 1;
  size_t i;
  // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit DecideOverRleUse 1\n");
  
  for (i = 0; i < length;) {
    fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter DecideOverRleUse 2\n");
    const uint8_t value = depth[i];
    size_t reps = 1;
    size_t k;
    // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit DecideOverRleUse 2\n");
    
    for (k = i + 1; k < length && depth[k] == value; ++k) {
      fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter DecideOverRleUse 3\n");
      ++reps;
      // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit DecideOverRleUse 3\n");
    }
    
    fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter DecideOverRleUse 4\n");
    if (reps >= 3 && value == 0) {
      fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter DecideOverRleUse 5\n");
      total_reps_zero += reps;
      ++count_reps_zero;
      // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit DecideOverRleUse 5\n");
    }
    // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit DecideOverRleUse 4\n");
    
    fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter DecideOverRleUse 6\n");
    if (reps >= 4 && value != 0) {
      fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter DecideOverRleUse 7\n");
      total_reps_non_zero += reps;
      ++count_reps_non_zero;
      // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit DecideOverRleUse 7\n");
    }
    // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit DecideOverRleUse 6\n");
    
    fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter DecideOverRleUse 8\n");
    i += reps;
    // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit DecideOverRleUse 8\n");
  }
  
  fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter DecideOverRleUse 9\n");
  *use_rle_for_non_zero =
      TO_BROTLI_BOOL(total_reps_non_zero > count_reps_non_zero * 2);
  *use_rle_for_zero = TO_BROTLI_BOOL(total_reps_zero > count_reps_zero * 2);
  // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit DecideOverRleUse 9\n");
}

void BrotliWriteHuffmanTree(const uint8_t* depth,
                            size_t length,
                            size_t* tree_size,
                            uint8_t* tree,
                            uint8_t* extra_bits_data) {
  fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliWriteHuffmanTree 1\n");
  uint8_t previous_value = BROTLI_INITIAL_REPEATED_CODE_LENGTH;
  size_t i;
  BROTLI_BOOL use_rle_for_non_zero = BROTLI_FALSE;
  BROTLI_BOOL use_rle_for_zero = BROTLI_FALSE;

  /* Throw away trailing zeros. */
  size_t new_length = length;
  // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliWriteHuffmanTree 1\n");
  
  for (i = 0; i < length; ++i) {
    fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliWriteHuffmanTree 2\n");
    if (depth[length - i - 1] == 0) {
      fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliWriteHuffmanTree 3\n");
      --new_length;
      // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliWriteHuffmanTree 3\n");
    } else {
      fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliWriteHuffmanTree 4\n");
      break;
      // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliWriteHuffmanTree 4\n");
    }
    // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliWriteHuffmanTree 2\n");
  }

  /* First gather statistics on if it is a good idea to do RLE. */
  fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliWriteHuffmanTree 5\n");
  if (length > 50) {
    fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliWriteHuffmanTree 6\n");
    /* Find RLE coding for longer codes.
       Shorter codes seem not to benefit from RLE. */
    DecideOverRleUse(depth, new_length,
                     &use_rle_for_non_zero, &use_rle_for_zero);
    // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliWriteHuffmanTree 6\n");
  }
  // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliWriteHuffmanTree 5\n");

  /* Actual RLE coding. */
  fprintf(stderr, "\n");
  for (i = 0; i < new_length;) {
    fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliWriteHuffmanTree 8\n");
    const uint8_t value = depth[i];
    size_t reps = 1;
    // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliWriteHuffmanTree 8\n");
    
    if ((value != 0 && use_rle_for_non_zero) ||
        (value == 0 && use_rle_for_zero)) {
      fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliWriteHuffmanTree 9\n");
      size_t k;
      for (k = i + 1; k < new_length && depth[k] == value; ++k) {
        fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliWriteHuffmanTree 10\n");
        ++reps;
        // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliWriteHuffmanTree 10\n");
      }
      // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliWriteHuffmanTree 9\n");
    }
    
    fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliWriteHuffmanTree 11\n");
    if (value == 0) {
      fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliWriteHuffmanTree 12\n");
      BrotliWriteHuffmanTreeRepetitionsZeros(
          reps, tree_size, tree, extra_bits_data);
      // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliWriteHuffmanTree 12\n");
    } else {
      fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliWriteHuffmanTree 13\n");
      BrotliWriteHuffmanTreeRepetitions(previous_value,
                                        value, reps, tree_size,
                                        tree, extra_bits_data);
      previous_value = value;
      // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliWriteHuffmanTree 13\n");
    }
    // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliWriteHuffmanTree 11\n");
    
    fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliWriteHuffmanTree 14\n");
    i += reps;
    // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliWriteHuffmanTree 14\n");
  }
}

static uint16_t BrotliReverseBits(size_t num_bits, uint16_t bits) {
  fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliReverseBits 1\n");
  static const size_t kLut[16] = {  /* Pre-reversed 4-bit values. */
    0x00, 0x08, 0x04, 0x0C, 0x02, 0x0A, 0x06, 0x0E,
    0x01, 0x09, 0x05, 0x0D, 0x03, 0x0B, 0x07, 0x0F
  };
  size_t retval = kLut[bits & 0x0F];
  size_t i;
  // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliReverseBits 1\n");
  
  for (i = 4; i < num_bits; i += 4) {
    fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliReverseBits 2\n");
    retval <<= 4;
    bits = (uint16_t)(bits >> 4);
    retval |= kLut[bits & 0x0F];
    // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliReverseBits 2\n");
  }
  
  fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliReverseBits 3\n");
  retval >>= ((0 - num_bits) & 0x03);
  return (uint16_t)retval;
  // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliReverseBits 3\n");
}

/* 0..15 are values for bits */
#define MAX_HUFFMAN_BITS 16

void BrotliConvertBitDepthsToSymbols(const uint8_t* depth,
                                     size_t len,
                                     uint16_t* bits) {
  fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliConvertBitDepthsToSymbols 1\n");
  /* In Brotli, all bit depths are [1..15]
     0 bit depth means that the symbol does not exist. */
  uint16_t bl_count[MAX_HUFFMAN_BITS] = { 0 };
  uint16_t next_code[MAX_HUFFMAN_BITS];
  size_t i;
  int code = 0;
  // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliConvertBitDepthsToSymbols 1\n");
  
  for (i = 0; i < len; ++i) {
    fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliConvertBitDepthsToSymbols 2\n");
    ++bl_count[depth[i]];
    // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliConvertBitDepthsToSymbols 2\n");
  }
  
  fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliConvertBitDepthsToSymbols 3\n");
  bl_count[0] = 0;
  next_code[0] = 0;
  // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliConvertBitDepthsToSymbols 3\n");
  
  for (i = 1; i < MAX_HUFFMAN_BITS; ++i) {
    fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliConvertBitDepthsToSymbols 4\n");
    code = (code + bl_count[i - 1]) << 1;
    next_code[i] = (uint16_t)code;
    // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliConvertBitDepthsToSymbols 4\n");
  }
  
  for (i = 0; i < len; ++i) {
    fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliConvertBitDepthsToSymbols 5\n");
    if (depth[i]) {
      fprintf(stderr, "[brotli/c/enc/entropy_encode.c] enter BrotliConvertBitDepthsToSymbols 6\n");
      bits[i] = BrotliReverseBits(depth[i], next_code[depth[i]]++);
      // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliConvertBitDepthsToSymbols 6\n");
    }
    // fprintf(stderr, "[brotli/c/enc/entropy_encode.c] exit BrotliConvertBitDepthsToSymbols 5\n");
  }
}

#if defined(__cplusplus) || defined(c_plusplus)
}  /* extern "C" */
#endif
// Total cost: 0.203286
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 501)]
// Total instrumented cost: 0.203286, input tokens: 2398, output tokens: 12093, cache read tokens: 2394, cache write tokens: 5643
