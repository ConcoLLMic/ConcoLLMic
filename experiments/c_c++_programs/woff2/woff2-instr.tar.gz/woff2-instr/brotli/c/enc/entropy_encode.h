/* Copyright 2010 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

/* Entropy encoding (Huffman) utilities. */

#ifndef BROTLI_ENC_ENTROPY_ENCODE_H_
#define BROTLI_ENC_ENTROPY_ENCODE_H_

#include "../common/platform.h"
#include <brotli/types.h>
#include <stdio.h>

#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

/* A node of a Huffman tree. */
typedef struct HuffmanTree {
  uint32_t total_count_;
  int16_t index_left_;
  int16_t index_right_or_value_;
} HuffmanTree;

static BROTLI_INLINE void InitHuffmanTree(HuffmanTree* self, uint32_t count,
    int16_t left, int16_t right) {
  fprintf(stderr, "[brotli/c/enc/entropy_encode.h] enter InitHuffmanTree 1\n");
  self->total_count_ = count;
  self->index_left_ = left;
  self->index_right_or_value_ = right;
  // fprintf(stderr, "[brotli/c/enc/entropy_encode.h] exit InitHuffmanTree 1\n");
}

/* Returns 1 is assignment of depths succeeded, otherwise 0. */
BROTLI_INTERNAL BROTLI_BOOL BrotliSetDepth(
    int p, HuffmanTree* pool, uint8_t* depth, int max_depth);

/* This function will create a Huffman tree.

   The (data,length) contains the population counts.
   The tree_limit is the maximum bit depth of the Huffman codes.

   The depth contains the tree, i.e., how many bits are used for
   the symbol.

   The actual Huffman tree is constructed in the tree[] array, which has to
   be at least 2 * length + 1 long.

   See http://en.wikipedia.org/wiki/Huffman_coding */
BROTLI_INTERNAL void BrotliCreateHuffmanTree(const uint32_t* data,
                                             const size_t length,
                                             const int tree_limit,
                                             HuffmanTree* tree,
                                             uint8_t* depth);

/* Change the population counts in a way that the consequent
   Huffman tree compression, especially its RLE-part will be more
   likely to compress this data more efficiently.

   length contains the size of the histogram.
   counts contains the population counts.
   good_for_rle is a buffer of at least length size */
BROTLI_INTERNAL void BrotliOptimizeHuffmanCountsForRle(
    size_t length, uint32_t* counts, uint8_t* good_for_rle);

/* Write a Huffman tree from bit depths into the bit-stream representation
   of a Huffman tree. The generated Huffman tree is to be compressed once
   more using a Huffman tree */
BROTLI_INTERNAL void BrotliWriteHuffmanTree(const uint8_t* depth,
                                            size_t num,
                                            size_t* tree_size,
                                            uint8_t* tree,
                                            uint8_t* extra_bits_data);

/* Get the actual bit values for a tree of bit depths. */
BROTLI_INTERNAL void BrotliConvertBitDepthsToSymbols(const uint8_t* depth,
                                                     size_t len,
                                                     uint16_t* bits);

/* Input size optimized Shell sort. */
typedef BROTLI_BOOL (*HuffmanTreeComparator)(
    const HuffmanTree*, const HuffmanTree*);
static BROTLI_INLINE void SortHuffmanTreeItems(HuffmanTree* items,
    const size_t n, HuffmanTreeComparator comparator) {
  fprintf(stderr, "[brotli/c/enc/entropy_encode.h] enter SortHuffmanTreeItems 1\n");
  static const size_t gaps[] = {132, 57, 23, 10, 4, 1};
  if (n < 13) {
    fprintf(stderr, "[brotli/c/enc/entropy_encode.h] enter SortHuffmanTreeItems 2\n");
    /* Insertion sort. */
    size_t i;
    for (i = 1; i < n; ++i) {
      fprintf(stderr, "[brotli/c/enc/entropy_encode.h] enter SortHuffmanTreeItems 3\n");
      HuffmanTree tmp = items[i];
      size_t k = i;
      size_t j = i - 1;
      while (comparator(&tmp, &items[j])) {
        fprintf(stderr, "[brotli/c/enc/entropy_encode.h] enter SortHuffmanTreeItems 4\n");
        items[k] = items[j];
        k = j;
        if (!j--) break;
        // fprintf(stderr, "[brotli/c/enc/entropy_encode.h] exit SortHuffmanTreeItems 4\n");
      }
      items[k] = tmp;
      // fprintf(stderr, "[brotli/c/enc/entropy_encode.h] exit SortHuffmanTreeItems 3\n");
    }
    return;
    // fprintf(stderr, "[brotli/c/enc/entropy_encode.h] exit SortHuffmanTreeItems 2\n");
  } else {
    fprintf(stderr, "[brotli/c/enc/entropy_encode.h] enter SortHuffmanTreeItems 5\n");
    /* Shell sort. */
    int g = n < 57 ? 2 : 0;
    for (; g < 6; ++g) {
      fprintf(stderr, "[brotli/c/enc/entropy_encode.h] enter SortHuffmanTreeItems 6\n");
      size_t gap = gaps[g];
      size_t i;
      for (i = gap; i < n; ++i) {
        fprintf(stderr, "[brotli/c/enc/entropy_encode.h] enter SortHuffmanTreeItems 7\n");
        size_t j = i;
        HuffmanTree tmp = items[i];
        for (; j >= gap && comparator(&tmp, &items[j - gap]); j -= gap) {
          fprintf(stderr, "[brotli/c/enc/entropy_encode.h] enter SortHuffmanTreeItems 8\n");
          items[j] = items[j - gap];
          // fprintf(stderr, "[brotli/c/enc/entropy_encode.h] exit SortHuffmanTreeItems 8\n");
        }
        items[j] = tmp;
        // fprintf(stderr, "[brotli/c/enc/entropy_encode.h] exit SortHuffmanTreeItems 7\n");
      }
      // fprintf(stderr, "[brotli/c/enc/entropy_encode.h] exit SortHuffmanTreeItems 6\n");
    }
    // fprintf(stderr, "[brotli/c/enc/entropy_encode.h] exit SortHuffmanTreeItems 5\n");
  }
  // fprintf(stderr, "[brotli/c/enc/entropy_encode.h] exit SortHuffmanTreeItems 1\n");
}

#if defined(__cplusplus) || defined(c_plusplus)
}  /* extern "C" */
#endif

#endif  /* BROTLI_ENC_ENTROPY_ENCODE_H_ */
// Total cost: 0.031596
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 122)]
// Total instrumented cost: 0.031596, input tokens: 2398, output tokens: 1708, cache read tokens: 2394, cache write tokens: 1399
