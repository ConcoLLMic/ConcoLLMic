/* Copyright 2010 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

/* Function to find maximal matching prefixes of strings. */

#ifndef BROTLI_ENC_FIND_MATCH_LENGTH_H_
#define BROTLI_ENC_FIND_MATCH_LENGTH_H_

#include "../common/platform.h"
#include <brotli/types.h>
#include <stdio.h>

#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

/* Separate implementation for little-endian 64-bit targets, for speed. */
#if defined(__GNUC__) && defined(_LP64) && defined(BROTLI_LITTLE_ENDIAN)

static BROTLI_INLINE size_t FindMatchLengthWithLimit(const uint8_t* s1,
                                                     const uint8_t* s2,
                                                     size_t limit) {
  fprintf(stderr, "[brotli/c/enc/find_match_length.h] enter FindMatchLengthWithLimit 1\n");
  size_t matched = 0;
  size_t limit2 = (limit >> 3) + 1;  /* + 1 is for pre-decrement in while */
  // fprintf(stderr, "[brotli/c/enc/find_match_length.h] exit FindMatchLengthWithLimit 1\n");
  
  while (BROTLI_PREDICT_TRUE(--limit2)) {
    fprintf(stderr, "[brotli/c/enc/find_match_length.h] enter FindMatchLengthWithLimit 2\n");
    if (BROTLI_PREDICT_FALSE(BROTLI_UNALIGNED_LOAD64LE(s2) ==
                      BROTLI_UNALIGNED_LOAD64LE(s1 + matched))) {
      fprintf(stderr, "[brotli/c/enc/find_match_length.h] enter FindMatchLengthWithLimit 3\n");
      s2 += 8;
      matched += 8;
      // fprintf(stderr, "[brotli/c/enc/find_match_length.h] exit FindMatchLengthWithLimit 3\n");
    } else {
      fprintf(stderr, "[brotli/c/enc/find_match_length.h] enter FindMatchLengthWithLimit 4\n");
      uint64_t x = BROTLI_UNALIGNED_LOAD64LE(s2) ^
          BROTLI_UNALIGNED_LOAD64LE(s1 + matched);
      size_t matching_bits = (size_t)__builtin_ctzll(x);
      matched += matching_bits >> 3;
      return matched;
      // fprintf(stderr, "[brotli/c/enc/find_match_length.h] exit FindMatchLengthWithLimit 4\n");
    }
    // fprintf(stderr, "[brotli/c/enc/find_match_length.h] exit FindMatchLengthWithLimit 2\n");
  }
  
  fprintf(stderr, "[brotli/c/enc/find_match_length.h] enter FindMatchLengthWithLimit 5\n");
  limit = (limit & 7) + 1;  /* + 1 is for pre-decrement in while */
  // fprintf(stderr, "[brotli/c/enc/find_match_length.h] exit FindMatchLengthWithLimit 5\n");
  
  while (--limit) {
    fprintf(stderr, "[brotli/c/enc/find_match_length.h] enter FindMatchLengthWithLimit 6\n");
    if (BROTLI_PREDICT_TRUE(s1[matched] == *s2)) {
      fprintf(stderr, "[brotli/c/enc/find_match_length.h] enter FindMatchLengthWithLimit 7\n");
      ++s2;
      ++matched;
      // fprintf(stderr, "[brotli/c/enc/find_match_length.h] exit FindMatchLengthWithLimit 7\n");
    } else {
      fprintf(stderr, "[brotli/c/enc/find_match_length.h] enter FindMatchLengthWithLimit 8\n");
      return matched;
      // fprintf(stderr, "[brotli/c/enc/find_match_length.h] exit FindMatchLengthWithLimit 8\n");
    }
    // fprintf(stderr, "[brotli/c/enc/find_match_length.h] exit FindMatchLengthWithLimit 6\n");
  }
  
  fprintf(stderr, "[brotli/c/enc/find_match_length.h] enter FindMatchLengthWithLimit 9\n");
  return matched;
  // fprintf(stderr, "[brotli/c/enc/find_match_length.h] exit FindMatchLengthWithLimit 9\n");
}
#else
static BROTLI_INLINE size_t FindMatchLengthWithLimit(const uint8_t* s1,
                                                     const uint8_t* s2,
                                                     size_t limit) {
  fprintf(stderr, "[brotli/c/enc/find_match_length.h] enter FindMatchLengthWithLimit 141\n");
  size_t matched = 0;
  const uint8_t* s2_limit = s2 + limit;
  const uint8_t* s2_ptr = s2;
  /* Find out how long the match is. We loop over the data 32 bits at a
     time until we find a 32-bit block that doesn't match; then we find
     the first non-matching bit and use that to calculate the total
     length of the match. */
  // fprintf(stderr, "[brotli/c/enc/find_match_length.h] exit FindMatchLengthWithLimit 141\n");
  
  while (s2_ptr <= s2_limit - 4 &&
         BrotliUnalignedRead32(s2_ptr) ==
         BrotliUnalignedRead32(s1 + matched)) {
    fprintf(stderr, "[brotli/c/enc/find_match_length.h] enter FindMatchLengthWithLimit 4900\n");
    s2_ptr += 4;
    matched += 4;
    // fprintf(stderr, "[brotli/c/enc/find_match_length.h] exit FindMatchLengthWithLimit 4900\n");
  }
  
  while ((s2_ptr < s2_limit) && (s1[matched] == *s2_ptr)) {
    fprintf(stderr, "[brotli/c/enc/find_match_length.h] enter FindMatchLengthWithLimit 3868\n");
    ++s2_ptr;
    ++matched;
    // fprintf(stderr, "[brotli/c/enc/find_match_length.h] exit FindMatchLengthWithLimit 3868\n");
  }
  
  fprintf(stderr, "[brotli/c/enc/find_match_length.h] enter FindMatchLengthWithLimit 4434\n");
  return matched;
  // fprintf(stderr, "[brotli/c/enc/find_match_length.h] exit FindMatchLengthWithLimit 4434\n");
}
#endif

#if defined(__cplusplus) || defined(c_plusplus)
}  /* extern "C" */
#endif

#endif  /* BROTLI_ENC_FIND_MATCH_LENGTH_H_ */
// Total cost: 0.027321
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 80)]
// Total instrumented cost: 0.027321, input tokens: 2398, output tokens: 1516, cache read tokens: 2394, cache write tokens: 1027
