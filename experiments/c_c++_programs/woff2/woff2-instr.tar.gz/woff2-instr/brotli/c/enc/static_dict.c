/* Copyright 2013 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

#include "./static_dict.h"
#include <stdio.h>

#include "../common/dictionary.h"
#include "../common/platform.h"
#include "../common/transform.h"
#include "./encoder_dict.h"
#include "./find_match_length.h"

#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

/* TODO: use BrotliTransforms.cutOffTransforms instead. */
static const uint8_t kOmitLastNTransforms[10] = {
  0, 12, 27, 23, 42, 63, 56, 48, 59, 64,
};

static BROTLI_INLINE uint32_t Hash(const uint8_t* data) {
  fprintf(stderr, "[brotli/c/enc/static_dict.c] enter Hash 1\n");
  uint32_t h = BROTLI_UNALIGNED_LOAD32LE(data) * kDictHashMul32;
  /* The higher bits contain more mixture from the multiplication,
     so we take our results from there. */
  return h >> (32 - kDictNumBits);
  // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit Hash 1\n");
}

static BROTLI_INLINE void AddMatch(size_t distance, size_t len, size_t len_code,
                                   uint32_t* matches) {
  fprintf(stderr, "[brotli/c/enc/static_dict.c] enter AddMatch 1\n");
  uint32_t match = (uint32_t)((distance << 5) + len_code);
  matches[len] = BROTLI_MIN(uint32_t, matches[len], match);
  // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit AddMatch 1\n");
}

static BROTLI_INLINE size_t DictMatchLength(const BrotliDictionary* dictionary,
                                            const uint8_t* data,
                                            size_t id,
                                            size_t len,
                                            size_t maxlen) {
  fprintf(stderr, "[brotli/c/enc/static_dict.c] enter DictMatchLength 1\n");
  const size_t offset = dictionary->offsets_by_length[len] + len * id;
  return FindMatchLengthWithLimit(&dictionary->data[offset], data,
                                  BROTLI_MIN(size_t, len, maxlen));
  // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit DictMatchLength 1\n");
}

static BROTLI_INLINE BROTLI_BOOL IsMatch(const BrotliDictionary* dictionary,
    DictWord w, const uint8_t* data, size_t max_length) {
  fprintf(stderr, "[brotli/c/enc/static_dict.c] enter IsMatch 1\n");
  if (w.len > max_length) {
    fprintf(stderr, "[brotli/c/enc/static_dict.c] enter IsMatch 2\n");
    return BROTLI_FALSE;
    // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit IsMatch 2\n");
  } else {
    fprintf(stderr, "[brotli/c/enc/static_dict.c] enter IsMatch 3\n");
    const size_t offset = dictionary->offsets_by_length[w.len] +
        (size_t)w.len * (size_t)w.idx;
    const uint8_t* dict = &dictionary->data[offset];
    // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit IsMatch 3\n");
    if (w.transform == 0) {
      fprintf(stderr, "[brotli/c/enc/static_dict.c] enter IsMatch 4\n");
      /* Match against base dictionary word. */
      return
          TO_BROTLI_BOOL(FindMatchLengthWithLimit(dict, data, w.len) == w.len);
      // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit IsMatch 4\n");
    } else if (w.transform == 10) {
      fprintf(stderr, "[brotli/c/enc/static_dict.c] enter IsMatch 5\n");
      /* Match against uppercase first transform.
         Note that there are only ASCII uppercase words in the lookup table. */
      return TO_BROTLI_BOOL(dict[0] >= 'a' && dict[0] <= 'z' &&
              (dict[0] ^ 32) == data[0] &&
              FindMatchLengthWithLimit(&dict[1], &data[1], w.len - 1u) ==
              w.len - 1u);
      // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit IsMatch 5\n");
    } else {
      fprintf(stderr, "[brotli/c/enc/static_dict.c] enter IsMatch 6\n");
      /* Match against uppercase all transform.
         Note that there are only ASCII uppercase words in the lookup table. */
      size_t i;
      for (i = 0; i < w.len; ++i) {
        fprintf(stderr, "[brotli/c/enc/static_dict.c] enter IsMatch 7\n");
        if (dict[i] >= 'a' && dict[i] <= 'z') {
          fprintf(stderr, "[brotli/c/enc/static_dict.c] enter IsMatch 8\n");
          if ((dict[i] ^ 32) != data[i]) return BROTLI_FALSE;
          // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit IsMatch 8\n");
        } else {
          fprintf(stderr, "[brotli/c/enc/static_dict.c] enter IsMatch 9\n");
          if (dict[i] != data[i]) return BROTLI_FALSE;
          // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit IsMatch 9\n");
        }
        // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit IsMatch 7\n");
      }
      return BROTLI_TRUE;
      // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit IsMatch 6\n");
    }
  }
  // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit IsMatch 1\n");
}

BROTLI_BOOL BrotliFindAllStaticDictionaryMatches(
    const BrotliEncoderDictionary* dictionary, const uint8_t* data,
    size_t min_length, size_t max_length, uint32_t* matches) {
  fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 1\n");
  BROTLI_BOOL has_found_match = BROTLI_FALSE;
  // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 1\n");
  {
    fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 2\n");
    size_t offset = dictionary->buckets[Hash(data)];
    BROTLI_BOOL end = !offset;
    // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 2\n");
    while (!end) {
      fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 3\n");
      DictWord w = dictionary->dict_words[offset++];
      const size_t l = w.len & 0x1F;
      const size_t n = (size_t)1 << dictionary->words->size_bits_by_length[l];
      const size_t id = w.idx;
      end = !!(w.len & 0x80);
      w.len = (uint8_t)l;
      // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 3\n");
      if (w.transform == 0) {
        fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 4\n");
        const size_t matchlen =
            DictMatchLength(dictionary->words, data, id, l, max_length);
        const uint8_t* s;
        size_t minlen;
        size_t maxlen;
        size_t len;
        // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 4\n");
        /* Transform "" + BROTLI_TRANSFORM_IDENTITY + "" */
        if (matchlen == l) {
          fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 5\n");
          AddMatch(id, l, l, matches);
          has_found_match = BROTLI_TRUE;
          // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 5\n");
        }
        /* Transforms "" + BROTLI_TRANSFORM_OMIT_LAST_1 + "" and
                      "" + BROTLI_TRANSFORM_OMIT_LAST_1 + "ing " */
        if (matchlen >= l - 1) {
          fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 6\n");
          AddMatch(id + 12 * n, l - 1, l, matches);
          // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 6\n");
          if (l + 2 < max_length &&
              data[l - 1] == 'i' && data[l] == 'n' && data[l + 1] == 'g' &&
              data[l + 2] == ' ') {
            fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 7\n");
            AddMatch(id + 49 * n, l + 3, l, matches);
            // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 7\n");
          }
          has_found_match = BROTLI_TRUE;
        }
        /* Transform "" + BROTLI_TRANSFORM_OMIT_LAST_# + "" (# = 2 .. 9) */
        fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 8\n");
        minlen = min_length;
        if (l > 9) minlen = BROTLI_MAX(size_t, minlen, l - 9);
        maxlen = BROTLI_MIN(size_t, matchlen, l - 2);
        // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 8\n");
        for (len = minlen; len <= maxlen; ++len) {
          fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 9\n");
          AddMatch(id + kOmitLastNTransforms[l - len] * n, len, l, matches);
          has_found_match = BROTLI_TRUE;
          // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 9\n");
        }
        if (matchlen < l || l + 6 >= max_length) {
          fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 10\n");
          continue;
          // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 10\n");
        }
        fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 11\n");
        s = &data[l];
        // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 11\n");
        /* Transforms "" + BROTLI_TRANSFORM_IDENTITY + <suffix> */
        if (s[0] == ' ') {
          fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 12\n");
          AddMatch(id + n, l + 1, l, matches);
          // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 12\n");
          if (s[1] == 'a') {
            fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 13\n");
            if (s[2] == ' ') {
              fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 14\n");
              AddMatch(id + 28 * n, l + 3, l, matches);
              // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 14\n");
            } else if (s[2] == 's') {
              fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 15\n");
              if (s[3] == ' ') AddMatch(id + 46 * n, l + 4, l, matches);
              // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 15\n");
            } else if (s[2] == 't') {
              fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 16\n");
              if (s[3] == ' ') AddMatch(id + 60 * n, l + 4, l, matches);
              // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 16\n");
            } else if (s[2] == 'n') {
              fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 17\n");
              if (s[3] == 'd' && s[4] == ' ') {
                fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 18\n");
                AddMatch(id + 10 * n, l + 5, l, matches);
                // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 18\n");
              }
              // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 17\n");
            }
            // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 13\n");
          } else if (s[1] == 'b') {
            fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 19\n");
            if (s[2] == 'y' && s[3] == ' ') {
              fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 20\n");
              AddMatch(id + 38 * n, l + 4, l, matches);
              // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 20\n");
            }
            // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 19\n");
          } else if (s[1] == 'i') {
            fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 21\n");
            if (s[2] == 'n') {
              fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 22\n");
              if (s[3] == ' ') AddMatch(id + 16 * n, l + 4, l, matches);
              // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 22\n");
            } else if (s[2] == 's') {
              fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 23\n");
              if (s[3] == ' ') AddMatch(id + 47 * n, l + 4, l, matches);
              // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 23\n");
            }
            // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 21\n");
          } else if (s[1] == 'f') {
            fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 24\n");
            if (s[2] == 'o') {
              fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 25\n");
              if (s[3] == 'r' && s[4] == ' ') {
                fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 26\n");
                AddMatch(id + 25 * n, l + 5, l, matches);
                // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 26\n");
              }
              // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 25\n");
            } else if (s[2] == 'r') {
              fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 27\n");
              if (s[3] == 'o' && s[4] == 'm' && s[5] == ' ') {
                fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 28\n");
                AddMatch(id + 37 * n, l + 6, l, matches);
                // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 28\n");
              }
              // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 27\n");
            }
            // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 24\n");
          } else if (s[1] == 'o') {
            fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 29\n");
            if (s[2] == 'f') {
              fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 30\n");
              if (s[3] == ' ') AddMatch(id + 8 * n, l + 4, l, matches);
              // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 30\n");
            } else if (s[2] == 'n') {
              fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 31\n");
              if (s[3] == ' ') AddMatch(id + 45 * n, l + 4, l, matches);
              // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 31\n");
            }
            // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 29\n");
          } else if (s[1] == 'n') {
            fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 32\n");
            if (s[2] == 'o' && s[3] == 't' && s[4] == ' ') {
              fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 33\n");
              AddMatch(id + 80 * n, l + 5, l, matches);
              // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 33\n");
            }
            // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 32\n");
          } else if (s[1] == 't') {
            fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 34\n");
            if (s[2] == 'h') {
              fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 35\n");
              if (s[3] == 'e') {
                fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 36\n");
                if (s[4] == ' ') AddMatch(id + 5 * n, l + 5, l, matches);
                // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 36\n");
              } else if (s[3] == 'a') {
                fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 37\n");
                if (s[4] == 't' && s[5] == ' ') {
                  fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 38\n");
                  AddMatch(id + 29 * n, l + 6, l, matches);
                  // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 38\n");
                }
                // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 37\n");
              }
              // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 35\n");
            } else if (s[2] == 'o') {
              fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 39\n");
              if (s[3] == ' ') AddMatch(id + 17 * n, l + 4, l, matches);
              // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 39\n");
            }
            // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 34\n");
          } else if (s[1] == 'w') {
            fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 40\n");
            if (s[2] == 'i' && s[3] == 't' && s[4] == 'h' && s[5] == ' ') {
              fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 41\n");
              AddMatch(id + 35 * n, l + 6, l, matches);
              // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 41\n");
            }
            // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 40\n");
          }
        } else if (s[0] == '"') {
          fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 42\n");
          AddMatch(id + 19 * n, l + 1, l, matches);
          // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 42\n");
          if (s[1] == '>') {
            fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 43\n");
            AddMatch(id + 21 * n, l + 2, l, matches);
            // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 43\n");
          }
        } else if (s[0] == '.') {
          fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 44\n");
          AddMatch(id + 20 * n, l + 1, l, matches);
          // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 44\n");
          if (s[1] == ' ') {
            fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 45\n");
            AddMatch(id + 31 * n, l + 2, l, matches);
            // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 45\n");
            if (s[2] == 'T' && s[3] == 'h') {
              fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 46\n");
              if (s[4] == 'e') {
                fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 47\n");
                if (s[5] == ' ') AddMatch(id + 43 * n, l + 6, l, matches);
                // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 47\n");
              } else if (s[4] == 'i') {
                fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 48\n");
                if (s[5] == 's' && s[6] == ' ') {
                  fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 49\n");
                  AddMatch(id + 75 * n, l + 7, l, matches);
                  // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 49\n");
                }
                // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 48\n");
              }
              // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 46\n");
            }
          }
        } else if (s[0] == ',') {
          fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 50\n");
          AddMatch(id + 76 * n, l + 1, l, matches);
          // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 50\n");
          if (s[1] == ' ') {
            fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 51\n");
            AddMatch(id + 14 * n, l + 2, l, matches);
            // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 51\n");
          }
        } else if (s[0] == '\n') {
          fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 52\n");
          AddMatch(id + 22 * n, l + 1, l, matches);
          // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 52\n");
          if (s[1] == '\t') {
            fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 53\n");
            AddMatch(id + 50 * n, l + 2, l, matches);
            // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 53\n");
          }
        } else if (s[0] == ']') {
          fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 54\n");
          AddMatch(id + 24 * n, l + 1, l, matches);
          // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 54\n");
        } else if (s[0] == '\'') {
          fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 55\n");
          AddMatch(id + 36 * n, l + 1, l, matches);
          // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 55\n");
        } else if (s[0] == ':') {
          fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 56\n");
          AddMatch(id + 51 * n, l + 1, l, matches);
          // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 56\n");
        } else if (s[0] == '(') {
          fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 57\n");
          AddMatch(id + 57 * n, l + 1, l, matches);
          // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 57\n");
        } else if (s[0] == '=') {
          fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 58\n");
          if (s[1] == '"') {
            fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 59\n");
            AddMatch(id + 70 * n, l + 2, l, matches);
            // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 59\n");
          } else if (s[1] == '\'') {
            fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 60\n");
            AddMatch(id + 86 * n, l + 2, l, matches);
            // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 60\n");
          }
          // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 58\n");
        } else if (s[0] == 'a') {
          fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 61\n");
          if (s[1] == 'l' && s[2] == ' ') {
            fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 62\n");
            AddMatch(id + 84 * n, l + 3, l, matches);
            // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 62\n");
          }
          // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 61\n");
        } else if (s[0] == 'e') {
          fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 63\n");
          if (s[1] == 'd') {
            fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 64\n");
            if (s[2] == ' ') AddMatch(id + 53 * n, l + 3, l, matches);
            // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 64\n");
          } else if (s[1] == 'r') {
            fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 65\n");
            if (s[2] == ' ') AddMatch(id + 82 * n, l + 3, l, matches);
            // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 65\n");
          } else if (s[1] == 's') {
            fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 66\n");
            if (s[2] == 't' && s[3] == ' ') {
              fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 67\n");
              AddMatch(id + 95 * n, l + 4, l, matches);
              // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 67\n");
            }
            // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 66\n");
          }
          // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 63\n");
        } else if (s[0] == 'f') {
          fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 68\n");
          if (s[1] == 'u' && s[2] == 'l' && s[3] == ' ') {
            fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 69\n");
            AddMatch(id + 90 * n, l + 4, l, matches);
            // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 69\n");
          }
          // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 68\n");
        } else if (s[0] == 'i') {
          fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 70\n");
          if (s[1] == 'v') {
            fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 71\n");
            if (s[2] == 'e' && s[3] == ' ') {
              fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 72\n");
              AddMatch(id + 92 * n, l + 4, l, matches);
              // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 72\n");
            }
            // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 71\n");
          } else if (s[1] == 'z') {
            fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 73\n");
            if (s[2] == 'e' && s[3] == ' ') {
              fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 74\n");
              AddMatch(id + 100 * n, l + 4, l, matches);
              // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 74\n");
            }
            // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 73\n");
          }
          // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 70\n");
        } else if (s[0] == 'l') {
          fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 75\n");
          if (s[1] == 'e') {
            fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 76\n");
            if (s[2] == 's' && s[3] == 's' && s[4] == ' ') {
              fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 77\n");
              AddMatch(id + 93 * n, l + 5, l, matches);
              // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 77\n");
            }
            // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 76\n");
          } else if (s[1] == 'y') {
            fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 78\n");
            if (s[2] == ' ') AddMatch(id + 61 * n, l + 3, l, matches);
            // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 78\n");
          }
          // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 75\n");
        } else if (s[0] == 'o') {
          fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 79\n");
          if (s[1] == 'u' && s[2] == 's' && s[3] == ' ') {
            fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 80\n");
            AddMatch(id + 106 * n, l + 4, l, matches);
            // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 80\n");
          }
          // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 79\n");
        }
      } else {
        fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 81\n");
        /* Set is_all_caps=0 for BROTLI_TRANSFORM_UPPERCASE_FIRST and
               is_all_caps=1 otherwise (BROTLI_TRANSFORM_UPPERCASE_ALL)
           transform. */
        const BROTLI_BOOL is_all_caps =
            TO_BROTLI_BOOL(w.transform != BROTLI_TRANSFORM_UPPERCASE_FIRST);
        const uint8_t* s;
        // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 81\n");
        if (!IsMatch(dictionary->words, w, data, max_length)) {
          fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 82\n");
          continue;
          // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 82\n");
        }
        fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 83\n");
        /* Transform "" + kUppercase{First,All} + "" */
        AddMatch(id + (is_all_caps ? 44 : 9) * n, l, l, matches);
        has_found_match = BROTLI_TRUE;
        // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 83\n");
        if (l + 1 >= max_length) {
          fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 84\n");
          continue;
          // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 84\n");
        }
        fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 85\n");
        /* Transforms "" + kUppercase{First,All} + <suffix> */
        s = &data[l];
        // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 85\n");
        if (s[0] == ' ') {
          fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 86\n");
          AddMatch(id + (is_all_caps ? 68 : 4) * n, l + 1, l, matches);
          // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 86\n");
        } else if (s[0] == '"') {
          fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 87\n");
          AddMatch(id + (is_all_caps ? 87 : 66) * n, l + 1, l, matches);
          // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 87\n");
          if (s[1] == '>') {
            fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 88\n");
            AddMatch(id + (is_all_caps ? 97 : 69) * n, l + 2, l, matches);
            // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 88\n");
          }
        } else if (s[0] == '.') {
          fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 89\n");
          AddMatch(id + (is_all_caps ? 101 : 79) * n, l + 1, l, matches);
          // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 89\n");
          if (s[1] == ' ') {
            fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 90\n");
            AddMatch(id + (is_all_caps ? 114 : 88) * n, l + 2, l, matches);
            // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 90\n");
          }
        } else if (s[0] == ',') {
          fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 91\n");
          AddMatch(id + (is_all_caps ? 112 : 99) * n, l + 1, l, matches);
          // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 91\n");
          if (s[1] == ' ') {
            fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 92\n");
            AddMatch(id + (is_all_caps ? 107 : 58) * n, l + 2, l, matches);
            // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 92\n");
          }
        } else if (s[0] == '\'') {
          fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 93\n");
          AddMatch(id + (is_all_caps ? 94 : 74) * n, l + 1, l, matches);
          // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 93\n");
        } else if (s[0] == '(') {
          fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 94\n");
          AddMatch(id + (is_all_caps ? 113 : 78) * n, l + 1, l, matches);
          // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 94\n");
        } else if (s[0] == '=') {
          fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 95\n");
          if (s[1] == '"') {
            fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 96\n");
            AddMatch(id + (is_all_caps ? 105 : 104) * n, l + 2, l, matches);
            // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 96\n");
          } else if (s[1] == '\'') {
            fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 97\n");
            AddMatch(id + (is_all_caps ? 116 : 108) * n, l + 2, l, matches);
            // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 97\n");
          }
          // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 95\n");
        }
      }
    }
  }
  /* Transforms with prefixes " " and "." */
  if (max_length >= 5 && (data[0] == ' ' || data[0] == '.')) {
    fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 98\n");
    BROTLI_BOOL is_space = TO_BROTLI_BOOL(data[0] == ' ');
    size_t offset = dictionary->buckets[Hash(&data[1])];
    BROTLI_BOOL end = !offset;
    // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 98\n");
    while (!end) {
      fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 99\n");
      DictWord w = dictionary->dict_words[offset++];
      const size_t l = w.len & 0x1F;
      const size_t n = (size_t)1 << dictionary->words->size_bits_by_length[l];
      const size_t id = w.idx;
      end = !!(w.len & 0x80);
      w.len = (uint8_t)l;
      // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 99\n");
      if (w.transform == 0) {
        fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 100\n");
        const uint8_t* s;
        // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 100\n");
        if (!IsMatch(dictionary->words, w, &data[1], max_length - 1)) {
          fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 101\n");
          continue;
          // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 101\n");
        }
        fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 102\n");
        /* Transforms " " + BROTLI_TRANSFORM_IDENTITY + "" and
                      "." + BROTLI_TRANSFORM_IDENTITY + "" */
        AddMatch(id + (is_space ? 6 : 32) * n, l + 1, l, matches);
        has_found_match = BROTLI_TRUE;
        // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 102\n");
        if (l + 2 >= max_length) {
          fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 103\n");
          continue;
          // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 103\n");
        }
        fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 104\n");
        /* Transforms " " + BROTLI_TRANSFORM_IDENTITY + <suffix> and
                      "." + BROTLI_TRANSFORM_IDENTITY + <suffix>
        */
        s = &data[l + 1];
        // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 104\n");
        if (s[0] == ' ') {
          fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 105\n");
          AddMatch(id + (is_space ? 2 : 77) * n, l + 2, l, matches);
          // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 105\n");
        } else if (s[0] == '(') {
          fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 106\n");
          AddMatch(id + (is_space ? 89 : 67) * n, l + 2, l, matches);
          // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 106\n");
        } else if (is_space) {
          fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 107\n");
          if (s[0] == ',') {
            fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 108\n");
            AddMatch(id + 103 * n, l + 2, l, matches);
            // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 108\n");
            if (s[1] == ' ') {
              fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 109\n");
              AddMatch(id + 33 * n, l + 3, l, matches);
              // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 109\n");
            }
          } else if (s[0] == '.') {
            fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 110\n");
            AddMatch(id + 71 * n, l + 2, l, matches);
            // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 110\n");
            if (s[1] == ' ') {
              fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 111\n");
              AddMatch(id + 52 * n, l + 3, l, matches);
              // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 111\n");
            }
          } else if (s[0] == '=') {
            fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 112\n");
            if (s[1] == '"') {
              fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 113\n");
              AddMatch(id + 81 * n, l + 3, l, matches);
              // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 113\n");
            } else if (s[1] == '\'') {
              fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 114\n");
              AddMatch(id + 98 * n, l + 3, l, matches);
              // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 114\n");
            }
            // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 112\n");
          }
          // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 107\n");
        }
      } else if (is_space) {
        fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 115\n");
        /* Set is_all_caps=0 for BROTLI_TRANSFORM_UPPERCASE_FIRST and
               is_all_caps=1 otherwise (BROTLI_TRANSFORM_UPPERCASE_ALL)
           transform. */
        const BROTLI_BOOL is_all_caps =
            TO_BROTLI_BOOL(w.transform != BROTLI_TRANSFORM_UPPERCASE_FIRST);
        const uint8_t* s;
        // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 115\n");
        if (!IsMatch(dictionary->words, w, &data[1], max_length - 1)) {
          fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 116\n");
          continue;
          // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 116\n");
        }
        fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 117\n");
        /* Transforms " " + kUppercase{First,All} + "" */
        AddMatch(id + (is_all_caps ? 85 : 30) * n, l + 1, l, matches);
        has_found_match = BROTLI_TRUE;
        // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 117\n");
        if (l + 2 >= max_length) {
          fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 118\n");
          continue;
          // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 118\n");
        }
        fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 119\n");
        /* Transforms " " + kUppercase{First,All} + <suffix> */
        s = &data[l + 1];
        // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 119\n");
        if (s[0] == ' ') {
          fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 120\n");
          AddMatch(id + (is_all_caps ? 83 : 15) * n, l + 2, l, matches);
          // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 120\n");
        } else if (s[0] == ',') {
          fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 121\n");
          if (!is_all_caps) {
            fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 122\n");
            AddMatch(id + 109 * n, l + 2, l, matches);
            // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 122\n");
          }
          if (s[1] == ' ') {
            fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 123\n");
            AddMatch(id + (is_all_caps ? 111 : 65) * n, l + 3, l, matches);
            // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 123\n");
          }
          // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 121\n");
        } else if (s[0] == '.') {
          fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 124\n");
          AddMatch(id + (is_all_caps ? 115 : 96) * n, l + 2, l, matches);
          // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 124\n");
          if (s[1] == ' ') {
            fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 125\n");
            AddMatch(id + (is_all_caps ? 117 : 91) * n, l + 3, l, matches);
            // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 125\n");
          }
        } else if (s[0] == '=') {
          fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 126\n");
          if (s[1] == '"') {
            fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 127\n");
            AddMatch(id + (is_all_caps ? 110 : 118) * n, l + 3, l, matches);
            // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 127\n");
          } else if (s[1] == '\'') {
            fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 128\n");
            AddMatch(id + (is_all_caps ? 119 : 120) * n, l + 3, l, matches);
            // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 128\n");
          }
          // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 126\n");
        }
      }
    }
  }
  if (max_length >= 6) {
    fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 129\n");
    /* Transforms with prefixes "e ", "s ", ", " and "\xC2\xA0" */
    if ((data[1] == ' ' &&
         (data[0] == 'e' || data[0] == 's' || data[0] == ',')) ||
        (data[0] == 0xC2 && data[1] == 0xA0)) {
      fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 130\n");
      size_t offset = dictionary->buckets[Hash(&data[2])];
      BROTLI_BOOL end = !offset;
      // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 130\n");
      while (!end) {
        fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 131\n");
        DictWord w = dictionary->dict_words[offset++];
        const size_t l = w.len & 0x1F;
        const size_t n = (size_t)1 << dictionary->words->size_bits_by_length[l];
        const size_t id = w.idx;
        end = !!(w.len & 0x80);
        w.len = (uint8_t)l;
        // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 131\n");
        if (w.transform == 0 &&
            IsMatch(dictionary->words, w, &data[2], max_length - 2)) {
          fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 132\n");
          if (data[0] == 0xC2) {
            fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 133\n");
            AddMatch(id + 102 * n, l + 2, l, matches);
            has_found_match = BROTLI_TRUE;
            // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 133\n");
          } else if (l + 2 < max_length && data[l + 2] == ' ') {
            fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 134\n");
            size_t t = data[0] == 'e' ? 18 : (data[0] == 's' ? 7 : 13);
            AddMatch(id + t * n, l + 3, l, matches);
            has_found_match = BROTLI_TRUE;
            // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 134\n");
          }
          // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 132\n");
        }
      }
    }
    // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 129\n");
  }
  if (max_length >= 9) {
    fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 135\n");
    /* Transforms with prefixes " the " and ".com/" */
    if ((data[0] == ' ' && data[1] == 't' && data[2] == 'h' &&
         data[3] == 'e' && data[4] == ' ') ||
        (data[0] == '.' && data[1] == 'c' && data[2] == 'o' &&
         data[3] == 'm' && data[4] == '/')) {
      fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 136\n");
      size_t offset = dictionary->buckets[Hash(&data[5])];
      BROTLI_BOOL end = !offset;
      // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 136\n");
      while (!end) {
        fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 137\n");
        DictWord w = dictionary->dict_words[offset++];
        const size_t l = w.len & 0x1F;
        const size_t n = (size_t)1 << dictionary->words->size_bits_by_length[l];
        const size_t id = w.idx;
        end = !!(w.len & 0x80);
        w.len = (uint8_t)l;
        // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 137\n");
        if (w.transform == 0 &&
            IsMatch(dictionary->words, w, &data[5], max_length - 5)) {
          fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 138\n");
          AddMatch(id + (data[0] == ' ' ? 41 : 72) * n, l + 5, l, matches);
          has_found_match = BROTLI_TRUE;
          // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 138\n");
          if (l + 5 < max_length) {
            fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 139\n");
            const uint8_t* s = &data[l + 5];
            // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 139\n");
            if (data[0] == ' ') {
              fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 140\n");
              if (l + 8 < max_length &&
                  s[0] == ' ' && s[1] == 'o' && s[2] == 'f' && s[3] == ' ') {
                fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 141\n");
                AddMatch(id + 62 * n, l + 9, l, matches);
                // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 141\n");
                if (l + 12 < max_length &&
                    s[4] == 't' && s[5] == 'h' && s[6] == 'e' && s[7] == ' ') {
                  fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 142\n");
                  AddMatch(id + 73 * n, l + 13, l, matches);
                  // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 142\n");
                }
              }
              // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 140\n");
            }
          }
        }
      }
    }
    // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 135\n");
  }
  fprintf(stderr, "[brotli/c/enc/static_dict.c] enter BrotliFindAllStaticDictionaryMatches 143\n");
  return has_found_match;
  // fprintf(stderr, "[brotli/c/enc/static_dict.c] exit BrotliFindAllStaticDictionaryMatches 143\n");
}

#if defined(__cplusplus) || defined(c_plusplus)
}  /* extern "C" */
#endif
// Total cost: 0.556264
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 488)]
// Total instrumented cost: 0.556264, input tokens: 12379, output tokens: 31040, cache read tokens: 12371, cache write tokens: 23181
