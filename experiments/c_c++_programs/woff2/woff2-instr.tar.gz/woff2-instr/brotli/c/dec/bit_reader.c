/* Copyright 2013 Google Inc. All Rights Reserved.

   Distributed under MIT license.
   See file LICENSE for detail or copy at https://opensource.org/licenses/MIT
*/

/* Bit reading helpers */

#include "./bit_reader.h"
#include <stdio.h>

#include "../common/platform.h"
#include <brotli/types.h>

#if defined(__cplusplus) || defined(c_plusplus)
extern "C" {
#endif

void BrotliInitBitReader(BrotliBitReader* const br) {
  fprintf(stderr, "[brotli/c/dec/bit_reader.c] enter BrotliInitBitReader 1\n");
  br->val_ = 0;
  br->bit_pos_ = sizeof(br->val_) << 3;
  // fprintf(stderr, "[brotli/c/dec/bit_reader.c] exit BrotliInitBitReader 1\n");
}

BROTLI_BOOL BrotliWarmupBitReader(BrotliBitReader* const br) {
  fprintf(stderr, "[brotli/c/dec/bit_reader.c] enter BrotliWarmupBitReader 1\n");
  size_t aligned_read_mask = (sizeof(br->val_) >> 1) - 1;
  /* Fixing alignment after unaligned BrotliFillWindow would result accumulator
     overflow. If unalignment is caused by BrotliSafeReadBits, then there is
     enough space in accumulator to fix alignment. */
  if (!BROTLI_ALIGNED_READ) {
    fprintf(stderr, "[brotli/c/dec/bit_reader.c] enter BrotliWarmupBitReader 2\n");
    aligned_read_mask = 0;
    // fprintf(stderr, "[brotli/c/dec/bit_reader.c] exit BrotliWarmupBitReader 2\n");
  }
  if (BrotliGetAvailableBits(br) == 0) {
    fprintf(stderr, "[brotli/c/dec/bit_reader.c] enter BrotliWarmupBitReader 3\n");
    if (!BrotliPullByte(br)) {
      fprintf(stderr, "[brotli/c/dec/bit_reader.c] enter BrotliWarmupBitReader 4\n");
      return BROTLI_FALSE;
      // fprintf(stderr, "[brotli/c/dec/bit_reader.c] exit BrotliWarmupBitReader 4\n");
    }
    // fprintf(stderr, "[brotli/c/dec/bit_reader.c] exit BrotliWarmupBitReader 3\n");
  }

  while ((((size_t)br->next_in) & aligned_read_mask) != 0) {
    fprintf(stderr, "[brotli/c/dec/bit_reader.c] enter BrotliWarmupBitReader 5\n");
    if (!BrotliPullByte(br)) {
      fprintf(stderr, "[brotli/c/dec/bit_reader.c] enter BrotliWarmupBitReader 6\n");
      /* If we consumed all the input, we don't care about the alignment. */
      return BROTLI_TRUE;
      // fprintf(stderr, "[brotli/c/dec/bit_reader.c] exit BrotliWarmupBitReader 6\n");
    }
    // fprintf(stderr, "[brotli/c/dec/bit_reader.c] exit BrotliWarmupBitReader 5\n");
  }
  fprintf(stderr, "[brotli/c/dec/bit_reader.c] enter BrotliWarmupBitReader 7\n");
  return BROTLI_TRUE;
  // fprintf(stderr, "[brotli/c/dec/bit_reader.c] exit BrotliWarmupBitReader 7\n");
  // fprintf(stderr, "[brotli/c/dec/bit_reader.c] exit BrotliWarmupBitReader 1\n");
}

#if defined(__cplusplus) || defined(c_plusplus)
}  /* extern "C" */
#endif
// Total cost: 0.015674
// Total split cost: 0.000000, input tokens: 0, output tokens: 0, cache read tokens: 0, cache write tokens: 0, split chunks: [(0, 48)]
// Total instrumented cost: 0.015674, input tokens: 2398, output tokens: 857, cache read tokens: 2394, cache write tokens: 557
