/*
Developed by ESN, an Electronic Arts Inc. studio.
Copyright (c) 2014, Electronic Arts Inc.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
* Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.
* Neither the name of ESN, Electronic Arts Inc. nor the
names of its contributors may be used to endorse or promote products
derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL ELECTRONIC ARTS INC. BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


Portions of code from MODP_ASCII - Ascii transformations (upper/lower, etc)
https://github.com/client9/stringencoders
Copyright (c) 2007  Nick Galbreath -- nickg [at] modp [dot] com. All rights reserved.

Numeric decoder derived from from TCL library
https://opensource.apple.com/source/tcl/tcl-14/tcl/license.terms
 * Copyright (c) 1988-1993 The Regents of the University of California.
 * Copyright (c) 1994 Sun Microsystems, Inc.
*/

#include "ultrajson.h"
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include <stdlib.h>
#include <stddef.h>
#include <stdint.h>
#include <math.h>

#include <float.h>

#ifndef TRUE
#define TRUE 1
#endif
#ifndef FALSE
#define FALSE 0
#endif

#if ( (defined(_WIN32) || defined(WIN32) ) && ( defined(_MSC_VER) ) )
#define snprintf sprintf_s
#endif

/*
Worst cases being:

Control characters (ASCII < 32)
0x00 (1 byte) input => \u0000 output (6 bytes)
1 * 6 => 6 (6 bytes required)

or UTF-16 surrogate pairs
4 bytes input in UTF-8 => \uXXXX\uYYYY (12 bytes).

4 * 6 => 24 bytes (12 bytes required)

The extra 2 bytes are for the quotes around the string

*/
#define RESERVE_STRING(_len) (2 + ((_len) * 6))

static const char g_hexChars[] = "0123456789abcdef";
static const char g_escapeChars[] = "0123456789\\b\\t\\n\\f\\r\\\"\\\\\\/";

/*
FIXME: While this is fine dandy and working it's a magic value mess which probably only the author understands.
Needs a cleanup and more documentation */

/*
Table for pure ascii output escaping all characters above 127 to \uXXXX */
static const JSUINT8 g_asciiOutputTable[256] =
{
/* 0x00 */ 0, 30, 30, 30, 30, 30, 30, 30, 10, 12, 14, 30, 16, 18, 30, 30,
/* 0x10 */ 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30,
/* 0x20 */ 1, 1, 20, 1, 1, 1, 29, 1, 1, 1, 1, 1, 1, 1, 1, 24,
/* 0x30 */ 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 29, 1, 29, 1,
/* 0x40 */ 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
/* 0x50 */ 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 22, 1, 1, 1,
/* 0x60 */ 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
/* 0x70 */ 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
/* 0x80 */ 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
/* 0x90 */ 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
/* 0xa0 */ 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
/* 0xb0 */ 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
/* 0xc0 */ 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
/* 0xd0 */ 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
/* 0xe0 */ 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
/* 0xf0 */ 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 6, 6, 1, 1
};

static void SetError (JSOBJ obj, JSONObjectEncoder *enc, const char *message)
{
  fprintf(stderr, "[lib/ultrajsonenc.c] enter SetError 1\n");
  enc->errorMsg = message;
  enc->errorObj = obj;
  fprintf(stderr, "[lib/ultrajsonenc.c] exit SetError 1\n");
}

/*
FIXME: Keep track of how big these get across several encoder calls and try to make an estimate
That way we won't run our head into the wall each call */
static void Buffer_Realloc (JSONObjectEncoder *enc, size_t cbNeeded)
{
  fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_Realloc 1\n");
  size_t free_space = enc->end - enc->offset;
  if (free_space >= cbNeeded)
  {
    fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_Realloc 2\n");
    return;
    fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_Realloc 2\n");
  }
  size_t curSize = enc->end - enc->start;
  size_t newSize = curSize;
  size_t offset = enc->offset - enc->start;

#ifdef DEBUG
  // In debug mode, allocate only what is requested so that any miscalculation
  // shows up plainly as a crash.
  fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_Realloc 3\n");
  newSize = (enc->offset - enc->start) + cbNeeded;
  fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_Realloc 3\n");
#else
  fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_Realloc 4\n");
  while (newSize < curSize + cbNeeded)
  {
    fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_Realloc 5\n");
    newSize *= 2;
    fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_Realloc 5\n");
  }
  fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_Realloc 4\n");
#endif

  if (enc->heap)
  {
    fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_Realloc 6\n");
    enc->start = (char *) enc->realloc (enc->start, newSize);
    if (!enc->start)
    {
      fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_Realloc 7\n");
      SetError (NULL, enc, "Could not reserve memory block");
      return;
      fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_Realloc 7\n");
    }
    fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_Realloc 6\n");
  }
  else
  {
    fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_Realloc 8\n");
    char *oldStart = enc->start;
    enc->heap = 1;
    enc->start = (char *) enc->malloc (newSize);
    if (!enc->start)
    {
      fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_Realloc 9\n");
      SetError (NULL, enc, "Could not reserve memory block");
      return;
      fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_Realloc 9\n");
    }
    memcpy (enc->start, oldStart, offset);
    fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_Realloc 8\n");
  }
  enc->offset = enc->start + offset;
  enc->end = enc->start + newSize;
  fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_Realloc 1\n");
}

#define Buffer_Reserve(__enc, __len) \
    if ( (size_t) ((__enc)->end - (__enc)->offset) < (size_t) (__len))  \
    {   \
      Buffer_Realloc((__enc), (__len));\
    }   \

static void *Buffer_memcpy (JSONObjectEncoder *enc, const void *src, size_t n)
{
  fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_memcpy 1\n");
  void *out;
#ifdef DEBUG
  if ((size_t) (enc->end - enc->offset) < n) {
    fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_memcpy 2\n");
    fprintf(stderr, "Ran out of buffer space during Buffer_memcpy()\n");
    abort();
    fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_memcpy 2\n");
  }
#endif
  out = memcpy(enc->offset, src, n);
  enc->offset += n;
  fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_memcpy 1\n");
  return out;
}

static FASTCALL_ATTR INLINE_PREFIX void FASTCALL_MSVC Buffer_AppendShortHexUnchecked (char *outputOffset, unsigned short value)
{
  fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_AppendShortHexUnchecked 1\n");
  *(outputOffset++) = g_hexChars[(value & 0xf000) >> 12];
  *(outputOffset++) = g_hexChars[(value & 0x0f00) >> 8];
  *(outputOffset++) = g_hexChars[(value & 0x00f0) >> 4];
  *(outputOffset++) = g_hexChars[(value & 0x000f) >> 0];
  fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_AppendShortHexUnchecked 1\n");
}

static int Buffer_EscapeStringUnvalidated (JSONObjectEncoder *enc, const char *io, const char *end)
{
  fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_EscapeStringUnvalidated 1\n");
  char *of = (char *) enc->offset;

  for (;;)
  {
#ifdef DEBUG
    // 6 is the maximum length of a single character (cf. RESERVE_STRING).
    if ((io < end) && (enc->end - of < 6)) {
      fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_EscapeStringUnvalidated 2\n");
      fprintf(stderr, "Ran out of buffer space during Buffer_EscapeStringUnvalidated()\n");
      abort();
      fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_EscapeStringUnvalidated 2\n");
    }
#endif
    switch (*io)
    {
      case 0x00:
      {
        if (io < end)
        {
          fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_EscapeStringUnvalidated 3\n");
          *(of++) = '\\';
          *(of++) = 'u';
          *(of++) = '0';
          *(of++) = '0';
          *(of++) = '0';
          *(of++) = '0';
          break;
          fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_EscapeStringUnvalidated 3\n");
        }
        else
        {
          fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_EscapeStringUnvalidated 4\n");
          enc->offset += (of - enc->offset);
          fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_EscapeStringUnvalidated 4\n");
          return TRUE;
        }
      }
      case '\"': 
        fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_EscapeStringUnvalidated 5\n");
        (*of++) = '\\'; 
        (*of++) = '\"'; 
        break;
        fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_EscapeStringUnvalidated 5\n");
      case '\\': 
        fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_EscapeStringUnvalidated 6\n");
        (*of++) = '\\'; 
        (*of++) = '\\'; 
        break;
        fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_EscapeStringUnvalidated 6\n");
      case '\b': 
        fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_EscapeStringUnvalidated 7\n");
        (*of++) = '\\'; 
        (*of++) = 'b'; 
        break;
        fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_EscapeStringUnvalidated 7\n");
      case '\f': 
        fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_EscapeStringUnvalidated 8\n");
        (*of++) = '\\'; 
        (*of++) = 'f'; 
        break;
        fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_EscapeStringUnvalidated 8\n");
      case '\n': 
        fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_EscapeStringUnvalidated 9\n");
        (*of++) = '\\'; 
        (*of++) = 'n'; 
        break;
        fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_EscapeStringUnvalidated 9\n");
      case '\r': 
        fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_EscapeStringUnvalidated 10\n");
        (*of++) = '\\'; 
        (*of++) = 'r'; 
        break;
        fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_EscapeStringUnvalidated 10\n");
      case '\t': 
        fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_EscapeStringUnvalidated 11\n");
        (*of++) = '\\'; 
        (*of++) = 't'; 
        break;
        fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_EscapeStringUnvalidated 11\n");

      case '/':
      {
        if (enc->escapeForwardSlashes)
        {
          fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_EscapeStringUnvalidated 12\n");
          (*of++) = '\\';
          (*of++) = '/';
          fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_EscapeStringUnvalidated 12\n");
        }
        else
        {
          fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_EscapeStringUnvalidated 13\n");
          // Same as default case below.
          (*of++) = (*io);
          fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_EscapeStringUnvalidated 13\n");
        }
        break;
      }
      case 0x26: // '&'
      case 0x3c: // '<'
      case 0x3e: // '>'
      {
        if (enc->encodeHTMLChars)
        {
          fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_EscapeStringUnvalidated 14\n");
          // Fall through to \u00XX case below.
          fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_EscapeStringUnvalidated 14\n");
        }
        else
        {
          fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_EscapeStringUnvalidated 15\n");
          // Same as default case below.
          (*of++) = (*io);
          break;
          fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_EscapeStringUnvalidated 15\n");
        }
      }
      case 0x01:
      case 0x02:
      case 0x03:
      case 0x04:
      case 0x05:
      case 0x06:
      case 0x07:
      case 0x0b:
      case 0x0e:
      case 0x0f:
      case 0x10:
      case 0x11:
      case 0x12:
      case 0x13:
      case 0x14:
      case 0x15:
      case 0x16:
      case 0x17:
      case 0x18:
      case 0x19:
      case 0x1a:
      case 0x1b:
      case 0x1c:
      case 0x1d:
      case 0x1e:
      case 0x1f:
      {
        fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_EscapeStringUnvalidated 16\n");
        *(of++) = '\\';
        *(of++) = 'u';
        *(of++) = '0';
        *(of++) = '0';
        *(of++) = g_hexChars[ (unsigned char) (((*io) & 0xf0) >> 4)];
        *(of++) = g_hexChars[ (unsigned char) ((*io) & 0x0f)];
        break;
        fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_EscapeStringUnvalidated 16\n");
      }
      default: 
        fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_EscapeStringUnvalidated 17\n");
        (*of++) = (*io); 
        break;
        fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_EscapeStringUnvalidated 17\n");
    }
    io++;
  }
  fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_EscapeStringUnvalidated 1\n");
}

static int Buffer_EscapeStringValidated (JSOBJ obj, JSONObjectEncoder *enc, const char *io, const char *end)
{
  fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_EscapeStringValidated 1\n");
  JSUTF32 ucs;
  char *of = (char *) enc->offset;

  for (;;)
  {
#ifdef DEBUG
    /*
    6 is the maximum length of a single character (cf. RESERVE_STRING).
    Note that the loop below may consume more than one input char and produce a UTF-16 surrogate pair.
    In that case, more than 6 characters would be needed on the output buffer.
    So this calculates the maximum length of the entire remaining input buffer instead. */
    if (enc->end - enc->offset < 6 * (end - io)) {
      fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_EscapeStringValidated 2\n");
      fprintf(stderr, "Ran out of buffer space during Buffer_EscapeStringValidated()\n");
      abort();
      fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_EscapeStringValidated 2\n");
    }
#endif
    JSUINT8 utflen = g_asciiOutputTable[(unsigned char) *io];

    switch (utflen)
    {
      case 0:
      {
        if (io < end)
        {
          fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_EscapeStringValidated 3\n");
          *(of++) = '\\';
          *(of++) = 'u';
          *(of++) = '0';
          *(of++) = '0';
          *(of++) = '0';
          *(of++) = '0';
          io ++;
          continue;
          fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_EscapeStringValidated 3\n");
        }
        else
        {
          fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_EscapeStringValidated 4\n");
          enc->offset += (of - enc->offset);
          fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_EscapeStringValidated 4\n");
          return TRUE;
        }
      }

      case 1:
      {
        fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_EscapeStringValidated 5\n");
        *(of++)= (*io++);
        continue;
        fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_EscapeStringValidated 5\n");
      }

      case 2:
      {
        fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_EscapeStringValidated 6\n");
        JSUTF32 in;
        JSUTF16 in16;

        if (end - io < 1)
        {
          fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_EscapeStringValidated 7\n");
          enc->offset += (of - enc->offset);
          SetError (obj, enc, "Unterminated UTF-8 sequence when encoding string");
          fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_EscapeStringValidated 7\n");
          return FALSE;
        }

        memcpy(&in16, io, sizeof(JSUTF16));
        in = (JSUTF32) in16;

#ifdef __LITTLE_ENDIAN__
        ucs = ((in & 0x1f) << 6) | ((in >> 8) & 0x3f);
#else
        ucs = ((in & 0x1f00) >> 2) | (in & 0x3f);
#endif

        if (ucs < 0x80)
        {
          fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_EscapeStringValidated 8\n");
          enc->offset += (of - enc->offset);
          SetError (obj, enc, "Overlong 2 byte UTF-8 sequence detected when encoding string");
          fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_EscapeStringValidated 8\n");
          return FALSE;
        }

        io += 2;
        break;
        fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_EscapeStringValidated 6\n");
      }

      case 3:
      {
        fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_EscapeStringValidated 9\n");
        JSUTF32 in;
        JSUTF16 in16;
        JSUINT8 in8;

        if (end - io < 2)
        {
          fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_EscapeStringValidated 10\n");
          enc->offset += (of - enc->offset);
          SetError (obj, enc, "Unterminated UTF-8 sequence when encoding string");
          fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_EscapeStringValidated 10\n");
          return FALSE;
        }

        memcpy(&in16, io, sizeof(JSUTF16));
        memcpy(&in8, io + 2, sizeof(JSUINT8));
#ifdef __LITTLE_ENDIAN__
        in = (JSUTF32) in16;
        in |= in8 << 16;
        ucs = ((in & 0x0f) << 12) | ((in & 0x3f00) >> 2) | ((in & 0x3f0000) >> 16);
#else
        in = in16 << 8;
        in |= in8;
        ucs = ((in & 0x0f0000) >> 4) | ((in & 0x3f00) >> 2) | (in & 0x3f);
#endif

        if (ucs < 0x800)
        {
          fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_EscapeStringValidated 11\n");
          enc->offset += (of - enc->offset);
          SetError (obj, enc, "Overlong 3 byte UTF-8 sequence detected when encoding string");
          fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_EscapeStringValidated 11\n");
          return FALSE;
        }

        io += 3;
        break;
        fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_EscapeStringValidated 9\n");
      }
      case 4:
      {
        fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_EscapeStringValidated 12\n");
        JSUTF32 in;

        if (end - io < 3)
        {
          fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_EscapeStringValidated 13\n");
          enc->offset += (of - enc->offset);
          SetError (obj, enc, "Unterminated UTF-8 sequence when encoding string");
          fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_EscapeStringValidated 13\n");
          return FALSE;
        }

        memcpy(&in, io, sizeof(JSUTF32));
#ifdef __LITTLE_ENDIAN__
        ucs = ((in & 0x07) << 18) | ((in & 0x3f00) << 4) | ((in & 0x3f0000) >> 10) | ((in & 0x3f000000) >> 24);
#else
        ucs = ((in & 0x07000000) >> 6) | ((in & 0x3f0000) >> 4) | ((in & 0x3f00) >> 2) | (in & 0x3f);
#endif
        if (ucs < 0x10000)
        {
          fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_EscapeStringValidated 14\n");
          enc->offset += (of - enc->offset);
          SetError (obj, enc, "Overlong 4 byte UTF-8 sequence detected when encoding string");
          fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_EscapeStringValidated 14\n");
          return FALSE;
        }

        io += 4;
        break;
        fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_EscapeStringValidated 12\n");
      }


      case 5:
      case 6:
      {
        fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_EscapeStringValidated 15\n");
        enc->offset += (of - enc->offset);
        SetError (obj, enc, "Unsupported UTF-8 sequence length when encoding string");
        fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_EscapeStringValidated 15\n");
        return FALSE;
      }

      case 29:
      {
        if (enc->encodeHTMLChars)
        {
          fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_EscapeStringValidated 16\n");
          // Fall through to \u00XX case 30 below.
          fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_EscapeStringValidated 16\n");
        }
        else
        {
          fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_EscapeStringValidated 17\n");
          // Same as case 1 above.
          *(of++) = (*io++);
          continue;
          fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_EscapeStringValidated 17\n");
        }
      }

      case 30:
      {
        fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_EscapeStringValidated 18\n");
        // \uXXXX encode
        *(of++) = '\\';
        *(of++) = 'u';
        *(of++) = '0';
        *(of++) = '0';
        *(of++) = g_hexChars[ (unsigned char) (((*io) & 0xf0) >> 4)];
        *(of++) = g_hexChars[ (unsigned char) ((*io) & 0x0f)];
        io ++;
        continue;
        fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_EscapeStringValidated 18\n");
      }
      case 10:
      case 12:
      case 14:
      case 16:
      case 18:
      case 20:
      case 22:
      {
        fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_EscapeStringValidated 19\n");
        *(of++) = *( (char *) (g_escapeChars + utflen + 0));
        *(of++) = *( (char *) (g_escapeChars + utflen + 1));
        io ++;
        continue;
        fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_EscapeStringValidated 19\n");
      }
      case 24:
      {
        if (enc->escapeForwardSlashes)
        {
          fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_EscapeStringValidated 20\n");
          *(of++) = *( (char *) (g_escapeChars + utflen + 0));
          *(of++) = *( (char *) (g_escapeChars + utflen + 1));
          io ++;
          fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_EscapeStringValidated 20\n");
        }
        else
        {
          fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_EscapeStringValidated 21\n");
          // Same as case 1 above.
          *(of++) = (*io++);
          fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_EscapeStringValidated 21\n");
        }
        continue;
      }
      // This can never happen, it's here to make L4 VC++ happy
      default:
      {
        fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_EscapeStringValidated 22\n");
        ucs = 0;
        break;
        fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_EscapeStringValidated 22\n");
      }
    }

    /*
    If the character is a UTF8 sequence of length > 1 we end up here */
    if (ucs >= 0x10000)
    {
      fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_EscapeStringValidated 23\n");
      ucs -= 0x10000;
      *(of++) = '\\';
      *(of++) = 'u';
      Buffer_AppendShortHexUnchecked(of, (unsigned short) (ucs >> 10) + 0xd800);
      of += 4;

      *(of++) = '\\';
      *(of++) = 'u';
      Buffer_AppendShortHexUnchecked(of, (unsigned short) (ucs & 0x3ff) + 0xdc00);
      of += 4;
      fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_EscapeStringValidated 23\n");
    }
    else
    {
      fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_EscapeStringValidated 24\n");
      *(of++) = '\\';
      *(of++) = 'u';
      Buffer_AppendShortHexUnchecked(of, (unsigned short) ucs);
      of += 4;
      fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_EscapeStringValidated 24\n");
    }
  }
  fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_EscapeStringValidated 1\n");
}


static FASTCALL_ATTR INLINE_PREFIX void FASTCALL_MSVC Buffer_AppendCharUnchecked(JSONObjectEncoder *enc, char chr)
{
  fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_AppendCharUnchecked 1\n");
#ifdef DEBUG
  if (enc->end <= enc->offset)
  {
    fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_AppendCharUnchecked 2\n");
    fprintf(stderr, "Overflow writing byte %d '%c'. The last few characters were:\n'''", chr, chr);
    char * recent = enc->offset - 1000;
    if (enc->start > recent)
    {
      fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_AppendCharUnchecked 3\n");
      recent = enc->start;
      fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_AppendCharUnchecked 3\n");
    }
    for (; recent < enc->offset; recent++)
    {
      fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_AppendCharUnchecked 4\n");
      fprintf(stderr, "%c", *recent);
      fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_AppendCharUnchecked 4\n");
    }
    fprintf(stderr, "'''\n");
    abort();
    fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_AppendCharUnchecked 2\n");
  }
#endif
  *(enc->offset++) = chr;
  fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_AppendCharUnchecked 1\n");
}

static FASTCALL_ATTR INLINE_PREFIX void FASTCALL_MSVC strreverse(char* begin, char* end)
{
  fprintf(stderr, "[lib/ultrajsonenc.c] enter strreverse 1\n");
  char aux;
  while (end > begin)
  {
    fprintf(stderr, "[lib/ultrajsonenc.c] enter strreverse 2\n");
    aux = *end, *end-- = *begin, *begin++ = aux;
    fprintf(stderr, "[lib/ultrajsonenc.c] exit strreverse 2\n");
  }
  fprintf(stderr, "[lib/ultrajsonenc.c] exit strreverse 1\n");
}

static void Buffer_AppendIndentNewlineUnchecked(JSONObjectEncoder *enc)
{
  fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_AppendIndentNewlineUnchecked 1\n");
  if (enc->indent > 0) 
  {
    fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_AppendIndentNewlineUnchecked 2\n");
    Buffer_AppendCharUnchecked(enc, '\n');
    fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_AppendIndentNewlineUnchecked 2\n");
  }
  fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_AppendIndentNewlineUnchecked 1\n");
}

static void Buffer_AppendIndentUnchecked(JSONObjectEncoder *enc, JSINT32 value)
{
  fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_AppendIndentUnchecked 1\n");
  int i;
  if (enc->indent > 0)
  {
    fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_AppendIndentUnchecked 2\n");
    while (value-- > 0)
    {
      fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_AppendIndentUnchecked 3\n");
      for (i = 0; i < enc->indent; i++)
      {
        fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_AppendIndentUnchecked 4\n");
        Buffer_AppendCharUnchecked(enc, ' ');
        fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_AppendIndentUnchecked 4\n");
      }
      fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_AppendIndentUnchecked 3\n");
    }
    fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_AppendIndentUnchecked 2\n");
  }
  fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_AppendIndentUnchecked 1\n");
}

static void Buffer_AppendLongUnchecked(JSONObjectEncoder *enc, JSINT64 value)
{
  fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_AppendLongUnchecked 1\n");
  char* wstr;
  JSUINT64 uvalue;

  if (value == INT64_MIN) {
    fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_AppendLongUnchecked 2\n");
    uvalue = INT64_MAX + UINT64_C(1);
    fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_AppendLongUnchecked 2\n");
  } else {
    fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_AppendLongUnchecked 3\n");
    uvalue = (value < 0) ? -value : value;
    fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_AppendLongUnchecked 3\n");
  }

  wstr = enc->offset;
#ifdef DEBUG
  // 20 is the maximum length of a JSINT64 (minus sign plus 19 digits)
  if (enc->end - enc->offset < 20) {
    fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_AppendLongUnchecked 4\n");
    fprintf(stderr, "Ran out of buffer space during Buffer_AppendLongUnchecked()\n");
    abort();
    fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_AppendLongUnchecked 4\n");
  }
#endif
  // Conversion. Number is reversed.

  do {
    fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_AppendLongUnchecked 5\n");
    *wstr++ = (char)(48 + (uvalue % 10ULL)); 
    fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_AppendLongUnchecked 5\n");
  } while(uvalue /= 10ULL);
  
  if (value < 0) {
    fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_AppendLongUnchecked 6\n");
    *wstr++ = '-';
    fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_AppendLongUnchecked 6\n");
  }

  // Reverse string
  strreverse(enc->offset,wstr - 1);
  enc->offset += (wstr - (enc->offset));
  fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_AppendLongUnchecked 1\n");
}

static void Buffer_AppendUnsignedLongUnchecked(JSONObjectEncoder *enc, JSUINT64 value)
{
  fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_AppendUnsignedLongUnchecked 1\n");
  char* wstr;
  JSUINT64 uvalue = value;

  wstr = enc->offset;
#ifdef DEBUG
  // 21 is the maximum length of a JSUINT64 (minus sign plus 20 digits)
  if (enc->end - enc->offset < 21) {
    fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_AppendUnsignedLongUnchecked 2\n");
    fprintf(stderr, "Ran out of buffer space during Buffer_AppendUnsignedLongUnchecked()\n");
    abort();
    fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_AppendUnsignedLongUnchecked 2\n");
  }
#endif
  // Conversion. Number is reversed.

  do {
    fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_AppendUnsignedLongUnchecked 3\n");
    *wstr++ = (char)(48 + (uvalue % 10ULL)); 
    fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_AppendUnsignedLongUnchecked 3\n");
  } while(uvalue /= 10ULL);

  // Reverse string
  strreverse(enc->offset,wstr - 1);
  enc->offset += (wstr - (enc->offset));
  fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_AppendUnsignedLongUnchecked 1\n");
}

static int Buffer_AppendDoubleDconv(JSOBJ obj, JSONObjectEncoder *enc, double value)
{
  fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_AppendDoubleDconv 1\n");
  char buf[128];
  int strlength;
#ifdef DEBUG
  if ((size_t) (enc->end - enc->offset) < sizeof(buf)) {
    fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_AppendDoubleDconv 2\n");
    fprintf(stderr, "Ran out of buffer space during Buffer_AppendDoubleDconv()\n");
    abort();
    fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_AppendDoubleDconv 2\n");
  }
#endif
  if(!dconv_d2s(enc->d2s, value, buf, sizeof(buf), &strlength))
  {
    fprintf(stderr, "[lib/ultrajsonenc.c] enter Buffer_AppendDoubleDconv 3\n");
    SetError (obj, enc, "Invalid value when encoding double");
    fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_AppendDoubleDconv 3\n");
    return FALSE;
  }

  Buffer_memcpy(enc, buf, strlength);

  fprintf(stderr, "[lib/ultrajsonenc.c] exit Buffer_AppendDoubleDconv 1\n");
  return TRUE;
}

/*
FIXME:
Handle integration functions returning NULL here */

/*
FIXME:
Perhaps implement recursion detection */


static void encode(JSOBJ obj, JSONObjectEncoder *enc, const char *name, size_t cbName)
{
  fprintf(stderr, "[lib/ultrajsonenc.c] enter encode 1\n");
  const char *value;
  char *objName;
  int count, res;
  JSOBJ iterObj;
  size_t szlen;
  JSONTypeContext tc;

  if (enc->level > enc->recursionMax)
  {
    fprintf(stderr, "[lib/ultrajsonenc.c] enter encode 2\n");
    SetError (obj, enc, "Maximum recursion level reached");
    return;
    fprintf(stderr, "[lib/ultrajsonenc.c] exit encode 2\n");
  }

  if (enc->errorMsg)
  {
    fprintf(stderr, "[lib/ultrajsonenc.c] enter encode 3\n");
    return;
    fprintf(stderr, "[lib/ultrajsonenc.c] exit encode 3\n");
  }

  if (name)
  {
    fprintf(stderr, "[lib/ultrajsonenc.c] enter encode 4\n");
    Buffer_Reserve(enc, RESERVE_STRING(cbName) + enc->keySeparatorLength);
    Buffer_AppendCharUnchecked(enc, '\"');

    if (enc->forceASCII)
    {
      fprintf(stderr, "[lib/ultrajsonenc.c] enter encode 5\n");
      if (!Buffer_EscapeStringValidated(obj, enc, name, name + cbName))
      {
        fprintf(stderr, "[lib/ultrajsonenc.c] enter encode 6\n");
        return;
        fprintf(stderr, "[lib/ultrajsonenc.c] exit encode 6\n");
      }
      fprintf(stderr, "[lib/ultrajsonenc.c] exit encode 5\n");
    }
    else
    {
      fprintf(stderr, "[lib/ultrajsonenc.c] enter encode 7\n");
      if (!Buffer_EscapeStringUnvalidated(enc, name, name + cbName))
      {
        fprintf(stderr, "[lib/ultrajsonenc.c] enter encode 8\n");
        return;
        fprintf(stderr, "[lib/ultrajsonenc.c] exit encode 8\n");
      }
      fprintf(stderr, "[lib/ultrajsonenc.c] exit encode 7\n");
    }

    Buffer_AppendCharUnchecked(enc, '\"');

    Buffer_memcpy(enc, enc->keySeparatorChars, enc->keySeparatorLength);
    fprintf(stderr, "[lib/ultrajsonenc.c] exit encode 4\n");
  }

  tc.encoder_prv = enc->prv;
  enc->beginTypeContext(obj, &tc, enc);

  /*
  This reservation covers any additions on non-variable parts below, specifically:
  - Opening brackets for JT_ARRAY and JT_OBJECT
  - Number representation for JT_LONG, JT_ULONG, JT_INT, and JT_DOUBLE
  - Constant value for JT_TRUE, JT_FALSE, JT_NULL

  The length of 128 is the worst case length of the Buffer_AppendDoubleDconv addition.
  The other types above all have smaller representations.
  */
  Buffer_Reserve (enc, 128);

  switch (tc.type)
  {
    case JT_INVALID:
    {
      fprintf(stderr, "[lib/ultrajsonenc.c] enter encode 9\n");
      /*
      There should already be an exception at the Python level.
      This however sets the errorMsg so recursion on arrays and objects stops.
      endTypeContext must not be called here as beginTypeContext already cleans up in the INVALID case.
      */
      SetError (obj, enc, "Invalid type");
      enc->level--;
      return;
      fprintf(stderr, "[lib/ultrajsonenc.c] exit encode 9\n");
    }

    case JT_ARRAY:
    {
      fprintf(stderr, "[lib/ultrajsonenc.c] enter encode 10\n");
      count = 0;

      Buffer_AppendCharUnchecked (enc, '[');

      while (enc->iterNext(obj, &tc))
      {
        fprintf(stderr, "[lib/ultrajsonenc.c] enter encode 11\n");
        // The extra 1 byte covers the optional newline.
        Buffer_Reserve (enc, enc->indent * (enc->level + 1) + enc->itemSeparatorLength + 1);

        if (count > 0)
        {
          fprintf(stderr, "[lib/ultrajsonenc.c] enter encode 12\n");
          Buffer_memcpy(enc, enc->itemSeparatorChars, enc->itemSeparatorLength);
          fprintf(stderr, "[lib/ultrajsonenc.c] exit encode 12\n");
        }
        Buffer_AppendIndentNewlineUnchecked (enc);

        iterObj = enc->iterGetValue(obj, &tc);

        enc->level ++;
        Buffer_AppendIndentUnchecked (enc, enc->level);
        encode (iterObj, enc, NULL, 0);
        if (enc->errorMsg)
        {
          fprintf(stderr, "[lib/ultrajsonenc.c] enter encode 13\n");
          enc->iterEnd(obj, &tc);
          enc->endTypeContext(obj, &tc);
          enc->level--;
          return;
          fprintf(stderr, "[lib/ultrajsonenc.c] exit encode 13\n");
        }
        count ++;
        fprintf(stderr, "[lib/ultrajsonenc.c] exit encode 11\n");
      }

      enc->iterEnd(obj, &tc);

      if (count > 0) {
        fprintf(stderr, "[lib/ultrajsonenc.c] enter encode 14\n");
        // Reserve space for the indentation plus the newline.
        Buffer_Reserve (enc, enc->indent * enc->level + 1);
        Buffer_AppendIndentNewlineUnchecked (enc);
        Buffer_AppendIndentUnchecked (enc, enc->level);
        fprintf(stderr, "[lib/ultrajsonenc.c] exit encode 14\n");
      }
      Buffer_Reserve (enc, 1);
      Buffer_AppendCharUnchecked (enc, ']');
      break;
      fprintf(stderr, "[lib/ultrajsonenc.c] exit encode 10\n");
    }

    case JT_OBJECT:
    {
      fprintf(stderr, "[lib/ultrajsonenc.c] enter encode 15\n");
      count = 0;

      Buffer_AppendCharUnchecked (enc, '{');

      while ((res = enc->iterNext(obj, &tc)))
      {
        fprintf(stderr, "[lib/ultrajsonenc.c] enter encode 16\n");
        // The extra 1 byte covers the optional newline.
        Buffer_Reserve (enc, enc->indent * (enc->level + 1) + enc->itemSeparatorLength + 1);

        if(res < 0)
        {
          fprintf(stderr, "[lib/ultrajsonenc.c] enter encode 17\n");
          enc->iterEnd(obj, &tc);
          enc->endTypeContext(obj, &tc);
          enc->level--;
          return;
          fprintf(stderr, "[lib/ultrajsonenc.c] exit encode 17\n");
        }

        if (count > 0)
        {
          fprintf(stderr, "[lib/ultrajsonenc.c] enter encode 18\n");
          Buffer_memcpy(enc, enc->itemSeparatorChars, enc->itemSeparatorLength);
          fprintf(stderr, "[lib/ultrajsonenc.c] exit encode 18\n");
        }
        Buffer_AppendIndentNewlineUnchecked (enc);

        iterObj = enc->iterGetValue(obj, &tc);
        objName = enc->iterGetName(obj, &tc, &szlen);

        enc->level ++;
        Buffer_AppendIndentUnchecked (enc, enc->level);
        encode (iterObj, enc, objName, szlen);
        if (enc->errorMsg)
        {
          fprintf(stderr, "[lib/ultrajsonenc.c] enter encode 19\n");
          enc->iterEnd(obj, &tc);
          enc->endTypeContext(obj, &tc);
          enc->level--;
          return;
          fprintf(stderr, "[lib/ultrajsonenc.c] exit encode 19\n");
        }
        count ++;
        fprintf(stderr, "[lib/ultrajsonenc.c] exit encode 16\n");
      }

      enc->iterEnd(obj, &tc);

      if (count > 0) {
        fprintf(stderr, "[lib/ultrajsonenc.c] enter encode 20\n");
        Buffer_Reserve (enc, enc->indent * enc->level + 1);
        Buffer_AppendIndentNewlineUnchecked (enc);
        Buffer_AppendIndentUnchecked (enc, enc->level);
        fprintf(stderr, "[lib/ultrajsonenc.c] exit encode 20\n");
      }
      Buffer_Reserve (enc, 1);
      Buffer_AppendCharUnchecked (enc, '}');
      break;
      fprintf(stderr, "[lib/ultrajsonenc.c] exit encode 15\n");
    }

    case JT_LONG:
    {
      fprintf(stderr, "[lib/ultrajsonenc.c] enter encode 21\n");
      Buffer_AppendLongUnchecked (enc, enc->getLongValue(obj, &tc));
      break;
      fprintf(stderr, "[lib/ultrajsonenc.c] exit encode 21\n");
    }

    case JT_ULONG:
    {
      fprintf(stderr, "[lib/ultrajsonenc.c] enter encode 22\n");
      Buffer_AppendUnsignedLongUnchecked (enc, enc->getUnsignedLongValue(obj, &tc));
      break;
      fprintf(stderr, "[lib/ultrajsonenc.c] exit encode 22\n");
    }

    case JT_TRUE:
    {
      fprintf(stderr, "[lib/ultrajsonenc.c] enter encode 23\n");
      Buffer_AppendCharUnchecked (enc, 't');
      Buffer_AppendCharUnchecked (enc, 'r');
      Buffer_AppendCharUnchecked (enc, 'u');
      Buffer_AppendCharUnchecked (enc, 'e');
      break;
      fprintf(stderr, "[lib/ultrajsonenc.c] exit encode 23\n");
    }

    case JT_FALSE:
    {
      fprintf(stderr, "[lib/ultrajsonenc.c] enter encode 24\n");
      Buffer_AppendCharUnchecked (enc, 'f');
      Buffer_AppendCharUnchecked (enc, 'a');
      Buffer_AppendCharUnchecked (enc, 'l');
      Buffer_AppendCharUnchecked (enc, 's');
      Buffer_AppendCharUnchecked (enc, 'e');
      break;
      fprintf(stderr, "[lib/ultrajsonenc.c] exit encode 24\n");
    }

    case JT_NULL:
    {
      fprintf(stderr, "[lib/ultrajsonenc.c] enter encode 25\n");
      Buffer_AppendCharUnchecked (enc, 'n');
      Buffer_AppendCharUnchecked (enc, 'u');
      Buffer_AppendCharUnchecked (enc, 'l');
      Buffer_AppendCharUnchecked (enc, 'l');
      break;
      fprintf(stderr, "[lib/ultrajsonenc.c] exit encode 25\n");
    }

    case JT_DOUBLE:
    {
      fprintf(stderr, "[lib/ultrajsonenc.c] enter encode 26\n");
      if (!Buffer_AppendDoubleDconv(obj, enc, enc->getDoubleValue(obj, &tc)))
      {
        fprintf(stderr, "[lib/ultrajsonenc.c] enter encode 27\n");
        enc->endTypeContext(obj, &tc);
        enc->level--;
        return;
        fprintf(stderr, "[lib/ultrajsonenc.c] exit encode 27\n");
      }
      break;
      fprintf(stderr, "[lib/ultrajsonenc.c] exit encode 26\n");
    }

    case JT_UTF8:
    {
      fprintf(stderr, "[lib/ultrajsonenc.c] enter encode 28\n");
      value = enc->getStringValue(obj, &tc, &szlen);
      if(!value)
      {
        fprintf(stderr, "[lib/ultrajsonenc.c] enter encode 29\n");
        SetError(obj, enc, "utf-8 encoding error");
        return;
        fprintf(stderr, "[lib/ultrajsonenc.c] exit encode 29\n");
      }

      Buffer_Reserve(enc, RESERVE_STRING(szlen));
      if (enc->errorMsg)
      {
        fprintf(stderr, "[lib/ultrajsonenc.c] enter encode 30\n");
        enc->endTypeContext(obj, &tc);
        return;
        fprintf(stderr, "[lib/ultrajsonenc.c] exit encode 30\n");
      }
      Buffer_AppendCharUnchecked (enc, '\"');

      if (enc->forceASCII)
      {
        fprintf(stderr, "[lib/ultrajsonenc.c] enter encode 31\n");
        if (!Buffer_EscapeStringValidated(obj, enc, value, value + szlen))
        {
          fprintf(stderr, "[lib/ultrajsonenc.c] enter encode 32\n");
          enc->endTypeContext(obj, &tc);
          enc->level--;
          return;
          fprintf(stderr, "[lib/ultrajsonenc.c] exit encode 32\n");
        }
        fprintf(stderr, "[lib/ultrajsonenc.c] exit encode 31\n");
      }
      else
      {
        fprintf(stderr, "[lib/ultrajsonenc.c] enter encode 33\n");
        if (!Buffer_EscapeStringUnvalidated(enc, value, value + szlen))
        {
          fprintf(stderr, "[lib/ultrajsonenc.c] enter encode 34\n");
          enc->endTypeContext(obj, &tc);
          enc->level--;
          return;
          fprintf(stderr, "[lib/ultrajsonenc.c] exit encode 34\n");
        }
        fprintf(stderr, "[lib/ultrajsonenc.c] exit encode 33\n");
      }

      Buffer_AppendCharUnchecked (enc, '\"');
      break;
      fprintf(stderr, "[lib/ultrajsonenc.c] exit encode 28\n");
    }

    case JT_RAW:
    {
      fprintf(stderr, "[lib/ultrajsonenc.c] enter encode 35\n");
      value = enc->getStringValue(obj, &tc, &szlen);
      if(!value)
      {
        fprintf(stderr, "[lib/ultrajsonenc.c] enter encode 36\n");
        SetError(obj, enc, "utf-8 encoding error");
        return;
        fprintf(stderr, "[lib/ultrajsonenc.c] exit encode 36\n");
      }

      Buffer_Reserve(enc, szlen);
      if (enc->errorMsg)
      {
        fprintf(stderr, "[lib/ultrajsonenc.c] enter encode 37\n");
        enc->endTypeContext(obj, &tc);
        return;
        fprintf(stderr, "[lib/ultrajsonenc.c] exit encode 37\n");
      }

      Buffer_memcpy(enc, value, szlen);

      break;
      fprintf(stderr, "[lib/ultrajsonenc.c] exit encode 35\n");
    }
  }

  enc->endTypeContext(obj, &tc);
  enc->level--;
  fprintf(stderr, "[lib/ultrajsonenc.c] exit encode 1\n");
}

char *JSON_EncodeObject(JSOBJ obj, JSONObjectEncoder *enc, char *_buffer, size_t _cbBuffer, size_t *_outLen)
{
  fprintf(stderr, "[lib/ultrajsonenc.c] enter JSON_EncodeObject 1\n");
  enc->malloc = enc->malloc ? enc->malloc : malloc;
  enc->free =  enc->free ? enc->free : free;
  enc->realloc = enc->realloc ? enc->realloc : realloc;
  enc->errorMsg = NULL;
  enc->errorObj = NULL;
  enc->level = 0;

  if (enc->recursionMax < 1)
  {
    fprintf(stderr, "[lib/ultrajsonenc.c] enter JSON_EncodeObject 2\n");
    enc->recursionMax = JSON_MAX_RECURSION_DEPTH;
    fprintf(stderr, "[lib/ultrajsonenc.c] exit JSON_EncodeObject 2\n");
  }

  if (_buffer == NULL)
  {
    fprintf(stderr, "[lib/ultrajsonenc.c] enter JSON_EncodeObject 3\n");
    _cbBuffer = 32768;
    enc->start = (char *) enc->malloc (_cbBuffer);
    if (!enc->start)
    {
      fprintf(stderr, "[lib/ultrajsonenc.c] enter JSON_EncodeObject 4\n");
      SetError(obj, enc, "Could not reserve memory block");
      return NULL;
      fprintf(stderr, "[lib/ultrajsonenc.c] exit JSON_EncodeObject 4\n");
    }
    enc->heap = 1;
    fprintf(stderr, "[lib/ultrajsonenc.c] exit JSON_EncodeObject 3\n");
  }
  else
  {
    fprintf(stderr, "[lib/ultrajsonenc.c] enter JSON_EncodeObject 5\n");
    enc->start = _buffer;
    enc->heap = 0;
    fprintf(stderr, "[lib/ultrajsonenc.c] exit JSON_EncodeObject 5\n");
  }

  enc->end = enc->start + _cbBuffer;
  enc->offset = enc->start;

  encode (obj, enc, NULL, 0);

  if (enc->errorMsg)
  {
    fprintf(stderr, "[lib/ultrajsonenc.c] enter JSON_EncodeObject 6\n");
    if (enc->heap == 1)
    {
      fprintf(stderr, "[lib/ultrajsonenc.c] enter JSON_EncodeObject 7\n");
      // Buffer was realloc'd at some point, or no initial buffer was provided.
      enc->free(enc->start);
      fprintf(stderr, "[lib/ultrajsonenc.c] exit JSON_EncodeObject 7\n");
    }
    return NULL;
    fprintf(stderr, "[lib/ultrajsonenc.c] exit JSON_EncodeObject 6\n");
  }

  *_outLen = enc->offset - enc->start;
  return enc->start;
  fprintf(stderr, "[lib/ultrajsonenc.c] exit JSON_EncodeObject 1\n");
}

// Total cost: 0.307008
// Total split cost: 0.046626, input tokens: 15227, output tokens: 63. Split chunks: [(0, 664), (664, 1001)]
// Total instrumented cost: 0.260382, input tokens: 14114, output tokens: 14536
