/*
Developed by ESN, an Electronic Arts Inc. studio.
Copyright (c) 2014, Electronic Arts Inc.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
* Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.
* Neither the name of ESN, Electronic Arts Inc. nor the
names of its contributors may be used to endorse or promote products
derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL ELECTRONIC ARTS INC. BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


Portions of code from MODP_ASCII - Ascii transformations (upper/lower, etc)
https://github.com/client9/stringencoders
Copyright (c) 2007  Nick Galbreath -- nickg [at] modp [dot] com. All rights reserved.

Numeric decoder derived from from TCL library
https://opensource.apple.com/source/tcl/tcl-14/tcl/license.terms
* Copyright (c) 1988-1993 The Regents of the University of California.
* Copyright (c) 1994 Sun Microsystems, Inc.
*/

#include "ultrajson.h"
#include <math.h>
#include <assert.h>
#include <string.h>
#include <limits.h>
#include <stdlib.h>
#include <errno.h>
#include <stdint.h>

#ifndef TRUE
#define TRUE 1
#define FALSE 0
#endif
#ifndef NULL
#define NULL 0
#endif

struct DecoderState
{
  char *start;
  char *end;
  JSUINT32 *escStart;
  JSUINT32 *escEnd;
  int escHeap;
  int lastType;
  JSUINT32 objDepth;
  void *prv;
  JSONObjectDecoder *dec;
};

static JSOBJ FASTCALL_MSVC decode_any( struct DecoderState *ds) FASTCALL_ATTR;
typedef JSOBJ (*PFN_DECODER)( struct DecoderState *ds);

static JSOBJ SetError( struct DecoderState *ds, int offset, const char *message)
{
  fprintf(stderr, "[lib/ultrajsondec.c] enter SetError 1\n");
  ds->dec->errorOffset = ds->start + offset;
  ds->dec->errorStr = (char *) message;
  return NULL;
  fprintf(stderr, "[lib/ultrajsondec.c] exit SetError 1\n");
}

static FASTCALL_ATTR JSOBJ FASTCALL_MSVC decodeDouble(struct DecoderState *ds)
{
  fprintf(stderr, "[lib/ultrajsondec.c] enter decodeDouble 1\n");
  int processed_characters_count;
  /* Prevent int overflow if ds->end - ds->start is too large. See check_decode_decimal_no_int_overflow()
  inside tests/test_ujson.py for an example where this check is necessary. */
  int len = ((size_t) (ds->end - ds->start) < (size_t) INT_MAX) ? (int) (ds->end - ds->start) : INT_MAX;
  double value = dconv_s2d(ds->dec->s2d, ds->start, len, &processed_characters_count);
  ds->lastType = JT_DOUBLE;
  ds->start += processed_characters_count;
  return ds->dec->newDouble(ds->prv, value);
  fprintf(stderr, "[lib/ultrajsondec.c] exit decodeDouble 1\n");
}

static FASTCALL_ATTR JSOBJ FASTCALL_MSVC decode_numeric (struct DecoderState *ds)
{
  fprintf(stderr, "[lib/ultrajsondec.c] enter decode_numeric 1\n");
  int intNeg = 1;
  int hasError = 0;
  JSUINT64 intValue;
  JSUINT64 addIntValue;
  int chr;
  char *offset = ds->start;

  JSUINT64 maxIntValue = ULLONG_MAX;
  JSUINT64 overflowLimit = maxIntValue / 10LLU;
  fprintf(stderr, "[lib/ultrajsondec.c] exit decode_numeric 1\n");

  if (*(offset) == 'I')
  {
    fprintf(stderr, "[lib/ultrajsondec.c] enter decode_numeric 2\n");
    goto DECODE_INF;
    fprintf(stderr, "[lib/ultrajsondec.c] exit decode_numeric 2\n");
  }
  else if (*(offset) == 'N')
  {
    fprintf(stderr, "[lib/ultrajsondec.c] enter decode_numeric 3\n");
    goto DECODE_NAN;
    fprintf(stderr, "[lib/ultrajsondec.c] exit decode_numeric 3\n");
  }
  else if (*(offset) == '-')
  {
    fprintf(stderr, "[lib/ultrajsondec.c] enter decode_numeric 4\n");
    offset++;
    intNeg = -1;
    fprintf(stderr, "[lib/ultrajsondec.c] exit decode_numeric 4\n");
    if (*(offset) == 'I')
    {
      fprintf(stderr, "[lib/ultrajsondec.c] enter decode_numeric 5\n");
      goto DECODE_INF;
      fprintf(stderr, "[lib/ultrajsondec.c] exit decode_numeric 5\n");
    }
    fprintf(stderr, "[lib/ultrajsondec.c] enter decode_numeric 6\n");
    maxIntValue = -(JSUINT64) LLONG_MIN;
    overflowLimit = maxIntValue / 10LL;
    fprintf(stderr, "[lib/ultrajsondec.c] exit decode_numeric 6\n");
  }

  // Scan integer part
  fprintf(stderr, "[lib/ultrajsondec.c] enter decode_numeric 7\n");
  intValue = 0;
  fprintf(stderr, "[lib/ultrajsondec.c] exit decode_numeric 7\n");

  while (1)
  {
    fprintf(stderr, "[lib/ultrajsondec.c] enter decode_numeric 8\n");
    chr = (int) (unsigned char) *(offset);

    switch (chr)
    {
      case '0':
      case '1':
      case '2':
      case '3':
      case '4':
      case '5':
      case '6':
      case '7':
      case '8':
      case '9':
      {
        fprintf(stderr, "[lib/ultrajsondec.c] enter decode_numeric 9\n");
        // check whether multiplication would be out of bounds
        if (intValue > overflowLimit)
        {
          fprintf(stderr, "[lib/ultrajsondec.c] enter decode_numeric 10\n");
          hasError = 1;
          fprintf(stderr, "[lib/ultrajsondec.c] exit decode_numeric 10\n");
        }
        intValue *= 10ULL;
        addIntValue = (JSUINT64) (chr - 48);

        // check whether addition would be out of bounds
        if (maxIntValue - intValue < addIntValue)
        {
          fprintf(stderr, "[lib/ultrajsondec.c] enter decode_numeric 11\n");
          hasError = 1;
          fprintf(stderr, "[lib/ultrajsondec.c] exit decode_numeric 11\n");
        }

        intValue += addIntValue;
        offset ++;
        fprintf(stderr, "[lib/ultrajsondec.c] exit decode_numeric 9\n");
        break;
      }
      case '.':
      {
        fprintf(stderr, "[lib/ultrajsondec.c] enter decode_numeric 12\n");
        offset ++;
        return decodeDouble(ds);
        fprintf(stderr, "[lib/ultrajsondec.c] exit decode_numeric 12\n");
      }
      case 'e':
      case 'E':
      {
        fprintf(stderr, "[lib/ultrajsondec.c] enter decode_numeric 13\n");
        offset ++;
        return decodeDouble(ds);
        fprintf(stderr, "[lib/ultrajsondec.c] exit decode_numeric 13\n");
      }

      default:
      {
        fprintf(stderr, "[lib/ultrajsondec.c] enter decode_numeric 14\n");
        if (hasError)
        {
          fprintf(stderr, "[lib/ultrajsondec.c] enter decode_numeric 15\n");
          char *strStart = ds->start;
          ds->lastType = JT_INT;
          ds->start = offset;
          return ds->dec->newIntegerFromString(ds->prv, strStart, offset - strStart);
          fprintf(stderr, "[lib/ultrajsondec.c] exit decode_numeric 15\n");
        }
        goto BREAK_INT_LOOP;
        fprintf(stderr, "[lib/ultrajsondec.c] exit decode_numeric 14\n");
        break;
      }
    }
    fprintf(stderr, "[lib/ultrajsondec.c] exit decode_numeric 8\n");
  }

BREAK_INT_LOOP:
  fprintf(stderr, "[lib/ultrajsondec.c] enter decode_numeric 16\n");
  ds->lastType = JT_INT;
  ds->start = offset;

  if (intNeg == 1 && (intValue & 0x8000000000000000ULL) != 0)
  {
    fprintf(stderr, "[lib/ultrajsondec.c] enter decode_numeric 17\n");
    return ds->dec->newUnsignedLong(ds->prv, intValue);
    fprintf(stderr, "[lib/ultrajsondec.c] exit decode_numeric 17\n");
  }
  else if ((intValue >> 31))
  {
    fprintf(stderr, "[lib/ultrajsondec.c] enter decode_numeric 18\n");
    return ds->dec->newLong(ds->prv, (JSINT64) (intValue * (JSINT64) intNeg));
    fprintf(stderr, "[lib/ultrajsondec.c] exit decode_numeric 18\n");
  }
  else
  {
    fprintf(stderr, "[lib/ultrajsondec.c] enter decode_numeric 19\n");
    return ds->dec->newInt(ds->prv, (JSINT32) (intValue * intNeg));
    fprintf(stderr, "[lib/ultrajsondec.c] exit decode_numeric 19\n");
  }
  fprintf(stderr, "[lib/ultrajsondec.c] exit decode_numeric 16\n");

DECODE_NAN:
    fprintf(stderr, "[lib/ultrajsondec.c] enter decode_numeric 20\n");
    offset++;
    if (*(offset++) != 'a') goto SET_NAN_ERROR;
    if (*(offset++) != 'N') goto SET_NAN_ERROR;

    ds->lastType = JT_NAN;
    ds->start = offset;
    return ds->dec->newNaN(ds->prv);
    fprintf(stderr, "[lib/ultrajsondec.c] exit decode_numeric 20\n");

SET_NAN_ERROR:
    fprintf(stderr, "[lib/ultrajsondec.c] enter decode_numeric 21\n");
    return SetError(ds, -1, "Unexpected character found when decoding 'NaN'");
    fprintf(stderr, "[lib/ultrajsondec.c] exit decode_numeric 21\n");

DECODE_INF:
    fprintf(stderr, "[lib/ultrajsondec.c] enter decode_numeric 22\n");
    offset++;
    if (*(offset++) != 'n') goto SET_INF_ERROR;
    if (*(offset++) != 'f') goto SET_INF_ERROR;
    if (*(offset++) != 'i') goto SET_INF_ERROR;
    if (*(offset++) != 'n') goto SET_INF_ERROR;
    if (*(offset++) != 'i') goto SET_INF_ERROR;
    if (*(offset++) != 't') goto SET_INF_ERROR;
    if (*(offset++) != 'y') goto SET_INF_ERROR;

    ds->start = offset;

    if (intNeg == 1) {
      fprintf(stderr, "[lib/ultrajsondec.c] enter decode_numeric 23\n");
      ds->lastType = JT_POS_INF;
      return ds->dec->newPosInf(ds->prv);
      fprintf(stderr, "[lib/ultrajsondec.c] exit decode_numeric 23\n");
    } else {
      fprintf(stderr, "[lib/ultrajsondec.c] enter decode_numeric 24\n");
      ds->lastType = JT_NEG_INF;
      return ds->dec->newNegInf(ds->prv);
      fprintf(stderr, "[lib/ultrajsondec.c] exit decode_numeric 24\n");
    }
    fprintf(stderr, "[lib/ultrajsondec.c] exit decode_numeric 22\n");

SET_INF_ERROR:
    fprintf(stderr, "[lib/ultrajsondec.c] enter decode_numeric 25\n");
    if (intNeg == 1) {
      fprintf(stderr, "[lib/ultrajsondec.c] enter decode_numeric 26\n");
      const char *msg = "Unexpected character found when decoding 'Infinity'";
      return SetError(ds, -1, msg);
      fprintf(stderr, "[lib/ultrajsondec.c] exit decode_numeric 26\n");
    } else {
      fprintf(stderr, "[lib/ultrajsondec.c] enter decode_numeric 27\n");
      const char *msg = "Unexpected character found when decoding '-Infinity'";
      return SetError(ds, -1, msg);
      fprintf(stderr, "[lib/ultrajsondec.c] exit decode_numeric 27\n");
    }
    fprintf(stderr, "[lib/ultrajsondec.c] exit decode_numeric 25\n");

}

static FASTCALL_ATTR JSOBJ FASTCALL_MSVC decode_true ( struct DecoderState *ds)
{
  fprintf(stderr, "[lib/ultrajsondec.c] enter decode_true 1\n");
  char *offset = ds->start;
  offset ++;

  if (*(offset++) != 'r')
    goto SETERROR;
  if (*(offset++) != 'u')
    goto SETERROR;
  if (*(offset++) != 'e')
    goto SETERROR;

  ds->lastType = JT_TRUE;
  ds->start = offset;
  return ds->dec->newTrue(ds->prv);
  fprintf(stderr, "[lib/ultrajsondec.c] exit decode_true 1\n");

SETERROR:
  fprintf(stderr, "[lib/ultrajsondec.c] enter decode_true 2\n");
  return SetError(ds, -1, "Unexpected character found when decoding 'true'");
  fprintf(stderr, "[lib/ultrajsondec.c] exit decode_true 2\n");
}

static FASTCALL_ATTR JSOBJ FASTCALL_MSVC decode_false ( struct DecoderState *ds)
{
  fprintf(stderr, "[lib/ultrajsondec.c] enter decode_false 1\n");
  char *offset = ds->start;
  offset ++;

  if (*(offset++) != 'a')
    goto SETERROR;
  if (*(offset++) != 'l')
    goto SETERROR;
  if (*(offset++) != 's')
    goto SETERROR;
  if (*(offset++) != 'e')
    goto SETERROR;

  ds->lastType = JT_FALSE;
  ds->start = offset;
  return ds->dec->newFalse(ds->prv);
  fprintf(stderr, "[lib/ultrajsondec.c] exit decode_false 1\n");

SETERROR:
  fprintf(stderr, "[lib/ultrajsondec.c] enter decode_false 2\n");
  return SetError(ds, -1, "Unexpected character found when decoding 'false'");
  fprintf(stderr, "[lib/ultrajsondec.c] exit decode_false 2\n");
}

static FASTCALL_ATTR JSOBJ FASTCALL_MSVC decode_null ( struct DecoderState *ds)
{
  fprintf(stderr, "[lib/ultrajsondec.c] enter decode_null 1\n");
  char *offset = ds->start;
  offset ++;

  if (*(offset++) != 'u')
    goto SETERROR;
  if (*(offset++) != 'l')
    goto SETERROR;
  if (*(offset++) != 'l')
    goto SETERROR;

  ds->lastType = JT_NULL;
  ds->start = offset;
  return ds->dec->newNull(ds->prv);
  fprintf(stderr, "[lib/ultrajsondec.c] exit decode_null 1\n");

SETERROR:
  fprintf(stderr, "[lib/ultrajsondec.c] enter decode_null 2\n");
  return SetError(ds, -1, "Unexpected character found when decoding 'null'");
  fprintf(stderr, "[lib/ultrajsondec.c] exit decode_null 2\n");
}

static FASTCALL_ATTR void FASTCALL_MSVC SkipWhitespace(struct DecoderState *ds)
{
  fprintf(stderr, "[lib/ultrajsondec.c] enter SkipWhitespace 1\n");
  char *offset = ds->start;

  for (;;)
  {
    fprintf(stderr, "[lib/ultrajsondec.c] enter SkipWhitespace 2\n");
    switch (*offset)
    {
      case ' ':
      case '\t':
      case '\r':
      case '\n':
        fprintf(stderr, "[lib/ultrajsondec.c] enter SkipWhitespace 3\n");
        offset ++;
        fprintf(stderr, "[lib/ultrajsondec.c] exit SkipWhitespace 3\n");
        break;

      default:
        fprintf(stderr, "[lib/ultrajsondec.c] enter SkipWhitespace 4\n");
        ds->start = offset;
        return;
        fprintf(stderr, "[lib/ultrajsondec.c] exit SkipWhitespace 4\n");
    }
    fprintf(stderr, "[lib/ultrajsondec.c] exit SkipWhitespace 2\n");
  }
  fprintf(stderr, "[lib/ultrajsondec.c] exit SkipWhitespace 1\n");
}

enum DECODESTRINGSTATE
{
  DS_ISNULL = 0x32,
  DS_ISQUOTE,
  DS_ISESCAPE,
  DS_UTFLENERROR,

};

static const JSUINT8 g_decoderLookup[256] =
{
  /* 0x00 */ DS_ISNULL, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  /* 0x10 */ 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  /* 0x20 */ 1, 1, DS_ISQUOTE, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  /* 0x30 */ 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  /* 0x40 */ 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  /* 0x50 */ 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, DS_ISESCAPE, 1, 1, 1,
  /* 0x60 */ 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  /* 0x70 */ 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  /* 0x80 */ 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  /* 0x90 */ 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  /* 0xa0 */ 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  /* 0xb0 */ 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  /* 0xc0 */ 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
  /* 0xd0 */ 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
  /* 0xe0 */ 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
  /* 0xf0 */ 4, 4, 4, 4, 4, 4, 4, 4, DS_UTFLENERROR, DS_UTFLENERROR, DS_UTFLENERROR, DS_UTFLENERROR, DS_UTFLENERROR, DS_UTFLENERROR, DS_UTFLENERROR, DS_UTFLENERROR,
};

static FASTCALL_ATTR JSOBJ FASTCALL_MSVC decode_string ( struct DecoderState *ds)
{
  fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 1\n");
  int index;
  JSUINT32 *escOffset;
  JSUINT32 *escStart;
  size_t escLen = (ds->escEnd - ds->escStart);
  JSUINT8 *inputOffset;
  JSUTF16 ch = 0;
  JSUINT8 *lastHighSurrogate = NULL;
  JSUINT8 oct;
  JSUTF32 ucs;
  ds->lastType = JT_INVALID;
  ds->start ++;
  fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 1\n");

  if ( (size_t) (ds->end - ds->start) > escLen)
  {
    fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 2\n");
    size_t newSize = (ds->end - ds->start);

    if (ds->escHeap)
    {
      fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 3\n");
      if (newSize > (SIZE_MAX / sizeof(JSUINT32)))
      {
        fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 4\n");
        return SetError(ds, -1, "Could not reserve memory block");
        fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 4\n");
      }
      escStart = (JSUINT32 *)ds->dec->realloc(ds->escStart, newSize * sizeof(JSUINT32));
      if (!escStart)
      {
        fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 5\n");
        // Don't free ds->escStart here; it gets handled in JSON_DecodeObject.
        return SetError(ds, -1, "Could not reserve memory block");
        fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 5\n");
      }
      ds->escStart = escStart;
      fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 3\n");
    }
    else
    {
      fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 6\n");
      JSUINT32 *oldStart = ds->escStart;
      if (newSize > (SIZE_MAX / sizeof(JSUINT32)))
      {
        fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 7\n");
        return SetError(ds, -1, "Could not reserve memory block");
        fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 7\n");
      }
      ds->escStart = (JSUINT32 *) ds->dec->malloc(newSize * sizeof(JSUINT32));
      if (!ds->escStart)
      {
        fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 8\n");
        return SetError(ds, -1, "Could not reserve memory block");
        fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 8\n");
      }
      ds->escHeap = 1;
      memcpy(ds->escStart, oldStart, escLen * sizeof(JSUINT32));
      fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 6\n");
    }

    ds->escEnd = ds->escStart + newSize;
    fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 2\n");
  }

  fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 9\n");
  escOffset = ds->escStart;
  inputOffset = (JSUINT8 *) ds->start;
  fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 9\n");

  for (;;)
  {
    fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 10\n");
    switch (g_decoderLookup[(JSUINT8)(*inputOffset)])
    {
      case DS_ISNULL:
      {
        fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 11\n");
        return SetError(ds, -1, "Unmatched '\"' when decoding 'string'");
        fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 11\n");
      }
      case DS_ISQUOTE:
      {
        fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 12\n");
        ds->lastType = JT_UTF8;
        inputOffset ++;
        ds->start += ( (char *) inputOffset - (ds->start));
        return ds->dec->newString(ds->prv, ds->escStart, escOffset);
        fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 12\n");
      }
      case DS_UTFLENERROR:
      {
        fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 13\n");
        return SetError (ds, -1, "Invalid UTF-8 sequence length when decoding 'string'");
        fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 13\n");
      }
      case DS_ISESCAPE:
      {
        fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 14\n");
        inputOffset ++;
        switch (*inputOffset)
        {
          case '\\': 
            fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 15\n");
            *(escOffset++) = '\\'; 
            inputOffset++; 
            fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 15\n");
            continue;
          case '\"': 
            fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 16\n");
            *(escOffset++) = '\"'; 
            inputOffset++; 
            fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 16\n");
            continue;
          case '/':  
            fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 17\n");
            *(escOffset++) = '/';  
            inputOffset++; 
            fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 17\n");
            continue;
          case 'b':  
            fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 18\n");
            *(escOffset++) = '\b'; 
            inputOffset++; 
            fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 18\n");
            continue;
          case 'f':  
            fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 19\n");
            *(escOffset++) = '\f'; 
            inputOffset++; 
            fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 19\n");
            continue;
          case 'n':  
            fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 20\n");
            *(escOffset++) = '\n'; 
            inputOffset++; 
            fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 20\n");
            continue;
          case 'r':  
            fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 21\n");
            *(escOffset++) = '\r'; 
            inputOffset++; 
            fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 21\n");
            continue;
          case 't':  
            fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 22\n");
            *(escOffset++) = '\t'; 
            inputOffset++; 
            fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 22\n");
            continue;

          case 'u':
          {
            fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 23\n");
            int index;
            inputOffset ++;

            for (index = 0; index < 4; index ++)
            {
              fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 24\n");
              switch (*inputOffset)
              {
                case '\0': 
                  fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 25\n");
                  return SetError (ds, -1, "Unterminated unicode escape sequence when decoding 'string'");
                  fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 25\n");
                default: 
                  fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 26\n");
                  return SetError (ds, -1, "Unexpected character in unicode escape sequence when decoding 'string'");
                  fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 26\n");

                case '0':
                case '1':
                case '2':
                case '3':
                case '4':
                case '5':
                case '6':
                case '7':
                case '8':
                case '9':
                  fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 27\n");
                  ch = (ch << 4) + (JSUTF16) (*inputOffset - '0');
                  fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 27\n");
                  break;

                case 'a':
                case 'b':
                case 'c':
                case 'd':
                case 'e':
                case 'f':
                  fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 28\n");
                  ch = (ch << 4) + 10 + (JSUTF16) (*inputOffset - 'a');
                  fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 28\n");
                  break;

                case 'A':
                case 'B':
                case 'C':
                case 'D':
                case 'E':
                case 'F':
                  fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 29\n");
                  ch = (ch << 4) + 10 + (JSUTF16) (*inputOffset - 'A');
                  fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 29\n");
                  break;
              }

              inputOffset ++;
              fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 24\n");
            }

            if ((ch & 0xfc00) == 0xdc00 && lastHighSurrogate == inputOffset - 6 * sizeof(*inputOffset))
            {
              fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 30\n");
              // Low surrogate immediately following a high surrogate
              // Overwrite existing high surrogate with combined character
              *(escOffset-1) = (((*(escOffset-1) - 0xd800) <<10) | (ch - 0xdc00)) + 0x10000;
              fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 30\n");
            }
            else
            {
              fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 31\n");
              *(escOffset++) = (JSUINT32) ch;
              fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 31\n");
            }
            if ((ch & 0xfc00) == 0xd800)
            {
              fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 32\n");
              lastHighSurrogate = inputOffset;
              fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 32\n");
            }
            fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 23\n");
            break;
          }

          case '\0': 
            fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 33\n");
            return SetError(ds, -1, "Unterminated escape sequence when decoding 'string'");
            fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 33\n");
          default: 
            fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 34\n");
            return SetError(ds, -1, "Unrecognized escape sequence when decoding 'string'");
            fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 34\n");
        }
        fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 14\n");
        break;
      }

      case 1:
      {
        fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 35\n");
        *(escOffset++) = (JSUINT32) (*inputOffset++);
        fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 35\n");
        break;
      }

      case 2:
      {
        fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 36\n");
        ucs = (*inputOffset++) & 0x1f;
        ucs <<= 6;
        if (((*inputOffset) & 0x80) != 0x80)
        {
          fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 37\n");
          return SetError(ds, -1, "Invalid octet in UTF-8 sequence when decoding 'string'");
          fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 37\n");
        }
        ucs |= (*inputOffset++) & 0x3f;
        if (ucs < 0x80) 
        {
          fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 38\n");
          return SetError (ds, -1, "Overlong 2 byte UTF-8 sequence detected when decoding 'string'");
          fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 38\n");
        }
        *(escOffset++) = (JSUINT32) ucs;
        fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 36\n");
        break;
      }

      case 3:
      {
        fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 39\n");
        JSUTF32 ucs = 0;
        ucs |= (*inputOffset++) & 0x0f;

        for (index = 0; index < 2; index ++)
        {
          fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 40\n");
          ucs <<= 6;
          oct = (*inputOffset++);

          if ((oct & 0x80) != 0x80)
          {
            fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 41\n");
            return SetError(ds, -1, "Invalid octet in UTF-8 sequence when decoding 'string'");
            fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 41\n");
          }

          ucs |= oct & 0x3f;
          fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 40\n");
        }

        if (ucs < 0x800) 
        {
          fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 42\n");
          return SetError (ds, -1, "Overlong 3 byte UTF-8 sequence detected when encoding string");
          fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 42\n");
        }
        *(escOffset++) = (JSUINT32) ucs;
        fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 39\n");
        break;
      }

      case 4:
      {
        fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 43\n");
        JSUTF32 ucs = 0;
        ucs |= (*inputOffset++) & 0x07;

        for (index = 0; index < 3; index ++)
        {
          fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 44\n");
          ucs <<= 6;
          oct = (*inputOffset++);

          if ((oct & 0x80) != 0x80)
          {
            fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 45\n");
            return SetError(ds, -1, "Invalid octet in UTF-8 sequence when decoding 'string'");
            fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 45\n");
          }

          ucs |= oct & 0x3f;
          fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 44\n");
        }

        if (ucs < 0x10000) 
        {
          fprintf(stderr, "[lib/ultrajsondec.c] enter decode_string 46\n");
          return SetError (ds, -1, "Overlong 4 byte UTF-8 sequence detected when decoding 'string'");
          fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 46\n");
        }

        *(escOffset++) = (JSUINT32) ucs;
        fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 43\n");
        break;
      }
    }
    fprintf(stderr, "[lib/ultrajsondec.c] exit decode_string 10\n");
  }
}

static FASTCALL_ATTR JSOBJ FASTCALL_MSVC decode_array(struct DecoderState *ds)
{
  fprintf(stderr, "[lib/ultrajsondec.c] enter decode_array 1\n");
  JSOBJ itemValue;
  JSOBJ newObj;
  int len;
  ds->objDepth++;
  if (ds->objDepth > JSON_MAX_OBJECT_DEPTH) {
    fprintf(stderr, "[lib/ultrajsondec.c] enter decode_array 2\n");
    return SetError(ds, -1, "Reached object decoding depth limit");
    fprintf(stderr, "[lib/ultrajsondec.c] exit decode_array 2\n");
  }

  newObj = ds->dec->newArray(ds->prv);
  len = 0;

  ds->lastType = JT_INVALID;
  ds->start ++;
  fprintf(stderr, "[lib/ultrajsondec.c] exit decode_array 1\n");

  for (;;)
  {
    fprintf(stderr, "[lib/ultrajsondec.c] enter decode_array 3\n");
    SkipWhitespace(ds);

    if ((*ds->start) == ']')
    {
      fprintf(stderr, "[lib/ultrajsondec.c] enter decode_array 4\n");
      ds->objDepth--;
      if (len == 0)
      {
        fprintf(stderr, "[lib/ultrajsondec.c] enter decode_array 5\n");
        ds->start ++;
        return newObj;
        fprintf(stderr, "[lib/ultrajsondec.c] exit decode_array 5\n");
      }

      ds->dec->releaseObject(ds->prv, newObj);
      return SetError(ds, -1, "Unexpected character found when decoding array value (1)");
      fprintf(stderr, "[lib/ultrajsondec.c] exit decode_array 4\n");
    }

    itemValue = decode_any(ds);

    if (itemValue == NULL)
    {
      fprintf(stderr, "[lib/ultrajsondec.c] enter decode_array 6\n");
      ds->dec->releaseObject(ds->prv, newObj);
      return NULL;
      fprintf(stderr, "[lib/ultrajsondec.c] exit decode_array 6\n");
    }

    ds->dec->arrayAddItem (ds->prv, newObj, itemValue);

    SkipWhitespace(ds);

    switch (*(ds->start++))
    {
    case ']':
    {
      fprintf(stderr, "[lib/ultrajsondec.c] enter decode_array 7\n");
      ds->objDepth--;
      return newObj;
      fprintf(stderr, "[lib/ultrajsondec.c] exit decode_array 7\n");
    }
    case ',':


      break;

    default:
      fprintf(stderr, "[lib/ultrajsondec.c] enter decode_array 9\n");
      ds->dec->releaseObject(ds->prv, newObj);
      return SetError(ds, -1, "Unexpected character found when decoding array value (2)");
      fprintf(stderr, "[lib/ultrajsondec.c] exit decode_array 9\n");
    }

    len++;
    fprintf(stderr, "[lib/ultrajsondec.c] exit decode_array 3\n");
  }
}

static FASTCALL_ATTR JSOBJ FASTCALL_MSVC decode_object( struct DecoderState *ds)
{
  fprintf(stderr, "[lib/ultrajsondec.c] enter decode_object 1\n");
  JSOBJ itemName;
  JSOBJ itemValue;
  JSOBJ newObj;
  int len;

  ds->objDepth++;
  if (ds->objDepth > JSON_MAX_OBJECT_DEPTH)
  {
    fprintf(stderr, "[lib/ultrajsondec.c] enter decode_object 2\n");
    return SetError(ds, -1, "Reached object decoding depth limit");
    fprintf(stderr, "[lib/ultrajsondec.c] exit decode_object 2\n");
  }

  newObj = ds->dec->newObject(ds->prv);
  len = 0;

  ds->start ++;
  fprintf(stderr, "[lib/ultrajsondec.c] exit decode_object 1\n");

  for (;;)
  {
    fprintf(stderr, "[lib/ultrajsondec.c] enter decode_object 3\n");
    SkipWhitespace(ds);

    if ((*ds->start) == '}')
    {
      fprintf(stderr, "[lib/ultrajsondec.c] enter decode_object 4\n");
      ds->objDepth--;
      if (len == 0)
      {
        fprintf(stderr, "[lib/ultrajsondec.c] enter decode_object 5\n");
        ds->start ++;
        return newObj;
        fprintf(stderr, "[lib/ultrajsondec.c] exit decode_object 5\n");
      }

      ds->dec->releaseObject(ds->prv, newObj);
      return SetError(ds, -1, "Unexpected character in found when decoding object value");
      fprintf(stderr, "[lib/ultrajsondec.c] exit decode_object 4\n");
    }

    ds->lastType = JT_INVALID;
    itemName = decode_any(ds);

    if (itemName == NULL)
    {
      fprintf(stderr, "[lib/ultrajsondec.c] enter decode_object 6\n");
      ds->dec->releaseObject(ds->prv, newObj);
      return NULL;
      fprintf(stderr, "[lib/ultrajsondec.c] exit decode_object 6\n");
    }

    if (ds->lastType != JT_UTF8)
    {
      fprintf(stderr, "[lib/ultrajsondec.c] enter decode_object 7\n");
      ds->dec->releaseObject(ds->prv, newObj);
      ds->dec->releaseObject(ds->prv, itemName);
      return SetError(ds, -1, "Key name of object must be 'string' when decoding 'object'");
      fprintf(stderr, "[lib/ultrajsondec.c] exit decode_object 7\n");
    }

    SkipWhitespace(ds);

    if (*(ds->start++) != ':')
    {
      fprintf(stderr, "[lib/ultrajsondec.c] enter decode_object 8\n");
      ds->dec->releaseObject(ds->prv, newObj);
      ds->dec->releaseObject(ds->prv, itemName);
      return SetError(ds, -1, "No ':' found when decoding object value");
      fprintf(stderr, "[lib/ultrajsondec.c] exit decode_object 8\n");
    }

    SkipWhitespace(ds);

    itemValue = decode_any(ds);

    if (itemValue == NULL)
    {
      fprintf(stderr, "[lib/ultrajsondec.c] enter decode_object 9\n");
      ds->dec->releaseObject(ds->prv, newObj);
      ds->dec->releaseObject(ds->prv, itemName);
      return NULL;
      fprintf(stderr, "[lib/ultrajsondec.c] exit decode_object 9\n");
    }

    ds->dec->objectAddKey (ds->prv, newObj, itemName, itemValue);

    SkipWhitespace(ds);

    switch (*(ds->start++))
    {
      case '}':
      {
        fprintf(stderr, "[lib/ultrajsondec.c] enter decode_object 10\n");
        ds->objDepth--;
        return newObj;
        fprintf(stderr, "[lib/ultrajsondec.c] exit decode_object 10\n");
      }
      case ',':


        break;

      default:
        fprintf(stderr, "[lib/ultrajsondec.c] enter decode_object 12\n");
        ds->dec->releaseObject(ds->prv, newObj);
        return SetError(ds, -1, "Unexpected character in found when decoding object value");
        fprintf(stderr, "[lib/ultrajsondec.c] exit decode_object 12\n");
    }

    len++;
    fprintf(stderr, "[lib/ultrajsondec.c] exit decode_object 3\n");
  }
}

static FASTCALL_ATTR JSOBJ FASTCALL_MSVC decode_any(struct DecoderState *ds)
{
  fprintf(stderr, "[lib/ultrajsondec.c] enter decode_any 1\n");
  for (;;)
  {
    fprintf(stderr, "[lib/ultrajsondec.c] enter decode_any 2\n");
    switch (*ds->start)
    {
      case '\"':
        fprintf(stderr, "[lib/ultrajsondec.c] enter decode_any 3\n");
        return decode_string (ds);
        fprintf(stderr, "[lib/ultrajsondec.c] exit decode_any 3\n");
      case '0':
      case '1':
      case '2':
      case '3':
      case '4':
      case '5':
      case '6':
      case '7':
      case '8':
      case '9':
      case 'I':
      case 'N':
      case '-':
        fprintf(stderr, "[lib/ultrajsondec.c] enter decode_any 4\n");
        return decode_numeric (ds);
        fprintf(stderr, "[lib/ultrajsondec.c] exit decode_any 4\n");

      case '[': 
        fprintf(stderr, "[lib/ultrajsondec.c] enter decode_any 5\n");
        return decode_array (ds);
        fprintf(stderr, "[lib/ultrajsondec.c] exit decode_any 5\n");
      case '{': 
        fprintf(stderr, "[lib/ultrajsondec.c] enter decode_any 6\n");
        return decode_object (ds);
        fprintf(stderr, "[lib/ultrajsondec.c] exit decode_any 6\n");
      case 't': 
        fprintf(stderr, "[lib/ultrajsondec.c] enter decode_any 7\n");
        return decode_true (ds);
        fprintf(stderr, "[lib/ultrajsondec.c] exit decode_any 7\n");
      case 'f': 
        fprintf(stderr, "[lib/ultrajsondec.c] enter decode_any 8\n");
        return decode_false (ds);
        fprintf(stderr, "[lib/ultrajsondec.c] exit decode_any 8\n");
      case 'n': 
        fprintf(stderr, "[lib/ultrajsondec.c] enter decode_any 9\n");
        return decode_null (ds);
        fprintf(stderr, "[lib/ultrajsondec.c] exit decode_any 9\n");

      case ' ':
      case '\t':
      case '\r':
      case '\n':
        fprintf(stderr, "[lib/ultrajsondec.c] enter decode_any 10\n");
        // White space
        ds->start ++;
        fprintf(stderr, "[lib/ultrajsondec.c] exit decode_any 10\n");
        break;

      default:
        fprintf(stderr, "[lib/ultrajsondec.c] enter decode_any 11\n");
        return SetError(ds, -1, "Expected object or value");
        fprintf(stderr, "[lib/ultrajsondec.c] exit decode_any 11\n");
    }
    fprintf(stderr, "[lib/ultrajsondec.c] exit decode_any 2\n");
  }
  fprintf(stderr, "[lib/ultrajsondec.c] exit decode_any 1\n");
}


JSOBJ JSON_DecodeObject(JSONObjectDecoder *dec, const char *buffer, size_t cbBuffer)
{
  fprintf(stderr, "[lib/ultrajsondec.c] enter JSON_DecodeObject 1\n");
  /*
  FIXME: Base the size of escBuffer of that of cbBuffer so that the unicode escaping doesn't run into the wall each time */
  struct DecoderState ds;
  JSUINT32 escBuffer[(JSON_MAX_STACK_BUFFER_SIZE / sizeof(JSUINT32))];
  JSOBJ ret;

  ds.start = (char *) buffer;
  ds.end = ds.start + cbBuffer;

  ds.escStart = escBuffer;
  ds.escEnd = ds.escStart + (JSON_MAX_STACK_BUFFER_SIZE / sizeof(JSUINT32));
  ds.escHeap = 0;
  ds.prv = dec->prv;
  ds.dec = dec;
  ds.dec->errorStr = NULL;
  ds.dec->errorOffset = NULL;
  ds.objDepth = 0;

  ds.dec = dec;

  ret = decode_any (&ds);
  fprintf(stderr, "[lib/ultrajsondec.c] exit JSON_DecodeObject 1\n");

  if (ds.escHeap)
  {
    fprintf(stderr, "[lib/ultrajsondec.c] enter JSON_DecodeObject 2\n");
    dec->free(ds.escStart);
    fprintf(stderr, "[lib/ultrajsondec.c] exit JSON_DecodeObject 2\n");
  }

  if (!(dec->errorStr))
  {
    fprintf(stderr, "[lib/ultrajsondec.c] enter JSON_DecodeObject 3\n");
    if ((ds.end - ds.start) > 0)
    {
      fprintf(stderr, "[lib/ultrajsondec.c] enter JSON_DecodeObject 4\n");
      SkipWhitespace(&ds);
      fprintf(stderr, "[lib/ultrajsondec.c] exit JSON_DecodeObject 4\n");
    }

    if (ds.start != ds.end && ret)
    {
      fprintf(stderr, "[lib/ultrajsondec.c] enter JSON_DecodeObject 5\n");
      dec->releaseObject(ds.prv, ret);
      return SetError(&ds, -1, "Trailing data");
      fprintf(stderr, "[lib/ultrajsondec.c] exit JSON_DecodeObject 5\n");
    }
    fprintf(stderr, "[lib/ultrajsondec.c] exit JSON_DecodeObject 3\n");
  }

  fprintf(stderr, "[lib/ultrajsondec.c] enter JSON_DecodeObject 6\n");
  return ret;
  fprintf(stderr, "[lib/ultrajsondec.c] exit JSON_DecodeObject 6\n");
}

// Total cost: 0.260970
// Total split cost: 0.038637, input tokens: 12699, output tokens: 36. Split chunks: [(0, 789), (789, 834)]
// Total instrumented cost: 0.222333, input tokens: 12436, output tokens: 12335
