extern PyObject* JSONDecodeError;


// Total cost: 0.006750
// Total split cost: 0.000000, input tokens: 0, output tokens: 0. Split chunks: [(0, 1)]
// Total instrumented cost: 0.006750, input tokens: 2135, output tokens: 23
