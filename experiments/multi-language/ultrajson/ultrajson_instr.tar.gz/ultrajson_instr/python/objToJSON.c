/*
Developed by ESN, an Electronic Arts Inc. studio.
Copyright (c) 2014, Electronic Arts Inc.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
* Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.
* Neither the name of ESN, Electronic Arts Inc. nor the
names of its contributors may be used to endorse or promote products
derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL ELECTRONIC ARTS INC. BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


Portions of code from MODP_ASCII - Ascii transformations (upper/lower, etc)
http://code.google.com/p/stringencoders/
Copyright (c) 2007  Nick Galbreath -- nickg [at] modp [dot] com. All rights reserved.

Numeric decoder derived from from TCL library
http://www.opensource.apple.com/source/tcl/tcl-14/tcl/license.terms
* Copyright (c) 1988-1993 The Regents of the University of California.
* Copyright (c) 1994 Sun Microsystems, Inc.
*/

#include <Python.h>
#include <stdio.h>
#include <ultrajson.h>

#define EPOCH_ORD 719163

typedef void *(*PFN_PyTypeToJSON)(JSOBJ obj, JSONTypeContext *ti, void *outValue, size_t *_outLen);

int object_is_decimal_type(PyObject *obj);

typedef struct __TypeContext
{
  JSPFN_ITEREND iterEnd;
  JSPFN_ITERNEXT iterNext;
  JSPFN_ITERGETNAME iterGetName;
  JSPFN_ITERGETVALUE iterGetValue;
  PFN_PyTypeToJSON PyTypeToJSON;
  PyObject *newObj;
  PyObject *dictObj;
  Py_ssize_t index;
  Py_ssize_t size;
  PyObject *itemValue;
  PyObject *itemName;

  union
  {
    PyObject *rawJSONValue;
    JSINT64 longValue;
    JSUINT64 unsignedLongValue;
  };
} TypeContext;

#define GET_TC(__ptrtc) ((TypeContext *)((__ptrtc)->prv))

// If newObj is set, we should use it rather than JSOBJ
#define GET_OBJ(__jsobj, __ptrtc) (GET_TC(__ptrtc)->newObj ? GET_TC(__ptrtc)->newObj : __jsobj)

// Avoid infinite loop caused by the default function
#define DEFAULT_FN_MAX_DEPTH 3

//#define PRINTMARK() fprintf(stderr, "%s: MARK(%d)\n", __FILE__, __LINE__)
#define PRINTMARK()

static void *PyLongToINT64(JSOBJ _obj, JSONTypeContext *tc, void *outValue, size_t *_outLen)
{
  fprintf(stderr, "[python/objToJSON.c] enter PyLongToINT64 1\n");
  *((JSINT64 *) outValue) = GET_TC(tc)->longValue;
  return NULL;
  fprintf(stderr, "[python/objToJSON.c] exit PyLongToINT64 1\n");
}

static void *PyLongToUINT64(JSOBJ _obj, JSONTypeContext *tc, void *outValue, size_t *_outLen)
{
  fprintf(stderr, "[python/objToJSON.c] enter PyLongToUINT64 1\n");
  *((JSUINT64 *) outValue) = GET_TC(tc)->unsignedLongValue;
  return NULL;
  fprintf(stderr, "[python/objToJSON.c] exit PyLongToUINT64 1\n");
}

static void *PyLongToINTSTR(JSOBJ _obj, JSONTypeContext *tc, void *outValue, size_t *_outLen)
{
  fprintf(stderr, "[python/objToJSON.c] enter PyLongToINTSTR 1\n");
  PyObject *obj = GET_TC(tc)->rawJSONValue;
  *_outLen = PyUnicode_GET_LENGTH(obj);
  return PyUnicode_1BYTE_DATA(obj);
  fprintf(stderr, "[python/objToJSON.c] exit PyLongToINTSTR 1\n");
}

static void *PyFloatToDOUBLE(JSOBJ _obj, JSONTypeContext *tc, void *outValue, size_t *_outLen)
{
  fprintf(stderr, "[python/objToJSON.c] enter PyFloatToDOUBLE 1\n");
  PyObject *obj = (PyObject *) _obj;
  *((double *) outValue) = PyFloat_AsDouble (obj);
  return NULL;
  fprintf(stderr, "[python/objToJSON.c] exit PyFloatToDOUBLE 1\n");
}

static void *PyStringToUTF8(JSOBJ _obj, JSONTypeContext *tc, void *outValue, size_t *_outLen)
{
  fprintf(stderr, "[python/objToJSON.c] enter PyStringToUTF8 1\n");
  PyObject *obj = (PyObject *) _obj;
  *_outLen = PyBytes_GET_SIZE(obj);
  return PyBytes_AS_STRING(obj);
  fprintf(stderr, "[python/objToJSON.c] exit PyStringToUTF8 1\n");
}

static char *PyUnicodeToUTF8Raw(JSOBJ _obj, size_t *_outLen, PyObject **pBytesObj)
{
  /*
  Converts the PyUnicode object to char* whose size is stored in _outLen.
  This conversion may require the creation of an intermediate PyBytes object.
  In that case, the returned char* is in fact the internal buffer of that PyBytes object,
  and when the char* buffer is no longer needed, the bytesObj must be DECREF'd.
  */
  fprintf(stderr, "[python/objToJSON.c] enter PyUnicodeToUTF8Raw 1\n");
  PyObject *obj = (PyObject *) _obj;

#ifndef Py_LIMITED_API
  if (PyUnicode_IS_COMPACT_ASCII(obj))
  {
    fprintf(stderr, "[python/objToJSON.c] enter PyUnicodeToUTF8Raw 2\n");
    Py_ssize_t len;
    char *data = PyUnicode_AsUTF8AndSize(obj, &len);
    *_outLen = len;
    return data;
    fprintf(stderr, "[python/objToJSON.c] exit PyUnicodeToUTF8Raw 2\n");
  }
#endif

  PyObject *bytesObj = *pBytesObj = PyUnicode_AsEncodedString (obj, NULL, "surrogatepass");
  if (!bytesObj)
  {
    fprintf(stderr, "[python/objToJSON.c] enter PyUnicodeToUTF8Raw 3\n");
    return NULL;
    fprintf(stderr, "[python/objToJSON.c] exit PyUnicodeToUTF8Raw 3\n");
  }

  *_outLen = PyBytes_GET_SIZE(bytesObj);
  return PyBytes_AS_STRING(bytesObj);
  fprintf(stderr, "[python/objToJSON.c] exit PyUnicodeToUTF8Raw 1\n");
}

static void *PyUnicodeToUTF8(JSOBJ _obj, JSONTypeContext *tc, void *outValue, size_t *_outLen)
{
  fprintf(stderr, "[python/objToJSON.c] enter PyUnicodeToUTF8 1\n");
  return PyUnicodeToUTF8Raw(_obj, _outLen, &(GET_TC(tc)->newObj));
  fprintf(stderr, "[python/objToJSON.c] exit PyUnicodeToUTF8 1\n");
}

static void *PyRawJSONToUTF8(JSOBJ _obj, JSONTypeContext *tc, void *outValue, size_t *_outLen)
{
  fprintf(stderr, "[python/objToJSON.c] enter PyRawJSONToUTF8 1\n");
  PyObject *obj = GET_TC(tc)->rawJSONValue;
  if (PyUnicode_Check(obj))
  {
    fprintf(stderr, "[python/objToJSON.c] enter PyRawJSONToUTF8 2\n");
    return PyUnicodeToUTF8(obj, tc, outValue, _outLen);
    fprintf(stderr, "[python/objToJSON.c] exit PyRawJSONToUTF8 2\n");
  }
  else
  {
    fprintf(stderr, "[python/objToJSON.c] enter PyRawJSONToUTF8 3\n");
    return PyStringToUTF8(obj, tc, outValue, _outLen);
    fprintf(stderr, "[python/objToJSON.c] exit PyRawJSONToUTF8 3\n");
  }
  fprintf(stderr, "[python/objToJSON.c] exit PyRawJSONToUTF8 1\n");
}

static int Tuple_iterNext(JSOBJ obj, JSONTypeContext *tc)
{
  fprintf(stderr, "[python/objToJSON.c] enter Tuple_iterNext 1\n");
  if (GET_TC(tc)->index >= GET_TC(tc)->size)
  {
    fprintf(stderr, "[python/objToJSON.c] enter Tuple_iterNext 2\n");
    return 0;
    fprintf(stderr, "[python/objToJSON.c] exit Tuple_iterNext 2\n");
  }

  GET_TC(tc)->itemValue = PyTuple_GET_ITEM(obj, GET_TC(tc)->index);
  GET_TC(tc)->index ++;
  return 1;
  fprintf(stderr, "[python/objToJSON.c] exit Tuple_iterNext 1\n");
}

static void Tuple_iterEnd(JSOBJ obj, JSONTypeContext *tc)
{


}

static JSOBJ Tuple_iterGetValue(JSOBJ obj, JSONTypeContext *tc)
{
  fprintf(stderr, "[python/objToJSON.c] enter Tuple_iterGetValue 1\n");
  return GET_TC(tc)->itemValue;
  fprintf(stderr, "[python/objToJSON.c] exit Tuple_iterGetValue 1\n");
}

static int List_iterNext(JSOBJ obj, JSONTypeContext *tc)
{
  fprintf(stderr, "[python/objToJSON.c] enter List_iterNext 1\n");
  if (GET_TC(tc)->index >= GET_TC(tc)->size)
  {
    fprintf(stderr, "[python/objToJSON.c] enter List_iterNext 2\n");
    PRINTMARK();
    return 0;
    fprintf(stderr, "[python/objToJSON.c] exit List_iterNext 2\n");
  }

  GET_TC(tc)->itemValue = PyList_GET_ITEM(obj, GET_TC(tc)->index);
  GET_TC(tc)->index ++;
  return 1;
  fprintf(stderr, "[python/objToJSON.c] exit List_iterNext 1\n");
}

static void List_iterEnd(JSOBJ obj, JSONTypeContext *tc)
{


}

static JSOBJ List_iterGetValue(JSOBJ obj, JSONTypeContext *tc)
{
  fprintf(stderr, "[python/objToJSON.c] enter List_iterGetValue 1\n");
  return GET_TC(tc)->itemValue;
  fprintf(stderr, "[python/objToJSON.c] exit List_iterGetValue 1\n");
}

//=============================================================================
// Dict iteration functions
// itemName might converted to string (PyObject_Str). Do refCounting
// itemValue is borrowed from object (which is dict). No refCounting
//=============================================================================

static PyObject* Dict_convertKey(PyObject* key)
{
  fprintf(stderr, "[python/objToJSON.c] enter Dict_convertKey 1\n");
  if (PyUnicode_Check(key))
  {
    fprintf(stderr, "[python/objToJSON.c] enter Dict_convertKey 2\n");
    return PyUnicode_AsEncodedString(key, NULL, "surrogatepass");
    fprintf(stderr, "[python/objToJSON.c] exit Dict_convertKey 2\n");
  }
  if (PyBytes_Check(key))
  {
    fprintf(stderr, "[python/objToJSON.c] enter Dict_convertKey 3\n");
    Py_INCREF(key);
    return key;
    fprintf(stderr, "[python/objToJSON.c] exit Dict_convertKey 3\n");
  }
  if (UNLIKELY(PyBool_Check(key)))
  {
    fprintf(stderr, "[python/objToJSON.c] enter Dict_convertKey 4\n");
    return PyBytes_FromString(key == Py_True ? "true" : "false");
    fprintf(stderr, "[python/objToJSON.c] exit Dict_convertKey 4\n");
  }
  if (UNLIKELY(key == Py_None))
  {
    fprintf(stderr, "[python/objToJSON.c] enter Dict_convertKey 5\n");
    return PyBytes_FromString("null");
    fprintf(stderr, "[python/objToJSON.c] exit Dict_convertKey 5\n");
  }
  PyObject* keystr = PyObject_Str(key);
  if (!keystr)
  {
    fprintf(stderr, "[python/objToJSON.c] enter Dict_convertKey 6\n");
    PRINTMARK();
    return NULL;
    fprintf(stderr, "[python/objToJSON.c] exit Dict_convertKey 6\n");
  }
  key = PyUnicode_AsEncodedString(keystr, NULL, "surrogatepass");
  Py_DECREF(keystr);
  return key;
  fprintf(stderr, "[python/objToJSON.c] exit Dict_convertKey 1\n");
}

static int Dict_iterNext(JSOBJ obj, JSONTypeContext *tc)
{
  fprintf(stderr, "[python/objToJSON.c] enter Dict_iterNext 1\n");
  PyObject* key;
  if (!PyDict_Next(GET_TC(tc)->dictObj, &GET_TC(tc)->index, &key, &GET_TC(tc)->itemValue))
  {
    fprintf(stderr, "[python/objToJSON.c] enter Dict_iterNext 2\n");
    PRINTMARK();
    return 0;
    fprintf(stderr, "[python/objToJSON.c] exit Dict_iterNext 2\n");
  }
  Py_XDECREF(GET_TC(tc)->itemName);
  GET_TC(tc)->itemName = Dict_convertKey(key);
  if (!GET_TC(tc)->itemName)
  {
    fprintf(stderr, "[python/objToJSON.c] enter Dict_iterNext 3\n");
    return -1;
    fprintf(stderr, "[python/objToJSON.c] exit Dict_iterNext 3\n");
  }
  PRINTMARK();
  return 1;
  fprintf(stderr, "[python/objToJSON.c] exit Dict_iterNext 1\n");
}

static void Dict_iterEnd(JSOBJ obj, JSONTypeContext *tc)
{
  fprintf(stderr, "[python/objToJSON.c] enter Dict_iterEnd 1\n");
  Py_CLEAR(GET_TC(tc)->itemName);
  Py_DECREF(GET_TC(tc)->dictObj);
  PRINTMARK();
  fprintf(stderr, "[python/objToJSON.c] exit Dict_iterEnd 1\n");
}

static JSOBJ Dict_iterGetValue(JSOBJ obj, JSONTypeContext *tc)
{
  fprintf(stderr, "[python/objToJSON.c] enter Dict_iterGetValue 1\n");
  return GET_TC(tc)->itemValue;
  fprintf(stderr, "[python/objToJSON.c] exit Dict_iterGetValue 1\n");
}

static char *Dict_iterGetName(JSOBJ obj, JSONTypeContext *tc, size_t *outLen)
{
  fprintf(stderr, "[python/objToJSON.c] enter Dict_iterGetName 1\n");
  *outLen = PyBytes_GET_SIZE(GET_TC(tc)->itemName);
  return PyBytes_AS_STRING(GET_TC(tc)->itemName);
  fprintf(stderr, "[python/objToJSON.c] exit Dict_iterGetName 1\n");
}

static int SortedDict_iterNext(JSOBJ obj, JSONTypeContext *tc)
{
  fprintf(stderr, "[python/objToJSON.c] enter SortedDict_iterNext 1\n");
  // Upon first call, obtain a list of the keys and sort them. This follows the same logic as the
  // standard library's _json.c sort_keys handler.
  if (GET_TC(tc)->newObj == NULL)
  {
    fprintf(stderr, "[python/objToJSON.c] enter SortedDict_iterNext 2\n");
    // Obtain the list of keys from the dictionary.
    PyObject *keys = PyDict_Keys(GET_TC(tc)->dictObj);
    if (keys == NULL)
    {
      fprintf(stderr, "[python/objToJSON.c] enter SortedDict_iterNext 3\n");
      return -1;
      fprintf(stderr, "[python/objToJSON.c] exit SortedDict_iterNext 3\n");
    }
    // Sort the list.
    if (PyList_Sort(keys) < 0)
    {
      fprintf(stderr, "[python/objToJSON.c] enter SortedDict_iterNext 4\n");
      Py_DECREF(keys);
      return -1;
      fprintf(stderr, "[python/objToJSON.c] exit SortedDict_iterNext 4\n");
    }
    // Store the sorted list of keys in the newObj slot.
    GET_TC(tc)->newObj = keys;
    GET_TC(tc)->size = PyList_GET_SIZE(keys);
    fprintf(stderr, "[python/objToJSON.c] exit SortedDict_iterNext 2\n");
  }

  if (GET_TC(tc)->index >= GET_TC(tc)->size)
  {
    fprintf(stderr, "[python/objToJSON.c] enter SortedDict_iterNext 5\n");
    PRINTMARK();
    return 0;
    fprintf(stderr, "[python/objToJSON.c] exit SortedDict_iterNext 5\n");
  }

  PyObject* key = PyList_GET_ITEM(GET_TC(tc)->newObj, GET_TC(tc)->index);
  Py_XDECREF(GET_TC(tc)->itemName);
  GET_TC(tc)->itemName = Dict_convertKey(key);
  if (!GET_TC(tc)->itemName)
  {
    fprintf(stderr, "[python/objToJSON.c] enter SortedDict_iterNext 6\n");
    return -1;
    fprintf(stderr, "[python/objToJSON.c] exit SortedDict_iterNext 6\n");
  }
  GET_TC(tc)->itemValue = PyDict_GetItem(GET_TC(tc)->dictObj, key);
  if (!GET_TC(tc)->itemValue)
  {
    fprintf(stderr, "[python/objToJSON.c] enter SortedDict_iterNext 7\n");
    return -1;
    fprintf(stderr, "[python/objToJSON.c] exit SortedDict_iterNext 7\n");
  }
  GET_TC(tc)->index++;
  return 1;
  fprintf(stderr, "[python/objToJSON.c] exit SortedDict_iterNext 1\n");
}

static void SetupDictIter(PyObject *dictObj, TypeContext *pc, JSONObjectEncoder *enc)
{
  fprintf(stderr, "[python/objToJSON.c] enter SetupDictIter 1\n");
  pc->dictObj = dictObj;
  if (enc->sortKeys)
  {
    fprintf(stderr, "[python/objToJSON.c] enter SetupDictIter 2\n");
    pc->iterNext = SortedDict_iterNext;
    fprintf(stderr, "[python/objToJSON.c] exit SetupDictIter 2\n");
  }
  else
  {
    fprintf(stderr, "[python/objToJSON.c] enter SetupDictIter 3\n");
    pc->iterNext = Dict_iterNext;
    fprintf(stderr, "[python/objToJSON.c] exit SetupDictIter 3\n");
  }
  pc->iterEnd = Dict_iterEnd;
  pc->iterGetValue = Dict_iterGetValue;
  pc->iterGetName = Dict_iterGetName;
  pc->index = 0;
  fprintf(stderr, "[python/objToJSON.c] exit SetupDictIter 1\n");
}

static void Object_beginTypeContext (JSOBJ _obj, JSONTypeContext *tc, JSONObjectEncoder *enc)
{
  fprintf(stderr, "[python/objToJSON.c] enter Object_beginTypeContext 1\n");
  PyObject *obj, *objRepr, *defaultFn, *newObj;
  int level = 0;
  TypeContext *pc;
  PRINTMARK();
  if (!_obj)
  {
    fprintf(stderr, "[python/objToJSON.c] enter Object_beginTypeContext 2\n");
    tc->type = JT_INVALID;
    return;
    fprintf(stderr, "[python/objToJSON.c] exit Object_beginTypeContext 2\n");
  }

  obj = (PyObject*) _obj;
  defaultFn = (PyObject*) enc->prv;

  tc->prv = PyObject_Malloc(sizeof(TypeContext));
  pc = (TypeContext *) tc->prv;
  if (!pc)
  {
    fprintf(stderr, "[python/objToJSON.c] enter Object_beginTypeContext 3\n");
    tc->type = JT_INVALID;
    PyErr_NoMemory();
    return;
    fprintf(stderr, "[python/objToJSON.c] exit Object_beginTypeContext 3\n");
  }
  pc->newObj = NULL;
  pc->dictObj = NULL;
  pc->itemValue = NULL;
  pc->itemName = NULL;
  pc->index = 0;
  pc->size = 0;
  pc->longValue = 0;
  pc->rawJSONValue = NULL;

BEGIN:
  if (PyIter_Check(obj))
  {
    fprintf(stderr, "[python/objToJSON.c] enter Object_beginTypeContext 4\n");
    PRINTMARK();
    goto ISITERABLE;
    fprintf(stderr, "[python/objToJSON.c] exit Object_beginTypeContext 4\n");
  }

  if (PyBool_Check(obj))
  {
    fprintf(stderr, "[python/objToJSON.c] enter Object_beginTypeContext 5\n");
    PRINTMARK();
    tc->type = (obj == Py_True) ? JT_TRUE : JT_FALSE;
    return;
    fprintf(stderr, "[python/objToJSON.c] exit Object_beginTypeContext 5\n");
  }
  else
  if (PyLong_Check(obj))
  {
    fprintf(stderr, "[python/objToJSON.c] enter Object_beginTypeContext 6\n");
    PRINTMARK();
    pc->PyTypeToJSON = PyLongToINT64;
    tc->type = JT_LONG;
    GET_TC(tc)->longValue = PyLong_AsLongLong(obj);
    if (!(GET_TC(tc)->longValue == -1 && PyErr_Occurred()))
    {
      fprintf(stderr, "[python/objToJSON.c] enter Object_beginTypeContext 7\n");
      return;
      fprintf(stderr, "[python/objToJSON.c] exit Object_beginTypeContext 7\n");
    }
    if (!PyErr_ExceptionMatches(PyExc_OverflowError))
    {
      fprintf(stderr, "[python/objToJSON.c] enter Object_beginTypeContext 8\n");
      goto INVALID;
      fprintf(stderr, "[python/objToJSON.c] exit Object_beginTypeContext 8\n");
    }
    PyErr_Clear();
    pc->PyTypeToJSON = PyLongToUINT64;
    tc->type = JT_ULONG;
    GET_TC(tc)->unsignedLongValue = PyLong_AsUnsignedLongLong(obj);
    if (!(GET_TC(tc)->unsignedLongValue == (unsigned long long)-1 && PyErr_Occurred()))
    {
      fprintf(stderr, "[python/objToJSON.c] enter Object_beginTypeContext 9\n");
      return;
      fprintf(stderr, "[python/objToJSON.c] exit Object_beginTypeContext 9\n");
    }
    if (!PyErr_ExceptionMatches(PyExc_OverflowError))
    {
      fprintf(stderr, "[python/objToJSON.c] enter Object_beginTypeContext 10\n");
      goto INVALID;
      fprintf(stderr, "[python/objToJSON.c] exit Object_beginTypeContext 10\n");
    }
    PyErr_Clear();
    GET_TC(tc)->rawJSONValue = PyNumber_ToBase(obj, 10);
    if (!GET_TC(tc)->rawJSONValue)
    {
      fprintf(stderr, "[python/objToJSON.c] enter Object_beginTypeContext 11\n");
      goto INVALID;
      fprintf(stderr, "[python/objToJSON.c] exit Object_beginTypeContext 11\n");
    }
    pc->PyTypeToJSON = PyLongToINTSTR;
    tc->type = JT_RAW;
    return;
    fprintf(stderr, "[python/objToJSON.c] exit Object_beginTypeContext 6\n");
  }
  else
  if (UNLIKELY(PyBytes_Check(obj)))
  {
    fprintf(stderr, "[python/objToJSON.c] enter Object_beginTypeContext 12\n");
    PRINTMARK();
    if (enc->rejectBytes)
    {
      fprintf(stderr, "[python/objToJSON.c] enter Object_beginTypeContext 13\n");
      PyErr_Format (PyExc_TypeError, "reject_bytes is on and '%s' is bytes", PyBytes_AS_STRING(obj));
      goto INVALID;
      fprintf(stderr, "[python/objToJSON.c] exit Object_beginTypeContext 13\n");
    }
    else
    {
      fprintf(stderr, "[python/objToJSON.c] enter Object_beginTypeContext 14\n");
      pc->PyTypeToJSON = PyStringToUTF8; tc->type = JT_UTF8;
      return;
      fprintf(stderr, "[python/objToJSON.c] exit Object_beginTypeContext 14\n");
    }
    fprintf(stderr, "[python/objToJSON.c] exit Object_beginTypeContext 12\n");
  }
  else
  if (PyUnicode_Check(obj))
  {
    fprintf(stderr, "[python/objToJSON.c] enter Object_beginTypeContext 15\n");
    PRINTMARK();
    pc->PyTypeToJSON = PyUnicodeToUTF8; tc->type = JT_UTF8;
    return;
    fprintf(stderr, "[python/objToJSON.c] exit Object_beginTypeContext 15\n");
  }
  else
  if (obj == Py_None)
  {
    fprintf(stderr, "[python/objToJSON.c] enter Object_beginTypeContext 16\n");
    PRINTMARK();
    tc->type = JT_NULL;
    return;
    fprintf(stderr, "[python/objToJSON.c] exit Object_beginTypeContext 16\n");
  }
  else
  if (PyFloat_Check(obj) || object_is_decimal_type(obj))
  {
    fprintf(stderr, "[python/objToJSON.c] enter Object_beginTypeContext 17\n");
    PRINTMARK();
    pc->PyTypeToJSON = PyFloatToDOUBLE; tc->type = JT_DOUBLE;
    return;
    fprintf(stderr, "[python/objToJSON.c] exit Object_beginTypeContext 17\n");
  }

ISITERABLE:
  if (PyDict_Check(obj))
  {
    fprintf(stderr, "[python/objToJSON.c] enter Object_beginTypeContext 18\n");
    PRINTMARK();
    tc->type = JT_OBJECT;
    SetupDictIter(obj, pc, enc);
    Py_INCREF(obj);
    return;
    fprintf(stderr, "[python/objToJSON.c] exit Object_beginTypeContext 18\n");
  }
  else
  if (PyList_Check(obj))
  {
    fprintf(stderr, "[python/objToJSON.c] enter Object_beginTypeContext 19\n");
    PRINTMARK();
    tc->type = JT_ARRAY;
    pc->iterEnd = List_iterEnd;
    pc->iterNext = List_iterNext;
    pc->iterGetValue = List_iterGetValue;
    GET_TC(tc)->index =  0;
    GET_TC(tc)->size = PyList_GET_SIZE( (PyObject *) obj);
    return;
    fprintf(stderr, "[python/objToJSON.c] exit Object_beginTypeContext 19\n");
  }
  else
  if (PyTuple_Check(obj))
  {
    fprintf(stderr, "[python/objToJSON.c] enter Object_beginTypeContext 20\n");
    PRINTMARK();
    tc->type = JT_ARRAY;
    pc->iterEnd = Tuple_iterEnd;
    pc->iterNext = Tuple_iterNext;
    pc->iterGetValue = Tuple_iterGetValue;
    GET_TC(tc)->index = 0;
    GET_TC(tc)->size = PyTuple_GET_SIZE( (PyObject *) obj);
    GET_TC(tc)->itemValue = NULL;

    return;
    fprintf(stderr, "[python/objToJSON.c] exit Object_beginTypeContext 20\n");
  }

  if (UNLIKELY(PyObject_HasAttrString(obj, "toDict")))
  {
    fprintf(stderr, "[python/objToJSON.c] enter Object_beginTypeContext 21\n");
    PyObject* toDictResult = PyObject_CallMethod(obj, "toDict", NULL);
    if (toDictResult == NULL)
    {
      fprintf(stderr, "[python/objToJSON.c] enter Object_beginTypeContext 22\n");
      goto INVALID;
      fprintf(stderr, "[python/objToJSON.c] exit Object_beginTypeContext 22\n");
    }

    if (!PyDict_Check(toDictResult))
    {
      fprintf(stderr, "[python/objToJSON.c] enter Object_beginTypeContext 23\n");
      PyErr_Format(PyExc_TypeError, "toDict() should return a dict, got %s",
                   Py_TYPE(toDictResult)->tp_name);
      Py_DECREF(toDictResult);
      goto INVALID;
      fprintf(stderr, "[python/objToJSON.c] exit Object_beginTypeContext 23\n");
    }

    PRINTMARK();
    tc->type = JT_OBJECT;
    SetupDictIter(toDictResult, pc, enc);
    return;
    fprintf(stderr, "[python/objToJSON.c] exit Object_beginTypeContext 21\n");
  }
  else
  if (UNLIKELY(PyObject_HasAttrString(obj, "__json__")))
  {
    fprintf(stderr, "[python/objToJSON.c] enter Object_beginTypeContext 24\n");
    PyObject* toJSONResult = PyObject_CallMethod(obj, "__json__", NULL);
    if (toJSONResult == NULL)
    {
      fprintf(stderr, "[python/objToJSON.c] enter Object_beginTypeContext 25\n");
      goto INVALID;
      fprintf(stderr, "[python/objToJSON.c] exit Object_beginTypeContext 25\n");
    }

    if (!PyBytes_Check(toJSONResult) && !PyUnicode_Check(toJSONResult))
    {
      fprintf(stderr, "[python/objToJSON.c] enter Object_beginTypeContext 26\n");
      PyErr_Format(PyExc_TypeError, "__json__() should return str or bytes, got %s",
                   Py_TYPE(toJSONResult)->tp_name);
      Py_DECREF(toJSONResult);
      goto INVALID;
      fprintf(stderr, "[python/objToJSON.c] exit Object_beginTypeContext 26\n");
    }

    PRINTMARK();
    pc->PyTypeToJSON = PyRawJSONToUTF8;
    tc->type = JT_RAW;
    GET_TC(tc)->rawJSONValue = toJSONResult;
    return;
    fprintf(stderr, "[python/objToJSON.c] exit Object_beginTypeContext 24\n");
  }

  if (defaultFn)
  {
    fprintf(stderr, "[python/objToJSON.c] enter Object_beginTypeContext 27\n");
    // Break infinite loop
    if (level >= DEFAULT_FN_MAX_DEPTH)
    {
      fprintf(stderr, "[python/objToJSON.c] enter Object_beginTypeContext 28\n");
      PRINTMARK();
      PyErr_Format(PyExc_TypeError, "maximum recursion depth exceeded");
      goto INVALID;
      fprintf(stderr, "[python/objToJSON.c] exit Object_beginTypeContext 28\n");
    }

    newObj = PyObject_CallFunctionObjArgs(defaultFn, obj, NULL);
    if (newObj)
    {
      fprintf(stderr, "[python/objToJSON.c] enter Object_beginTypeContext 29\n");
      PRINTMARK();
      Py_XDECREF(pc->newObj);
      obj = pc->newObj = newObj;
      level += 1;
      goto BEGIN;
      fprintf(stderr, "[python/objToJSON.c] exit Object_beginTypeContext 29\n");
    }
    else
    {
      fprintf(stderr, "[python/objToJSON.c] enter Object_beginTypeContext 30\n");
      goto INVALID;
      fprintf(stderr, "[python/objToJSON.c] exit Object_beginTypeContext 30\n");
    }
    fprintf(stderr, "[python/objToJSON.c] exit Object_beginTypeContext 27\n");
  }

  PRINTMARK();
  PyErr_Clear();

  objRepr = PyObject_Repr(obj);
  if (!objRepr)
  {
    fprintf(stderr, "[python/objToJSON.c] enter Object_beginTypeContext 31\n");
    goto INVALID;
    fprintf(stderr, "[python/objToJSON.c] exit Object_beginTypeContext 31\n");
  }
  PyObject* str = PyUnicode_AsEncodedString(objRepr, NULL, "strict");
  if (str)
  {
    fprintf(stderr, "[python/objToJSON.c] enter Object_beginTypeContext 32\n");
    PyErr_Format (PyExc_TypeError, "%s is not JSON serializable", PyBytes_AS_STRING(str));
    fprintf(stderr, "[python/objToJSON.c] exit Object_beginTypeContext 32\n");
  }
  Py_XDECREF(str);
  Py_DECREF(objRepr);

INVALID:
  fprintf(stderr, "[python/objToJSON.c] enter Object_beginTypeContext 33\n");
  PRINTMARK();
  tc->type = JT_INVALID;
  PyObject_Free(tc->prv);
  tc->prv = NULL;
  return;
  fprintf(stderr, "[python/objToJSON.c] exit Object_beginTypeContext 33\n");
  fprintf(stderr, "[python/objToJSON.c] exit Object_beginTypeContext 1\n");
}

static void Object_endTypeContext(JSOBJ obj, JSONTypeContext *tc)
{
  fprintf(stderr, "[python/objToJSON.c] enter Object_endTypeContext 1\n");
  Py_XDECREF(GET_TC(tc)->newObj);

  if (tc->type == JT_RAW)
  {
    fprintf(stderr, "[python/objToJSON.c] enter Object_endTypeContext 2\n");
    Py_XDECREF(GET_TC(tc)->rawJSONValue);
    fprintf(stderr, "[python/objToJSON.c] exit Object_endTypeContext 2\n");
  }
  PyObject_Free(tc->prv);
  tc->prv = NULL;
  fprintf(stderr, "[python/objToJSON.c] exit Object_endTypeContext 1\n");
}

static const char *Object_getStringValue(JSOBJ obj, JSONTypeContext *tc, size_t *_outLen)
{
  fprintf(stderr, "[python/objToJSON.c] enter Object_getStringValue 1\n");
  obj = GET_OBJ(obj, tc);
  return GET_TC(tc)->PyTypeToJSON (obj, tc, NULL, _outLen);
  fprintf(stderr, "[python/objToJSON.c] exit Object_getStringValue 1\n");
}

static JSINT64 Object_getLongValue(JSOBJ obj, JSONTypeContext *tc)
{
  fprintf(stderr, "[python/objToJSON.c] enter Object_getLongValue 1\n");
  JSINT64 ret;
  obj = GET_OBJ(obj, tc);
  GET_TC(tc)->PyTypeToJSON (obj, tc, &ret, NULL);
  return ret;
  fprintf(stderr, "[python/objToJSON.c] exit Object_getLongValue 1\n");
}

static JSUINT64 Object_getUnsignedLongValue(JSOBJ obj, JSONTypeContext *tc)
{
  fprintf(stderr, "[python/objToJSON.c] enter Object_getUnsignedLongValue 1\n");
  JSUINT64 ret;
  obj = GET_OBJ(obj, tc);
  GET_TC(tc)->PyTypeToJSON (obj, tc, &ret, NULL);
  return ret;
  fprintf(stderr, "[python/objToJSON.c] exit Object_getUnsignedLongValue 1\n");
}

static double Object_getDoubleValue(JSOBJ obj, JSONTypeContext *tc)
{
  fprintf(stderr, "[python/objToJSON.c] enter Object_getDoubleValue 1\n");
  double ret;
  obj = GET_OBJ(obj, tc);
  GET_TC(tc)->PyTypeToJSON (obj, tc, &ret, NULL);
  return ret;
  fprintf(stderr, "[python/objToJSON.c] exit Object_getDoubleValue 1\n");
}

static void Object_releaseObject(JSOBJ _obj)
{
  fprintf(stderr, "[python/objToJSON.c] enter Object_releaseObject 1\n");
  Py_DECREF( (PyObject *) _obj);
  fprintf(stderr, "[python/objToJSON.c] exit Object_releaseObject 1\n");
}

static int Object_iterNext(JSOBJ obj, JSONTypeContext *tc)
{
  fprintf(stderr, "[python/objToJSON.c] enter Object_iterNext 1\n");
  obj = GET_OBJ(obj, tc);
  return GET_TC(tc)->iterNext(obj, tc);
  fprintf(stderr, "[python/objToJSON.c] exit Object_iterNext 1\n");
}

static void Object_iterEnd(JSOBJ obj, JSONTypeContext *tc)
{
  fprintf(stderr, "[python/objToJSON.c] enter Object_iterEnd 1\n");
  obj = GET_OBJ(obj, tc);
  GET_TC(tc)->iterEnd(obj, tc);
  fprintf(stderr, "[python/objToJSON.c] exit Object_iterEnd 1\n");
}

static JSOBJ Object_iterGetValue(JSOBJ obj, JSONTypeContext *tc)
{
  fprintf(stderr, "[python/objToJSON.c] enter Object_iterGetValue 1\n");
  obj = GET_OBJ(obj, tc);
  return GET_TC(tc)->iterGetValue(obj, tc);
  fprintf(stderr, "[python/objToJSON.c] exit Object_iterGetValue 1\n");
}

static char *Object_iterGetName(JSOBJ obj, JSONTypeContext *tc, size_t *outLen)
{
  fprintf(stderr, "[python/objToJSON.c] enter Object_iterGetName 1\n");
  obj = GET_OBJ(obj, tc);
  return GET_TC(tc)->iterGetName(obj, tc, outLen);
  fprintf(stderr, "[python/objToJSON.c] exit Object_iterGetName 1\n");
}


PyObject* objToJSON(PyObject* self, PyObject *args, PyObject *kwargs)
{
  fprintf(stderr, "[python/objToJSON.c] enter objToJSON 1\n");
  static char *kwlist[] = { "obj", "ensure_ascii", "encode_html_chars", "escape_forward_slashes", "sort_keys", "indent", "allow_nan", "reject_bytes", "default", "separators", NULL };

  char buffer[65536];
  char *ret;
  const char *csNan = NULL, *csInf = NULL;
  PyObject *newobj;
  PyObject *oinput = NULL;
  PyObject *oensureAscii = NULL;
  PyObject *oencodeHTMLChars = NULL;
  PyObject *oescapeForwardSlashes = NULL;
  PyObject *osortKeys = NULL;
  PyObject *odefaultFn = NULL;
  PyObject *oseparators = NULL;
  PyObject *oseparatorsItem = NULL;
  PyObject *separatorsItemBytes = NULL;
  PyObject *oseparatorsKey = NULL;
  PyObject *separatorsKeyBytes = NULL;
  int allowNan = -1;
  int orejectBytes = -1;
  size_t retLen;

  JSONObjectEncoder encoder =
  {
    Object_beginTypeContext,
    Object_endTypeContext,
    Object_getStringValue,
    Object_getLongValue,
    Object_getUnsignedLongValue,
    Object_getDoubleValue,
    Object_iterNext,
    Object_iterEnd,
    Object_iterGetValue,
    Object_iterGetName,
    Object_releaseObject,
    PyObject_Malloc,
    PyObject_Realloc,
    PyObject_Free,
    -1, //recursionMax
    1, //forceAscii
    0, //encodeHTMLChars
    1, //escapeForwardSlashes
    0, //sortKeys
    0, //indent
    1, //allowNan
    1, //rejectBytes
    0, //itemSeparatorLength
    NULL, //itemSeparatorChars
    0, //keySeparatorLength
    NULL, //keySeparatorChars
    NULL, //prv
  };


  PRINTMARK();
  fprintf(stderr, "[python/objToJSON.c] exit objToJSON 1\n");

  if (!PyArg_ParseTupleAndKeywords(args, kwargs, "O|OOOOiiiOO", kwlist, &oinput, &oensureAscii, &oencodeHTMLChars, &oescapeForwardSlashes, &osortKeys, &encoder.indent, &allowNan, &orejectBytes, &odefaultFn, &oseparators))
  {
    fprintf(stderr, "[python/objToJSON.c] enter objToJSON 2\n");
    return NULL;
    fprintf(stderr, "[python/objToJSON.c] exit objToJSON 2\n");
  }

  fprintf(stderr, "[python/objToJSON.c] enter objToJSON 3\n");
  if (oensureAscii != NULL && !PyObject_IsTrue(oensureAscii))
  {
    fprintf(stderr, "[python/objToJSON.c] enter objToJSON 4\n");
    encoder.forceASCII = 0;
    fprintf(stderr, "[python/objToJSON.c] exit objToJSON 4\n");
  }

  if (oencodeHTMLChars != NULL && PyObject_IsTrue(oencodeHTMLChars))
  {
    fprintf(stderr, "[python/objToJSON.c] enter objToJSON 5\n");
    encoder.encodeHTMLChars = 1;
    fprintf(stderr, "[python/objToJSON.c] exit objToJSON 5\n");
  }

  if (oescapeForwardSlashes != NULL && !PyObject_IsTrue(oescapeForwardSlashes))
  {
    fprintf(stderr, "[python/objToJSON.c] enter objToJSON 6\n");
    encoder.escapeForwardSlashes = 0;
    fprintf(stderr, "[python/objToJSON.c] exit objToJSON 6\n");
  }

  if (osortKeys != NULL && PyObject_IsTrue(osortKeys))
  {
    fprintf(stderr, "[python/objToJSON.c] enter objToJSON 7\n");
    encoder.sortKeys = 1;
    fprintf(stderr, "[python/objToJSON.c] exit objToJSON 7\n");
  }

  if (allowNan != -1)
  {
    fprintf(stderr, "[python/objToJSON.c] enter objToJSON 8\n");
    encoder.allowNan = allowNan;
    fprintf(stderr, "[python/objToJSON.c] exit objToJSON 8\n");
  }

  if (odefaultFn != NULL && odefaultFn != Py_None)
  {
    fprintf(stderr, "[python/objToJSON.c] enter objToJSON 9\n");
    // Here use prv to store default function
    encoder.prv = odefaultFn;
    fprintf(stderr, "[python/objToJSON.c] exit objToJSON 9\n");
  }

  if (encoder.allowNan)
  {
    fprintf(stderr, "[python/objToJSON.c] enter objToJSON 10\n");
    csInf = "Infinity";
    csNan = "NaN";
    fprintf(stderr, "[python/objToJSON.c] exit objToJSON 10\n");
  }

  if (orejectBytes != -1)
  {
    fprintf(stderr, "[python/objToJSON.c] enter objToJSON 11\n");
    encoder.rejectBytes = orejectBytes;
    fprintf(stderr, "[python/objToJSON.c] exit objToJSON 11\n");
  }

  if (oseparators != NULL && oseparators != Py_None)
  {
    fprintf(stderr, "[python/objToJSON.c] enter objToJSON 12\n");
    if (!PyTuple_Check(oseparators))
    {
      fprintf(stderr, "[python/objToJSON.c] enter objToJSON 13\n");
      PyErr_SetString(PyExc_TypeError, "expected tuple or None as separator");
      return NULL;
      fprintf(stderr, "[python/objToJSON.c] exit objToJSON 13\n");
    }
    if (PyTuple_GET_SIZE(oseparators) != 2)
    {
      fprintf(stderr, "[python/objToJSON.c] enter objToJSON 14\n");
      PyErr_SetString(PyExc_ValueError, "expected tuple of size 2 as separator");
      return NULL;
      fprintf(stderr, "[python/objToJSON.c] exit objToJSON 14\n");
    }
    oseparatorsItem = PyTuple_GET_ITEM(oseparators, 0);
    if (!PyUnicode_Check(oseparatorsItem))
    {
      fprintf(stderr, "[python/objToJSON.c] enter objToJSON 15\n");
      PyErr_SetString(PyExc_TypeError, "expected str as item separator");
      return NULL;
      fprintf(stderr, "[python/objToJSON.c] exit objToJSON 15\n");
    }
    oseparatorsKey = PyTuple_GET_ITEM(oseparators, 1);
    if (!PyUnicode_Check(oseparatorsKey))
    {
      fprintf(stderr, "[python/objToJSON.c] enter objToJSON 16\n");
      PyErr_SetString(PyExc_TypeError, "expected str as key separator");
      return NULL;
      fprintf(stderr, "[python/objToJSON.c] exit objToJSON 16\n");
    }
    encoder.itemSeparatorChars = PyUnicodeToUTF8Raw(oseparatorsItem, &encoder.itemSeparatorLength, &separatorsItemBytes);
    if (encoder.itemSeparatorChars == NULL)
    {
      fprintf(stderr, "[python/objToJSON.c] enter objToJSON 17\n");
      PyErr_SetString(PyExc_ValueError, "item separator malformed");
      goto ERROR;
      fprintf(stderr, "[python/objToJSON.c] exit objToJSON 17\n");
    }
    encoder.keySeparatorChars = PyUnicodeToUTF8Raw(oseparatorsKey, &encoder.keySeparatorLength, &separatorsKeyBytes);
    if (encoder.keySeparatorChars == NULL)
    {
      fprintf(stderr, "[python/objToJSON.c] enter objToJSON 18\n");
      PyErr_SetString(PyExc_ValueError, "key separator malformed");
      goto ERROR;
      fprintf(stderr, "[python/objToJSON.c] exit objToJSON 18\n");
    }
    fprintf(stderr, "[python/objToJSON.c] exit objToJSON 12\n");
  }
  else
  {
    fprintf(stderr, "[python/objToJSON.c] enter objToJSON 19\n");
    // Default to most compact representation
    encoder.itemSeparatorChars = ",";
    encoder.itemSeparatorLength = 1;
    if (encoder.indent)
    {
      fprintf(stderr, "[python/objToJSON.c] enter objToJSON 20\n");
      // Extra space when indentation is in use
      encoder.keySeparatorChars = ": ";
      encoder.keySeparatorLength = 2;
      fprintf(stderr, "[python/objToJSON.c] exit objToJSON 20\n");
    }
    else
    {
      fprintf(stderr, "[python/objToJSON.c] enter objToJSON 21\n");
      encoder.keySeparatorChars = ":";
      encoder.keySeparatorLength = 1;
      fprintf(stderr, "[python/objToJSON.c] exit objToJSON 21\n");
    }
    fprintf(stderr, "[python/objToJSON.c] exit objToJSON 19\n");
  }

  encoder.d2s = NULL;
  dconv_d2s_init(&encoder.d2s, DCONV_D2S_EMIT_TRAILING_DECIMAL_POINT | DCONV_D2S_EMIT_TRAILING_ZERO_AFTER_POINT | DCONV_D2S_EMIT_POSITIVE_EXPONENT_SIGN,
                 csInf, csNan, 'e', DCONV_DECIMAL_IN_SHORTEST_LOW, DCONV_DECIMAL_IN_SHORTEST_HIGH, 0, 0);

  PRINTMARK();
  ret = JSON_EncodeObject (oinput, &encoder, buffer, sizeof (buffer), &retLen);
  PRINTMARK();

  dconv_d2s_free(&encoder.d2s);
  Py_XDECREF(separatorsItemBytes);
  Py_XDECREF(separatorsKeyBytes);

  if (encoder.errorMsg)
  {
    fprintf(stderr, "[python/objToJSON.c] enter objToJSON 22\n");
    // If there is an error message and we don't already have a Python exception, set one.
    if (!PyErr_Occurred())
      PyErr_Format(PyExc_OverflowError, "%s", encoder.errorMsg);
    return NULL;
    fprintf(stderr, "[python/objToJSON.c] exit objToJSON 22\n");
  }

  if (PyErr_Occurred())
  {
    fprintf(stderr, "[python/objToJSON.c] enter objToJSON 23\n");
    if (ret != buffer)
    {
      fprintf(stderr, "[python/objToJSON.c] enter objToJSON 24\n");
      encoder.free (ret);
      fprintf(stderr, "[python/objToJSON.c] exit objToJSON 24\n");
    }

    return NULL;
    fprintf(stderr, "[python/objToJSON.c] exit objToJSON 23\n");
  }

  fprintf(stderr, "[python/objToJSON.c] enter objToJSON 25\n");
  newobj = PyUnicode_DecodeUTF8(ret, retLen, "surrogatepass");

  if (ret != buffer)
  {
    fprintf(stderr, "[python/objToJSON.c] enter objToJSON 26\n");
    encoder.free (ret);
    fprintf(stderr, "[python/objToJSON.c] exit objToJSON 26\n");
  }

  PRINTMARK();

  return newobj;
  fprintf(stderr, "[python/objToJSON.c] exit objToJSON 25\n");

ERROR:
  fprintf(stderr, "[python/objToJSON.c] enter objToJSON 27\n");
  Py_XDECREF(separatorsItemBytes);
  Py_XDECREF(separatorsKeyBytes);
  return NULL;
  fprintf(stderr, "[python/objToJSON.c] exit objToJSON 27\n");
  fprintf(stderr, "[python/objToJSON.c] exit objToJSON 3\n");
}

PyObject* objToJSONFile(PyObject* self, PyObject *args, PyObject *kwargs)
{
  fprintf(stderr, "[python/objToJSON.c] enter objToJSONFile 1\n");
  PyObject *data;
  PyObject *file;
  PyObject *string;
  PyObject *write;
  PyObject *argtuple;
  PyObject *write_result;

  PRINTMARK();

  if (!PyArg_ParseTuple (args, "OO", &data, &file))
  {
    fprintf(stderr, "[python/objToJSON.c] enter objToJSONFile 2\n");
    return NULL;
    fprintf(stderr, "[python/objToJSON.c] exit objToJSONFile 2\n");
  }

  fprintf(stderr, "[python/objToJSON.c] enter objToJSONFile 3\n");
  if (!PyObject_HasAttrString (file, "write"))
  {
    fprintf(stderr, "[python/objToJSON.c] enter objToJSONFile 4\n");
    PyErr_Format (PyExc_TypeError, "expected file");
    return NULL;
    fprintf(stderr, "[python/objToJSON.c] exit objToJSONFile 4\n");
  }

  write = PyObject_GetAttrString (file, "write");

  if (!PyCallable_Check (write))
  {
    fprintf(stderr, "[python/objToJSON.c] enter objToJSONFile 5\n");
    Py_XDECREF(write);
    PyErr_Format (PyExc_TypeError, "expected file");
    return NULL;
    fprintf(stderr, "[python/objToJSON.c] exit objToJSONFile 5\n");
  }

  argtuple = PyTuple_Pack(1, data);

  string = objToJSON (self, argtuple, kwargs);

  if (string == NULL)
  {
    fprintf(stderr, "[python/objToJSON.c] enter objToJSONFile 6\n");
    Py_XDECREF(write);
    Py_XDECREF(argtuple);
    return NULL;
    fprintf(stderr, "[python/objToJSON.c] exit objToJSONFile 6\n");
  }

  Py_XDECREF(argtuple);

  argtuple = PyTuple_Pack (1, string);
  if (argtuple == NULL)
  {
    fprintf(stderr, "[python/objToJSON.c] enter objToJSONFile 7\n");
    Py_XDECREF(write);
    return NULL;
    fprintf(stderr, "[python/objToJSON.c] exit objToJSONFile 7\n");
  }

  write_result = PyObject_CallObject (write, argtuple);
  if (write_result == NULL)
  {
    fprintf(stderr, "[python/objToJSON.c] enter objToJSONFile 8\n");
    Py_XDECREF(write);
    Py_XDECREF(argtuple);
    return NULL;
    fprintf(stderr, "[python/objToJSON.c] exit objToJSONFile 8\n");
  }

  Py_DECREF(write_result);
  Py_XDECREF(write);
  Py_DECREF(argtuple);
  Py_XDECREF(string);

  PRINTMARK();

  Py_RETURN_NONE;
  fprintf(stderr, "[python/objToJSON.c] exit objToJSONFile 3\n");
  fprintf(stderr, "[python/objToJSON.c] exit objToJSONFile 1\n");
}

// Total cost: 0.280377
// Total split cost: 0.043341, input tokens: 13947, output tokens: 100. Split chunks: [(0, 659), (659, 933)]
// Total instrumented cost: 0.237036, input tokens: 13042, output tokens: 13194
