/*
Developed by ESN, an Electronic Arts Inc. studio.
Copyright (c) 2014, Electronic Arts Inc.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
* Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.
* Neither the name of ESN, Electronic Arts Inc. nor the
names of its contributors may be used to endorse or promote products
derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL ELECTRONIC ARTS INC. BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


Portions of code from MODP_ASCII - Ascii transformations (upper/lower, etc)
http://code.google.com/p/stringencoders/
Copyright (c) 2007  Nick Galbreath -- nickg [at] modp [dot] com. All rights reserved.

Numeric decoder derived from from TCL library
http://www.opensource.apple.com/source/tcl/tcl-14/tcl/license.terms
 * Copyright (c) 1988-1993 The Regents of the University of California.
 * Copyright (c) 1994 Sun Microsystems, Inc.
*/

#include <stdbool.h>

#include <Python.h>
#include <ultrajson.h>
#include "ujson.h"

// Import JSONDecodeError from ujson.c
extern PyObject* JSONDecodeError;


//#define PRINTMARK() fprintf(stderr, "%s: MARK(%d)\n", __FILE__, __LINE__)
#define PRINTMARK()

static void Object_objectAddKey(void *prv, JSOBJ obj, JSOBJ name, JSOBJ value)
{
  fprintf(stderr, "[python/JSONtoObj.c] enter Object_objectAddKey 1\n");
  int result = PyDict_SetItem(obj, name, value);
  if (result == -1) {
    fprintf(stderr, "[python/JSONtoObj.c] enter Object_objectAddKey 2\n");
    // Clear the Python error state to prevent SystemError
    PyErr_Clear();
    // Set our own error
    PyErr_SetString(JSONDecodeError, "Invalid JSON: object keys must be strings");
    fprintf(stderr, "[python/JSONtoObj.c] exit Object_objectAddKey 2\n");
  }
  Py_DECREF( (PyObject *) name);
  Py_DECREF( (PyObject *) value);
  return;
  fprintf(stderr, "[python/JSONtoObj.c] exit Object_objectAddKey 1\n");
}

static void Object_arrayAddItem(void *prv, JSOBJ obj, JSOBJ value)
{
  fprintf(stderr, "[python/JSONtoObj.c] enter Object_arrayAddItem 1\n");
  PyList_Append(obj, value);
  Py_DECREF( (PyObject *) value);
  return;
  fprintf(stderr, "[python/JSONtoObj.c] exit Object_arrayAddItem 1\n");
}

/*
Check that Py_UCS4 is the same as JSUINT32, else Object_newString will fail.
Based on Linux's check in vbox_vmmdev_types.h.
This should be replaced with
  _Static_assert(sizeof(Py_UCS4) == sizeof(JSUINT32));
when C11 is made mandatory (CPython 3.11+, PyPy ?).
*/
typedef char assert_py_ucs4_is_jsuint32[1 - 2*!(sizeof(Py_UCS4) == sizeof(JSUINT32))];

static JSOBJ Object_newString(void *prv, JSUINT32 *start, JSUINT32 *end)
{
  fprintf(stderr, "[python/JSONtoObj.c] enter Object_newString 1\n");
  return PyUnicode_FromKindAndData (PyUnicode_4BYTE_KIND, (Py_UCS4 *) start, (end - start));
  fprintf(stderr, "[python/JSONtoObj.c] exit Object_newString 1\n");
}

static JSOBJ Object_newTrue(void *prv)
{
  fprintf(stderr, "[python/JSONtoObj.c] enter Object_newTrue 1\n");
  Py_RETURN_TRUE;
  fprintf(stderr, "[python/JSONtoObj.c] exit Object_newTrue 1\n");
}

static JSOBJ Object_newFalse(void *prv)
{
  fprintf(stderr, "[python/JSONtoObj.c] enter Object_newFalse 1\n");
  Py_RETURN_FALSE;
  fprintf(stderr, "[python/JSONtoObj.c] exit Object_newFalse 1\n");
}

static JSOBJ Object_newNull(void *prv)
{
  fprintf(stderr, "[python/JSONtoObj.c] enter Object_newNull 1\n");
  Py_RETURN_NONE;
  fprintf(stderr, "[python/JSONtoObj.c] exit Object_newNull 1\n");
}

static JSOBJ Object_newNaN(void *prv)
{
  fprintf(stderr, "[python/JSONtoObj.c] enter Object_newNaN 1\n");
  return PyFloat_FromDouble(Py_NAN);
  fprintf(stderr, "[python/JSONtoObj.c] exit Object_newNaN 1\n");
}

static JSOBJ Object_newPosInf(void *prv)
{
  fprintf(stderr, "[python/JSONtoObj.c] enter Object_newPosInf 1\n");
  return PyFloat_FromDouble(Py_HUGE_VAL);
  fprintf(stderr, "[python/JSONtoObj.c] exit Object_newPosInf 1\n");
}

static JSOBJ Object_newNegInf(void *prv)
{
  fprintf(stderr, "[python/JSONtoObj.c] enter Object_newNegInf 1\n");
  return PyFloat_FromDouble(-Py_HUGE_VAL);
  fprintf(stderr, "[python/JSONtoObj.c] exit Object_newNegInf 1\n");
}

static JSOBJ Object_newObject(void *prv)
{
  fprintf(stderr, "[python/JSONtoObj.c] enter Object_newObject 1\n");
  return PyDict_New();
  fprintf(stderr, "[python/JSONtoObj.c] exit Object_newObject 1\n");
}

static JSOBJ Object_newArray(void *prv)
{
  fprintf(stderr, "[python/JSONtoObj.c] enter Object_newArray 1\n");
  return PyList_New(0);
  fprintf(stderr, "[python/JSONtoObj.c] exit Object_newArray 1\n");
}

static JSOBJ Object_newInteger(void *prv, JSINT32 value)
{
  fprintf(stderr, "[python/JSONtoObj.c] enter Object_newInteger 1\n");
  return PyLong_FromLong( (long) value);
  fprintf(stderr, "[python/JSONtoObj.c] exit Object_newInteger 1\n");
}

static JSOBJ Object_newLong(void *prv, JSINT64 value)
{
  fprintf(stderr, "[python/JSONtoObj.c] enter Object_newLong 1\n");
  return PyLong_FromLongLong (value);
  fprintf(stderr, "[python/JSONtoObj.c] exit Object_newLong 1\n");
}

static JSOBJ Object_newUnsignedLong(void *prv, JSUINT64 value)
{
  fprintf(stderr, "[python/JSONtoObj.c] enter Object_newUnsignedLong 1\n");
  return PyLong_FromUnsignedLongLong (value);
  fprintf(stderr, "[python/JSONtoObj.c] exit Object_newUnsignedLong 1\n");
}

static JSOBJ Object_newIntegerFromString(void *prv, char *value, size_t length)
{
  fprintf(stderr, "[python/JSONtoObj.c] enter Object_newIntegerFromString 1\n");
  // PyLong_FromString requires a NUL-terminated string in CPython, contrary to the documentation: https://github.com/python/cpython/issues/59200
  char *buf = PyObject_Malloc(length + 1);
  memcpy(buf, value, length);
  buf[length] = '\0';
  return PyLong_FromString(buf, NULL, 10);
  fprintf(stderr, "[python/JSONtoObj.c] exit Object_newIntegerFromString 1\n");
}

static JSOBJ Object_newDouble(void *prv, double value)
{
  fprintf(stderr, "[python/JSONtoObj.c] enter Object_newDouble 1\n");
  return PyFloat_FromDouble(value);
  fprintf(stderr, "[python/JSONtoObj.c] exit Object_newDouble 1\n");
}

static void Object_releaseObject(void *prv, JSOBJ obj)
{
  fprintf(stderr, "[python/JSONtoObj.c] enter Object_releaseObject 1\n");
  Py_DECREF( ((PyObject *)obj));
  fprintf(stderr, "[python/JSONtoObj.c] exit Object_releaseObject 1\n");
}

static char *g_kwlist[] = {"obj", NULL};

PyObject* JSONToObj(PyObject* self, PyObject *args, PyObject *kwargs)
{
  fprintf(stderr, "[python/JSONtoObj.c] enter JSONToObj 1\n");
  PyObject *ret;
  PyObject *sarg;
  PyObject *arg;
  JSONObjectDecoder decoder =
  {
    Object_newString,
    Object_objectAddKey,
    Object_arrayAddItem,
    Object_newTrue,
    Object_newFalse,
    Object_newNull,
    Object_newNaN,
    Object_newPosInf,
    Object_newNegInf,
    Object_newObject,
    Object_newArray,
    Object_newInteger,
    Object_newLong,
    Object_newUnsignedLong,
    Object_newIntegerFromString,
    Object_newDouble,
    Object_releaseObject,
    PyObject_Malloc,
    PyObject_Free,
    PyObject_Realloc
  };

  decoder.prv = NULL;
  fprintf(stderr, "[python/JSONtoObj.c] exit JSONToObj 1\n");

  if (!PyArg_ParseTupleAndKeywords(args, kwargs, "O", g_kwlist, &arg))
  {
      fprintf(stderr, "[python/JSONtoObj.c] enter JSONToObj 2\n");
      return NULL;
      fprintf(stderr, "[python/JSONtoObj.c] exit JSONToObj 2\n");
  }

  fprintf(stderr, "[python/JSONtoObj.c] enter JSONToObj 3\n");
  Py_buffer buffer;
  size_t sarg_length;
  char * raw;
  bool is_bytes_like = !PyObject_GetBuffer(arg, &buffer, PyBUF_C_CONTIGUOUS);
  fprintf(stderr, "[python/JSONtoObj.c] exit JSONToObj 3\n");
  
  if (is_bytes_like)
  {
    fprintf(stderr, "[python/JSONtoObj.c] enter JSONToObj 4\n");
    #ifdef PYPY_VERSION
      // PyPy's buffer protocol implementation is buggy: https://foss.heptapod.net/pypy/pypy/-/issues/3872
      if (!PyBytes_Check(arg) && !PyByteArray_Check(arg)) {
        fprintf(stderr, "[python/JSONtoObj.c] enter JSONToObj 5\n");
        PyBuffer_Release(&buffer);
        PyErr_Format(PyExc_TypeError, "Arbitrary bytes-like objects are not supported on PyPy, Use either string, bytes, or bytearray");
        return NULL;
        fprintf(stderr, "[python/JSONtoObj.c] exit JSONToObj 5\n");
      }
    #endif
    raw = buffer.buf;
    sarg_length = buffer.len;
    fprintf(stderr, "[python/JSONtoObj.c] exit JSONToObj 4\n");
  }
  else
  {
    fprintf(stderr, "[python/JSONtoObj.c] enter JSONToObj 6\n");
    PyErr_Clear();
    fprintf(stderr, "[python/JSONtoObj.c] exit JSONToObj 6\n");
    
    if (PyUnicode_Check(arg))
    {
      fprintf(stderr, "[python/JSONtoObj.c] enter JSONToObj 7\n");
      sarg = PyUnicode_AsEncodedString(arg, NULL, "surrogatepass");
      if (sarg == NULL)
      {
        fprintf(stderr, "[python/JSONtoObj.c] enter JSONToObj 8\n");
        //Exception raised above us by codec according to docs
        return NULL;
        fprintf(stderr, "[python/JSONtoObj.c] exit JSONToObj 8\n");
      }
      sarg_length = PyBytes_Size(sarg);
      raw = PyBytes_AsString(sarg);
      fprintf(stderr, "[python/JSONtoObj.c] exit JSONToObj 7\n");
    }
    else
    {
      fprintf(stderr, "[python/JSONtoObj.c] enter JSONToObj 9\n");
      #ifdef PYPY_VERSION
        PyErr_Format(PyExc_TypeError, "Expected string, bytes, or bytearray");
      #else
        PyErr_Format(PyExc_TypeError, "Expected string or C-contiguous bytes-like object");
      #endif
      return NULL;
      fprintf(stderr, "[python/JSONtoObj.c] exit JSONToObj 9\n");
    }
  }

  fprintf(stderr, "[python/JSONtoObj.c] enter JSONToObj 10\n");
  decoder.errorStr = NULL;
  decoder.errorOffset = NULL;

  decoder.s2d = NULL;
  dconv_s2d_init(&decoder.s2d, DCONV_S2D_ALLOW_TRAILING_JUNK, 0.0, 0.0, "Infinity", "NaN");

  ret = JSON_DecodeObject(&decoder, raw, sarg_length);

  dconv_s2d_free(&decoder.s2d);
  fprintf(stderr, "[python/JSONtoObj.c] exit JSONToObj 10\n");

  if (!is_bytes_like)
  {
    fprintf(stderr, "[python/JSONtoObj.c] enter JSONToObj 11\n");
    Py_DECREF(sarg);
    fprintf(stderr, "[python/JSONtoObj.c] exit JSONToObj 11\n");
  }
  else
  {
    fprintf(stderr, "[python/JSONtoObj.c] enter JSONToObj 12\n");
    PyBuffer_Release(&buffer);
    fprintf(stderr, "[python/JSONtoObj.c] exit JSONToObj 12\n");
  }

  // Check if a Python error occurred during decoding
  if (PyErr_Occurred())
  {
    fprintf(stderr, "[python/JSONtoObj.c] enter JSONToObj 100\n");
    if (ret)
    {
      fprintf(stderr, "[python/JSONtoObj.c] enter JSONToObj 101\n");
      Py_DECREF( (PyObject *) ret);
      fprintf(stderr, "[python/JSONtoObj.c] exit JSONToObj 101\n");
    }
    return NULL;
    fprintf(stderr, "[python/JSONtoObj.c] exit JSONToObj 100\n");
  }

  if (decoder.errorStr)
  {
    fprintf(stderr, "[python/JSONtoObj.c] enter JSONToObj 13\n");
    /*
    FIXME: It's possible to give a much nicer error message here with actual failing element in input etc*/

    PyErr_Format (JSONDecodeError, "%s", decoder.errorStr);

    if (ret)
    {
        fprintf(stderr, "[python/JSONtoObj.c] enter JSONToObj 14\n");
        Py_DECREF( (PyObject *) ret);
        fprintf(stderr, "[python/JSONtoObj.c] exit JSONToObj 14\n");
    }

    return NULL;
    fprintf(stderr, "[python/JSONtoObj.c] exit JSONToObj 13\n");
  }

  fprintf(stderr, "[python/JSONtoObj.c] enter JSONToObj 15\n");
  return ret;
  fprintf(stderr, "[python/JSONtoObj.c] exit JSONToObj 15\n");
}

PyObject* JSONFileToObj(PyObject* self, PyObject *args, PyObject *kwargs)
{
  fprintf(stderr, "[python/JSONtoObj.c] enter JSONFileToObj 1\n");
  PyObject *read;
  PyObject *string;
  PyObject *result;
  PyObject *file = NULL;
  PyObject *argtuple;
  fprintf(stderr, "[python/JSONtoObj.c] exit JSONFileToObj 1\n");

  if (!PyArg_ParseTuple (args, "O", &file))
  {
    fprintf(stderr, "[python/JSONtoObj.c] enter JSONFileToObj 2\n");
    return NULL;
    fprintf(stderr, "[python/JSONtoObj.c] exit JSONFileToObj 2\n");
  }

  fprintf(stderr, "[python/JSONtoObj.c] enter JSONFileToObj 3\n");
  if (!PyObject_HasAttrString (file, "read"))
  {
    fprintf(stderr, "[python/JSONtoObj.c] enter JSONFileToObj 4\n");
    PyErr_Format (PyExc_TypeError, "expected file");
    return NULL;
    fprintf(stderr, "[python/JSONtoObj.c] exit JSONFileToObj 4\n");
  }

  read = PyObject_GetAttrString (file, "read");
  fprintf(stderr, "[python/JSONtoObj.c] exit JSONFileToObj 3\n");

  fprintf(stderr, "[python/JSONtoObj.c] enter JSONFileToObj 5\n");
  if (!PyCallable_Check (read)) {
    fprintf(stderr, "[python/JSONtoObj.c] enter JSONFileToObj 6\n");
    Py_XDECREF(read);
    PyErr_Format (PyExc_TypeError, "expected file");
    return NULL;
    fprintf(stderr, "[python/JSONtoObj.c] exit JSONFileToObj 6\n");
  }

  string = PyObject_CallObject (read, NULL);
  Py_XDECREF(read);
  fprintf(stderr, "[python/JSONtoObj.c] exit JSONFileToObj 5\n");

  fprintf(stderr, "[python/JSONtoObj.c] enter JSONFileToObj 7\n");
  if (string == NULL)
  {
    fprintf(stderr, "[python/JSONtoObj.c] enter JSONFileToObj 8\n");
    return NULL;
    fprintf(stderr, "[python/JSONtoObj.c] exit JSONFileToObj 8\n");
  }

  argtuple = PyTuple_Pack(1, string);
  fprintf(stderr, "[python/JSONtoObj.c] exit JSONFileToObj 7\n");

  fprintf(stderr, "[python/JSONtoObj.c] enter JSONFileToObj 9\n");
  result = JSONToObj (self, argtuple, kwargs);

  Py_XDECREF(argtuple);
  Py_XDECREF(string);
  fprintf(stderr, "[python/JSONtoObj.c] exit JSONFileToObj 9\n");

  fprintf(stderr, "[python/JSONtoObj.c] enter JSONFileToObj 10\n");
  if (result == NULL) {
    fprintf(stderr, "[python/JSONtoObj.c] enter JSONFileToObj 11\n");
    return NULL;
    fprintf(stderr, "[python/JSONtoObj.c] exit JSONFileToObj 11\n");
  }

  return result;
  fprintf(stderr, "[python/JSONtoObj.c] exit JSONFileToObj 10\n");
}

// Total cost: 0.080979
// Total split cost: 0.000000, input tokens: 0, output tokens: 0. Split chunks: [(0, 316)]
// Total instrumented cost: 0.080979, input tokens: 5048, output tokens: 4389
